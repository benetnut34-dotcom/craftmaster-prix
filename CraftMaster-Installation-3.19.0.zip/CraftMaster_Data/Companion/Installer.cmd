@echo off
rem CraftMaster - installe le compagnon des prix Blizzard (double-clic).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
echo.
pause
