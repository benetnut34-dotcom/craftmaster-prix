# CraftMaster - compagnon des prix Blizzard
#
# Telecharge les hotels des ventes de WoW Forever depuis l'API officielle de
# Blizzard (Battle.net) et les ecrit dans l'addon CraftMaster_Data, que
# CraftMaster lit a la connexion ou au /reload. Lance toutes les heures par une
# tache planifiee (voir Installer.cmd).
#
# La configuration (identifiant API, cle secrete chiffree pour ton compte
# Windows) et l'etat (prix les plus bas des 14 derniers jours) restent dans
# %LOCALAPPDATA%\CraftMaster. La cle n'est jamais ecrite dans l'addon.
#
# Compatible Windows PowerShell 5.1 (installe d'office) et PowerShell 7.
#
# -Force : telecharge meme en pause (Lancer.cmd, icone > Synchroniser maintenant).
# Pause : fichier %LOCALAPPDATA%\CraftMaster\pause, pose par l'icone (Icone.ps1).

param([switch]$Force)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Home2 = Join-Path $env:LOCALAPPDATA 'CraftMaster'
$ConfigPath = Join-Path $Home2 'config.json'
$StatePath = Join-Path $Home2 'state.json'
$LogPath = Join-Path $Home2 'sync.log'
$AddonDir = Split-Path -Parent $PSScriptRoot          # ...\AddOns\CraftMaster_Data
$OutPath = Join-Path $AddonDir 'Data.lua'
$KeepDays = 14

# En pause (icone de la zone de notification) : la tache horaire ne fait rien.
if (-not $Force -and (Test-Path (Join-Path $Home2 'pause'))) { exit 0 }

function Log([string]$msg) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $msg
    Write-Host $line
    try {
        if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 512KB)) {
            Move-Item -Force $LogPath ($LogPath + '.old')
        }
        Add-Content -Path $LogPath -Value $line -Encoding UTF8
    } catch { }
}

# Les trois hotels de chaque type de serveur (Alliance, Horde, commune).
# L'API ne dit pas a quel type appartient chaque hotel : correspondance
# relevee par la communaute (110/113/116 = JcJ, 111/114/117 = JcE...).
# CraftMaster la verifie en comparant avec tes propres scans.
$HOUSES = @{
    'PvP'  = @(110, 113, 116)
    'PvE'  = @(111, 114, 117)
    'RP'   = @(119, 120, 121)
    'RPvP' = @(123, 124, 125)
}
$RULESET_IDS = @{ 'PvP' = 1; 'PvE' = 2; 'RP' = 3; 'RPvP' = 15 }
$SIDES = @('Alliance', 'Horde', 'Neutral')

# --- JSON (les reponses font jusqu'a ~9 Mo : trop pour ConvertFrom-Json en 5.1)
$script:Json = $null
try {
    Add-Type -AssemblyName System.Web.Extensions
    $script:Json = New-Object System.Web.Script.Serialization.JavaScriptSerializer
    $script:Json.MaxJsonLength = [int]::MaxValue
    $script:Json.RecursionLimit = 1000
} catch { $script:Json = $null }

function FromJson([string]$text) {
    if ($script:Json) { return $script:Json.DeserializeObject($text) }
    return ($text | ConvertFrom-Json -AsHashtable)
}
function ToJson($obj) {
    if ($script:Json) { return $script:Json.Serialize($obj) }
    return ($obj | ConvertTo-Json -Depth 10 -Compress)
}
function Get-Field($obj, [string]$name) {
    if ($null -eq $obj) { return $null }
    if ($obj -is [System.Collections.IDictionary]) {
        # Dictionary<string,object> (JavaScriptSerializer) n'expose Contains que
        # par l'interface : il faut passer par elle
        if (([System.Collections.IDictionary]$obj).Contains($name)) { return $obj[$name] }
        return $null
    }
    return $obj.$name
}

# --- configuration
if (-not (Test-Path $ConfigPath)) {
    Log "Pas de configuration ($ConfigPath) : lance d'abord Installer.cmd."
    exit 2
}
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
$region = ([string]$cfg.region).ToLower()
if (-not $region) { $region = 'eu' }
$ruleset = [string]$cfg.ruleset
if (-not $HOUSES.ContainsKey($ruleset)) {
    Log "Type de serveur inconnu dans la configuration : '$ruleset' (PvP, PvE, RP ou RPvP)."
    exit 2
}
# --- l'addon : nouvelle version ? (installee ici a chaque passage, voir CraftMasterUpdate.ps1)
try {
    & (Join-Path $PSScriptRoot 'CraftMasterUpdate.ps1') -Auto | Out-Null
} catch { Log "Mise a jour de l'addon : $($_.Exception.Message)" }

# --- prix partages : on recopie simplement le fichier publie (aucun identifiant)
if ($cfg.mode -eq 'shared') {
    $url = [string]$cfg.url
    $etagPath = Join-Path $Home2 'shared.etag'
    $stamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

    # Ce que l'addon lit en jeu (pages Donnees et Accueil), ecrit en tete de Data.lua :
    #   synced = derniere verification, got = dernier telechargement,
    #   comp = version de ce script, task = version de la tache planifiee installee
    #   (task.version, ecrit par Planifier.ps1 ; plus ancienne que VERSION = relancer Installer.cmd).
    function Set-Header([string]$text, [long]$synced, [long]$got) {
        $comp = 0; $task = 0
        try { $comp = [int]((Get-Content -Raw (Join-Path $PSScriptRoot 'VERSION')).Trim()) } catch { }
        try { $task = [int]((Get-Content -Raw (Join-Path $Home2 'task.version')).Trim()) } catch { }
        if ($got -le 0 -and $text -match 'got = (\d+), ') { $got = [long]$Matches[1] }
        $text = $text -replace '(synced|got|comp|task) = \d+, ', ''
        $text = $text -replace '(ver|latest|upd) = "[^"]*", ', ''
        # l'addon installe sur le disque, la derniere version publiee, et l'etat de la mise a jour
        $ver = ''; $latest = ''; $upd = ''
        try {
            $u = Get-Content -Raw (Join-Path $Home2 'update.json') | ConvertFrom-Json
            $ver = [string]$u.installed; $latest = [string]$u.latest; $upd = [string]$u.status
        } catch { }
        $head = "synced = $synced, "
        if ($got -gt 0) { $head += "got = $got, " }
        $head += "comp = $comp, task = $task, ver = `"$ver`", latest = `"$latest`", upd = `"$upd`", "
        return ($text -replace 'CraftMasterData = \{ ', ('CraftMasterData = { ' + $head))
    }
    function Set-SyncedStamp([string]$path, [long]$when) {
        $t = Set-Header ([IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)) $when 0
        $tmp = $path + '.tmp'
        [IO.File]::WriteAllText($tmp, $t, (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -Force $tmp $path
    }

    # Au reveil de la veille, le reseau met parfois une minute a revenir : 4 essais.
    $resp = $null
    $lastErr = ''
    for ($try = 1; $try -le 4 -and -not $resp; $try++) {
        $req = [System.Net.HttpWebRequest]::Create($url)
        $req.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
        $req.Timeout = 120000
        $req.ReadWriteTimeout = 120000
        $req.UserAgent = 'CraftMaster-compagnon'
        if ((Test-Path $etagPath) -and (Test-Path $OutPath) -and ((Get-Item $OutPath).Length -gt 200)) {
            $req.Headers.Add('If-None-Match', (Get-Content -Raw $etagPath).Trim())
        }
        try { $resp = $req.GetResponse() }
        catch [System.Net.WebException] {
            $r = $_.Exception.Response
            if ($r -and [int]$r.StatusCode -eq 304) {
                try { Set-SyncedStamp $OutPath $stamp } catch { }
                Log 'Prix partages : deja a jour (pas de nouveaux prix depuis le dernier passage).'
                exit 0
            }
            if ($r) { Log "Prix partages : HTTP $([int]$r.StatusCode) sur $url"; exit 4 }
            $lastErr = $_.Exception.Message
            if ($try -lt 4) { Log "Prix partages : reseau pas pret (essai $try/4) : $lastErr"; Start-Sleep -Seconds 20 }
        }
    }
    if (-not $resp) { Log "Prix partages : $lastErr"; exit 4 }
    try {
        $etag = $resp.Headers['ETag']
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
        $text = $reader.ReadToEnd()
        $reader.Close()
    } finally { $resp.Close() }
    if ($text -notmatch 'CraftMasterData = \{') { Log 'Prix partages : fichier inattendu, ignore.'; exit 4 }
    # origine locale : quand ce PC a recopie le fichier (synced = derniere verification, got = dernier telechargement)
    $text = Set-Header $text $stamp $stamp
    $tmp = $OutPath + '.tmp'
    [IO.File]::WriteAllText($tmp, $text, (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -Force $tmp $OutPath
    if ($etag) { Set-Content -Path $etagPath -Value $etag -Encoding ASCII }
    Log "Prix partages recopies : $OutPath ($([math]::Round($text.Length / 1KB)) Ko). /reload en jeu pour les voir."
    exit 0
}

$houseIds = $HOUSES[$ruleset]
if ($cfg.houses) { $houseIds = @($cfg.houses) }       # correction manuelle possible

$secure = ConvertTo-SecureString ([string]$cfg.secret)
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $secret = ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)).Trim() }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }

# --- etat
$state = @{ token = ''; tokenUntil = 0; modified = @{}; lows = @{}; snap = @{} }
if (Test-Path $StatePath) {
    try {
        $loaded = FromJson (Get-Content -Raw -Path $StatePath -Encoding UTF8)
        foreach ($k in @('token', 'tokenUntil', 'modified', 'lows', 'snap')) {
            $v = Get-Field $loaded $k
            if ($null -ne $v) { $state[$k] = $v }
        }
    } catch { Log "Etat illisible, on repart de zero : $($_.Exception.Message)" }
}
function AsDict($v) {
    $d = @{}
    if ($v -is [System.Collections.IDictionary]) { foreach ($k in $v.Keys) { $d[[string]$k] = $v[$k] } }
    elseif ($null -ne $v) { foreach ($p in $v.PSObject.Properties) { $d[$p.Name] = $p.Value } }
    return $d
}
$state.modified = AsDict $state.modified
$state.lows = AsDict $state.lows
$state.snap = AsDict $state.snap

$now = [int64][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

# --- jeton
function Get-Token {
    if ($state.token -and ([int]$state.tokenUntil -gt ($now + 300))) { return $state.token }
    $pair = [Text.Encoding]::UTF8.GetBytes(([string]$cfg.clientId).Trim() + ':' + $secret)
    $headers = @{ Authorization = 'Basic ' + [Convert]::ToBase64String($pair) }
    $r = Invoke-RestMethod -Method Post -Uri 'https://oauth.battle.net/token' -Headers $headers `
        -Body @{ grant_type = 'client_credentials' } -ContentType 'application/x-www-form-urlencoded'
    $state.token = $r.access_token
    $state.tokenUntil = $now + [int]$r.expires_in
    return $state.token
}

# GET avec If-Modified-Since : $null quand rien n'a change depuis la derniere fois.
function Get-Api([string]$path, [string]$tag) {
    $url = "https://$region.api.blizzard.com$path" + "?namespace=dynamic-forever-$region&locale=en_GB"
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.Method = 'GET'
    $req.Headers.Add('Authorization', 'Bearer ' + (Get-Token))
    $req.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $req.Timeout = 120000
    $req.ReadWriteTimeout = 120000
    $prev = $state.modified[$tag]
    if ($prev) { try { $req.IfModifiedSince = [DateTime]::Parse($prev).ToUniversalTime() } catch { } }
    try {
        $resp = $req.GetResponse()
    } catch [System.Net.WebException] {
        $r = $_.Exception.Response
        if ($r -and [int]$r.StatusCode -eq 304) { return $null }
        if ($r) { throw "HTTP $([int]$r.StatusCode) sur $path" }
        throw
    }
    try {
        $lm = $resp.Headers['Last-Modified']
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
        $text = $reader.ReadToEnd()
        $reader.Close()
    } finally { $resp.Close() }
    $at = $now
    if ($lm) { try { $at = [int]([DateTimeOffset]::Parse($lm).ToUnixTimeSeconds()) } catch { } }
    return @{ text = $text; at = $at; lastModified = $lm }
}

# Les annonces -> prix unitaire le plus bas et quantite totale par objet.
function Add-Auctions($list, $items, [bool]$commodity) {
    if ($null -eq $list) { return }
    foreach ($a in $list) {
        $item = Get-Field $a 'item'
        $id = [int](Get-Field $item 'id')
        $qty = [int](Get-Field $a 'quantity')
        if ($id -le 0 -or $qty -le 0) { continue }
        $unit = 0
        if ($commodity) { $unit = [double](Get-Field $a 'unit_price') }
        else {
            $buyout = Get-Field $a 'buyout'
            if ($null -ne $buyout) { $unit = [double]$buyout / $qty }
        }
        $cur = $items[$id]
        if ($null -eq $cur) { $cur = @(0, 0); $items[$id] = $cur }
        if ($unit -gt 0 -and ($cur[0] -eq 0 -or $unit -lt $cur[0])) { $cur[0] = [math]::Floor($unit) }
        $cur[1] = $cur[1] + $qty
    }
}

# Le jeton d'abord : si Blizzard refuse les identifiants, inutile d'aller plus loin.
try { [void](Get-Token) }
catch {
    $code = ''
    try { $code = [int]$_.Exception.Response.StatusCode } catch { }
    if ($code -eq 401 -or $code -eq 400) {
        Log "Blizzard refuse l'identifiant ou la cle secrete (HTTP $code). Relance Installer.cmd et recolle-les (develop.battle.net > API Access > ton client)."
        exit 3
    }
    Log "Jeton Blizzard impossible a obtenir : $($_.Exception.Message)"
    exit 3
}

$rsId = $RULESET_IDS[$ruleset]
$changed = $false
$day = [int][math]::Floor($now / 86400)

for ($i = 0; $i -lt 3; $i++) {
    $hid = [int]$houseIds[$i]
    $key = $ruleset + '-' + $SIDES[$i]
    try {
        $main = Get-Api "/data/wow/ruleset/$rsId/auctions/$hid" "a$hid"
        $comm = Get-Api "/data/wow/ruleset/$rsId/auctions/$hid/commodities" "c$hid"
        if ($null -eq $main -and $null -eq $comm) { Log "$key (hotel $hid) : pas de nouvelles donnees."; continue }
        # un seul des deux a change : il faut quand meme l'autre pour une photo complete
        if ($null -eq $main) { $state.modified.Remove("a$hid"); $main = Get-Api "/data/wow/ruleset/$rsId/auctions/$hid" "a$hid" }
        if ($null -eq $comm) { $state.modified.Remove("c$hid"); $comm = Get-Api "/data/wow/ruleset/$rsId/auctions/$hid/commodities" "c$hid" }
        $items = @{}
        $at = 0
        foreach ($part in @(@{ r = $main; c = $false }, @{ r = $comm; c = $true })) {
            if ($null -eq $part.r) { continue }
            $data = FromJson $part.r.text
            Add-Auctions (Get-Field $data 'auctions') $items $part.c
            if ($part.r.at -gt $at) { $at = $part.r.at }
        }
        if ($main) { $state.modified["a$hid"] = $main.lastModified }
        if ($comm) { $state.modified["c$hid"] = $comm.lastModified }
        if ($items.Count -eq 0) { Log "$key (hotel $hid) : hotel vide."; continue }

        # photo du moment
        $sb = New-Object System.Text.StringBuilder
        foreach ($id in $items.Keys) {
            $e = $items[$id]
            if ($e[0] -gt 0) { [void]$sb.Append($id).Append(':').Append([int64]$e[0]).Append(':').Append($e[1]).Append(';') }
        }
        $state.snap[$key] = @{ id = $hid; at = $at; items = $sb.ToString() }

        # plus bas du jour, 14 jours
        $lows = AsDict $state.lows[$key]
        $d = [int][math]::Floor($at / 86400)
        foreach ($id in $items.Keys) {
            $p = [int64]$items[$id][0]
            if ($p -le 0) { continue }
            $sid = [string]$id
            $days = @{}
            $old = [string]$lows[$sid]
            if ($old) {
                foreach ($pair in $old.Split(',')) {
                    $kv = $pair.Split(':')
                    if ($kv.Count -eq 2 -and ([int]$kv[0] -gt $day - $KeepDays)) { $days[[int]$kv[0]] = [int64]$kv[1] }
                }
            }
            if (-not $days.ContainsKey($d) -or $p -lt $days[$d]) { $days[$d] = $p }
            $lows[$sid] = (($days.Keys | Sort-Object | ForEach-Object { "$($_):$($days[$_])" }) -join ',')
        }
        $state.lows[$key] = $lows
        $changed = $true
        Log ("{0} (hotel {1}) : {2} objets, donnees de {3:HH:mm}." -f $key, $hid, $items.Count, ([DateTimeOffset]::FromUnixTimeSeconds($at).LocalDateTime))
    } catch {
        Log "$key (hotel $hid) : erreur : $($_.Exception.Message)"
    }
}

# --- nettoyage des jours trop vieux et ecriture de l'addon
if ($changed -or -not (Test-Path $OutPath)) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('-- Ecrit par le compagnon CraftMaster (API Blizzard). Ne pas modifier.')
    [void]$sb.AppendLine(('CraftMasterData = {{ v = 1, at = {0}, region = "{1}", ruleset = "{2}", houses = {{' -f $now, $region, $ruleset))
    foreach ($key in @($state.snap.Keys)) {
        $s = AsDict $state.snap[$key]
        $lows = AsDict $state.lows[$key]
        $lb = New-Object System.Text.StringBuilder
        foreach ($sid in @($lows.Keys)) {
            $kept = @()
            foreach ($pair in ([string]$lows[$sid]).Split(',')) {
                $kv = $pair.Split(':')
                if ($kv.Count -eq 2 -and ([int]$kv[0] -gt $day - $KeepDays)) { $kept += $pair }
            }
            if ($kept.Count -eq 0) { $lows.Remove($sid); continue }
            $lows[$sid] = ($kept -join ',')
            [void]$lb.Append($sid).Append('=').Append($lows[$sid]).Append(';')
        }
        $state.lows[$key] = $lows
        [void]$sb.AppendLine(('["{0}"] = {{ id = {1}, at = {2},' -f $key, $s.id, $s.at))
        [void]$sb.AppendLine('items = "' + $s.items + '",')
        [void]$sb.AppendLine('lows = "' + $lb.ToString() + '" },')
    }
    [void]$sb.AppendLine('} }')
    $tmp = $OutPath + '.tmp'
    [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -Force $tmp $OutPath
    Log "Ecrit : $OutPath ($([math]::Round((Get-Item $OutPath).Length / 1KB)) Ko). /reload en jeu pour les voir."
}

[IO.File]::WriteAllText($StatePath, (ToJson $state), (New-Object System.Text.UTF8Encoding($false)))
exit 0
