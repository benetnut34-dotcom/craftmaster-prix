# CraftMaster - tache planifiee des prix Blizzard
#
# Cree (ou remplace) la tache "CraftMaster - prix Blizzard". Elle lance
# CraftMasterSync.ps1 :
#   - toutes les heures (a h32 : les prix partages sont publies vers h21) ;
#   - a l'ouverture de session Windows ;
#   - au reveil du PC apres une mise en veille (les passages horaires manques
#     pendant la veille ne sont pas rattrapes par Windows).
# Si le reseau n'est pas encore pret, le script reessaie lui-meme.
# Sans danger a relancer : la tache est simplement remplacee.

$ErrorActionPreference = 'Stop'
$Script = Join-Path $PSScriptRoot 'CraftMasterSync.ps1'
$name = 'CraftMaster - prix Blizzard'
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$psArgs = '-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + $Script + '"'
# Sans fenetre : powershell.exe est un programme console, Windows lui ouvre une
# fenetre (au premier plan) avant que -WindowStyle Hidden ne la cache, d'ou le
# flash noir a chaque passage. "conhost.exe --headless" (Windows 10 1809 et plus)
# lui donne une console invisible : aucune fenetre ne s'ouvre. Sur un Windows plus
# ancien, on garde l'ancien lancement.
$conhost = Join-Path $env:SystemRoot 'System32\conhost.exe'
if ((Test-Path $conhost) -and [Environment]::OSVersion.Version.Build -ge 17763) {
    $action = New-ScheduledTaskAction -Execute $conhost -Argument ('--headless "' + $ps + '" ' + $psArgs)
} else {
    $action = New-ScheduledTaskAction -Execute $ps -Argument $psArgs
}

# 1. toutes les heures
$start = (Get-Date).Date.AddHours((Get-Date).Hour + 1).AddMinutes(32)
$hourly = New-ScheduledTaskTrigger -Once -At $start -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)

# 2. a l'ouverture de session (1 minute de delai : le temps que le reseau arrive)
$logon = New-ScheduledTaskTrigger -AtLogOn -User ($env:USERDOMAIN + '\' + $env:USERNAME)
$logon.Delay = 'PT1M'

# 3. au reveil de la veille (evenement 1 de Power-Troubleshooter)
$cls = Get-CimClass -ClassName MSFT_TaskEventTrigger -Namespace Root/Microsoft/Windows/TaskScheduler
$query = '<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name=''Microsoft-Windows-Power-Troubleshooter''] and EventID=1]]</Select></Query></QueryList>'
$wake = New-CimInstance -CimClass $cls -ClientOnly -Property @{ Enabled = $true; Subscription = $query; Delay = 'PT1M' }

$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries `
    -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 5) `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 20)
$principal = New-ScheduledTaskPrincipal -UserId ($env:USERDOMAIN + '\' + $env:USERNAME) -LogonType Interactive -RunLevel Limited

Register-ScheduledTask -TaskName $name -Action $action -Trigger @($hourly, $logon, $wake) -Settings $settings -Principal $principal `
    -Description 'Recopie les prix de l''hotel des ventes WoW Forever pour CraftMaster : toutes les heures, a l''ouverture de session et au reveil du PC.' -Force | Out-Null
Write-Host "Tache planifiee '$name' : toutes les heures, a l'ouverture de session et au reveil du PC." -ForegroundColor Green

# Icone de la zone de notification (Icone.ps1) : etat du compagnon, pause, arret.
# Lancee a l'ouverture de session, sans limite de duree ; une seule a la fois.
$iconName = 'CraftMaster - icone'
$icon = Join-Path $PSScriptRoot 'Icone.ps1'
$iconArgs = '-NoProfile -NonInteractive -STA -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + $icon + '"'
if ((Test-Path $conhost) -and [Environment]::OSVersion.Version.Build -ge 17763) {
    $iconAction = New-ScheduledTaskAction -Execute $conhost -Argument ('--headless "' + $ps + '" ' + $iconArgs)
} else {
    $iconAction = New-ScheduledTaskAction -Execute $ps -Argument $iconArgs
}
$iconLogon = New-ScheduledTaskTrigger -AtLogOn -User ($env:USERDOMAIN + '\' + $env:USERNAME)
$iconSettings = New-ScheduledTaskSettingsSet -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Seconds 0)
Register-ScheduledTask -TaskName $iconName -Action $iconAction -Trigger $iconLogon -Settings $iconSettings -Principal $principal `
    -Description 'Icone CraftMaster en bas a droite : etat des prix Blizzard, pause et arret du compagnon.' -Force | Out-Null
try { Start-ScheduledTask -TaskName $iconName } catch { }
Write-Host "Icone CraftMaster ajoutee en bas a droite (clic droit : pause, arret, journal)." -ForegroundColor Green

# On note la version installee : Verifier.ps1 et l'addon (page Accueil) la comparent a VERSION.
$home2 = Join-Path $env:LOCALAPPDATA 'CraftMaster'
New-Item -ItemType Directory -Force -Path $home2 | Out-Null
$ver = '0'
try { $ver = (Get-Content -Raw (Join-Path $PSScriptRoot 'VERSION')).Trim() } catch { }
Set-Content -Path (Join-Path $home2 'task.version') -Value $ver -Encoding ASCII
