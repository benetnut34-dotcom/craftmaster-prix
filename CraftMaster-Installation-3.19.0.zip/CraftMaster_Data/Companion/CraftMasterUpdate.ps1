# CraftMaster - mise a jour de l'addon
#
# Compare la version de l'addon installe (CraftMaster\CraftMaster.toc, ligne
# "## Version:") a la derniere publiee (latest.json), et la installe quand elle est
# plus recente. Lance :
#   - a chaque passage de CraftMasterSync.ps1 (-Auto : installe sans rien demander) ;
#   - par l'icone (menu "Mettre a jour l'addon") et quand le bouton de l'addon en jeu
#     le demande (-Install) ;
#   - a la main : -Check dit s'il y a une nouvelle version sans rien installer.
#
# Ce qui est telecharge : un zip qui ne contient que le dossier CraftMaster (du Lua,
# des fichiers XML, des images). Rien n'est installe si :
#   - l'empreinte SHA-256 du zip n'est pas celle annoncee par latest.json ;
#   - une entree sort du dossier CraftMaster, ou n'est pas d'un type d'addon
#     (.lua .toc .xml .png .tga .blp .ttf) : jamais de script, jamais d'executable ;
#   - la version du .toc du zip n'est pas celle annoncee.
# Les scripts de ce dossier (Companion) ne sont JAMAIS mis a jour par ici : ils
# tournent sur ton PC avec tes droits. Quand ils changent, latest.json le dit
# ("companion") et l'addon demande de relancer Installer.cmd.
# L'ancienne version est gardee (%LOCALAPPDATA%\CraftMaster\backup) et remise en
# place si l'installation echoue. Les reglages et l'historique (WTF) ne sont pas touches.
#
# Ecrit %LOCALAPPDATA%\CraftMaster\update.json : installed, latest, status
# (ok | available | installed | error), checked, installedAt, error.
# Compatible Windows PowerShell 5.1 et PowerShell 7.

param(
    [switch]$Auto,                 # installe si une version plus recente existe
    [switch]$Install,              # idem (demande explicite : icone, bouton en jeu)
    [switch]$Check,                # regarde seulement
    [switch]$Force,                # reinstalle la derniere version meme si elle est deja la (jamais une plus ancienne)
    [string]$ManifestUrl,          # test : adresse (ou chemin) de latest.json
    [string]$AddonsPath,           # test : dossier AddOns
    [string]$HomeDir               # test : dossier d'etat
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Home2 = if ($HomeDir) { $HomeDir } else { Join-Path $env:LOCALAPPDATA 'CraftMaster' }
New-Item -ItemType Directory -Force -Path $Home2 | Out-Null
$LogPath = Join-Path $Home2 'sync.log'
$StatusPath = Join-Path $Home2 'update.json'
$DefaultBase = 'https://raw.githubusercontent.com/benetnut34-dotcom/craftmaster-prix/release/'
$AllowedExt = @('.lua', '.toc', '.xml', '.png', '.tga', '.blp', '.ttf', '.txt')

function Log([string]$msg) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $msg
    Write-Host $line
    try { Add-Content -Path $LogPath -Value $line -Encoding UTF8 } catch { }
}

function Save-Status([hashtable]$s) {
    $old = @{}
    try {
        if (Test-Path $StatusPath) {
            $o = Get-Content -Raw -Path $StatusPath | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) { $old[$p.Name] = $p.Value }
        }
    } catch { }
    foreach ($k in $s.Keys) { $old[$k] = $s[$k] }
    $old['checked'] = [int64][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $tmp = $StatusPath + '.tmp'
    [IO.File]::WriteAllText($tmp, ($old | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -Force $tmp $StatusPath
}

function Get-Cfg {
    $p = Join-Path $Home2 'config.json'
    if (Test-Path $p) { try { return Get-Content -Raw -Path $p | ConvertFrom-Json } catch { } }
    return $null
}
$cfg = Get-Cfg

# le dossier AddOns : celui du test, celui de la configuration, sinon celui ou tournent ces scripts
$addons = $AddonsPath
if (-not $addons -and $cfg -and $cfg.addons) { $addons = [string]$cfg.addons }
if (-not $addons) { $addons = Split-Path -Parent (Split-Path -Parent $PSScriptRoot) }
$addonDir = Join-Path $addons 'CraftMaster'

function Get-TocVersion([string]$toc) {
    if (-not (Test-Path $toc)) { return $null }
    foreach ($l in (Get-Content -Path $toc -Encoding UTF8 -TotalCount 40)) {
        if ($l -match '^\s*##\s*Version:\s*([0-9]+(\.[0-9]+){1,3})\s*$') { return $Matches[1] }
    }
    return $null
}
function Test-Newer([string]$latest, [string]$have) {
    try { return ([version]$latest) -gt ([version]$have) } catch { return $false }
}

function Read-Remote([string]$source) {
    # un chemin local (tests) ou une adresse web : le texte ; ou le chemin du fichier telecharge
    if ($source -match '^[A-Za-z]:\\' -or $source -like '\\\\*') {
        return [IO.File]::ReadAllText($source, [Text.Encoding]::UTF8)
    }
    $last = ''
    for ($try = 1; $try -le 3; $try++) {
        try {
            $req = [System.Net.HttpWebRequest]::Create($source)
            $req.UserAgent = 'CraftMaster-compagnon'
            $req.Timeout = 60000
            $req.Headers.Add('Cache-Control', 'no-cache')
            $resp = $req.GetResponse()
            try {
                $rd = New-Object System.IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
                return $rd.ReadToEnd()
            } finally { $resp.Close() }
        } catch { $last = $_.Exception.Message; Start-Sleep -Seconds (5 * $try) }
    }
    throw $last
}
function Get-RemoteFile([string]$source, [string]$dest) {
    if ($source -match '^[A-Za-z]:\\' -or $source -like '\\\\*') { Copy-Item -Force $source $dest; return }
    $last = ''
    for ($try = 1; $try -le 3; $try++) {
        try {
            $wc = New-Object System.Net.WebClient
            $wc.Headers.Add('User-Agent', 'CraftMaster-compagnon')
            $wc.DownloadFile($source, $dest)
            return
        } catch { $last = $_.Exception.Message; Start-Sleep -Seconds (5 * $try) }
    }
    throw $last
}

try {
    $have = Get-TocVersion (Join-Path $addonDir 'CraftMaster.toc')
    if (-not $have) {
        Save-Status @{ installed = ''; status = 'error'; error = 'addon introuvable' }
        Log "Mise a jour : addon introuvable dans $addons."
        exit 2
    }
    $base = $DefaultBase
    if ($cfg -and $cfg.updateUrl) { $base = [string]$cfg.updateUrl }
    if (-not $base.EndsWith('/') -and -not $base.EndsWith('\')) { $base += '/' }
    $manUrl = if ($ManifestUrl) { $ManifestUrl } else { $base + 'latest.json' }

    $man = (Read-Remote $manUrl) | ConvertFrom-Json
    $latest = [string]$man.version
    if ($latest -notmatch '^[0-9]+(\.[0-9]+){1,3}$') { throw "latest.json : version illisible ('$latest')" }
    $companion = 0
    try { $companion = [int]$man.companion } catch { }

    $newer = Test-Newer $latest $have
    $again = $Force -and -not (Test-Newer $have $latest)     # forcee : la meme version, ou une plus recente
    if (-not $newer -and -not $again) {
        Save-Status @{ installed = $have; latest = $latest; status = 'ok'; error = ''; companion = $companion }
        Log "Addon a jour : version $have."
        exit 0
    }
    Save-Status @{ installed = $have; latest = $latest; status = 'available'; error = ''; companion = $companion }
    if ($Check -or -not ($Auto -or $Install -or $Force)) {
        Log "Nouvelle version de l'addon : $have -> $latest (pas installee)."
        exit 0
    }

    # --- telechargement et verification
    $work = Join-Path $Home2 'update'
    if (Test-Path $work) { Remove-Item -Recurse -Force $work }
    New-Item -ItemType Directory -Force -Path $work | Out-Null
    $zipSrc = [string]$man.zip
    if ($zipSrc -notmatch '^(https?://|[A-Za-z]:\\|\\\\)') {
        if ($manUrl -match '^[A-Za-z]:\\') { $zipSrc = Join-Path (Split-Path -Parent $manUrl) $zipSrc } else { $zipSrc = $base + $zipSrc }
    }
    $zipPath = Join-Path $work 'addon.zip'
    Log "Mise a jour de l'addon : $have -> $latest ($zipSrc)"
    Get-RemoteFile $zipSrc $zipPath
    $hash = (Get-FileHash -Algorithm SHA256 -Path $zipPath).Hash.ToLower()
    if ($hash -ne ([string]$man.sha256).ToLower()) { throw "empreinte SHA-256 differente (attendue $($man.sha256), recue $hash) : zip refuse" }

    # --- extraction controlee, fichier par fichier
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $stage = Join-Path $work 'stage'
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    $stageRoot = [IO.Path]::GetFullPath($stage).TrimEnd('\') + '\'
    $zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        foreach ($e in $zip.Entries) {
            $name = $e.FullName.Replace('\', '/')
            if (-not $name.StartsWith('CraftMaster/')) { throw "entree hors du dossier CraftMaster : $name" }
            if ($name.Contains('..')) { throw "entree suspecte : $name" }
            if ($name.EndsWith('/')) { continue }
            $ext = [IO.Path]::GetExtension($name).ToLower()
            if ($AllowedExt -notcontains $ext -and [IO.Path]::GetFileName($name) -ne 'LICENSE') { throw "type de fichier refuse : $name" }
            $target = [IO.Path]::GetFullPath((Join-Path $stage $name))
            if (-not $target.StartsWith($stageRoot)) { throw "entree hors du dossier : $name" }
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
        }
    } finally { $zip.Dispose() }
    $newVer = Get-TocVersion (Join-Path $stage 'CraftMaster\CraftMaster.toc')
    if ($newVer -ne $latest) { throw "le zip contient la version '$newVer' au lieu de '$latest'" }

    # --- remplacement, avec retour arriere
    $incoming = $addonDir + '.new'
    if (Test-Path $incoming) { Remove-Item -Recurse -Force $incoming }
    Copy-Item -Recurse -Force (Join-Path $stage 'CraftMaster') $incoming
    $backupRoot = Join-Path $Home2 'backup'
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $backup = Join-Path $backupRoot ('CraftMaster-' + $have)
    if (Test-Path $backup) { Remove-Item -Recurse -Force $backup }
    $moved = $false
    try {
        Move-Item -Path $addonDir -Destination $backup
        $moved = $true
        Move-Item -Path $incoming -Destination $addonDir
    } catch {
        if ($moved -and -not (Test-Path $addonDir) -and (Test-Path $backup)) { Move-Item -Path $backup -Destination $addonDir }
        throw
    }
    # on ne garde que la derniere sauvegarde
    foreach ($d in (Get-ChildItem -Path $backupRoot -Directory | Sort-Object LastWriteTime -Descending | Select-Object -Skip 1)) {
        try { Remove-Item -Recurse -Force $d.FullName } catch { }
    }
    Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
    Save-Status @{ installed = $latest; latest = $latest; status = 'installed'; error = ''; installedAt = [int64][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
    Log "Addon mis a jour : version $latest installee. /reload en jeu pour l'activer (ancienne version gardee : $backup)."
    exit 0
} catch {
    $m = $_.Exception.Message
    try { Save-Status @{ status = 'error'; error = $m } } catch { }
    Log "Mise a jour de l'addon : $m"
    exit 4
}
