# CraftMaster - installation du compagnon des prix Blizzard
# Demande l'identifiant API, l'enregistre pour ton compte Windows (la cle
# secrete est chiffree par Windows et illisible depuis un autre compte ou un
# autre PC), cree la tache planifiee horaire et fait un premier passage.

$ErrorActionPreference = 'Stop'
$Home2 = Join-Path $env:LOCALAPPDATA 'CraftMaster'
New-Item -ItemType Directory -Force -Path $Home2 | Out-Null
$ConfigPath = Join-Path $Home2 'config.json'

# --- ou est le dossier AddOns de WoW Forever ?
# Ce script peut tourner de deux endroits : depuis le dossier AddOns lui-meme (depot Git),
# ou depuis le zip decompresse n'importe ou (Telechargements...). Dans le second cas on cherche
# le dossier AddOns de WoW Forever, puis on y copie l'addon et le compagnon.
function Resolve-AddOns([string]$p) {
    if (-not $p) { return $null }
    $p = $p.Trim().Trim('"').TrimEnd([char]92)
    if (-not (Test-Path $p)) { return $null }
    if ((Split-Path -Leaf $p) -eq 'AddOns' -and (Split-Path -Leaf (Split-Path -Parent $p)) -eq 'Interface') { return $p }
    $try = Join-Path $p 'Interface\AddOns'
    if (Test-Path $try) { return $try }
    $try = Join-Path $p '_forever_\Interface\AddOns'
    if (Test-Path $try) { return $try }
    return $null
}
function Find-AddOnsCandidates {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($k in @('HKLM:\SOFTWARE\WOW6432Node\Blizzard Entertainment\World of Warcraft', 'HKLM:\SOFTWARE\Blizzard Entertainment\World of Warcraft')) {
        try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).InstallPath; if ($v) { $roots.Add([string]$v) } } catch { }
    }
    foreach ($d in (Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Za-z]:\\$' })) {
        foreach ($sub in @('Program Files (x86)\World of Warcraft', 'Program Files\World of Warcraft', 'World of Warcraft', 'Games\World of Warcraft', 'Jeux\World of Warcraft')) {
            $roots.Add((Join-Path $d.Root $sub))
        }
    }
    $found = @()
    foreach ($r in $roots) {
        $a = Join-Path $r '_forever_\Interface\AddOns'
        if ((Test-Path $a) -and ($found -notcontains $a)) { $found += $a }
    }
    return $found
}
function Select-AddOnsFolder {
    Write-Host ''
    Write-Host 'Je n''ai pas trouve le dossier AddOns de WoW Forever tout seul.' -ForegroundColor Yellow
    Write-Host 'Choisis le dossier ou est installe WoW Forever (celui qui contient le dossier _forever_).' -ForegroundColor Yellow
    Write-Host 'Il me faut le chemin vers son dossier AddOns, par exemple :' -ForegroundColor Yellow
    Write-Host '   C:\Program Files (x86)\World of Warcraft\_forever_\Interface\AddOns' -ForegroundColor Yellow
    for ($i = 1; $i -le 5; $i++) {
        $picked = $null
        try {
            Add-Type -AssemblyName System.Windows.Forms
            $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
            $dlg.Description = "Dossier ou est installe WoW Forever. Choisis son dossier AddOns : ...\World of Warcraft\_forever_\Interface\AddOns (ou le dossier World of Warcraft, je trouverai la suite)."
            $dlg.ShowNewFolderButton = $false
            $top = New-Object System.Windows.Forms.Form
            $top.TopMost = $true
            if ($dlg.ShowDialog($top) -eq 'OK') { $picked = $dlg.SelectedPath }
            $top.Dispose()
        } catch { }
        if (-not $picked) { $picked = Read-Host 'Colle le chemin du dossier AddOns (vide pour abandonner)' }
        if (-not $picked) { return $null }
        $ok = Resolve-AddOns $picked
        if ($ok) { return $ok }
        Write-Host "  '$picked' ne contient pas WoW Forever (Interface\AddOns introuvable). Reessaie." -ForegroundColor Red
    }
    return $null
}

$Pkg = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)          # dossier qui contient CraftMaster et CraftMaster_Data
$AddOns = Resolve-AddOns $Pkg
if ($AddOns -and ((Split-Path -Leaf $Pkg) -ne 'AddOns')) { $AddOns = $null }
if (-not $AddOns) {
    $saved = $null
    if (Test-Path $ConfigPath) { try { $saved = (Get-Content -Raw $ConfigPath | ConvertFrom-Json).addons } catch { } }
    $found = @(Find-AddOnsCandidates)
    if ($saved -and (Test-Path $saved) -and ($found -notcontains $saved)) { $found = @($saved) + $found }
    if ($found.Count -ge 1) {
        Write-Host 'Dossier AddOns de WoW Forever trouve :'
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host ("  {0} = {1}" -f ($i + 1), $found[$i]) }
        $c = Read-Host ('Numero a utiliser [1], ou 0 pour en choisir un autre')
        if (-not $c) { $c = '1' }
        if ($c -match '^\d+$' -and [int]$c -ge 1 -and [int]$c -le $found.Count) { $AddOns = $found[[int]$c - 1] }
    }
    if (-not $AddOns) { $AddOns = Select-AddOnsFolder }
    if (-not $AddOns) { throw 'Dossier AddOns de WoW Forever introuvable : rien n''a ete installe.' }
    Write-Host "Installation dans : $AddOns" -ForegroundColor Green
    # copie de l'addon et du compagnon (le Data.lua existant n'est jamais ecrase)
    foreach ($name in @('CraftMaster', 'CraftMaster_Data')) {
        $src = Join-Path $Pkg $name
        $dst = Join-Path $AddOns $name
        if (-not (Test-Path $src)) { throw "$name est absent du paquet ($src)." }
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Get-ChildItem -Path $src -Recurse -Force | ForEach-Object {
            $rel = $_.FullName.Substring($src.Length).TrimStart([char]92)
            $target = Join-Path $dst $rel
            if ($_.PSIsContainer) { New-Item -ItemType Directory -Force -Path $target | Out-Null }
            elseif (-not (($name -eq 'CraftMaster_Data') -and ($rel -eq 'Data.lua') -and (Test-Path $target))) { Copy-Item -Force $_.FullName $target }
        }
    }
}
$CompanionDir = Join-Path $AddOns 'CraftMaster_Data\Companion'
# les scripts viennent d'un zip telecharge : Windows les marque « venus d'internet »; on leve la marque
Get-ChildItem -Path (Join-Path $AddOns 'CraftMaster_Data') -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$Script = Join-Path $CompanionDir 'CraftMasterSync.ps1'

Write-Host ''
Write-Host '=== CraftMaster : prix de l''hotel des ventes depuis l''API Blizzard ===' -ForegroundColor Yellow
Write-Host ''

function Ask([string]$label, [string]$default) {
    $hint = ''
    if ($default) { $hint = " [$default]" }
    $v = Read-Host ($label + $hint)
    if (-not $v) { return $default }
    return $v.Trim()
}

$old = $null
if (Test-Path $ConfigPath) { $old = Get-Content -Raw $ConfigPath | ConvertFrom-Json }

Write-Host 'Comment recuperer les prix ?'
Write-Host '  1 = prix partages (aucun identifiant, recommande)'
Write-Host '  2 = ma propre cle API Blizzard'
$defMode = '1'
if ($old -and $old.mode -eq 'own') { $defMode = '2' }
$mode = 'shared'
if ((Ask 'Choix' $defMode) -eq '2') { $mode = 'own' }


$region = (Ask 'Region (eu, us, kr, tw)' $(if ($old) { $old.region } else { 'eu' })).ToLower()
if ($mode -eq 'shared') {
    # Les prix partages ne sont publies que pour le serveur JcJ (PvP).
    Write-Host 'Prix partages : serveur JcJ (PvP) uniquement.' -ForegroundColor Green
    $ruleset = 'PvP'
} else {
    Write-Host 'Type de serveur : PvP = JcJ, PvE = JcE (Normal), RP = JdR, RPvP = JdR-JcJ'
    $ruleset = Ask 'Type de serveur' $(if ($old) { $old.ruleset } else { 'PvP' })
}
$map = @{ 'pvp' = 'PvP'; 'jcj' = 'PvP'; 'pve' = 'PvE'; 'jce' = 'PvE'; 'normal' = 'PvE'; 'rp' = 'RP'; 'jdr' = 'RP'; 'rpvp' = 'RPvP'; 'rp-pvp' = 'RPvP'; 'jdr-jcj' = 'RPvP' }
if ($map.ContainsKey($ruleset.ToLower())) { $ruleset = $map[$ruleset.ToLower()] } else { throw "Type de serveur inconnu : $ruleset" }

$SharedUrl = 'https://raw.githubusercontent.com/benetnut34-dotcom/craftmaster-prix/data/Data-{0}.lua'
if ($mode -eq 'own') {
# Demande l'identifiant et la cle, et les essaie aupres de Blizzard avant de les garder.
    function Test-Credentials([string]$id, [string]$plain) {
        $pair = [Text.Encoding]::UTF8.GetBytes($id + ':' + $plain)
        $headers = @{ Authorization = 'Basic ' + [Convert]::ToBase64String($pair) }
        try {
            $r = Invoke-RestMethod -Method Post -Uri 'https://oauth.battle.net/token' -Headers $headers `
                -Body @{ grant_type = 'client_credentials' } -ContentType 'application/x-www-form-urlencoded'
            return [bool]$r.access_token
        } catch {
            $code = ''
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            Write-Host "  Refuse par Blizzard (HTTP $code) : $($_.Exception.Message)" -ForegroundColor Red
            return $false
        }
    }
    function Plain([Security.SecureString]$s) {
        $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
        try { return ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)).Trim() }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
    }
    
    $clientId = $null
    $secretEnc = $null
    for ($try = 1; $try -le 3; $try++) {
        $default = ''
        if ($old) { $default = $old.clientId }
        if ($clientId) { $default = $clientId }
        $clientId = (Ask 'Client ID' $default)
        if ($clientId) { $clientId = $clientId.Trim() }
        if (-not $clientId) { throw 'Client ID manquant.' }
        $plain = $null
        if ($try -eq 1 -and $old -and $old.secret) {
            $keep = Read-Host 'Garder le Client Secret deja enregistre ? (O/n)'
            if ($keep -notmatch '^[nN]') { $plain = Plain (ConvertTo-SecureString $old.secret) }
        }
        if (-not $plain) {
            # La saisie masquee de Windows PowerShell n'accepte pas le collage :
            # on lit la cle dans le presse-papiers, puis on le vide.
            Write-Host 'Sur develop.battle.net, COPIE le Client Secret (Ctrl+C), puis reviens ici et appuie sur Entree.' -ForegroundColor Yellow
            [void](Read-Host 'Entree quand c''est copie')
            $clip = ''
            try { $clip = [string](Get-Clipboard -Raw) } catch { }
            if (-not $clip) { try { Add-Type -AssemblyName System.Windows.Forms; $clip = [System.Windows.Forms.Clipboard]::GetText() } catch { } }
            $plain = ([string]$clip).Trim()
            try { Set-Clipboard -Value ' ' } catch { }
            if (-not $plain) {
                Write-Host 'Presse-papiers vide : tape le Client Secret a la main (il s''affichera).'
                $plain = ([string](Read-Host 'Client Secret')).Trim()
            }
            if ($plain.Length -ge 4) {
                Write-Host ("  Lu : {0}...{1}" -f $plain.Substring(0, 2), $plain.Substring($plain.Length - 2))
            }
        }
        Write-Host ("  Client ID : {0} caracteres, Client Secret : {1} caracteres (normalement 32 chacun)." -f $clientId.Length, $plain.Length)
        Write-Host '  Verification aupres de Blizzard...'
        if (Test-Credentials $clientId $plain) {
            Write-Host '  Identifiants acceptes.' -ForegroundColor Green
            $secretEnc = ConvertFrom-SecureString (ConvertTo-SecureString $plain -AsPlainText -Force)
            break
        }
        Write-Host '  Verifie sur https://develop.battle.net/access/clients : le Client ID et le Client Secret de ton client (pas inverses).' -ForegroundColor Yellow
    }
    $plain = $null
    if (-not $secretEnc) { throw 'Identifiants refuses 3 fois : rien n''a ete enregistre.' }
    $cfg = [ordered]@{ mode = 'own'; region = $region; ruleset = $ruleset; clientId = $clientId; secret = $secretEnc }
    if ($old -and $old.houses) { $cfg.houses = $old.houses }
} else {
    $cfg = [ordered]@{ mode = 'shared'; region = $region; ruleset = $ruleset; url = ($SharedUrl -f $ruleset) }
    Write-Host ("Prix partages : " + $cfg.url) -ForegroundColor Green
}
$cfg['addons'] = $AddOns
($cfg | ConvertTo-Json) | Set-Content -Path $ConfigPath -Encoding UTF8
Write-Host "Configuration enregistree : $ConfigPath" -ForegroundColor Green

# Tache planifiee : toutes les heures, a l'ouverture de session et au reveil du PC.
& (Join-Path $CompanionDir 'Planifier.ps1')
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

Write-Host ''
Write-Host 'Premier telechargement (1 a 2 minutes)...' -ForegroundColor Yellow
& $ps -NoProfile -ExecutionPolicy Bypass -File $Script -Force
Write-Host ''
Write-Host 'Termine. Les prix et l''addon se mettent a jour tout seuls. En jeu : /reload, puis /craftmaster diag.' -ForegroundColor Green
Write-Host "Journal : $(Join-Path $Home2 'sync.log')"
