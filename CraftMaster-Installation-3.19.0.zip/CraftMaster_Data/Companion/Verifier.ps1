# CraftMaster - Installer.cmd doit-il etre relance ?
#
# A lancer apres chaque "git pull" (les CLAUDE.md le demandent a Claude) :
#   powershell -NoProfile -ExecutionPolicy Bypass -File CraftMaster_Data\Companion\Verifier.ps1
# Ne modifie rien. Code de sortie 0 = a jour ; 3 = RELANCER Installer.cmd.
#
# CraftMasterSync.ps1 tourne depuis le depot : un "git pull" le met a jour tout
# seul. Seule la tache planifiee (ses declencheurs) doit etre recreee : c'est ce
# que fait Installer.cmd (via Planifier.ps1, qui note la version installee dans
# %LOCALAPPDATA%\CraftMaster\task.version). VERSION = la version attendue ; elle
# monte a chaque changement de la tache.

$ErrorActionPreference = 'Stop'
$need = 0
try { $need = [int]((Get-Content -Raw (Join-Path $PSScriptRoot 'VERSION')).Trim()) }
catch { Write-Output 'ERREUR : VERSION illisible dans le dossier Companion.'; exit 2 }

$home2 = Join-Path $env:LOCALAPPDATA 'CraftMaster'
if (-not (Test-Path (Join-Path $home2 'config.json'))) {
    Write-Output 'RELANCER_INSTALLER : le compagnon n''a jamais ete installe sur ce PC (pas de configuration). Lance CraftMaster_Data\Companion\Installer.cmd (choix 1, region eu).'
    exit 3
}
$task = $null
try { $task = Get-ScheduledTask -TaskName 'CraftMaster - prix Blizzard' -ErrorAction Stop } catch { }
if (-not $task) {
    Write-Output 'RELANCER_INSTALLER : la tache planifiee ''CraftMaster - prix Blizzard'' n''existe pas. Lance CraftMaster_Data\Companion\Installer.cmd (choix 1, region eu).'
    exit 3
}
$done = 0
try { $done = [int]((Get-Content -Raw (Join-Path $home2 'task.version')).Trim()) } catch { }
if ($done -lt $need) {
    Write-Output "RELANCER_INSTALLER : la tache planifiee est en version $done, la version $need est attendue (nouveaux declencheurs). Lance CraftMaster_Data\Companion\Installer.cmd (choix 1, region eu), puis un /reload en jeu."
    exit 3
}
Write-Output "OK : le compagnon est a jour (tache en version $done)."
exit 0
