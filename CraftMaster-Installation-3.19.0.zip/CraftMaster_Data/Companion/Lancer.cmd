@echo off
rem CraftMaster - telecharge les prix Blizzard tout de suite (sans attendre la tache horaire).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CraftMasterSync.ps1" -Force
echo.
pause
