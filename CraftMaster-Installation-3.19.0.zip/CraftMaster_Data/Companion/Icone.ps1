﻿# CraftMaster - icône du compagnon dans la zone de notification (en bas à droite)
#
# Lancée à l'ouverture de session par la tâche « CraftMaster - icône » (créée par
# Planifier.ps1). Elle montre l'état du compagnon des prix Blizzard et permet de le
# couper :
#   - pièce dorée : tout va bien ; bleue : téléchargement en cours ;
#     grise : en pause ; orange : prix en retard ; rouge : le dernier passage a échoué ;
#   - clic droit : synchroniser maintenant, mettre en pause / reprendre, arrêter le
#     passage en cours, ouvrir le journal, fermer l'icône ;
#   - double-clic : synchroniser maintenant.
# La pause est un simple fichier %LOCALAPPDATA%\CraftMaster\pause : tant qu'il
# existe, la tâche horaire ne télécharge rien (CraftMasterSync.ps1 s'arrête tout de
# suite). Lancer.cmd et « Synchroniser maintenant » passent outre.
# Une seule icône à la fois. Ne lit ni n'affiche aucune clé.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$mutex = New-Object System.Threading.Mutex($false, 'Local\CraftMasterIcone')
if (-not $mutex.WaitOne(0)) { exit 0 }      # déjà lancée

$Home2 = Join-Path $env:LOCALAPPDATA 'CraftMaster'
$LogPath = Join-Path $Home2 'sync.log'
$PausePath = Join-Path $Home2 'pause'
$Sync = Join-Path $PSScriptRoot 'CraftMasterSync.ps1'
$UpdateScript = Join-Path $PSScriptRoot 'CraftMasterUpdate.ps1'
$UpdatePath = Join-Path $Home2 'update.json'
$ConfigPath = Join-Path $Home2 'config.json'
$DataPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'Data.lua'
$Ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$Conhost = Join-Path $env:SystemRoot 'System32\conhost.exe'

# --- les pièces (dessinées ici, une fois pour toutes)
function New-Coin([System.Drawing.Color]$fill, [System.Drawing.Color]$edge) {
    $bmp = New-Object System.Drawing.Bitmap(32, 32)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.FillEllipse((New-Object System.Drawing.SolidBrush($fill)), 2, 2, 28, 28)
    $g.DrawEllipse((New-Object System.Drawing.Pen($edge, 3)), 3, 3, 26, 26)
    $font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $fmt = New-Object System.Drawing.StringFormat
    $fmt.Alignment = 'Center'; $fmt.LineAlignment = 'Center'
    $g.DrawString('C', $font, (New-Object System.Drawing.SolidBrush($edge)), (New-Object System.Drawing.RectangleF(0, 1, 32, 32)), $fmt)
    $g.Dispose()
    return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
$C = [System.Drawing.Color]
$Icons = @{
    ok      = New-Coin $C::FromArgb(242, 196, 62) $C::FromArgb(140, 98, 18)
    running = New-Coin $C::FromArgb(98, 168, 245) $C::FromArgb(24, 74, 140)
    paused  = New-Coin $C::FromArgb(170, 170, 176) $C::FromArgb(80, 80, 88)
    late    = New-Coin $C::FromArgb(245, 150, 50) $C::FromArgb(140, 70, 10)
    error   = New-Coin $C::FromArgb(230, 80, 70) $C::FromArgb(120, 20, 20)
}

# --- état du compagnon
function Get-SyncProcesses {
    try {
        return @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' AND CommandLine LIKE '%CraftMasterSync.ps1%'" -ErrorAction Stop)
    } catch { return @() }
}
function Get-LastLog {
    try {
        if (Test-Path $LogPath) {
            $l = Get-Content -Path $LogPath -Tail 1 -Encoding UTF8
            if ($l) { return [string]$l }
        }
    } catch { }
    return ''
}
function Get-Synced {
    # « synced = … » en tête de Data.lua : dernière vérification réussie
    try {
        if (Test-Path $DataPath) {
            $r = New-Object System.IO.StreamReader($DataPath)
            $buf = New-Object char[] 400
            $n = $r.Read($buf, 0, 400); $r.Close()
            $head = New-Object string($buf, 0, $n)
            if ($head -match 'synced = (\d+)') { return [DateTimeOffset]::FromUnixTimeSeconds([long]$Matches[1]).LocalDateTime }
        }
    } catch { }
    return $null
}
function Get-State {
    $s = @{ running = (Get-SyncProcesses).Count -gt 0; paused = Test-Path $PausePath; synced = Get-Synced; last = Get-LastLog }
    $s.failed = $s.last -match '(erreur|refuse|impossible|HTTP \d|Pas de configuration|inattendu|inconnu)' -and $s.last -notmatch 'essai \d/'
    $s.late = (-not $s.synced) -or (((Get-Date) - $s.synced).TotalHours -gt 2)
    if ($s.running) { $s.key = 'running'; $s.text = 'Téléchargement des prix en cours...' }
    elseif ($s.paused) { $s.key = 'paused'; $s.text = 'En pause : aucun téléchargement' }
    elseif ($s.failed) { $s.key = 'error'; $s.text = 'Le dernier passage a échoué (voir le journal)' }
    elseif ($s.late) { $s.key = 'late'; $s.text = 'Prix en retard' }
    else { $s.key = 'ok'; $s.text = 'Prix à jour' }
    if ($s.synced) { $s.when = 'Dernière vérification : ' + $s.synced.ToString('dd/MM HH:mm') }
    else { $s.when = 'Aucune vérification pour l''instant' }
    return $s
}

# --- l'addon : version installée, dernière version publiée (update.json, écrit par CraftMasterUpdate.ps1)
function Get-AddonState {
    $a = @{ installed = ''; latest = ''; status = ''; error = '' }
    try {
        if (Test-Path $UpdatePath) {
            $u = Get-Content -Raw -Path $UpdatePath -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @('installed', 'latest', 'status', 'error')) { if ($u.$k) { $a[$k] = [string]$u.$k } }
        }
    } catch { }
    return $a
}
function Get-UpdateProcesses {
    try {
        return @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' AND CommandLine LIKE '%CraftMasterUpdate.ps1%'" -ErrorAction Stop)
    } catch { return @() }
}
function Start-UpdateNow([bool]$force = $false) {
    if ((Get-UpdateProcesses).Count -gt 0) { return }
    $args2 = '-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + $UpdateScript + '" -Install'
    if ($force) { $args2 += ' -Force' }
    if ((Test-Path $Conhost) -and [Environment]::OSVersion.Version.Build -ge 17763) {
        Start-Process -FilePath $Conhost -ArgumentList ('--headless "' + $Ps + '" ' + $args2) -WindowStyle Hidden
    } else {
        Start-Process -FilePath $Ps -ArgumentList $args2 -WindowStyle Hidden
    }
}

# --- demande de mise à jour faite depuis le jeu (bouton « Mettre à jour » de l'addon) :
# l'addon écrit « updateAsk = <heure> » dans ses variables sauvegardées (fichier CraftMaster.lua du dossier
# WTF\Account\*\SavedVariables, écrit au /reload). On regarde ces fichiers toutes les 5 secondes (une simple
# date de fichier : la lecture n'a lieu que s'il a changé).
$script:askSeen = @{}
function Get-AskFiles {
    $cfg = $null
    try { $cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json } catch { }
    $addons = if ($cfg -and $cfg.addons) { [string]$cfg.addons } else { Split-Path -Parent (Split-Path -Parent $PSScriptRoot) }
    $wtf = Join-Path (Split-Path -Parent (Split-Path -Parent $addons)) 'WTF\Account'
    if (-not (Test-Path $wtf)) { return @() }
    return @(Get-ChildItem -Path $wtf -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $f = Join-Path $_.FullName 'SavedVariables\CraftMaster.lua'
        if (Test-Path $f) { Get-Item $f }
    })
}
function Test-AskFromGame {
    foreach ($f in (Get-AskFiles)) {
        $stamp = $f.LastWriteTimeUtc.Ticks
        if ($script:askSeen[$f.FullName] -eq $stamp) { continue }
        $first = -not $script:askSeen.ContainsKey($f.FullName)
        $script:askSeen[$f.FullName] = $stamp
        if ($first) { continue }                  # au premier regard on note seulement la date
        try {
            $txt = [IO.File]::ReadAllText($f.FullName)
            if ($txt -match '\["updateAsk"\]\s*=\s*(\d+)') {
                $ask = [long]$Matches[1]
                $done = 0
                try { $done = [long](Get-Content -Raw (Join-Path $Home2 'update.asked')) } catch { }
                if ($ask -gt $done) {
                    Set-Content -Path (Join-Path $Home2 'update.asked') -Value $ask -Encoding ASCII
                    # « Forcer » dans l'addon écrit aussi updateForce = la meme heure
                    $force = ($txt -match '\["updateForce"\]\s*=\s*(\d+)') -and ([long]$Matches[1] -eq $ask)
                    Start-UpdateNow $force
                    return
                }
            }
        } catch { }
    }
}

# --- actions
function Start-SyncNow {
    if ((Get-SyncProcesses).Count -gt 0) { return }
    $args2 = '-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + $Sync + '" -Force'
    if ((Test-Path $Conhost) -and [Environment]::OSVersion.Version.Build -ge 17763) {
        Start-Process -FilePath $Conhost -ArgumentList ('--headless "' + $Ps + '" ' + $args2) -WindowStyle Hidden
    } else {
        Start-Process -FilePath $Ps -ArgumentList $args2 -WindowStyle Hidden
    }
}
function Stop-SyncNow {
    foreach ($p in Get-SyncProcesses) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop } catch { } }
}
function Set-Paused([bool]$on) {
    try {
        if ($on) {
            New-Item -ItemType Directory -Force -Path $Home2 | Out-Null
            Set-Content -Path $PausePath -Value (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Encoding ASCII
            Stop-SyncNow
        } elseif (Test-Path $PausePath) {
            Remove-Item -Force $PausePath
        }
    } catch { }
}

# --- l'icône et son menu
$tray = New-Object System.Windows.Forms.NotifyIcon
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$mTitle = $menu.Items.Add('CraftMaster - prix Blizzard'); $mTitle.Enabled = $false
$mTitle.Font = New-Object System.Drawing.Font($mTitle.Font, [System.Drawing.FontStyle]::Bold)
$mState = $menu.Items.Add(''); $mState.Enabled = $false
$mWhen = $menu.Items.Add(''); $mWhen.Enabled = $false
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$mAddon = $menu.Items.Add(''); $mAddon.Enabled = $false
$mUpdate = $menu.Items.Add('Mettre à jour l''addon')
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$mNow = $menu.Items.Add('Synchroniser maintenant')
$mPause = $menu.Items.Add('Mettre en pause')
$mStop = $menu.Items.Add('Arrêter le téléchargement en cours')
$mLog = $menu.Items.Add('Ouvrir le journal')
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$mQuit = $menu.Items.Add('Fermer l''icône (la synchro continue)')

$script:lastKey = ''
function Update-Tray {
    $s = Get-State
    $tray.Icon = $Icons[$s.key]
    $tip = 'CraftMaster : ' + $s.text
    if ($tip.Length -gt 63) { $tip = $tip.Substring(0, 60) + '...' }
    $tray.Text = $tip
    $mState.Text = $s.text
    $mWhen.Text = $s.when
    $a = Get-AddonState
    $newer = $false
    try { $newer = $a.latest -and $a.installed -and ([version]$a.latest -gt [version]$a.installed) } catch { }
    if (-not $a.installed) { $mAddon.Text = 'Addon : version inconnue' }
    elseif ($a.status -eq 'error') { $mAddon.Text = 'Addon ' + $a.installed + ' : mise à jour impossible (voir le journal)' }
    elseif ($newer) { $mAddon.Text = 'Addon ' + $a.installed + ' : la ' + $a.latest + ' est disponible' }
    elseif ($a.latest) { $mAddon.Text = 'Addon ' + $a.installed + ' : à jour (dernière version)' }
    else { $mAddon.Text = 'Addon ' + $a.installed + ' : dernière version pas encore vérifiée' }
    $mUpdate.Visible = $newer
    $mUpdate.Enabled = $newer -and ((Get-UpdateProcesses).Count -eq 0)
    if ($newer) { $mUpdate.Text = 'Mettre à jour l''addon (' + $a.latest + ')' }
    # une bulle quand une nouvelle version vient d'être installée (une seule fois par version)
    if ($a.status -eq 'installed' -and $a.installed -and $script:lastInstalled -and $script:lastInstalled -ne $a.installed) {
        $tray.ShowBalloonTip(8000, 'CraftMaster', ('Addon mis à jour en version ' + $a.installed + '. Tape /reload en jeu (ou clique sur Recharger dans la page Données).'), [System.Windows.Forms.ToolTipIcon]::Info)
    }
    $script:lastInstalled = $a.installed
    $mPause.Text = $(if ($s.paused) { 'Reprendre' } else { 'Mettre en pause' })
    $mNow.Enabled = -not $s.running
    $mStop.Enabled = $s.running
    # une bulle quand un passage échoue (une seule fois par échec)
    if ($s.key -eq 'error' -and $script:lastKey -ne 'error' -and $script:lastKey -ne '') {
        $tray.ShowBalloonTip(8000, 'CraftMaster', 'Le téléchargement des prix a échoué. Clic droit sur la pièce > Ouvrir le journal.', [System.Windows.Forms.ToolTipIcon]::Warning)
    }
    $script:lastKey = $s.key
}

$mUpdate.add_Click({ Start-UpdateNow; Start-Sleep -Milliseconds 300; Update-Tray })
$mNow.add_Click({ Start-SyncNow; Start-Sleep -Milliseconds 300; Update-Tray })
$mPause.add_Click({ Set-Paused (-not (Test-Path $PausePath)); Update-Tray })
$mStop.add_Click({ Stop-SyncNow; Start-Sleep -Milliseconds 300; Update-Tray })
$mLog.add_Click({ if (Test-Path $LogPath) { Start-Process notepad.exe -ArgumentList ('"' + $LogPath + '"') } })
$mQuit.add_Click({ $tray.Visible = $false; [System.Windows.Forms.Application]::Exit() })
$tray.add_DoubleClick({ Start-SyncNow; Start-Sleep -Milliseconds 300; Update-Tray })
$menu.add_Opening({ Update-Tray })
$tray.ContextMenuStrip = $menu

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 5000
$timer.add_Tick({ Test-AskFromGame; Update-Tray })

Update-Tray
$tray.Visible = $true
$timer.Start()
try {
    [System.Windows.Forms.Application]::Run()
} finally {
    $timer.Stop()
    $tray.Visible = $false
    $tray.Dispose()
    $mutex.ReleaseMutex()
}
