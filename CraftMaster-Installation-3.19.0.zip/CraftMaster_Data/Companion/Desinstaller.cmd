@echo off
rem CraftMaster - retire la tache planifiee et la configuration du compagnon.
powershell.exe -NoProfile -Command "Unregister-ScheduledTask -TaskName 'CraftMaster - prix Blizzard' -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName 'CraftMaster - icone' -Confirm:$false -ErrorAction SilentlyContinue; Get-CimInstance Win32_Process -Filter \"Name = 'powershell.exe' AND CommandLine LIKE '%%Icone.ps1%%'\" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Remove-Item -Recurse -Force (Join-Path $env:LOCALAPPDATA 'CraftMaster') -ErrorAction SilentlyContinue; Write-Host 'Compagnon retire.'"
pause
