-- Rempli par le compagnon (Installer.cmd).
CraftMasterData = nil
