@echo off
rem CraftMaster - installation (double-clic). Cherche le dossier AddOns de WoW Forever,
rem y copie l'addon et le compagnon, puis installe les telechargements automatiques.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CraftMaster_Data\Companion\Install.ps1"
echo.
pause
