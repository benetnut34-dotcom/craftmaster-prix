local addonName, ns = ...
local L = ns.L
local W = ns.W

-- The window: Buffalo's layout. A header (logo, name, a line that changes
-- each time, the search box), one colored stripe per page under it, the
-- page menu on the left, the page on the right.
local UI = {}
ns.UI = UI

local MEDIA = ns.MEDIA
local WIDTH, HEIGHT = 1200, 680
local MIN_W, MIN_H, MAX_W, MAX_H = 1000, 500, 1700, 1100
local NAV_W, HEADER_H, PAD = 172, 62, 16
local ORDER = { "home", "gmdeals", "gmcrafts", "gmvolume", "compare", "gmplans", "gmops",
                "recipes", "guide", "cart", "codex", "loot", "scans", "timing", "data", "settings" }
-- The menu in groups, under a small heading each (the Home page stays on top, alone).
local GROUPS = {
    { key = "gold", pages = { "gmdeals", "gmcrafts", "gmvolume", "compare", "gmplans", "gmops" } },
    { key = "craft", pages = { "recipes", "guide", "cart" } },
    { key = "bags", pages = { "codex", "loot" } },
    { key = "setup", pages = { "scans", "timing", "data", "settings" } },
}
UI.GROUPS = GROUPS
local HEAD_H = 22   -- the height of a group heading in the menu
UI.NAV_W, UI.HEADER_H, UI.PAD = NAV_W, HEADER_H, PAD

local builders = {}
local pages, navButtons = {}, {}
local win, current

function UI.AddPage(key, build) builders[key] = build end

-- A page that breaks says so in the chat (once per message), so it can be reported.
local reported = {}
function UI.ReportError(key, err)
    local msg = tostring(err)
    if reported[msg] then return end
    reported[msg] = true
    ns.Print("|cffff6060" .. string.format(ns.L.PAGE_ERROR, (ns.L.PAGE[key] or key)) .. "|r " .. msg)
end
function UI.Color(key) return ns.Theme.SECTIONS[key] end
function UI.Frame() return win end
function UI.Current() return current end
function UI.Page(key) return pages[key] end

local function tagline()
    local t = L.TAGLINES
    return (type(t) == "table" and #t > 0) and t[math.random(#t)] or ""
end

local function select(key)
    if not pages[key] then key = "recipes" end
    current = key
    for k, p in pairs(pages) do p.frame:SetShown(k == key) end
    for k, b in pairs(navButtons) do
        local on = k == key
        local c = UI.Color(k)
        b.bar:SetShown(on)
        b.sel:SetShown(on)
        b.label:SetTextColor(on and 1 or 0.8, on and 1 or 0.82, on and 1 or 0.86)
        b.icon:SetVertexColor(c[1], c[2], c[3], on and 1 or 0.65)
    end
    ns.char.page = key
    ns.db.visited = ns.db.visited or {}
    ns.db.visited[key] = true          -- for the first steps on the Home page
    win.search:SetShown(pages[key].search ~= nil)
    if pages[key].search then
        win.search:SetText(pages[key].query or "")
        win.search.hint:SetText(pages[key].search)
        win.search.hint:SetShown((pages[key].query or "") == "")
    end
    UI.Refresh()
end
UI.Select = select

local function build()
    win = CreateFrame("Frame", "CraftMasterWindow", UIParent)
    local saved = ns.char.win
    local w, h = WIDTH, HEIGHT
    local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
    if type(sw) == "number" and sw > 0 then w = math.max(MIN_W, math.min(WIDTH, sw - 60)) end
    if type(sh) == "number" and sh > 0 then h = math.max(MIN_H, math.min(HEIGHT, sh - 60)) end
    if type(saved) == "table" and tonumber(saved[1]) then
        w = math.max(MIN_W, math.min(MAX_W, saved[1]))
        h = math.max(MIN_H, math.min(MAX_H, saved[2]))
    end
    win:SetSize(w, h)
    win:SetPoint("CENTER")
    win:SetResizable(true)
    if win.SetResizeBounds then win:SetResizeBounds(MIN_W, MIN_H, MAX_W, MAX_H)
    elseif win.SetMinResize then win:SetMinResize(MIN_W, MIN_H); win:SetMaxResize(MAX_W, MAX_H) end
    win:SetFrameStrata("HIGH")
    win:SetToplevel(true)
    win:SetClampedToScreen(true)
    win:EnableMouse(true)
    win:SetMovable(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:HookScript("OnMouseDown", function() if win.behind then UI.ToFront() end end)
    win:Hide()
    W.Skin(win, "window")
    tinsert(UISpecialFrames, "CraftMasterWindow")

    local gold = ns.Theme.C.gold
    local logo = win:CreateTexture(nil, "ARTWORK")
    logo:SetSize(42, 42)
    logo:SetPoint("TOPLEFT", win, "TOPLEFT", PAD - 2, -10)
    logo:SetTexture(MEDIA .. "logo.png")
    local title = W.Text(win, "title", "LEFT")
    title:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, -4)
    title:SetText("CraftMaster")
    title:SetTextColor(gold[1], gold[2], gold[3])
    win.tagline = W.Text(win, "small", "LEFT")
    win.tagline:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    local m = ns.Theme.C.label
    win.tagline:SetTextColor(m[1], m[2], m[3])
    win.tagline:SetWordWrap(false)
    win.tagline:SetText(tagline())

    local close = W.Close(win)
    close:SetPoint("TOPRIGHT", win, "TOPRIGHT", -10, -10)
    win.search = W.Input(win, { hint = L.SEARCH, width = 200, onChange = function(t)
        local p = pages[current]
        if p and p.search then p.query = t; if p.OnSearch then p.OnSearch(t) end end
    end })
    win.search:SetPoint("TOPRIGHT", win, "TOPRIGHT", -44, -19)
    win.scanBtn = W.Button(win, L.SCAN_AH, 200, function()
        if ns.Scan.Running() then ns.Scan.Stop() else ns.Scan.Start() end
    end)
    win.scanBtn:SetPoint("RIGHT", win.search, "LEFT", -10, 0)
    W.Tip(win.scanBtn, L.SCAN_AH, L.SCAN_TIP)
    win.scan = W.Text(win, "tiny", "RIGHT")
    win.scan:SetPoint("TOPRIGHT", win.search, "BOTTOMRIGHT", 0, -4)
    win.scan:SetTextColor(m[1], m[2], m[3])

    -- One stripe per page under the header.
    local stripes = {}
    for i, key in ipairs(ORDER) do
        local c = UI.Color(key)
        stripes[i] = win:CreateTexture(nil, "ARTWORK")
        stripes[i]:SetColorTexture(c[1], c[2], c[3], 0.9)
    end
    local function placeStripes()
        local sw2 = win:GetWidth() / #stripes
        for i, s in ipairs(stripes) do
            s:ClearAllPoints()
            s:SetSize(sw2, 2)
            s:SetPoint("TOPLEFT", win, "TOPLEFT", (i - 1) * sw2, -HEADER_H)
        end
    end
    placeStripes()

    -- Resize from the corner.
    local corner = CreateFrame("Frame", nil, win)
    corner:SetSize(18, 18)
    corner:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -2, 2)
    corner:SetFrameLevel(win:GetFrameLevel() + 30)
    corner:EnableMouse(true)
    corner.dots = {}
    for i, at in ipairs({ { -3, 3 }, { -8, 3 }, { -3, 8 }, { -13, 3 }, { -8, 8 }, { -3, 13 } }) do
        local d = corner:CreateTexture(nil, "OVERLAY")
        d:SetSize(2, 2)
        d:SetPoint("BOTTOMRIGHT", corner, "BOTTOMRIGHT", at[1], at[2])
        d:SetColorTexture(1, 1, 1, 0.4)
        corner.dots[i] = d
    end
    corner:SetScript("OnEnter", function(self)
        local r, g, b = W.Accent()
        for _, d in ipairs(self.dots) do d:SetColorTexture(r, g, b, 1) end
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:SetText(L.RESIZE, 1, 1, 1)
        GameTooltip:Show()
    end)
    corner:SetScript("OnLeave", function(self)
        for _, d in ipairs(self.dots) do d:SetColorTexture(1, 1, 1, 0.4) end
        GameTooltip:Hide()
    end)
    corner:SetScript("OnMouseDown", function() win:StartSizing("BOTTOMRIGHT") end)
    corner:SetScript("OnMouseUp", function()
        win:StopMovingOrSizing()
        ns.char.win = { math.floor(win:GetWidth() + 0.5), math.floor(win:GetHeight() + 0.5) }
    end)
    win:SetScript("OnSizeChanged", function()
        placeStripes()
        win.tagline:SetWidth(math.max(40, win:GetWidth() - 770))
        for _, p in pairs(pages) do if p.OnResize then p.OnResize() end end
    end)
    win.tagline:SetWidth(math.max(40, w - 770))

    -- Page menu.
    local nav = CreateFrame("Frame", nil, win)
    nav:SetPoint("TOPLEFT", win, "TOPLEFT", 0, -HEADER_H - 2)
    nav:SetPoint("BOTTOMLEFT", win, "BOTTOMLEFT", 0, 0)
    nav:SetWidth(NAV_W)
    W.Fill(nav, "BACKGROUND", 0, 0, 0, 0.25)
    for i, key in ipairs(ORDER) do
        local c = UI.Color(key)
        local b = CreateFrame("Button", nil, nav)
        b:SetSize(NAV_W, 34)
        b.index = i
        b.sel = b:CreateTexture(nil, "BACKGROUND")
        b.sel:SetAllPoints()
        b.sel:SetColorTexture(c[1], c[2], c[3], 0.14)
        b.bar = b:CreateTexture(nil, "ARTWORK")
        b.bar:SetPoint("TOPLEFT"); b.bar:SetPoint("BOTTOMLEFT")
        b.bar:SetWidth(3)
        b.bar:SetColorTexture(c[1], c[2], c[3], 1)
        local hl = b:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(18, 18)
        b.icon:SetPoint("LEFT", b, "LEFT", 16, 0)
        b.icon:SetTexture(MEDIA .. "nav-" .. key .. ".png")
        b.label = W.Text(b, "body", "LEFT")
        b.label:SetPoint("LEFT", b.icon, "RIGHT", 10, 0)
        b.label:SetText(L.PAGE[key])
        b.badge = W.Text(b, "small", "RIGHT")
        b.badge:SetPoint("RIGHT", b, "RIGHT", -14, 0)
        b.badge:SetTextColor(c[1], c[2], c[3])
        b:SetScript("OnClick", function() select(key) end)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L.PAGE[key], c[1], c[2], c[3])
            GameTooltip:AddLine(L.PAGE_DESC[key], 1, 1, 1, true)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        navButtons[key] = b
    end
    -- the group headings: small, grey, above the pages of each group
    local heads, groupOf = {}, {}
    for _, g in ipairs(GROUPS) do
        local h = W.Text(nav, "tiny", "LEFT")
        h:SetText(L.NAV_GROUP[g.key])
        h:SetTextColor(m[1], m[2], m[3])
        heads[g.key] = h
        groupOf[g.pages[1]] = g.key
    end
    UI.navHeads = heads
    -- the menu tightens when the window is short
    local function placeNav()
        local room = (win:GetHeight() or HEIGHT) - HEADER_H - 2 - 10 - 86 - #GROUPS * HEAD_H
        local step = math.max(26, math.min(36, math.floor(room / #ORDER)))
        local y = -10
        for _, key in ipairs(ORDER) do
            local g = groupOf[key]
            if g then
                heads[g]:ClearAllPoints()
                heads[g]:SetPoint("TOPLEFT", nav, "TOPLEFT", 16, y - 8)
                y = y - HEAD_H
            end
            local b = navButtons[key]
            b:SetHeight(step - 2)
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", nav, "TOPLEFT", 0, y)
            y = y - step
        end
    end
    placeNav()
    win:HookScript("OnSizeChanged", placeNav)
    -- the version at the foot of the menu: is it the latest, a button to update (then to reload),
    -- and one to force the update
    win.verMain = W.Button(nav, L.UPD_BUTTON, 100, function()
        local _, _, action = ns.Update.Menu()
        if action == "update" then ns.Update.Ask() elseif action == "reload" then ns.Update.Reload() end
    end)
    win.verMain:SetHeight(20)
    win.verMain:SetPoint("BOTTOMLEFT", nav, "BOTTOMLEFT", 12, 8)
    win.verForce = W.Button(nav, L.UPD_FORCE, 48, function() ns.Update.Force() end)
    win.verForce:SetHeight(20)
    win.verForce:SetPoint("BOTTOMRIGHT", nav, "BOTTOMRIGHT", -12, 8)
    W.Tip(win.verForce, L.UPD_FORCE, L.UPD_FORCE_TIP)
    local ver = W.Text(nav, "tiny", "LEFT")
    ver:SetPoint("BOTTOMLEFT", nav, "BOTTOMLEFT", 16, 34)
    ver:SetWidth(NAV_W - 28)
    ver:SetWordWrap(true)
    ver:SetText("v" .. ns.version)
    ver:SetTextColor(m[1], m[2], m[3])
    win.ver = ver
    win.guild = W.Text(nav, "tiny", "LEFT")
    win.guild:SetPoint("BOTTOMLEFT", ver, "TOPLEFT", 0, 6)
    win.guild:SetWidth(NAV_W - 28)
    win.guild:SetTextColor(m[1], m[2], m[3])
    win.sources = W.Text(nav, "tiny", "LEFT")
    win.sources:SetPoint("BOTTOMLEFT", win.guild, "TOPLEFT", 0, 6)
    win.sources:SetWidth(NAV_W - 28)
    win.sources:SetWordWrap(true)
    win.sources:SetTextColor(m[1], m[2], m[3])

    for _, key in ipairs(ORDER) do
        local f = CreateFrame("Frame", nil, win)
        f:SetPoint("TOPLEFT", win, "TOPLEFT", NAV_W + PAD, -HEADER_H - 14)
        f:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -PAD, 14)
        local c = UI.Color(key)
        local icon = f:CreateTexture(nil, "ARTWORK")
        icon:SetSize(22, 22)
        icon:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        icon:SetTexture(MEDIA .. "nav-" .. key .. ".png")
        icon:SetVertexColor(c[1], c[2], c[3])
        local heading = W.Text(f, "title", "LEFT")
        heading:SetPoint("LEFT", icon, "RIGHT", 8, 0)
        heading:SetText(L.PAGE[key])
        heading:SetTextColor(c[1], c[2], c[3])
        local blurb = W.Text(f, "small", "LEFT")
        blurb:SetPoint("LEFT", heading, "RIGHT", 12, -1)
        blurb:SetText(L.PAGE_DESC[key])
        blurb:SetTextColor(m[1], m[2], m[3])
        local body = CreateFrame("Frame", nil, f)
        body:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -34)
        body:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
        local page = { frame = f, body = body, color = c, key = key }
        local ok, err = pcall(builders[key], page)
        if not ok then UI.ReportError(key, err) end
        pages[key] = page
        f:Hide()
    end
    select(ns.char.page or "recipes")
end

function UI.Refresh()
    if not (win and win:IsShown()) then return end
    ns.Prices.ResetUsage()
    local p = pages[current]
    if p and p.Refresh then
        local ok, err = pcall(p.Refresh)
        if not ok then UI.ReportError(current, err) end
    end
    -- Good deals: how many Top offers the last scan of the house shown has
    local ds = ns.Gold.DealsPeek()
    navButtons.gmdeals.badge:SetText((ds and ds.top > 0) and tostring(ds.top) or "")
    -- the version: the latest or not, and the button that goes with it
    local ust, vtext, vact = ns.Update.Menu()
    local C = ns.Theme.C
    local late = ust ~= "current" and ust ~= "unknown"
    win.ver:SetText(vtext)
    win.ver:SetTextColor((late and C.amber or C.muted)[1], (late and C.amber or C.muted)[2], (late and C.amber or C.muted)[3])
    win.verMain:SetShown(vact ~= nil)
    if vact then win.verMain.SetLabel(vact == "update" and L.UPD_BUTTON or L.UPD_RELOAD) end
    -- the cart: how many recipes wait in it
    local nCart = ns.Cart.Count()
    navButtons.cart.badge:SetText(nCart > 0 and tostring(nCart) or "")
    if ns.Scan.Running() then
        win.scanBtn.SetLabel(string.format(L.SCAN_RUNNING, ns.Scan.Count()))
        win.scanBtn.SetTint(ns.Theme.C.sky)
        win.scanBtn.SetEnabledLook(true)
    elseif ns.Buy.ahOpen then
        -- which house the scan will go to, before it starts
        local h = ns.Scan.OpenHouse()
        win.scanBtn.SetLabel(string.format(L.SCAN_AH_AT, ns.HouseName(h)))
        win.scanBtn.SetTint(h == "neutral" and { 1, 0.62, 0.3 } or nil)
        win.scanBtn.SetEnabledLook(true)
    else
        win.scanBtn.SetLabel(L.SCAN_AH)
        win.scanBtn.SetTint(nil)
        win.scanBtn.SetEnabledLook(false)
    end
    local at = ns.Prices.LastScan()
    win.scan:SetText(ns.RulesetLabel() .. " · " .. (at and string.format(L.AGO, ns.Duration(time() - at)) or L.NO_SCAN))
    local used = ns.Prices.MainSource()
    if not used and win.lastUsed and win.lastUsed[1] == ns.House() then used = win.lastUsed[2] end
    if not used then
        -- nothing priced on this page: the source this house would use
        if ns.House() == "neutral" then
            used = ns.Scan.LastAt("neutral") and (ns.Scan.Book("neutral").from == "blizzard" and "Blizzard" or "CraftMaster") or nil
        else
            for _, s in ipairs(ns.Prices.Sources()) do
                if not used and (ns.db.source == "auto" or s.key == ns.db.source) then used = s.label and s.label() or s.name end
            end
        end
    end
    if used then win.lastUsed = { ns.House(), used } end
    local st = ns.Sync.Status()
    if st.on then
        win.guild:SetText(string.format(L.SYNC_LINE, st.peers) .. (st.queued > 0 and ("  |cff73d982" .. string.format(L.SYNC_SENDING, st.queued) .. "|r") or ""))
    else
        win.guild:SetText(ns.db.share == false and L.SYNC_OFF or "")
    end
    win.sources:SetText(used and (L.PRICE_SOURCE .. "\n|cffd9d9de" .. used .. "|r") or L.SOURCES_NONE)
end

local refreshPending = false
function UI.RefreshSoon()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(0.15, function() refreshPending = false; UI.Refresh() end)
end

function UI.Open(key)
    if not win then build() end
    win:Show()
    if win.behind then UI.ToFront() end
    win.tagline:SetText(tagline())
    -- apres une mise a jour, la fenetre s'ouvre sur l'Accueil (les nouveautes)
    if not key and ns.db.seenVersion ~= ns.version and pages.home then key = "home" end
    select(key or current or ns.char.page or "home")
end

function UI.Toggle()
    if win and win:IsShown() then win:Hide() else UI.Open() end
end

-- Opens the window with the search box ready to type in (a page without a
-- search box gives way to Recipes, which has one).
function UI.FocusSearch()
    UI.Open()
    if not (win.search and win.search:IsShown()) then select("recipes") end
    if win.search and win.search:IsShown() then win.search:SetFocus() end
end

-- In front of the other windows or behind them, like a window of the game: a
-- click on the Auction House, the bags, the character sheet... laid over the
-- window brings that one over it; a click on the window brings it back in front
-- (HIGH, over everything). The chat, the action bars and the rest of the
-- interface never send it behind. The click is seen with GLOBAL_MOUSE_DOWN (a
-- click on a button too) or, without it, on the background of the windows.
local STRATA = { "BACKGROUND", "LOW", "MEDIUM", "HIGH", "DIALOG", "FULLSCREEN" }
local function strataRank(s)
    for i, v in ipairs(STRATA) do if v == s then return i end end
    return 3
end
local host, hooked = nil, {}
local function ahHost()
    if host and host:IsVisible() then return host end
    host = ns.AHPanel and ns.AHPanel.Host and ns.AHPanel.Host() or nil
    return host
end
-- is this frame part of root (a drop-down menu of the window is part of it)?
local function within(f, root)
    for _ = 1, 30 do
        if not f or not root then return false end
        if f == root then return true end
        f = f.GetParent and f:GetParent()
    end
    return false
end
local function mouseFocus()
    if GetMouseFoci then
        local ok, list = pcall(GetMouseFoci)
        return ok and type(list) == "table" and list[1] or nil
    end
    if GetMouseFocus then
        local ok, f = pcall(GetMouseFocus)
        return ok and f or nil
    end
end
-- the window a frame belongs to: its last parent under UIParent
local function topOf(f)
    for _ = 1, 30 do
        local p = f and f.GetParent and f:GetParent()
        if not p or p == UIParent or p == WorldFrame then return f end
        f = p
    end
    return f
end
local function overlaps(a, b)
    local ok, r = pcall(function()
        return a:GetLeft() < b:GetRight() and b:GetLeft() < a:GetRight() and a:GetBottom() < b:GetTop() and b:GetBottom() < a:GetTop()
    end)
    return ok and r or false
end
-- a window of the game (bags, character, spellbook...): a toplevel frame in the
-- strata of the windows; not the chat or the bars (lower, or not toplevel)
local function isWindow(f)
    if not f or f == win or f == UIParent or f == WorldFrame or not f.IsToplevel then return false end
    local ok, top = pcall(f.IsToplevel, f)
    if not (ok and top) then return false end
    local rank = strataRank(f:GetFrameStrata())
    return rank == 3 or rank == 4
end
-- front: over everything (HIGH, or one step above the Auction House's strata);
-- back: one step under the strata of the window clicked (win.behind = that window)
function UI.ToFront()
    if not win then return end
    local h = ahHost()
    local rank = h and math.max(4, strataRank(h:GetFrameStrata()) + 1) or 4
    win:SetFrameStrata(STRATA[math.min(rank, #STRATA)])
    win:Raise()
    win.behind = nil
end
function UI.ToBack(other)
    other = other or ahHost()
    if not (win and other) then return end
    win:SetFrameStrata(STRATA[math.max(1, strataRank(other:GetFrameStrata()) - 1)])
    win.behind = other
end
-- Which window was clicked: the one that gets the click (the frame under the
-- mouse, on top), not the one the mouse is merely over: the window behind the
-- Auction House is under its search box too.
local function onClick()
    if not (win and win:IsShown()) then return end
    local h = ns.Buy.ahOpen and ahHost() or nil
    local focus = mouseFocus()
    local front, back
    if within(focus, win) then front = true
    elseif h and within(focus, h) then back = true
    elseif focus then
        -- another window laid over this one comes in front; the world, the chat,
        -- the bars, a window elsewhere on the screen: nothing moves
        local top = topOf(focus)
        if not win.behind and isWindow(top) and overlaps(top, win) then UI.ToBack(top) end
        return
    elseif not h then
        return
    else
        -- the game does not say which frame: by where the mouse is, and when it
        -- is over both, the one in front keeps the click (nothing changes)
        local overWin, overHost = win:IsMouseOver(), h and h:IsMouseOver()
        if overWin and not overHost then front = true
        elseif overHost and not overWin then back = true end
    end
    if front and win.behind then UI.ToFront()
    elseif back and not win.behind then UI.ToBack(h) end
end
UI.OnGlobalClick = onClick
ns.Register("GLOBAL_MOUSE_DOWN", onClick)
-- without GLOBAL_MOUSE_DOWN: a click on the background of either window
local function hookHost()
    local h = ahHost()
    if h and not hooked[h] and h.HookScript then
        hooked[h] = true
        pcall(h.HookScript, h, "OnMouseDown", function() if win and win:IsShown() and not win.behind then UI.ToBack(h) end end)
    end
end
ns.Register("AUCTION_HOUSE_SHOW", function()
    host = nil
    if C_Timer and C_Timer.After then C_Timer.After(0.5, hookHost) end
end)
ns.Register("AUCTION_HOUSE_CLOSED", function()
    local old = host
    host = nil
    -- behind the Auction House: in front again once it is closed (behind the bags: stays)
    if win and win.behind and win.behind == old then UI.ToFront() end
end)

-- Keys: Game menu > Key Bindings > AddOns > CraftMaster (see Bindings.xml).
function CraftMasterToggle() UI.Toggle() end
function CraftMasterSearch() UI.FocusSearch() end
BINDING_HEADER_CRAFTMASTER = "CraftMaster"
BINDING_NAME_CRAFTMASTER_TOGGLE = L.BIND_TOGGLE
BINDING_NAME_CRAFTMASTER_SEARCH = L.BIND_SEARCH

function UI.IsShown() return win and win:IsShown() end

for _, e in ipairs({ "CartChanged", "PricesChanged", "RecipesChanged", "ItemsLoaded", "BuyChanged",
                     "BagsChanged", "HistoryChanged", "MerchantChanged", "ProfessionsChanged", "ScanProgress", "HouseChanged", "DealsChanged", "SyncChanged", "RulesetChanged", "ImportDone",
                     "GoldChanged", "SalesChanged", "SellChanged" }) do
    ns.On(e, function() UI.RefreshSoon() end)
end
