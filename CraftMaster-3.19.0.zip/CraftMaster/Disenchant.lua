local _, ns = ...

-- What disenchanting a piece of gear gives, on average: the classic rules by
-- item level and quality (dust and essence for green gear — armour mostly
-- dust, weapons mostly essence — a shard for blue, shards or a Nexus Crystal
-- for purple). Forever may differ: amounts are shown as estimates.
local D = {}
ns.Disenchant = D

-- { max item level, dust, dust qty, lesser/greater essence, essence qty, shard }
local GREEN = {
    { 15, 10940, 1.5, 10938, 1.5, nil },
    { 20, 10940, 2.5, 10939, 1.5, 10978 },
    { 25, 10940, 5, 10998, 1.5, 10978 },
    { 30, 11083, 1.5, 11082, 1.5, 11084 },
    { 35, 11083, 3.5, 11134, 1.5, 11138 },
    { 40, 11137, 1.5, 11135, 1.5, 11139 },
    { 45, 11137, 3.5, 11174, 1.5, 11177 },
    { 50, 11176, 1.5, 11175, 1.5, 11178 },
    { 55, 11176, 3.5, 16202, 1.5, 14343 },
    { 60, 16204, 1.5, 16203, 1.5, 14344 },
    { 999, 16204, 3.5, 16203, 2.5, 14344 },
}
local BLUE = {
    { 25, 10978 }, { 30, 11084 }, { 35, 11138 }, { 40, 11139 }, { 45, 11177 }, { 50, 11178 },
    { 55, 14343 }, { 999, 14344 },
}
D.MATERIALS = {}
for _, row in ipairs(GREEN) do D.MATERIALS[row[2]] = true; D.MATERIALS[row[4]] = true; if row[6] then D.MATERIALS[row[6]] = true end end
for _, row in ipairs(BLUE) do D.MATERIALS[row[2]] = true end
D.MATERIALS[20725] = true

-- Whether the item can be disenchanted: green or better armour or weapon.
function D.Can(id)
    local i = ns.Item(id)
    if not i or not i.name then return false end
    return (i.classID == 2 or i.classID == 4) and (i.quality or 0) >= 2 and (i.quality or 0) <= 4
        and (i.ilvl or 0) > 0 and i.equip ~= nil and i.equip ~= ""
end

-- { { itemID, chance, qty } } — what comes out, on average.
function D.Results(id)
    if not D.Can(id) then return nil end
    local i = ns.Item(id)
    local lvl, q = i.ilvl, i.quality
    if q == 2 then
        for _, row in ipairs(GREEN) do
            if lvl <= row[1] then
                local weapon = i.classID == 2
                local dust, ess = weapon and 0.2 or 0.75, weapon and 0.75 or 0.2
                local out = { { row[2], dust, row[3] }, { row[4], ess, row[5] } }
                if row[6] then out[3] = { row[6], 0.05, 1 } end
                return out
            end
        end
    elseif q == 3 then
        for _, row in ipairs(BLUE) do
            if lvl <= row[1] then
                local out = { { row[2], 1, 1 } }
                if lvl >= 56 then out = { { row[2], 0.995, 1 }, { 20725, 0.005, 1 } } end
                return out
            end
        end
    elseif q == 4 then
        if lvl >= 56 then return { { 20725, 1, 1.5 } } end
        for _, row in ipairs(BLUE) do
            if lvl <= row[1] then return { { row[2], 1, 3 } } end
        end
    end
    return nil
end

-- The average worth of what one disenchant gives, at the Auction House
-- after its cut. Nil when some result has no price.
function D.Value(id)
    local res = D.Results(id)
    if not res then return nil end
    local cut = 1 - ns.CutPct() / 100
    local total = 0
    for _, r in ipairs(res) do
        local p = ns.Prices.AH(r[1])
        if not p then return nil, res end
        total = total + p * r[2] * r[3] * cut
    end
    return total, res
end

function D.IsEnchanter() return ns.profs.enchanting ~= nil end
