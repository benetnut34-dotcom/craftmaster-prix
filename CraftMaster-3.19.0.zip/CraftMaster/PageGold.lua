local _, ns = ...
local L = ns.L
local W = ns.W

-- The market pages, in CraftMaster's look:
--   Good deals — items listed well under what they sell for (or under what
--                a vendor pays), "Top offers" by rarity, every deal by rarity;
--   Crafts     — recipes whose product sells for more than its materials,
--                "Top crafts" by profession, every craft of a profession,
--                the detail of a recipe, the materials left out;
--   Volume     — the cheapest units of a material, a lot to buy and sell back.
--   Comparison — bought at one house, sold at the other (Horde and Commune);
--   Plans      — bought at a merchant, sold at the Auction House.
-- One model (Gold.lua), the same filters, columns, Top and detail in the four.

local G = ns.Gold
local HEX = ns.Theme.HEX
local MUTED, GREEN, GOLD, RED, AMBER, WHITE = HEX.muted, HEX.profit, HEX.gold, HEX.loss, HEX.amber, HEX.white
local GUESS = " " .. HEX.guess .. "~|r"   -- after a resale price guessed from the listings

local ROW_H = 22
local TOP_H, TOP_CARDS = 92, 5
local BOARD_CARDS, CARD_H, LABEL_W = 5, 56, 130

local function C() return ns.Theme.C end

-- Profit: above 5 gold, gold pieces only (rounded)
local function profitMoney(c)
    if c and math.abs(c) >= 50000 then
        local g = math.floor(math.abs(c) / 10000 + 0.5) * 10000
        return ns.Money(c < 0 and -g or g)
    end
    return ns.Money(c)
end
-- short, for a card: gold and silver from 1g, gold alone from 10g
local function shortMoney(c)
    if c and math.abs(c) >= 100000 then
        local g = math.floor(math.abs(c) / 10000 + 0.5)
        return (c < 0 and "-" or "") .. g .. "|cffffd700g|r"
    end
    if c and math.abs(c) >= 10000 then return ns.Money(math.floor(c / 100 + 0.5) * 100) end
    return ns.Money(c)
end
local function signedProfit(c)
    if c and c < 0 then return RED .. "-|r" .. profitMoney(-c) end
    return profitMoney(c)
end
-- Where a figure of the detail comes from, in words: "scan Blizzard, il y a 1 h".
-- from: "blizzard", "scans", "guild" or "history" (both); at: when (optional).
local SOURCE_NAME = { blizzard = "GM_SRC_BLIZZ", scans = "GM_SRC_SCAN", guild = "GM_SRC_GUILD", history = "GM_SRC_HISTORY" }
function G.SourceName(from) return L[SOURCE_NAME[from] or "GM_SRC_SCAN"] end
function G.SourceWords(from, at)
    local name = G.SourceName(from)
    if at and at > 0 then name = name .. ", " .. string.format(L.GM_SRC_AGO, ns.Duration(math.max(0, time() - at))) end
    return name
end
local function gold(c) return (c and c > 0) and string.format("%g", c / 10000) or "" end
local function parseGold(t)
    local v = tonumber(((t or ""):gsub(",", ".")))
    return v and math.floor(v * 10000) or 0
end

-- the type and subtype of an item, without waiting for its data
local function instantType(id)
    local _, itemType, itemSub = nil, nil, nil
    if C_Item and C_Item.GetItemInfoInstant then
        _, itemType, itemSub = C_Item.GetItemInfoInstant(id)
    elseif GetItemInfoInstant then
        _, itemType, itemSub = GetItemInfoInstant(id)
    end
    return _, itemType, itemSub
end

local function qualityName(q)
    return _G["ITEM_QUALITY" .. q .. "_DESC"] or (L.GM_QUALITY and L.GM_QUALITY[q]) or ("Q" .. q)
end
local function qualityHex(q)
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
    if not c then return "" end
    return c.hex or string.format("|cff%02x%02x%02x", math.floor((c.r or 1) * 255), math.floor((c.g or 1) * 255), math.floor((c.b or 1) * 255))
end

-- The kind of an item, for the lines of the comparison: plans, gear, materials
-- for crafts, consumables, the rest (by its class, known without loading it).
local KIND_OF_CLASS = { [9] = "plans", [2] = "gear", [4] = "gear", [7] = "mats", [5] = "mats", [0] = "consumable" }
local KIND_RANK = { plans = 1, gear = 2, mats = 3, consumable = 4, other = 5 }
local function itemKind(id)
    local classID
    if C_Item and C_Item.GetItemInfoInstant then classID = select(6, C_Item.GetItemInfoInstant(id))
    elseif GetItemInfoInstant then classID = select(6, GetItemInfoInstant(id)) end
    return KIND_OF_CLASS[classID] or "other"
end
G.ItemKind = itemKind

-- The name of a house: "Horde" (the player's faction) or "Commune".
local function houseName(h) return h == "neutral" and L.HOUSE_NEUTRAL or ns.FactionName() end
-- From one house to the other: "Acheter à l'HV Horde, revendre à l'HV Commune";
-- a plan: "Acheter chez le marchand, revendre à l'HV Commune".
local function transferWords(d)
    if d.plan then return string.format(L.GM_PL_LINE, houseName(d.house)) end
    return string.format(L.GM_TR_LINE, houseName(d.from), houseName(d.to))
end

-- ---------------------------------------------------------------------
-- Tooltips
-- ---------------------------------------------------------------------

local function addProfitLines(d, count)
    count = count or 1
    if not d.profit then
        GameTooltip:AddLine(L.GM_PROFIT_UNKNOWN, 1, 0.4, 0.4)
        return
    end
    local cost = d.buy and d.buy * count
    local profit = d.profit * count
    GameTooltip:AddDoubleLine(d.recipe and L.GM_COST or L.GM_BUY_PRICE, ns.Money(cost), 0.8, 0.8, 0.8, 1, 1, 1)
    if d.excludedCount and d.excludedCount > 0 then
        GameTooltip:AddLine(string.format(L.GM_N_EXCLUDED, d.excludedCount), 0.95, 0.71, 0.23)
    end
    local cutPct = ns.CutPct()
    local net = d.sell * count * (d.kind == "PNJ" and 1 or (1 - cutPct / 100))   -- a vendor takes no cut
    GameTooltip:AddDoubleLine(d.kind == "PNJ" and L.GM_RESALE_VENDOR or string.format(L.GM_RESALE_NET, cutPct),
        ns.Money(net), 0.8, 0.8, 0.8, 1, 1, 1)
    if d.cd then
        GameTooltip:AddDoubleLine(L.GM_PROFIT_BEFORE_CD, signedProfit((d.profitRaw or d.profit) * count), 0.8, 0.8, 0.8, 1, 1, 1)
        if d.cdPrice then
            GameTooltip:AddDoubleLine(string.format(L.GM_CD_VALUE_OF, ns.Cooldown.Label(d.cd)),
                RED .. "-|r" .. ns.Money(d.cdPrice * count), 0.8, 0.8, 0.8, 1, 1, 1)
        else
            GameTooltip:AddDoubleLine(string.format(L.GM_CD_OF, ns.Cooldown.Label(d.cd)), MUTED .. L.GM_UNKNOWN_VALUE .. "|r",
                0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
    GameTooltip:AddDoubleLine(L.GM_PROFIT, signedProfit(profit), 1, 0.82, 0, 1, 1, 1)
    if d.perDay then
        GameTooltip:AddDoubleLine(L.GM_PROFIT_PER_DAY, signedProfit(d.perDay), 0.95, 0.71, 0.23, 1, 1, 1)
    end
    if cost and cost > 0 then
        local pct = math.floor(profit / cost * 100 + 0.5)
        GameTooltip:AddDoubleLine(L.GM_MARGIN, (pct < 0 and RED or GREEN) .. pct .. " %|r", 1, 0.82, 0, 1, 1, 1)
    end
end

local function addSalesTooltip(d)
    if d.kind == "PNJ" then
        GameTooltip:AddLine(L.GM_VENDOR_SAFE, 0.35, 0.85, 0.45)
        return
    end
    local st = d.stats
    GameTooltip:AddLine(" ")
    if not st or st.n == 0 then
        GameTooltip:AddLine(L.GM_NO_SALE_YET, 0.55, 0.55, 0.6)
        if st and (st.expired or 0) > 0 then
            GameTooltip:AddLine(string.format(L.GM_EXPIRED_N, st.expired), 1, 0.4, 0.4)
        end
        return
    end
    GameTooltip:AddDoubleLine(L.GM_CONFIDENCE, G.StarString(d.conf or st.score, 14), 1, 0.82, 0, 1, 1, 1)
    local c = d.comp
    if c and c.units > 0 then
        local hard = (d.conf or 0) < (st.score or 0)
        GameTooltip:AddLine(string.format(L.GM_COMP_TIP, c.units, c.days or 0), hard and 1 or 0.8, hard and 0.55 or 0.8, hard and 0.3 or 0.8)
    end
    local ev = d.ev
    if ns.Tracker.EvidenceAlarm(ev) then
        GameTooltip:AddLine(string.format(L.GM_EXP_TIP, ev.expired24, math.floor(ev.sold24 + 0.5)), 1, 0.4, 0.4)
    end
    GameTooltip:AddDoubleLine(L.GM_SALES_SEEN, string.format(L.GM_N_OVER_DAYS, math.floor(st.n + 0.5), G.SpanText(st)), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine(L.GM_VOLUME, string.format(L.GM_PER_DAY, st.perDay), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine(L.GM_THROUGH, string.format("%d %%", math.floor((st.through or 0) * 100 + 0.5)), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine(L.GM_SALE_PRICES, ns.Money(st.p25) .. " – " .. ns.Money(st.p75), 0.8, 0.8, 0.8, 1, 1, 1)
    if d.source == "sales" then
        local days = G.DaysToSell(d)
        if days then
            GameTooltip:AddDoubleLine(L.GM_DAYS_TO_SELL, days < 1 and L.GM_LESS_THAN_DAY or string.format(L.GM_DAYS_N, days),
                0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
end

-- a lot bought in volume: how many, up to what price, sold back at what
local function addVolumeLine(d)
    if d.transfer or d.plan then GameTooltip:AddLine(transferWords(d), 0.6, 0.8, 1, true) end
    for _, w in ipairs(d.limits or {}) do GameTooltip:AddLine("[!] " .. w, 0.94, 0.62, 0.24, true) end
    if d.volume and d.n then
        GameTooltip:AddLine(string.format(L.GM_VOL_TIP, d.n, ns.Money(d.unitMax), ns.Money(d.market)), 0.6, 0.8, 1, true)
    end
end

-- ---------------------------------------------------------------------
-- Small parts
-- ---------------------------------------------------------------------

-- A flat clickable tile (cards of the boards and of the top strip).
local function tile(parent, color)
    local b = CreateFrame("Button", nil, parent)
    b.bg = W.Fill(b, "BACKGROUND", 0, 0, 0, 0.30)
    b.line = W.Outline(b, 1, 1, 1, 0.08)
    b:HookScript("OnEnter", function(self) self.line.Color(color[1], color[2], color[3], 0.9) end)
    b:HookScript("OnLeave", function(self)
        local r = self.rest
        if r then self.line.Color(r[1], r[2], r[3], 0.45) else self.line.Color(1, 1, 1, 0.08) end
    end)
    return b
end

-- The color of a stake: green a small one, amber a mid one, red a big one.
local function budgetColor(k)
    local C0 = C()
    return k == "big" and C0.loss or (k == "mid" and C0.amber or C0.profit)
end
local function budgetHex(k) return k == "big" and RED or (k == "mid" and AMBER or GREEN) end

-- A tile showing one deal or craft: icon, name, profit; tooltip; click opens it.
local function offerCard(parent, color, open)
    local card = tile(parent, color)
    card.icon = card:CreateTexture(nil, "ARTWORK")
    card.icon:SetSize(28, 28)
    card.icon:SetPoint("LEFT", card, "LEFT", 6, 0)
    card.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    card.name = W.Text(card, "small", "LEFT")
    card.name:SetPoint("BOTTOMLEFT", card.icon, "RIGHT", 6, 1)
    card.name:SetPoint("RIGHT", card, "RIGHT", -6, 0)
    card.name:SetWordWrap(false)
    card.profit = W.Text(card, "head", "LEFT")
    card.profit:SetPoint("TOPLEFT", card.icon, "RIGHT", 6, -2)
    card.profit:SetPoint("RIGHT", card, "RIGHT", -6, 0)
    card.profit:SetWordWrap(false)
    -- a lot in volume: a band on the left edge, colored by the stake (small, mid, big)
    card.budget = card:CreateTexture(nil, "ARTWORK")
    card.budget:SetPoint("TOPLEFT", card, "TOPLEFT", 1, -1)
    card.budget:SetPoint("BOTTOMLEFT", card, "BOTTOMLEFT", 1, 1)
    card.budget:SetWidth(4)
    card.budget:Hide()
    card:HookScript("OnEnter", function(self)
        local d = self.data
        if not d then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetItemByID(d.itemID)
        GameTooltip:AddLine(" ")
        if d.recipe then
            GameTooltip:AddLine(string.format(L.GM_RECIPE_OF, d.label or "?", G.ProfName(d.recipe.prof)), 0.4, 0.73, 1)
        end
        addVolumeLine(d)
        local bk = d.volume and G.Budget(d.buy)
        if bk then
            local bc = budgetColor(bk)
            GameTooltip:AddLine(string.format(L.GM_BUDGET_TIP[bk], ns.Money(d.buy)), bc[1], bc[2], bc[3], true)
        end
        addProfitLines(d)
        addSalesTooltip(d)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(d.recipe and L.GM_CLICK_CRAFT or L.GM_CLICK_DEAL, 0.35, 0.85, 0.45)
        GameTooltip:Show()
    end)
    card:HookScript("OnLeave", function() GameTooltip:Hide() end)
    card:SetScript("OnClick", function(self) if self.data then open(self.data) end end)
    function card.Set(d)
        card.data = d
        local i = ns.Item(d.itemID)
        card.icon:SetTexture(i.icon or 134400)
        card.name:SetText((d.label or i.name or ("#" .. d.itemID)) .. (d.suffix or ""))
        -- a plan hard to get (limited stock, reputation, event): a [!] after the profit
        -- a lot in volume: what it costs next to what it earns (a big stake for a small gain shows)
        local bk = d.volume and G.Budget(d.buy)
        local bc = bk and budgetColor(bk)
        card.rest = bc
        card.budget:SetShown(bc ~= nil)
        if bc then card.budget:SetColorTexture(bc[1], bc[2], bc[3], 0.95) end
        if bc then card.line.Color(bc[1], bc[2], bc[3], 0.45) else card.line.Color(1, 1, 1, 0.08) end
        local stake = bk and ("  " .. budgetHex(bk) .. string.format(L.GM_VOL_STAKE, shortMoney(d.buy)) .. "|r") or ""
        card.profit:SetText(GREEN .. "+|r " .. (d.volume and shortMoney(d.profit) or profitMoney(d.profit)) .. stake .. ((d.limits and #d.limits > 0) and ("  " .. AMBER .. "[!]|r") or ""))
    end
    return card
end

-- Buying from a detail, one button per way of buying: the first click asks the
-- game for the real price, the second buys (or bids) at that price. bid: a bid
-- on the item instead of its buyout.
local function buyMatches(st, id, bid) return st and st.id == id and (st.bid or false) == (bid or false) end
-- ctx: where the purchase comes from, for My operations
local function buyClick(id, qty, maxUnit, bid, ctx)
    local st = ns.Buy.State()
    if buyMatches(st, id, bid) and st.step == "confirm" then ns.Buy.Confirm() return end
    if st or (ns.Sell.Busy and ns.Sell.Busy()) then return end
    ns.Buy.Start(id, qty, maxUnit, bid, ctx)
end
-- the purchase of an offer: a good deal, or for the other house
local function offerCtx(d)
    return { kind = d.transfer and "transfer" or "deal", aim = d.market, sellHouse = d.house or ns.House() }
end
-- the label of a buy button: idle (what it buys), "confirm ...", or waiting for the game
local function buyLook(btn, id, bid, idle, canStart, tint)
    local st = ns.Buy.State()
    if buyMatches(st, id, bid) and st.step == "confirm" then
        btn.SetLabel(string.format(bid and L.GM_BUY_CONFIRM_BID or L.GM_BUY_CONFIRM, ns.Money(st.total)))
        btn.SetTint(C().gold)
        btn.SetEnabledLook(true)
    elseif buyMatches(st, id, bid) then
        btn.SetLabel(L.BUY_WAIT)
        btn.SetTint(nil)
        btn.SetEnabledLook(false)
    else
        btn.SetLabel(idle)
        btn.SetTint(tint)
        btn.SetEnabledLook(ns.Buy.ahOpen and not st and canStart and true or false)
    end
end

-- A square button showing a game icon (a profession, a kind of material).
local function iconButton(parent, icon, key, onClick)
    local b = W.Button(parent, "", 30, onClick)
    b:SetSize(30, 30)
    b.text:Hide()
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", b, "TOPLEFT", 3, -3)
    b.icon:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -3, 3)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.icon:SetTexture(icon)
    b.key = key
    return b
end

-- A scrolling area: returns the scroll frame and its content (set its height).
local function scrollArea(parent)
    local sf = CreateFrame("ScrollFrame", nil, parent)
    local content = CreateFrame("Frame", nil, sf)
    content:SetSize(10, 10)
    sf:SetScrollChild(content)
    local thumb = sf:CreateTexture(nil, "OVERLAY")
    thumb:SetWidth(3)
    thumb:SetColorTexture(1, 1, 1, 0.35)
    function sf.Update()
        content:SetWidth(math.max(10, sf:GetWidth() - 8))
        local view, total = sf:GetHeight(), content:GetHeight()
        if total <= view + 1 then
            thumb:Hide()
            sf:SetVerticalScroll(0)
            return
        end
        local maxScroll = total - view
        if sf:GetVerticalScroll() > maxScroll then sf:SetVerticalScroll(maxScroll) end
        local h = math.max(20, view * view / total)
        thumb:SetHeight(h)
        thumb:ClearAllPoints()
        thumb:SetPoint("TOPRIGHT", sf, "TOPRIGHT", 0, -(sf:GetVerticalScroll() / maxScroll) * (view - h))
        thumb:Show()
    end
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local maxScroll = math.max(0, content:GetHeight() - self:GetHeight())
        self:SetVerticalScroll(math.min(maxScroll, math.max(0, self:GetVerticalScroll() - delta * 50)))
        sf.Update()
    end)
    sf:SetScript("OnSizeChanged", function() sf.Update() end)
    return sf, content
end

-- A panel over the whole page (details, settings), opaque.
local function overlay(body)
    local f = CreateFrame("Frame", nil, body)
    f:SetAllPoints(body)
    f:SetFrameLevel(body:GetFrameLevel() + 40)
    f:EnableMouse(true)
    W.Fill(f, "BACKGROUND", 0.075, 0.08, 0.095, 1)
    W.Outline(f, 1, 1, 1, 0.06)
    f:Hide()
    return f
end

-- A labelled number box: label on the left, value on Enter / focus lost.
local function box(parent, label, width, get, set, tip, onChange)
    local l = W.Text(parent, "small", "LEFT")
    l:SetText(label)
    local c = C().label
    l:SetTextColor(c[1], c[2], c[3])
    local e
    e = W.Input(parent, { width = width, onEnter = function(t)
        set(t)
        if onChange then onChange() end
    end })
    e:SetPoint("LEFT", l, "RIGHT", 6, 0)
    e.label = l
    -- in use (a value that hides lines): label and outline in gold
    local ring = W.Outline(e, 0, 0, 0, 0)
    function e.SetActive(on)
        local g = C().gold
        ring.Color(g[1], g[2], g[3], on and 0.95 or 0)
        local lc = on and g or C().label
        l:SetTextColor(lc[1], lc[2], lc[3])
    end
    function e.Refresh() if not e:HasFocus() then e:SetText(get()) end end
    W.Tip(e, label, tip)
    return e, l
end

-- A small "label + switch" pair.
local function switch(parent, label, get, set, tip)
    local s = W.Switch(parent, get, set)
    local l = W.Text(parent, "small", "RIGHT")
    l:SetPoint("RIGHT", s, "LEFT", -6, 0)
    l:SetText(label)
    W.Tip(s, label, tip)
    return s, l
end

-- The rating of an offer or a craft, shared by the two details: the verdict
-- (one coloured line), then one of two views: "why" (a small table of what
-- makes the stars and what happened) or "chart" (the price curve).
--   R.Layout(y, wdt)   places it all from y down; returns the lowest y used
--   R.Fill(d, mode)    mode "why", "chart", or nil (only the verdict)
local VERDICT_COLOR = { good = "profit", warn = "amber", bad = "loss", info = "sky" }
local WHY_X, SRC_W, LOG_ROWS, CHART_H = 130, 200, 5, 200

local function ratingBlock(ct, color)
    local R = {}
    local function head(words)
        local t = W.Text(ct, "head", "LEFT")
        t:SetText(words)
        t:SetTextColor(color[1], color[2], color[3])
        return t
    end

    local verdict = CreateFrame("Frame", nil, ct)
    verdict:SetHeight(26)
    verdict.bg = verdict:CreateTexture(nil, "BACKGROUND")
    verdict.bg:SetAllPoints()
    verdict.text = W.Text(verdict, "body", "LEFT")
    verdict.text:SetPoint("LEFT", verdict, "LEFT", 10, 0)
    verdict.text:SetPoint("RIGHT", verdict, "RIGHT", -10, 0)
    verdict.text:SetWordWrap(false)
    R.verdict = verdict

    -- why the stars: a small table, one line per thing that makes the score
    local whyTitle = head(L.GM_WHY)
    local whyHead = CreateFrame("Frame", nil, ct)
    whyHead:SetHeight(20)
    W.Fill(whyHead, "BACKGROUND", 1, 1, 1, 0.05)
    local function headText(words, x)
        local t = W.Text(whyHead, "small", "LEFT")
        t:SetPoint("LEFT", whyHead, "LEFT", x, 0)
        t:SetText(words)
        local lc = C().label
        t:SetTextColor(lc[1], lc[2], lc[3])
        return t
    end
    headText(L.GM_T_WHAT, 8)
    headText(L.GM_T_VALUE, WHY_X)
    local headSrc = headText(L.GM_T_SOURCE, WHY_X)
    local headAge = headText(L.GM_T_AGE, WHY_X)
    local why = {}
    for i = 1, 4 do
        local row = CreateFrame("Frame", nil, ct)
        row:SetHeight(20)
        W.Fill(row, "BACKGROUND", 1, 1, 1, i % 2 == 0 and 0.03 or 0)
        row.k = W.Text(row, "small", "LEFT")
        row.k:SetPoint("LEFT", row, "LEFT", 8, 0)
        row.v = W.Text(row, "small", "LEFT")
        row.v:SetPoint("LEFT", row, "LEFT", WHY_X, 0)
        row.v:SetWordWrap(false)
        row.src = W.Text(row, "small", "LEFT")
        row.age = W.Text(row, "small", "LEFT")
        why[i] = row
    end
    -- the Source and Updated columns start after the longest value, the same on every line
    local function alignWhy()
        local wmax = 0
        for _, row in ipairs(why) do wmax = math.max(wmax, row.v:GetStringWidth() or 0) end
        local sx = WHY_X + math.max(wmax, 120) + 24
        headSrc:ClearAllPoints(); headSrc:SetPoint("LEFT", whyHead, "LEFT", sx, 0)
        headAge:ClearAllPoints(); headAge:SetPoint("LEFT", whyHead, "LEFT", sx + SRC_W, 0)
        for _, row in ipairs(why) do
            row.src:ClearAllPoints(); row.src:SetPoint("LEFT", row, "LEFT", sx, 0)
            row.age:ClearAllPoints(); row.age:SetPoint("LEFT", row, "LEFT", sx + SRC_W, 0)
        end
    end
    local function setWhy(i, key, value, from, at)
        local row = why[i]
        row.k:SetText(MUTED .. key .. "|r")
        row.v:SetText(value)
        row.src:SetText(from and (MUTED .. G.SourceName(from) .. "|r") or "")
        row.age:SetText((from and at and at > 0) and (MUTED .. string.format(L.GM_SRC_AGO, ns.Duration(math.max(0, time() - at))) .. "|r") or "")
    end

    -- what happened: the sales seen, one line per scan and kind
    local logTitle = head(L.GM_WHAT_HAPPENED)
    local logRows = {}
    for i = 1, LOG_ROWS do
        local row = CreateFrame("Frame", nil, ct)
        row:SetHeight(20)
        W.Fill(row, "BACKGROUND", 1, 1, 1, i % 2 == 0 and 0.025 or 0)
        row.d = W.Text(row, "small", "LEFT")
        row.d:SetPoint("LEFT", row, "LEFT", 8, 0)
        row.t = W.Text(row, "small", "LEFT")
        row.t:SetPoint("LEFT", row, "LEFT", WHY_X, 0)
        logRows[i] = row
    end
    local noSales = W.Text(ct, "small", "LEFT")
    noSales:SetText(MUTED .. L.GM_NO_SALES_YET .. "|r")

    -- the price curve: daily lows and the resale aimed at
    local chartTitle = head(L.GM_CHART_TITLE)
    local chart = ns.Chart.New(ct)
    chart:SetHeight(CHART_H)
    local legend = W.Text(ct, "tiny", "LEFT")
    legend:SetText(MUTED .. L.GM_CHART_LEGEND .. "|r")

    local whyParts = { whyTitle, whyHead, logTitle }
    local chartParts = { chartTitle, chart, legend }

    function R.Layout(y, wdt)
        verdict:ClearAllPoints()
        verdict:SetPoint("TOPLEFT", ct, "TOPLEFT", 10, y)
        verdict:SetWidth(wdt - 20)
        return y - 26
    end

    -- the view under the verdict, from y down; returns the lowest y used
    function R.LayoutView(y, wdt)
        whyTitle:ClearAllPoints(); whyTitle:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, y)
        chartTitle:ClearAllPoints(); chartTitle:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, y)
        whyHead:ClearAllPoints()
        whyHead:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, y - 22)
        whyHead:SetWidth(wdt - 12)
        for i, row in ipairs(why) do
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, y - 42 - (i - 1) * 20)
            row:SetWidth(wdt - 12)
        end
        local ly = y - 42 - 4 * 20 - 18
        logTitle:ClearAllPoints(); logTitle:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, ly)
        for i, row in ipairs(logRows) do
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, ly - 22 - (i - 1) * 20)
            row:SetWidth(wdt - 12)
        end
        noSales:ClearAllPoints(); noSales:SetPoint("TOPLEFT", ct, "TOPLEFT", 14, ly - 24)
        chart:ClearAllPoints()
        chart:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, y - 24)
        chart:SetWidth(wdt - 12)
        legend:ClearAllPoints(); legend:SetPoint("TOPLEFT", chart, "BOTTOMLEFT", 6, -6)
        return math.min(ly - 22 - LOG_ROWS * 20, y - 24 - CHART_H - 24)
    end

    -- d: an offer (EvaluateItem) or a craft (EvaluateRecipe); mode: "why", "chart" or nil
    function R.Fill(d, mode)
        local id = d.itemID
        local price = d.market or d.sell   -- a craft's d.sell is net of the cut, for its whole batch
        local level, words = G.Verdict(d)
        local vc = C()[VERDICT_COLOR[level] or "sky"]
        verdict.bg:SetColorTexture(vc[1], vc[2], vc[3], 0.16)
        verdict.text:SetText(words)
        verdict.text:SetTextColor(vc[1], vc[2], vc[3])

        for _, p in ipairs(whyParts) do p:SetShown(mode == "why") end
        for _, row in ipairs(why) do row:SetShown(mode == "why") end
        for _, p in ipairs(chartParts) do p:SetShown(mode == "chart") end
        if mode ~= "why" then
            for _, row in ipairs(logRows) do row:Hide() end
            noSales:Hide()
        end
        if mode == "chart" then
            local series = { { points = ns.Deals.Lows(id, d.house or ns.House()), color = C().sky,
                               label = d.transfer and string.format(L.GM_LOWEST_AT, houseName(d.to)) or L.GM_LOWEST } }
            if d.transfer then   -- the two houses side by side: where it is bought too
                table.insert(series, 1, { points = ns.Deals.Lows(id, d.from), color = C().amber,
                                          label = string.format(L.GM_LOWEST_AT, houseName(d.from)) })
            end
            if price and price > 0 then
                local today = ns.Today()
                series[2] = { points = { { today - 14, price }, { today, price } }, color = C().profit, label = L.GM_RESALE_AIM }
            end
            chart.Draw(series, 14, L.GM_NO_DATA_DAY)
        end
        if mode ~= "why" then return end

        local s, ev, c = d.stats, d.ev, d.comp
        -- the house these sales and prices are of: where it is sold (the one shown, or the other one)
        local where = houseName(d.house or ns.House())
        logTitle:SetText(string.format(L.GM_WHAT_HAPPENED_AT, where))
        if s and s.n > 0 then
            setWhy(1, L.GM_WHY_SALES, string.format(L.GM_WHY_SALES_V, math.floor(s.n + 0.5), G.SpanText(s), s.perDay or 0, where), s.from, s.at)
        else
            setWhy(1, L.GM_WHY_SALES, MUTED .. L.GM_NONE_YET .. "|r")
        end
        if ev then
            local txt = string.format(L.GM_WHY_AT_PRICE_V, math.floor(ev.through * 100 + 0.5), ev.expired24)
            setWhy(2, L.GM_WHY_AT_PRICE, ns.Tracker.EvidenceAlarm(ev) and (RED .. txt .. "|r") or txt, "scans")
        elseif s and s.n > 0 then
            setWhy(2, L.GM_WHY_AT_PRICE, string.format(L.GM_WHY_THROUGH_V, math.floor((s.through or 0) * 100 + 0.5)), s.from)
        else
            setWhy(2, L.GM_WHY_AT_PRICE, MUTED .. "-|r")
        end
        if c then
            local days = G.DaysToSell(d)
            local txt = days and string.format(L.GM_WHY_COMP_DAYS_V, c.units, days) or string.format(L.GM_WHY_COMP_V, c.units)
            local heavy = (c.listings > 10 and (c.days or 0) > 1) or (c.days or 0) > 2
            setWhy(3, L.GM_WHY_COMP, heavy and (AMBER .. txt .. "|r") or txt, c.from, c.at)
        else
            setWhy(3, L.GM_WHY_COMP, MUTED .. L.GM_WHY_UNKNOWN .. "|r")
        end
        local market = G.MarketPrice(id, d.house)
        local priceTxt
        if s and s.n > 0 and s.p25 then
            priceTxt = string.format(L.GM_WHY_PRICE_V, ns.Money(s.p25), ns.Money(s.p75), where)
            if market then priceTxt = priceTxt .. "  ·  " .. string.format(L.GM_WHY_USUAL_V, ns.Money(market)) end
        elseif market then
            priceTxt = string.format(L.GM_WHY_USUAL_V, ns.Money(market))
        end
        setWhy(4, L.GM_WHY_PRICE, priceTxt or (MUTED .. L.GM_NOT_ENOUGH_HISTORY .. "|r"), priceTxt and "history" or nil)
        alignWhy()

        local groups = G.SalesGroups(G.Sales(id, d.house), LOG_ROWS)
        for k, row in ipairs(logRows) do
            local g = groups[k]
            if g then
                row.d:SetText(MUTED .. date("%d/%m %H:%M", g.t) .. "|r")
                local range = g.lo == g.hi and ns.Money(g.lo) or (ns.Money(g.lo) .. " – " .. ns.Money(g.hi))
                local col = g.kind == "expired" and RED or (g.kind == "sold" and GREEN or AMBER)
                local key = g.kind == "expired" and L.GM_LOG_EXPIRED or (g.kind == "sold" and L.GM_LOG_SOLD or L.GM_LOG_MAYBE)
                local who = g.mine == "buy" and L.GM_MY_BUY or (g.mine == "sell" and L.GM_MY_SALE) or (g.shared and L.GM_SHARED)
                if g.mine == "buy" then col = MUTED end   -- not a sale to the market: left out of the figures
                row.t:SetText(col .. string.format(key, g.n, range) .. "|r" .. (who and (MUTED .. "  " .. who .. "|r") or ""))
                row:Show()
            else
                row:Hide()
            end
        end
        noSales:SetShown(#groups == 0)
    end
    return R
end

local SOURCE_NOTE = { sales = "GM_NOTE_SALES", listings = "GM_NOTE_LISTINGS", estimate = "GM_NOTE_ESTIMATE", vendor = "GM_NOTE_VENDOR" }
-- the confidence tile: stars, "guaranteed" for a vendor, or no sale seen
local function confText(d, size)
    if d.kind == "PNJ" then return GREEN .. L.GM_GUARANTEED .. "|r" end
    return (d.conf or 0) > 0 and G.StarString(d.conf, size or 18) or (MUTED .. L.GM_NO_SALE_SEEN .. "|r")
end

-- The detail of an offer, a craft or a lot, the same frame for the three: back,
-- "select at the AH", the item (icon, name in its quality colour, a line under
-- it), four tiles (buy, resale, profit, confidence), the verdict and the views.
--   o.buy, o.buyTip     the first tile (what it costs) and its tooltip
--   o.resaleTip, o.ahTip the tooltips of the resale tile and of the AH button
--   o.views             { { key, label } }: the views under the verdict
--   o.profitTip()       fills the profit tooltip (else the profit of P.data)
-- P.data is what is shown; P.Refresh redraws it (set by the page).
local function detailPanel(body, color, o)
    local P = overlay(body)
    local back = W.Button(P, L.GM_BACK, 110, function() P:Hide(); ns.UI.RefreshSoon() end)
    back:SetPoint("TOPLEFT", P, "TOPLEFT", 10, -10)
    local sel = W.Button(P, L.GM_SELECT_AH, 220, function() if P.data then G.SearchAH(P.data.itemID) end end)
    sel:SetPoint("TOPRIGHT", P, "TOPRIGHT", -10, -10)
    sel.SetTint(color)
    W.Tip(sel, L.GM_SELECT_AH, o.ahTip or L.GM_SELECT_AH_TIP)
    local sf, ct = scrollArea(P)
    sf:SetPoint("TOPLEFT", P, "TOPLEFT", 0, -40)
    sf:SetPoint("BOTTOMRIGHT", P, "BOTTOMRIGHT", -4, 6)
    P.sf, P.ct = sf, ct
    P.icon = W.ItemIcon(ct, 40)
    P.icon:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, -4)
    P.name = W.Text(ct, "title", "LEFT")
    P.name:SetPoint("TOPLEFT", P.icon, "TOPRIGHT", 10, -2)
    P.name:SetPoint("RIGHT", ct, "RIGHT", -12, 0)
    P.name:SetWordWrap(false)
    P.sub = W.Text(ct, "small", "LEFT")
    P.sub:SetPoint("TOPLEFT", P.name, "BOTTOMLEFT", 0, -6)

    local tiles = W.Tiles(ct, 4, 54)
    P.tiles = tiles
    local t = tiles.tiles
    for _, tile in ipairs(t) do tile:EnableMouse(true) end
    W.Tip(t[1], o.buy, o.buyTip)
    W.Tip(t[2], L.GM_RESALE_AIM, o.resaleTip or L.GM_RESALE_AIM_TIP)
    W.Tip(t[4], L.GM_CONFIDENCE, L.GM_CONFIDENCE_TIP)
    t[3]:SetScript("OnEnter", function(self)
        if not P.data then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        if o.profitTip then o.profitTip()
        else
            GameTooltip:AddLine(L.GM_PROFIT_DETAIL, 1, 0.82, 0)
            addProfitLines(P.data)
        end
        GameTooltip:Show()
    end)
    t[3]:SetScript("OnLeave", function() GameTooltip:Hide() end)

    P.R = ratingBlock(ct, color)
    P.view = o.views[1][1]
    P.views = W.Segments(ct, o.views, function() return P.view end, function(v) P.view = v; P.Refresh() end)
    P.views.color = color
    function P.SetView(v) P.view = v; P.views.Refresh(); P.Refresh() end

    -- the tiles from y down, the verdict, the view buttons; returns where the view starts
    function P.LayoutHead(y, wdt)
        tiles:ClearAllPoints()
        tiles:SetPoint("TOPLEFT", ct, "TOPLEFT", 10, y)
        tiles:SetWidth(wdt - 20)
        P.R.Layout(y - 64, wdt)
        P.views:ClearAllPoints()
        P.views:SetPoint("TOPLEFT", ct, "TOPLEFT", 10, y - 100)
        return y - 138
    end
    -- the item: its name (or the recipe's) in its quality colour, the quality first on the line under it
    function P.SetItem(id, label, ...)
        P.icon.Set(id)
        local i = ns.Item(id)
        P.name:SetText(label or ns.ItemName(id))
        P.name:SetTextColor(ns.QualityColor(i.quality or 1))
        local parts = {}
        if not i.loading and i.quality then parts[1] = qualityName(i.quality) end
        for k = 1, select("#", ...) do
            local w = select(k, ...)
            if w and w ~= "" then parts[#parts + 1] = w end
        end
        P.sub:SetText(MUTED .. table.concat(parts, "  ·  ") .. "|r")
    end
    -- the four tiles: what it costs, the resale aimed at, the profit, the confidence
    function P.SetTiles(d, buy, buyNote, resale, resaleNote, profit)
        local C0 = C()
        tiles.Set(1, o.buy, buy or "-", C0.sky, buyNote)
        tiles.Set(2, L.GM_RESALE_AIM, resale or "-", C0.gold, resaleNote)
        tiles.Set(3, L.GM_PROFIT, profit and signedProfit(profit) or "-", (profit or 0) < 0 and C0.loss or C0.profit)
        tiles.Set(4, L.GM_CONFIDENCE, confText(d), color)
    end
    return P
end

local function ago(t)
    if not t then return L.GM_NEVER end
    local m = math.floor((time() - t) / 60)
    if m < 1 then return L.GM_JUST_NOW end
    if m < 60 then return string.format(L.GM_AGO_MIN, m) end
    if m < 1440 then return string.format(L.GM_AGO_H, math.floor(m / 60)) end
    return string.format(L.GM_AGO_D, math.floor(m / 1440))
end
G.Ago = ago

-- The scan line at the foot of the market pages: last scan, next one, prices of a friend.
-- What the loader says: the scan under way (how far), else the reckoning.
local function loadingWords()
    if ns.Scan.Running() then
        local n, pct = ns.Scan.Count(), ns.Scan.Progress()
        if pct then
            return string.format(ns.Scan.Mode() == "quick" and L.AHP_SCANNING_PCT or L.AHP_SCANNING_FULL, math.floor(pct * 100), n)
        end
        return string.format(L.AHP_SCANNING, n)
    end
    return L.GM_LOADING
end

function G.ScanInfo()
    if ns.Scan.Running() then return GOLD .. L.GM_SCANNING .. "|r" end
    local b = ns.Scan.Book(ns.House())
    local at = b.at
    local wait = G.ScanWait()
    if not at then return GREEN .. L.GM_NO_SCAN_READY .. "|r" end
    local nextTxt = wait == 0 and (GREEN .. L.GM_SCAN_READY .. "|r") or string.format(L.GM_SCAN_IN, math.ceil(wait / 60))
    if b.fromGuild and b.fromWho then
        return string.format(L.GM_PRICES_OF, b.fromWho, math.floor((time() - at) / 60)) .. "  ·  " .. nextTxt
    end
    return string.format(L.GM_LAST_SCAN, math.floor((time() - at) / 60)) .. "  ·  " .. nextTxt
end

-- ---------------------------------------------------------------------
-- The page
-- ---------------------------------------------------------------------

local COLS = {
    { key = "buy", w = 110, deals = "GM_COL_BUY", crafts = "GM_COL_COST", volume = "GM_COL_BUY", transfer = "GM_COL_BUY", plans = "GM_COL_BUY" },
    { key = "sell", w = 110, deals = "GM_COL_SELL", crafts = "GM_COL_SELL", volume = "GM_COL_SELL", transfer = "GM_COL_SELL", plans = "GM_COL_SELL" },
    { key = "profit", w = 100, deals = "GM_COL_PROFIT_U", crafts = "GM_COL_PROFIT", volume = "GM_COL_PROFIT", transfer = "GM_COL_PROFIT_U", plans = "GM_COL_PROFIT_U" },
    { key = "conf", w = 120, deals = "GM_COL_CONF", crafts = "GM_COL_CONF", volume = "GM_COL_CONF", transfer = "GM_COL_CONF", plans = "GM_COL_CONF" },
}

local function buildMarket(page, mode)
    local body, color = page.body, page.color
    local crafts = mode == "crafts"
    local volume = mode == "volume"   -- buying in volume: like an offer, a lot of the cheapest units
    local deals = mode == "deals"
    local transfer = mode == "transfer"   -- bought in one house, sold in the other: like an offer
    local plans = mode == "plans"         -- bought at a merchant, sold at the Auction House: like an offer
    -- the same words in the three tabs: good deals, crafts, volume
    local function pick(a, b, c, t, pl)
        if crafts then return b elseif volume then return c elseif transfer then return t elseif plans then return pl end
        return a
    end
    -- the Top board is shown (else a list)
    local function isBoard()
        local u = ns.db.gmUI
        if crafts then return u.profFilter == "top" end
        if volume then return (u.volFilter or "top") == "top" end
        return true   -- Good deals: one screen, the Top offers by rarity
    end
    local function ui() return ns.db.gmUI end
    local function F() return ns.db.gmUI.filters end
    page.search = crafts and L.GM_SEARCH_RECIPE or L.SEARCH_ITEM
    local refreshers = {}
    local data, baseList = {}, {}
    local expanded = {}

    local function changed() ns.UI.RefreshSoon() end
    function page.OnSearch(t) F().search = t; changed() end

    -- ------------------------------------------------------------ filters
    local bar1 = CreateFrame("Frame", nil, body)
    bar1:SetHeight(30)
    bar1:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    bar1:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local profButtons, gear, lastFilter = {}, nil, nil
    local trTabs
    if deals or plans then
        -- one screen: the Top offers (by rarity, or by profession); the filters start the line
    elseif transfer then
        -- one tab per way: bought at the Horde (or Alliance) house and sold at the shared one, or the reverse
        trTabs = W.Segments(bar1, { { "faction", "" }, { "neutral", "" } }, function() return ui().trDir or "faction" end,
            function(v) ui().trDir = v; changed() end, 250)
        trTabs.color = color
        trTabs:SetPoint("LEFT", bar1, "LEFT", 0, 0)
        for _, b in ipairs(trTabs.buttons) do W.Tip(b, L.GM_TOP_TR_UP, L.GM_HOW_TOP_TR) end
        refreshers[#refreshers + 1] = trTabs.Refresh
        page.trTabs = trTabs
        lastFilter = trTabs
    elseif volume then
        local top = W.Button(bar1, L.GM_TOP_VOLUME, 100, function() ui().volFilter = "top"; changed() end)
        top:SetPoint("LEFT", bar1, "LEFT", 0, 0)
        W.Tip(top, L.GM_TOP_VOLUME, L.GM_TOP_VOLUME_TIP)
        refreshers[#refreshers + 1] = function() top.SetTint((ui().volFilter or "top") == "top" and color or nil) end
        local catButtons = {}
        for i, c in ipairs(G.VOLUME_CATS) do
            local b = iconButton(bar1, c.icon, c.key, function() ui().volFilter = c.key; changed() end)
            b:SetPoint("LEFT", top, "RIGHT", 10 + (i - 1) * 34, 0)
            W.Tip(b, L.GM_VOL_CAT[c.key], L.GM_VOL_CAT_TIP[c.key])
            catButtons[#catButtons + 1] = b
        end
        refreshers[#refreshers + 1] = function()
            for _, b in ipairs(catButtons) do b.SetTint(ui().volFilter == b.key and color or nil) end
        end
        lastFilter = catButtons[#catButtons]
    else
        local top = W.Button(bar1, L.GM_TOP_CRAFTS, 100, function() ui().profFilter = "top"; changed() end)
        top:SetPoint("LEFT", bar1, "LEFT", 0, 0)
        W.Tip(top, L.GM_TOP_CRAFTS, L.GM_TOP_CRAFTS_TIP)
        refreshers[#refreshers + 1] = function() top.SetTint(ui().profFilter == "top" and color or nil) end
        for i, p in ipairs(G.Professions()) do
            local b = iconButton(bar1, p.icon, p.id, function() ui().profFilter = p.id; changed() end)
            b:SetPoint("LEFT", top, "RIGHT", 10 + (i - 1) * 34, 0)
            b:HookScript("OnEnter", function(self)
                local info
                for _, q in ipairs(G.Professions()) do if q.id == self.key then info = q end end
                if not info then return end
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:AddLine(info.name, 1, 0.82, 0)
                GameTooltip:AddLine(string.format(L.GM_N_RECIPES, info.count), 1, 1, 1)
                if info.known then GameTooltip:AddLine(L.GM_MY_PROF, 0.35, 0.85, 0.45) end
                if info.count == 0 then GameTooltip:AddLine(L.GM_NO_RECIPES_PROF, 1, 0.5, 0, true) end
                GameTooltip:AddLine(L.GM_CLICK_PROF, 0.6, 0.6, 0.6)
                GameTooltip:Show()
            end)
            b:HookScript("OnLeave", function() GameTooltip:Hide() end)
            profButtons[#profButtons + 1] = b
        end
        lastFilter = profButtons[#profButtons] or top
        refreshers[#refreshers + 1] = function()
            local counts = {}
            for _, p in ipairs(G.Professions()) do counts[p.id] = p.count end
            for _, b in ipairs(profButtons) do
                b.SetTint(ui().profFilter == b.key and color or nil)
                b.icon:SetDesaturated((counts[b.key] or 0) == 0)
            end
        end
        gear = W.Button(bar1, L.GM_SETTINGS, 150)
        W.Tip(gear, L.GM_SETTINGS, function()
            local n = 0
            for _ in pairs(ns.db.excludedGlobal or {}) do n = n + 1 end
            return { L.GM_SETTINGS_TIP, n > 0 and (GOLD .. string.format(L.GM_N_REMOVED, n) .. "|r") or nil }
        end)
        refreshers[#refreshers + 1] = function()
            local n = 0
            for _ in pairs(ns.db.excludedGlobal or {}) do n = n + 1 end
            gear.SetLabel(L.GM_SETTINGS .. (n > 0 and (" " .. GOLD .. "(" .. n .. ")|r") or ""))
        end
    end

    -- the values to filter on, the same in both tabs: on the line of the choices
    -- when it fits, else on a second line (the window can be narrowed)
    local group = CreateFrame("Frame", nil, body)
    group:SetHeight(24)
    local parts = {}   -- from the left: { f, width(), visible() }
    local minProfit, l1 = box(group, L.GM_MIN_PROFIT, 50, function() return gold(ns.db.minProfit) end,
        function(t) ns.db.minProfit = parseGold(t) end, L.GM_MIN_PROFIT_TIP, changed)
    refreshers[#refreshers + 1] = minProfit.Refresh
    parts[#parts + 1] = { f = l1, width = function() return l1:GetStringWidth() + 6 + minProfit:GetWidth() end }
    local maxBuy, l2 = box(group, L.GM_MAX_BUY, 50, function() return gold(F().maxBuy) end,
        function(t) F().maxBuy = parseGold(t) end, L.GM_MAX_BUY_TIP, changed)
    refreshers[#refreshers + 1] = maxBuy.Refresh
    parts[#parts + 1] = { f = l2, width = function() return l2:GetStringWidth() + 6 + maxBuy:GetWidth() end }
    local maxPct
    if deals or transfer or plans then
        local l3
        maxPct, l3 = box(group, L.GM_MAX_PCT, 40, function()
            return tostring(math.floor((ns.db.dealThreshold or 0.7) * 100 + 0.5))
        end, function(t)
            local v = tonumber(t)
            if v and v > 0 and v < 100 then ns.db.dealThreshold = v / 100 end
        end, L.GM_MAX_PCT_TIP, changed)
        refreshers[#refreshers + 1] = maxPct.Refresh
        parts[#parts + 1] = { f = l3, width = function() return l3:GetStringWidth() + 6 + maxPct:GetWidth() end }
    end
    -- buying in volume: the least a lot must earn on what it costs
    local minRet
    if volume then
        local l4
        minRet, l4 = box(group, L.GM_MIN_RETURN, 34, function() return tostring(ns.db.volMinReturn or 5) end, function(t)
            local v = tonumber(((t or ""):gsub(",", ".")))
            if v and v >= 0 and v < 1000 then ns.db.volMinReturn = v end
        end, L.GM_MIN_RETURN_TIP, changed)
        refreshers[#refreshers + 1] = minRet.Refresh
        parts[#parts + 1] = { f = l4, width = function() return l4:GetStringWidth() + 6 + minRet:GetWidth() end }
    end
    -- the confidence filter (shared by the two tabs)
    local stars = W.Pick(group, L.GM_CONF_PICK, function()
        return { { "all", L.GM_ALL_CONF }, { 2, G.StarString(40) .. " +" }, { 3, G.StarString(60) .. " +" },
                 { 4, G.StarString(75) .. " +" }, { 5, G.StarString(100) } }
    end, function() return F().minStars or "all" end, function(v)
        F().minStars = v ~= "all" and v or nil
        changed()
    end)
    W.Tip(stars, L.GM_MIN_CONF, L.GM_MIN_CONF_TIP)
    refreshers[#refreshers + 1] = stars.Refresh
    -- not on the Top boards: a Top offer or craft has 4 stars at least anyway
    local function onBoard() return isBoard() end
    parts[#parts + 1] = { f = stars, width = function() return stars:GetWidth() end, visible = function() return not onBoard() end }
    if crafts then
        -- a profession's list: the paying recipes, or all of them (losing ones too)
        local which = W.Segments(group, { { false, L.GM_SHOW_PAYING }, { true, L.GM_SHOW_ALL_RECIPES } },
            function() return ui().craftsAll == true end, function(v) ui().craftsAll = v or nil; changed() end)
        which.color = color
        for _, b in ipairs(which.buttons) do W.Tip(b, L.GM_SHOW_ALL_RECIPES, L.GM_SHOW_ALL_TIP) end
        refreshers[#refreshers + 1] = which.Refresh
        parts[#parts + 1] = { f = which, width = function() return which:GetWidth() end,
                              visible = function() return ui().profFilter ~= "top" end }
        -- the advanced filtering, right after the choices
        parts[#parts + 1] = { f = gear, width = function() return gear:GetWidth() end }
    end

    -- the filters in use stand out (gold), so it is plain why lines are missing
    local function filterOn(key)
        if key == "minProfit" then return (ns.db.minProfit or 0) > 0 end
        if key == "maxBuy" then return (F().maxBuy or 0) > 0 end
        if key == "stars" then return F().minStars ~= nil end
        if key == "maxPct" then return math.abs((ns.db.dealThreshold or 0.7) - 0.7) > 0.001 end
        if key == "minReturn" then return (ns.db.volMinReturn or 5) ~= 5 end
        if key == "search" then return (F().search or "") ~= "" end
        return false
    end
    G.FilterOn = filterOn
    refreshers[#refreshers + 1] = function()
        minProfit.SetActive(filterOn("minProfit"))
        maxBuy.SetActive(filterOn("maxBuy"))
        if maxPct then maxPct.SetActive(filterOn("maxPct")) end
        if minRet then minRet.SetActive(filterOn("minReturn")) end
        stars.SetTint(filterOn("stars") and C().gold or nil)
    end

    -- ------------------------------------------------------------ status line
    local status = W.Text(body, "small", "LEFT")
    status:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 2, 0)
    status:SetPoint("RIGHT", body, "CENTER", 150, 0)
    status:SetWordWrap(false)
    local scanInfo = W.Text(body, "small", "RIGHT")
    scanInfo:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -2, 0)
    scanInfo:SetPoint("LEFT", body, "CENTER", 160, 0)
    scanInfo:SetWordWrap(false)
    local m = C().label
    scanInfo:SetTextColor(m[1], m[2], m[3])

    local area = CreateFrame("Frame", nil, body)
    -- in the middle while a scan or a reckoning is under way and nothing is shown yet
    local loader = W.Loader(area, color)
    loader:SetPoint("CENTER", area, "CENTER", 0, 20)
    loader:SetFrameLevel(area:GetFrameLevel() + 20)
    page.loader = loader

    local function layoutFilters()
        local x = 0
        for _, part in ipairs(parts) do
            local shown = not part.visible or part.visible()
            part.f:SetShown(shown)
            if shown then
                if x > 0 then x = x + 16 end
                part.f:ClearAllPoints()
                part.f:SetPoint("LEFT", group, "LEFT", x, 0)
                x = x + part.width()
            end
        end
        group:SetWidth(math.max(1, x))
        local avail = bar1:GetWidth() or 0
        local used = (lastFilter and lastFilter:GetRight() and bar1:GetLeft()) and (lastFilter:GetRight() - bar1:GetLeft()) or 0
        group:ClearAllPoints()
        area:ClearAllPoints()
        if not lastFilter then
            group:SetPoint("LEFT", bar1, "LEFT", 0, 0)
            area:SetPoint("TOPLEFT", bar1, "BOTTOMLEFT", 0, -10)
        elseif avail <= 0 or used + 18 + x <= avail then
            group:SetPoint("LEFT", lastFilter, "RIGHT", 18, 0)
            area:SetPoint("TOPLEFT", bar1, "BOTTOMLEFT", 0, -10)
        else
            group:SetPoint("TOPLEFT", bar1, "BOTTOMLEFT", 0, -8)
            area:SetPoint("TOPLEFT", group, "BOTTOMLEFT", 0, -10)
        end
        area:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 20)
    end
    layoutFilters()
    bar1:SetScript("OnSizeChanged", function() layoutFilters() end)
    refreshers[#refreshers + 1] = layoutFilters

    local openDeal, openCraft, openVolume  -- set below

    local function open(d)
        if d.recipe then openCraft(d.recipeID) elseif d.volume then openVolume(d) else openDeal(d) end
    end

    -- ------------------------------------------------------------ top strip
    local topCard = W.Card(area)
    topCard:SetPoint("TOPLEFT", area, "TOPLEFT", 0, 0)
    topCard:SetPoint("RIGHT", area, "RIGHT", 0, 0)
    topCard:SetHeight(TOP_H)
    local topTitle = W.Text(topCard, "head", "LEFT")
    topTitle:SetPoint("TOPLEFT", topCard, "TOPLEFT", 12, -8)
    topTitle:SetTextColor(color[1], color[2], color[3])
    topTitle:SetText(pick(L.GM_TOP_OFFERS_UP, L.GM_TOP_CRAFTS_UP, L.GM_TOP_VOLUME_UP, L.GM_TOP_TR_UP, L.GM_TOP_PL_UP))
    local topSub = W.Text(topCard, "small", "LEFT")
    topSub:SetPoint("LEFT", topTitle, "RIGHT", 10, 0)
    topSub:SetText(MUTED .. pick(L.GM_TOP_OFFERS_SUB, L.GM_TOP_CRAFTS_SUB, L.GM_TOP_VOLUME_SUB, L.GM_TOP_TR_SUB, L.GM_TOP_PL_SUB) .. "|r")
    local help = CreateFrame("Frame", nil, topCard)
    help:SetSize(18, 18)
    help:SetPoint("TOPRIGHT", topCard, "TOPRIGHT", -8, -6)
    help:EnableMouse(true)
    local q = W.Text(help, "head", "CENTER")
    q:SetPoint("CENTER")
    q:SetText("?")
    q:SetTextColor(color[1], color[2], color[3])
    W.Tip(help, L.GM_HOW_TOP, { L.GM_HOW_TOP_1, pick(L.GM_HOW_TOP_DEALS, L.GM_HOW_TOP_CRAFTS, L.GM_HOW_TOP_VOLUME, L.GM_HOW_TOP_TR, L.GM_HOW_TOP_PL), L.GM_HOW_TOP_2 })
    local topEmpty = W.Text(topCard, "small", "LEFT")
    topEmpty:SetPoint("TOPLEFT", topCard, "TOPLEFT", 12, -34)
    topEmpty:SetPoint("RIGHT", topCard, "RIGHT", -12, 0)
    topEmpty:SetWordWrap(true)
    local topCards = {}
    for i = 1, TOP_CARDS do
        topCards[i] = offerCard(topCard, color, open)
        topCards[i]:SetHeight(54)
    end
    local function placeTopCards()
        local w = (topCard:GetWidth() - 12 - (TOP_CARDS - 1) * 6) / TOP_CARDS
        for i, c in ipairs(topCards) do
            c:SetWidth(math.max(40, w))
            c:ClearAllPoints()
            c:SetPoint("TOPLEFT", topCard, "TOPLEFT", 6 + (i - 1) * (w + 6), -30)
        end
    end

    local function refreshTop(list)
        local top = pick(G.TopDeals, G.TopCrafts, G.TopVolume, G.TopTransfers, G.TopPlans)(list)
        placeTopCards()
        for i, c in ipairs(topCards) do
            if top[i] then c.Set(top[i]); c:Show() else c.data = nil; c:Hide() end
        end
        if #top == 0 then
            local n, items = G.TotalSales()
            topEmpty:SetText(MUTED .. string.format(pick(L.GM_TOP_EMPTY_DEALS, L.GM_TOP_EMPTY_CRAFTS, L.GM_TOP_EMPTY_VOLUME, L.GM_TOP_EMPTY_DEALS, L.GM_TOP_EMPTY_DEALS), n, items, ns.db.scanCount or 0) .. "|r")
            topEmpty:Show()
        else
            topEmpty:Hide()
        end
    end

    -- ------------------------------------------------------------ list
    local listCard = W.Card(area)
    listCard:SetPoint("TOPLEFT", topCard, "BOTTOMLEFT", 0, -8)
    listCard:SetPoint("BOTTOMRIGHT", area, "BOTTOMRIGHT", 0, 0)
    local header = CreateFrame("Frame", nil, listCard)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", listCard, "TOPLEFT", 10, -8)
    header:SetPoint("RIGHT", listCard, "RIGHT", -10, 0)
    local heads = {}
    local function headButton(key, justify)
        local h = CreateFrame("Button", nil, header)
        h:SetHeight(20)
        h.text = W.Text(h, "small", justify)
        h.text:SetAllPoints()
        h.key = key
        h:SetScript("OnClick", function()
            local u = ui()
            if u.sortKey == key then u.sortDesc = not u.sortDesc
            else u.sortKey, u.sortDesc = key, key ~= "name" end
            changed()
        end)
        if key == "conf" then W.Tip(h, L.GM_CONF_HEAD, L.GM_CONF_HEAD_TIP)
        else W.Tip(h, L.GM_SORT, L.GM_SORT_TIP) end
        heads[#heads + 1] = h
        return h
    end
    local x = -4
    for i = #COLS, 1, -1 do
        local h = headButton(COLS[i].key, "RIGHT")
        h:SetWidth(COLS[i].w)
        h:SetPoint("RIGHT", header, "RIGHT", x, 0)
        h.label = L[COLS[i][mode]]
        COLS[i].x = x
        x = x - COLS[i].w - 8
    end
    local nameHead = headButton("name", "LEFT")
    nameHead:SetPoint("LEFT", header, "LEFT", 26, 0)
    nameHead:SetPoint("RIGHT", header, "RIGHT", x, 0)
    nameHead.label = pick(L.GM_COL_ITEM, L.GM_COL_RECIPE, L.GM_COL_MATERIAL, L.GM_COL_ITEM, L.GM_COL_ITEM)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(18, 18)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        r.cols = {}
        local xx = -4
        for i = #COLS, 1, -1 do
            local fs = W.Text(r, "small", "RIGHT")
            fs:SetWidth(COLS[i].w)
            fs:SetPoint("RIGHT", r, "RIGHT", xx, 0)
            fs:SetWordWrap(false)
            r.cols[i] = fs
            xx = xx - COLS[i].w - 8
        end
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
        r.name:SetPoint("RIGHT", r.cols[1], "LEFT", -8, 0)
        r.name:SetWordWrap(false)
        -- the profit cell has its own tooltip
        local hit = CreateFrame("Button", nil, r)
        hit:SetAllPoints(r.cols[3])
        hit:SetScript("OnClick", function() r:Click() end)
        hit:SetScript("OnEnter", function(self)
            if not r.data then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(L.GM_PROFIT_DETAIL, 1, 0.82, 0)
            addProfitLines(r.data)
            GameTooltip:Show()
        end)
        hit:SetScript("OnLeave", function() GameTooltip:Hide() end)
        r:SetScript("OnClick", function(self) if self.data then open(self.data) end end)
        r:SetScript("OnEnter", function(self)
            local d = self.data
            if not d then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetItemByID(d.itemID)
            GameTooltip:AddLine(" ")
            if not d.buy then GameTooltip:AddLine(d.recipe and L.GM_MAT_UNKNOWN or L.GM_NOT_LISTED, 1, 0.3, 0.3) end
            if d.estimate then
                GameTooltip:AddLine(L.GM_ESTIMATE, 1, 0.5, 0)
            elseif d.days and d.days > 0 then
                GameTooltip:AddLine(string.format(L.GM_USUAL_DAYS, d.days), 0.6, 0.8, 1)
            end
            if d.recipe then GameTooltip:AddLine(L.GM_PROF .. " " .. G.ProfName(d.recipe.prof), 1, 1, 1) end
            if d.qty then GameTooltip:AddLine(string.format(L.GM_N_LISTED, d.qty), 1, 1, 1) end
            addVolumeLine(d)
            addSalesTooltip(d)
            GameTooltip:AddLine(d.recipe and L.GM_CLICK_MATS or L.GM_CLICK_DEAL, 0.35, 0.85, 0.45)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return r
    end
    local function fillRow(r, d)
        r.data = d
        local i = ns.Item(d.itemID)
        r.icon:SetTexture(i.icon or 134400)
        local tag = ""
        if d.cd then tag = " " .. HEX.sky .. "[" .. string.format(L.GM_CD_TAG, ns.Cooldown.Label(d.cd)) .. "]|r" end
        if d.kind == "PNJ" then tag = " " .. GREEN .. "[" .. L.GM_VENDOR_TAG .. "]|r" end
        r.name:SetText((d.label or i.name or ("#" .. d.itemID)) .. (d.suffix or "") .. tag)
        r.name:SetTextColor(ns.QualityColor(i.quality or 1))
        r.cols[1]:SetText(ns.Money(d.buy))
        r.cols[2]:SetText(ns.Money(G.ResaleShown(d)) .. (d.estimate and GUESS or ""))
        r.cols[3]:SetText(signedProfit(d.profit))
        r.cols[4]:SetText(confText(d, 11))
    end
    local list = W.List(listCard, ROW_H, makeRow, fillRow)
    list:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -6)
    list:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -6, 8)
    list.Color(color)
    local listEmpty = W.Text(listCard, "body", "CENTER")
    listEmpty:SetPoint("TOPLEFT", list, "TOPLEFT", 20, -30)
    listEmpty:SetPoint("TOPRIGHT", list, "TOPRIGHT", -20, -30)
    listEmpty:SetWordWrap(true)
    listEmpty:SetTextColor(m[1], m[2], m[3])

    -- ------------------------------------------------------------ board (top view)
    local board = W.Card(area)
    board:SetAllPoints(area)
    local bsf, bcontent = scrollArea(board)
    bsf:SetPoint("TOPLEFT", board, "TOPLEFT", 6, -6)
    bsf:SetPoint("BOTTOMRIGHT", board, "BOTTOMRIGHT", -4, 6)
    local boardEmpty = W.Text(board, "body", "LEFT")
    boardEmpty:SetPoint("TOPLEFT", board, "TOPLEFT", 16, -16)
    boardEmpty:SetPoint("RIGHT", board, "RIGHT", -16, 0)
    boardEmpty:SetWordWrap(true)
    local lines = {}

    local function boardLine(i)
        local line = CreateFrame("Button", nil, bcontent)
        line.bg = W.Fill(line, "BACKGROUND", 1, 1, 1, 0.035)
        line.edge = W.Outline(line, 1, 1, 1, 0.06)
        local bar = line:CreateTexture(nil, "ARTWORK")
        bar:SetPoint("TOPLEFT"); bar:SetPoint("BOTTOMLEFT")
        bar:SetWidth(3)
        bar:SetColorTexture(color[1], color[2], color[3], 1)
        line.bar = bar
        line.icon = line:CreateTexture(nil, "ARTWORK")
        line.icon:SetSize(30, 30)
        line.icon:SetPoint("TOPLEFT", line, "TOPLEFT", 12, -8)
        line.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        line.name = W.Text(line, "body", "LEFT")
        line.name:SetPoint("TOPLEFT", line.icon, "BOTTOMLEFT", 0, -4)
        line.name:SetWidth(LABEL_W - 16)
        line.name:SetWordWrap(false)
        line.name:SetTextColor(color[1], color[2], color[3])
        line.toggle = W.Text(line, "tiny", "LEFT")
        line.toggle:SetPoint("TOPLEFT", line.name, "BOTTOMLEFT", 0, -4)
        line.toggle:SetWidth(LABEL_W - 16)
        line.cards = {}
        line:SetScript("OnClick", function(self)
            if not self.expandable then return end
            expanded[self.gid] = not expanded[self.gid]
            changed()
        end)
        line:SetScript("OnEnter", function(self)
            if not self.expandable then return end
            self.edge.Color(color[1], color[2], color[3], 0.8)
            GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
            GameTooltip:AddLine(self.gname, 1, 0.82, 0)
            GameTooltip:AddLine(expanded[self.gid] and L.GM_COLLAPSE_TIP or L.GM_EXPAND_TIP, 1, 1, 1)
            GameTooltip:Show()
        end)
        line:SetScript("OnLeave", function(self)
            self.edge.Color(1, 1, 1, 0.06)
            GameTooltip:Hide()
        end)
        lines[i] = line
        return line
    end

    local function refreshBoard(list2)
        local groups = {}
        for _, d in ipairs(list2) do
            local id, g
            if crafts then
                id = d.recipe.prof or "?"
                g = groups[id]
                if not g then
                    g = { id = id, name = G.ProfName(id), icon = ns.PROF_ICONS[id] or 134400, items = {} }
                    groups[id] = g
                end
            elseif plans then
                id = d.prof or "?"
                g = groups[id]
                if not g then
                    g = { id = id, name = G.ProfName(id), icon = ns.PROF_ICONS[id] or 134400, items = {} }
                    groups[id] = g
                end
            elseif transfer then
                -- one line per kind of item: plans, gear, materials, consumables, the rest
                id = itemKind(d.itemID)
                g = groups[id]
                if not g then
                    g = { id = id, rank = -KIND_RANK[id], items = {}, name = L.GM_KIND[id] }
                    groups[id] = g
                end
            elseif volume then
                id = d.cat or "other"
                g = groups[id]
                if not g then
                    local rank, icon = 0, 134400
                    for k, c in ipairs(G.VOLUME_CATS) do if c.key == id then rank, icon = -k, c.icon end end
                    g = { id = id, rank = rank, name = L.GM_VOL_CAT[id] or id, icon = icon, items = {} }
                    groups[id] = g
                end
            else
                local i = ns.Item(d.itemID)
                local qq = (not i.loading) and i.quality or nil
                id = "q" .. tostring(qq or "?")
                g = groups[id]
                if not g then
                    g = { id = id, rank = qq or -1, name = qq and (qualityHex(qq) .. qualityName(qq) .. "|r") or L.GM_QUALITY_UNKNOWN, items = {} }
                    groups[id] = g
                end
            end
            g.items[#g.items + 1] = d
        end
        local ordered = {}
        for _, g in pairs(groups) do
            -- best first: profit x confidence (no sale seen yet: by profit alone, after the confirmed ones)
            table.sort(g.items, function(a, b)
                local ka, kb = (a.rank or a.profit or 0) * math.max(a.conf or 0, 0.01), (b.rank or b.profit or 0) * math.max(b.conf or 0, 0.01)
                if ka == kb then return a.itemID < b.itemID end
                return ka > kb
            end)
            if not g.icon then g.icon = ns.Item(g.items[1].itemID).icon end
            ordered[#ordered + 1] = g
        end
        if crafts or plans then
            table.sort(ordered, function(a, b) return tostring(a.name) < tostring(b.name) end)
        else
            table.sort(ordered, function(a, b) return a.rank > b.rank end)
        end
        bsf.Update()
        local contentW = math.max(300, bsf:GetWidth() - 10)
        local labelW = LABEL_W
        local cardW = (contentW - labelW - 12 - (BOARD_CARDS - 1) * 6) / BOARD_CARDS
        local y = 0
        for i, g in ipairs(ordered) do
            local line = lines[i] or boardLine(i)
            local isOpen = expanded[g.id] and #g.items > BOARD_CARDS
            local shown = isOpen and #g.items or math.min(#g.items, BOARD_CARDS)
            local cardRows = math.max(1, math.ceil(shown / BOARD_CARDS))
            local blockH = cardRows * (CARD_H + 6) - 6
            local h = math.max(blockH + 10, 84)
            local offsetY = math.floor((h - blockH) / 2)
            line.gid, line.gname = g.id, g.name
            line.expandable = #g.items > BOARD_CARDS
            line.icon:SetTexture(g.icon)
            line.name:SetText(g.name)
            if line.expandable then
                local more = #g.items - BOARD_CARDS
                line.toggle:SetText(isOpen and (GOLD .. L.GM_COLLAPSE .. "|r") or (GOLD .. string.format(L.GM_N_MORE, more) .. "|r"))
                line.toggle:Show()
            else
                line.toggle:Hide()
            end
            for c = 1, math.max(shown, #line.cards) do
                local card = line.cards[c]
                local d = g.items[c]
                if c <= shown and d then
                    if not card then
                        card = offerCard(line, color, open)
                        line.cards[c] = card
                    end
                    local col, row = (c - 1) % BOARD_CARDS, math.floor((c - 1) / BOARD_CARDS)
                    card:SetSize(math.max(40, cardW), CARD_H)
                    card:ClearAllPoints()
                    card:SetPoint("TOPLEFT", line, "TOPLEFT", labelW + col * (cardW + 6), -offsetY - row * (CARD_H + 6))
                    card.Set(d)
                    card:Show()
                elseif card then
                    card.data = nil
                    card:Hide()
                end
            end
            line:SetSize(contentW, h)
            line:ClearAllPoints()
            line:SetPoint("TOPLEFT", bcontent, "TOPLEFT", 0, -y)
            line:Show()
            y = y + h + 6
        end
        for i = #ordered + 1, #lines do lines[i]:Hide() end
        bcontent:SetHeight(math.max(1, y))
        bsf.Update()
        if #ordered == 0 then
            local n, items = G.TotalSales()
            local words = string.format(pick(L.GM_BOARD_EMPTY_DEALS, L.GM_BOARD_EMPTY_CRAFTS, L.GM_BOARD_EMPTY_VOLUME, L.GM_BOARD_EMPTY_TR, L.GM_BOARD_EMPTY_PL), n, items, ns.db.scanCount or 0)
            if page.emptyReason == "filters" then
                -- sales are known: nothing passes the filters (most often the profit min)
                local minP = ns.db.minProfit or 0
                words = minP > 0 and string.format(L.GM_TOP_EMPTY_MINPROFIT, ns.Money(minP)) or L.GM_TOP_EMPTY_FILTERS
            end
            boardEmpty:SetText(MUTED .. words .. "|r")
            boardEmpty:Show()
        else
            boardEmpty:Hide()
        end
        return #ordered
    end

    -- ------------------------------------------------------------ deal detail (an offer, or from one house to the other)
    if deals or transfer or plans then
        local D = detailPanel(body, color, { buy = L.GM_BUY_PRICE, buyTip = L.GM_BUY_PRICE_TIP,
                                             views = { { "why", L.GM_SHOW_WHY }, { "chart", L.GM_SHOW_CHART } } })
        function page.ToggleDealChart()
            D.SetView(D.view == "chart" and "why" or "chart")
            return D.view == "chart"
        end

        -- buy it now (the cheapest buyout) or bid on it, two clicks each
        local buyNow = W.Button(D.ct, "", 230, function()
            local d = D.data
            if d and d.buy then buyClick(d.itemID, 1, math.floor(d.buy * 1.05), false, offerCtx(d)) end
        end)
        buyNow:SetPoint("TOPRIGHT", D.ct, "TOPRIGHT", -12, -4)
        W.Tip(buyNow, L.GM_BUY_NOW_T, L.GM_BUY_NOW_TIP)
        local bidBtn = W.Button(D.ct, L.GM_BID, 200, function()
            local d = D.data
            if d then buyClick(d.itemID, 1, nil, true, offerCtx(d)) end
        end)
        bidBtn:SetPoint("RIGHT", buyNow, "LEFT", -6, 0)
        W.Tip(bidBtn, L.GM_BID, L.GM_BID_TIP)
        -- a plan: bought at a merchant, a marker on the map to the nearest one
        local vendorBtn = W.Button(D.ct, "", 230, function()
            local d = D.data
            local list = d and ns.Prices.VendorsOf(d.itemID) or {}
            local pins = {}
            for _, v in ipairs(list) do pins[#pins + 1] = v.pin end
            if #pins > 0 then ns.Map.Show(ns.Map.Nearest(pins)) end
        end)
        vendorBtn:SetPoint("TOPRIGHT", D.ct, "TOPRIGHT", -12, -4)
        vendorBtn.SetTint(color)
        W.Tip(vendorBtn, L.GM_PL_VENDOR_T, L.GM_PL_VENDOR_TIP)
        page.dealVendor = vendorBtn
        local buyCancel = W.Button(D.ct, L.GM_VOL_DO_CANCEL, 90, function() ns.Buy.Cancel(); ns.Sell.Cancel() end)
        buyCancel:SetPoint("RIGHT", bidBtn, "LEFT", -6, 0)
        -- once picked up at the mailbox: post it at the resale aimed, for 24 h (an
        -- item one listing per click, a commodity all the units in the bags)
        local function sellQty(id)
            local n = ns.Sell.InBags(id)
            return ns.Buy.IsCommodity(id) and n or math.min(n, 1), n
        end
        local sellBtn = W.Button(D.ct, "", 250, function()
            local d = D.data
            if not (d and d.market) then return end
            local st = ns.Sell.State()
            if st and st.id == d.itemID and st.step == "confirm" then ns.Sell.Confirm() return end
            if st or ns.Buy.Busy() then return end
            ns.Sell.Post(d.itemID, (sellQty(d.itemID)), math.floor(d.market))
        end)
        sellBtn:SetPoint("RIGHT", buyCancel, "LEFT", -6, 0)
        W.Tip(sellBtn, L.GM_SELL_T, L.GM_SELL_TIP)
        page.dealSell = sellBtn
        -- bought here and still in the mail: { [id] = units }
        local inMail = {}
        ns.On("Bought", function(id, qty) inMail[id] = (inMail[id] or 0) + (qty or 1) end)
        local buyHint = W.Text(D.ct, "small", "RIGHT")
        page.DealHint = function() return buyHint:GetText() end
        buyHint:SetPoint("TOPRIGHT", buyNow, "BOTTOMRIGHT", 0, -6)
        buyHint:SetPoint("LEFT", D.ct, "CENTER", -60, 0)
        buyHint:SetWordWrap(false)
        -- the buttons shown, lined up from the right; the name takes what is left
        local function layoutButtons()
            local prev
            for _, b in ipairs({ vendorBtn, buyNow, bidBtn, buyCancel, sellBtn }) do
                if b:IsShown() then
                    b:ClearAllPoints()
                    if prev then b:SetPoint("RIGHT", prev, "LEFT", -6, 0)
                    else b:SetPoint("TOPRIGHT", D.ct, "TOPRIGHT", -12, -4) end
                    prev = b
                end
            end
            D.name:ClearAllPoints()
            D.name:SetPoint("TOPLEFT", D.icon, "TOPRIGHT", 10, -2)
            if prev then D.name:SetPoint("RIGHT", prev, "LEFT", -10, 0)
            else D.name:SetPoint("RIGHT", D.ct, "RIGHT", -12, 0) end
        end
        page.dealBuy, page.dealBid = buyNow, bidBtn

        local function refreshBuy(d)
            local id = d.itemID
            local commodity = ns.Buy.IsCommodity(id)
            -- from one house to the other: bought at one, posted at the other
            local here = ns.Scan.OpenHouse and ns.Scan.OpenHouse()
            local atFrom = not d.transfer or here == d.from
            local atTo = not (d.transfer or d.plan) or here == d.to
            -- a plan: at a merchant, not at the Auction House
            buyNow:SetShown(not d.plan)
            vendorBtn:SetShown(d.plan == true)
            local vendors = d.plan and ns.Prices.VendorsOf(id) or {}
            if d.plan then
                vendorBtn.SetLabel(L.GM_PL_MAP)
                vendorBtn.SetEnabledLook(#vendors > 0)
            end
            buyLook(buyNow, id, false, string.format(L.GM_BUY_NOW, d.buy and ns.Money(d.buy) or "-"), d.buy ~= nil and atFrom, color)
            bidBtn:SetShown(not commodity and not d.plan)
            buyLook(bidBtn, id, true, L.GM_BID, atFrom, nil)
            local st = ns.Buy.State()
            local mine = st and st.id == id
            -- posting what is in the bags
            local sst = ns.Sell.State()
            local selling = sst and sst.id == id
            local qty, have = sellQty(id)
            if have > 0 then inMail[id] = nil end
            local canSell = d.kind ~= "PNJ" and d.market ~= nil and (have > 0 or selling)
            sellBtn:SetShown(canSell or false)
            if selling and sst.step == "confirm" then
                sellBtn.SetLabel(L.GM_VOL_DO_SELL_CONFIRM)
                sellBtn.SetTint(C().gold)
                sellBtn.SetEnabledLook(true)
            elseif selling then
                sellBtn.SetLabel(L.GM_VOL_DO_WAIT)
                sellBtn.SetTint(nil)
                sellBtn.SetEnabledLook(false)
            elseif canSell then
                sellBtn.SetLabel(string.format(L.GM_VOL_DO_SELL, qty, ns.Money(math.floor(d.market))))
                sellBtn.SetTint(C().profit)
                sellBtn.SetEnabledLook(ns.Buy.ahOpen and atTo and not st and not sst and true or false)
            end
            buyCancel:SetShown((mine and st.step == "confirm") or (selling and sst.step == "confirm") or false)
            local words = ""
            if not ns.Buy.ahOpen and not d.plan then
                words = MUTED .. L.BUY_AH_CLOSED .. "|r"
            elseif d.kind == "PNJ" and have > 0 then
                words = GREEN .. L.GM_SELL_VENDOR .. "|r"
            elseif d.plan and have == 0 then
                local v = vendors[1]
                words = v and (MUTED .. string.format(L.GM_PL_WHERE, v.name, v.zone or "?") .. "|r") or (MUTED .. L.GM_PL_SEEN .. "|r")
            elseif (d.transfer or d.plan) and have > 0 and not atTo then
                words = GOLD .. string.format(L.GM_TR_GO_SELL, houseName(d.to)) .. "|r"
            elseif d.transfer and have == 0 and not atFrom and (inMail[id] or 0) == 0 then
                words = GOLD .. string.format(L.GM_TR_GO_BUY, houseName(d.from)) .. "|r"
            elseif (inMail[id] or 0) > 0 and have == 0 then
                words = GOLD .. L.GM_BUY_MAIL .. "|r"
            elseif canSell and not ns.Buy.IsCommodity(id) and have > 1 then
                words = MUTED .. string.format(L.GM_SELL_ONE_BY_ONE, have) .. "|r"
            elseif mine and st.step == "confirm" and st.bid then
                words = MUTED .. L.GM_BID_HINT .. "|r"
            elseif mine and st.step == "confirm" and d.buy and st.unit and st.unit > d.buy * 1.03 then
                words = RED .. string.format(L.GM_BUY_DEARER, ns.Money(d.buy)) .. "|r"
            elseif commodity then
                words = MUTED .. L.GM_BUY_ONE .. "|r"
            end
            buyHint:SetText(words)
            layoutButtons()
        end

        function page.RefreshDeal()
            if not D:IsShown() or not D.data then return end
            local d = D.data
            local id = d.itemID
            if d.transfer then d = G.EvaluateTransfer(id, d.from) or d; D.data = d
            elseif d.plan then d = G.EvaluatePlan(id, d.house) or d; D.data = d
            elseif d.kind ~= "PNJ" then d = G.EvaluateItem(id); D.data = d end
            local wdt = math.max(500, D.sf:GetWidth() - 12)
            D.ct:SetHeight(-D.R.LayoutView(D.LayoutHead(-56, wdt), wdt) + 12)
            local _, itemType, itemSub = instantType(id)
            local limits = (d.limits and #d.limits > 0) and ("|r" .. AMBER .. "[!] " .. table.concat(d.limits, "  ·  ") .. "|r" .. MUTED) or nil
            D.SetItem(id, nil, itemType, itemSub ~= itemType and itemSub or nil, (d.transfer or d.plan) and transferWords(d) or nil, limits)
            D.SetTiles(d, ns.Money(d.buy), nil, ns.Money(G.ResaleShown(d)) .. (d.estimate and GUESS or ""),
                SOURCE_NOTE[d.source] and L[SOURCE_NOTE[d.source]], d.profit)
            D.R.Fill(d, D.view)
            refreshBuy(d)
            D.sf.Update()
        end
        D.Refresh = page.RefreshDeal

        openDeal = function(d)
            D.data = d
            D:Show()
            page.RefreshDeal()
        end
        page.dealPanel = D
        page.OpenDeal = openDeal
    end

    -- ------------------------------------------------------------ volume detail
    if volume then
        local V = detailPanel(body, color, { buy = L.GM_VOL_BUY, buyTip = L.GM_VOL_BUY_TIP, resaleTip = L.GM_VOL_RESALE_TIP,
                                             views = { { "plan", L.GM_VIEW_PLAN }, { "why", L.GM_SHOW_WHY }, { "chart", L.GM_SHOW_CHART } } })
        local ct, R = V.ct, V.R
        function page.SetVolumeView(v) V.SetView(v) end

        -- the plans: two or three lots to choose from, in a small table; a click on one
        -- shows its listings below, cheapest first, the ones to buy in green
        local selPlan = "max"
        local SCOLS = { { 8, "GM_VOL_PLAN_COL" }, { 110, "GM_QTY" }, { 200, "GM_VOL_UP_TO" }, { 310, "GM_VOL_COST" },
                        { 430, "GM_VOL_RESALE_U" }, { 550, "GM_PROFIT" }, { 660, "GM_VOL_RETURN" }, { 760, "GM_VOL_DELAY" },
                        { 850, "GM_VOL_STARS" } }
        local shead = CreateFrame("Frame", nil, ct)
        shead:SetHeight(20)
        W.Fill(shead, "BACKGROUND", 1, 1, 1, 0.05)
        for _, c in ipairs(SCOLS) do
            local t = W.Text(shead, "small", "LEFT")
            t:SetPoint("LEFT", shead, "LEFT", c[1], 0)
            t:SetText(L[c[2]])
            local lc = C().label
            t:SetTextColor(lc[1], lc[2], lc[3])
        end
        local PLAN_MAX = 4   -- prudent, balanced, max, risky
        local srows = {}
        for i = 1, PLAN_MAX do
            local row = CreateFrame("Button", nil, ct)
            row:SetHeight(22)
            row.sel = row:CreateTexture(nil, "BACKGROUND")
            row.sel:SetAllPoints()
            local hl = row:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0.05)
            row.c = {}
            for j, c in ipairs(SCOLS) do
                local t = W.Text(row, j == 1 and "body" or "small", "LEFT")
                t:SetPoint("LEFT", row, "LEFT", c[1], 0)
                row.c[j] = t
            end
            row:SetScript("OnClick", function(self) if self.key then selPlan = self.key; page.RefreshVolume() end end)
            row:SetScript("OnEnter", function(self)
                if not self.key then return end
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:AddLine(L.GM_VOL_PLAN_NAME[self.key], 1, 0.82, 0)
                GameTooltip:AddLine(L.GM_VOL_PLAN_TIP[self.key], 1, 1, 1, true)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function() GameTooltip:Hide() end)
            srows[i] = row
        end
        local planHint = W.Text(ct, "tiny", "LEFT")
        local planText = W.Text(ct, "body", "LEFT")   -- when there is no plan
        planText:SetWordWrap(true)

        -- do the plan chosen: buy it, then post it. The game wants a click for each
        -- purchase and each post: one button each, the label says the next click.
        local current            -- { d, plan }: what the buttons act on
        local run = {}           -- [itemID] = units bought for a plan in this session
        ns.On("Bought", function(id, qty) run[id] = (run[id] or 0) + (qty or 0) end)
        ns.On("Posted", function(id, qty) if run[id] then run[id] = math.max(0, run[id] - (qty or 0)) end end)
        local function toPost(id)
            local inBags = ns.Sell.InBags(id)
            return (run[id] or 0) > 0 and math.min(run[id], inBags) or inBags
        end
        local doBuy = W.Button(ct, "", 300, function()
            local c = current
            if not (c and c.plan) then return end
            local id, st = c.d.itemID, ns.Buy.State()
            if st and st.id == id and st.step == "confirm" then ns.Buy.Confirm() return end
            if st or ns.Sell.Busy() then return end
            local left = c.plan.n - (run[id] or 0)
            if left > 0 then ns.Buy.Start(id, left, c.plan.unit, nil, { kind = "volume", aim = c.plan.resale, sellHouse = ns.House() }) end
        end)
        doBuy.SetTint(color)
        local doSell = W.Button(ct, "", 300, function()
            local c = current
            if not (c and c.plan) then return end
            local id, st = c.d.itemID, ns.Sell.State()
            if st and st.id == id and st.step == "confirm" then ns.Sell.Confirm() return end
            if st or ns.Buy.Busy() then return end
            ns.Sell.Post(id, toPost(id), c.plan.resale)
        end)
        local doCancel = W.Button(ct, L.GM_VOL_DO_CANCEL, 100, function() ns.Buy.Cancel(); ns.Sell.Cancel() end)
        local doText = W.Text(ct, "small", "LEFT")
        doText:SetWordWrap(true)
        W.Tip(doBuy, L.GM_VOL_DO_TITLE, L.GM_VOL_DO_TIP)
        W.Tip(doSell, L.GM_VOL_DO_TITLE, L.GM_VOL_DO_TIP)

        -- the labels of the two buttons and the line under them, for the plan chosen
        local function refreshDo(d, plan, shown)
            current = shown and plan and { d = d, plan = plan } or nil
            doBuy:SetShown(current ~= nil)
            doSell:SetShown(current ~= nil)
            doText:SetShown(current ~= nil)
            if not current then doCancel:Hide() return end
            local id = d.itemID
            local open = ns.Buy.ahOpen
            local bst, sst = ns.Buy.State(), ns.Sell.State()
            local myBuy, mySell = bst and bst.id == id, sst and sst.id == id
            -- a scan only gets in the way of buying an item (it is searched like the scan
            -- browses); a commodity is bought, and anything posted, while a scan runs
            local scanning = ns.Scan.Running() and not ns.Buy.IsCommodity(id)
            local free = open and not bst and not sst
            local bought = run[id] or 0
            local left = math.max(0, plan.n - bought)
            local post = toPost(id)
            -- buy
            if myBuy and bst.step == "confirm" then
                doBuy.SetLabel(string.format(L.GM_VOL_DO_CONFIRM, bst.qty or 0, ns.Money(bst.total)))
                doBuy.SetEnabledLook(true)
            elseif myBuy then
                doBuy.SetLabel(L.GM_VOL_DO_WAIT)
                doBuy.SetEnabledLook(false)
            elseif left > 0 then
                doBuy.SetLabel(string.format(L.GM_VOL_DO_BUY, left, ns.Money(plan.unit)))
                doBuy.SetEnabledLook(free and not scanning)
            else
                doBuy.SetLabel(L.GM_VOL_DO_BOUGHT)
                doBuy.SetEnabledLook(false)
            end
            -- post
            if mySell and sst.step == "confirm" then
                doSell.SetLabel(L.GM_VOL_DO_SELL_CONFIRM)
                doSell.SetEnabledLook(true)
            elseif mySell then
                doSell.SetLabel(L.GM_VOL_DO_WAIT)
                doSell.SetEnabledLook(false)
            else
                doSell.SetLabel(string.format(L.GM_VOL_DO_SELL, post, ns.Money(plan.resale)))
                doSell.SetEnabledLook(free and post > 0)
            end
            -- a purchase or a sale of another item still waits: it blocks this one, it can be cancelled here
            local other = (bst and not myBuy and bst) or (sst and not mySell and sst) or nil
            doCancel:SetShown((myBuy and bst.step == "confirm") or (mySell and sst.step == "confirm") or other ~= nil)
            -- what to know before the next click
            local words
            local need, room = G.SlotsFor(id, left), G.FreeSlots()
            if not open then
                words = MUTED .. L.GM_VOL_DO_AH .. "|r"
            elseif ns.Scan.OpenHouse() ~= ns.House() then
                words = AMBER .. string.format(L.GM_VOL_DO_OTHER_AH, ns.HouseName(ns.Scan.OpenHouse()), ns.HouseName(ns.House()), ns.HouseName(ns.House())) .. "|r"
            elseif other then
                words = AMBER .. string.format(other == bst and L.GM_VOL_DO_OTHER_BUY or L.GM_VOL_DO_OTHER_SELL, ns.ItemName(other.id)) .. "|r"
            elseif scanning and left > 0 then
                words = AMBER .. L.BUY_SCANNING .. "|r"
            elseif myBuy and bst.step == "confirm" and bst.total and plan.n > 0 then
                local expected = plan.cost * (bst.qty or plan.n) / plan.n
                local over = expected > 0 and (bst.total / expected - 1) * 100 or 0
                if over > 3 then
                    words = RED .. string.format(L.GM_VOL_DO_DEARER, math.floor(over + 0.5), ns.Money(expected)) .. "|r"
                else
                    words = GREEN .. string.format(L.GM_VOL_DO_PRICE_OK, ns.Money(expected)) .. "|r"
                end
            elseif bought > 0 and ns.Sell.InBags(id) < bought then
                words = GOLD .. L.GM_VOL_DO_MAIL .. "|r"
            elseif post > 0 and left == 0 then
                words = GREEN .. L.GM_VOL_DO_READY .. "|r"
            elseif left > 0 and room and need > room then
                words = AMBER .. string.format(L.GM_VOL_DO_ROOM, need, room) .. "|r"
            else
                words = MUTED .. L.GM_VOL_DO_HOW .. "|r"
            end
            doText:SetText(words)
        end
        local PCOLS = { { 8, "GM_UNIT_PRICE" }, { 170, "GM_QTY" }, { 270, "GM_VOL_CUMUL" }, { 380, "GM_VOL_CUMUL_COST" }, { 540, "GM_VOL_STATE" } }
        local phead = CreateFrame("Frame", nil, ct)
        phead:SetHeight(20)
        W.Fill(phead, "BACKGROUND", 1, 1, 1, 0.05)
        for _, c in ipairs(PCOLS) do
            local t = W.Text(phead, "small", "LEFT")
            t:SetPoint("LEFT", phead, "LEFT", c[1], 0)
            t:SetText(L[c[2]])
            local lc = C().label
            t:SetTextColor(lc[1], lc[2], lc[3])
        end
        local PLAN_ROWS = 12
        local prows = {}
        for i = 1, PLAN_ROWS do
            local row = CreateFrame("Frame", nil, ct)
            row:SetHeight(20)
            W.Fill(row, "BACKGROUND", 1, 1, 1, i % 2 == 0 and 0.025 or 0)
            row.c = {}
            for j, c in ipairs(PCOLS) do
                local t = W.Text(row, "small", "LEFT")
                t:SetPoint("LEFT", row, "LEFT", c[1], 0)
                row.c[j] = t
            end
            prows[i] = row
        end
        local planMore = W.Text(ct, "small", "LEFT")
        local planParts = { phead, planMore }

        local function layout()
            local wdt = math.max(500, V.sf:GetWidth() - 12)
            local bottom = R.LayoutView(V.LayoutHead(-56, wdt), wdt)
            shead:ClearAllPoints()
            shead:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, -194)
            shead:SetWidth(wdt - 12)
            for i, row in ipairs(srows) do
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, -214 - (i - 1) * 22)
                row:SetWidth(wdt - 12)
            end
            local y0 = -214 - PLAN_MAX * 22   -- under the plans
            doBuy:ClearAllPoints(); doBuy:SetPoint("TOPLEFT", ct, "TOPLEFT", 10, y0 - 8)
            doSell:ClearAllPoints(); doSell:SetPoint("LEFT", doBuy, "RIGHT", 8, 0)
            doCancel:ClearAllPoints(); doCancel:SetPoint("LEFT", doSell, "RIGHT", 8, 0)
            doText:ClearAllPoints(); doText:SetPoint("TOPLEFT", ct, "TOPLEFT", 14, y0 - 38)
            doText:SetWidth(wdt - 28)
            planHint:ClearAllPoints()
            planHint:SetPoint("TOPLEFT", ct, "TOPLEFT", 14, y0 - 60)
            planText:ClearAllPoints()
            planText:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, -194)
            planText:SetWidth(wdt - 24)
            local py = -214 - PLAN_MAX * 22 - 82
            phead:ClearAllPoints()
            phead:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, py)
            phead:SetWidth(wdt - 12)
            for i, row in ipairs(prows) do
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, py - 20 - (i - 1) * 20)
                row:SetWidth(wdt - 12)
            end
            planMore:ClearAllPoints()
            planMore:SetPoint("TOPLEFT", ct, "TOPLEFT", 14, py - 24 - PLAN_ROWS * 20)
            local planBottom = py - 20 - PLAN_ROWS * 20 - 24
            ct:SetHeight(-(V.view == "plan" and planBottom or bottom) + 12)
        end

        function page.RefreshVolume()
            if not V:IsShown() or not V.data then return end
            -- the Auction House open: the real listings read again (once a minute at most)
            local age = ns.Tracker.LiveAge(V.data.itemID)
            if ns.Buy.ahOpen and (not age or age > 60) then ns.Tracker.ReadLive(V.data.itemID) end
            local d = G.EvaluateVolume(V.data.itemID) or V.data
            V.data = d
            local id = d.itemID
            -- the plan chosen (Maximum at first) sets the tiles at the top
            local allPlans = G.VolumePlans(d) or {}
            local chosen = allPlans[#allPlans]
            for _, pl in ipairs(allPlans) do if pl.key == selPlan then chosen = pl end end
            V.SetItem(id, nil, L.GM_VOL_CAT[d.cat], chosen and (GOLD .. string.format(L.GM_VOL_PLAN_ON, L.GM_VOL_PLAN_NAME[chosen.key]) .. "|r"))
            layout()
            if chosen then
                V.SetTiles(d, ns.Money(chosen.cost), string.format(L.GM_VOL_N_SLOTS, chosen.n, G.SlotsFor(id, chosen.n)),
                    ns.Money(chosen.n * chosen.resale), string.format(L.GM_VOL_PER_UNIT, ns.Money(chosen.resale)), chosen.profit)
            else
                V.SetTiles(d, d.buy and ns.Money(d.buy), d.n and string.format(L.GM_VOL_N_UNITS, d.n),
                    d.sell and ns.Money(d.sell), d.market and string.format(L.GM_VOL_PER_UNIT, ns.Money(d.market)), d.profit)
            end
            -- the view
            local plan = V.view == "plan"
            for _, p in ipairs(planParts) do p:SetShown(plan) end
            R.Fill(d, not plan and V.view or nil)
            -- the plans table, the one chosen tinted
            local plans = plan and allPlans or {}
            for k, row in ipairs(srows) do
                local pl = plans[k]
                if pl then
                    row.key = pl.key
                    local on = pl == chosen
                    row.sel:SetColorTexture(color[1], color[2], color[3], on and 0.18 or (k % 2 == 0 and 0.025 or 0))
                    local tint = on and GOLD or (pl.key == "risk" and AMBER or WHITE)
                    row.c[1]:SetText(tint .. L.GM_VOL_PLAN_NAME[pl.key] .. "|r")
                    row.c[2]:SetText("x" .. pl.n)
                    row.c[3]:SetText(ns.Money(pl.unit))
                    row.c[4]:SetText(ns.Money(pl.cost))
                    row.c[5]:SetText(ns.Money(pl.resale))
                    row.c[6]:SetText(signedProfit(pl.profit))
                    row.c[7]:SetText(string.format("%d %%", math.floor(pl.margin * 100 + 0.5)))
                    row.c[8]:SetText(pl.days and string.format(L.GM_DAYS_N, pl.days) or "-")
                    row.c[9]:SetText(G.StarString(pl.conf or 0, 11))
                    row:Show()
                else
                    row.key = nil
                    row:Hide()
                end
            end
            refreshDo(d, chosen, plan and #plans > 0)
            shead:SetShown(plan and #plans > 0)
            planHint:SetShown(plan and #plans > 0)
            planHint:SetText(MUTED .. (#plans > 1 and (L.GM_VOL_PLAN_HINT .. "  ") or "")
                .. (d.ladderFrom == "live" and L.GM_VOL_LIVE or L.GM_VOL_FROM_SCAN) .. "|r")
            planText:SetShown(plan and #plans == 0)
            planText:SetText(MUTED .. L.GM_VOL_NO_PLAN .. "|r")
            if plan then
                -- bought in full, in part (what is left of it sets my price), the first
                -- one left (I sell just under it), then the rest
                local lv, n, cost, priced = d.ladder or {}, 0, 0, false
                for k, row in ipairs(prows) do
                    local l = lv[k]
                    if l then
                        local take = 0
                        local want = chosen and chosen.n
                        if want and n < want then take = math.min(l[2], want - n) end
                        n, cost = n + take, cost + take * l[1]
                        local state
                        if take > 0 and take == l[2] then
                            state = GREEN .. L.GM_VOL_BUY_IT .. "|r"
                        elseif take > 0 then
                            state = GREEN .. string.format(L.GM_VOL_BUY_PART, take) .. "|r"
                            priced = true
                        elseif not priced and chosen then
                            state = GOLD .. L.GM_VOL_UNDERCUT .. "|r"
                            priced = true
                        else
                            state = MUTED .. L.GM_VOL_LEAVE .. "|r"
                        end
                        row.c[1]:SetText(ns.Money(l[1]))
                        row.c[2]:SetText("x" .. l[2])
                        row.c[3]:SetText(take > 0 and tostring(n) or (MUTED .. "-|r"))
                        row.c[4]:SetText(take > 0 and ns.Money(cost) or (MUTED .. "-|r"))
                        row.c[5]:SetText(state)
                        row:Show()
                    else
                        row:Hide()
                    end
                end
                planMore:SetText(#lv > PLAN_ROWS and (MUTED .. string.format(L.GM_VOL_MORE, #lv - PLAN_ROWS) .. "|r") or "")
            else
                for _, row in ipairs(prows) do row:Hide() end
            end
            V.sf.Update()
        end
        V.Refresh = page.RefreshVolume

        openVolume = function(d)
            V.data = d
            selPlan = "max"
            V:Show()
            page.RefreshVolume()
        end
        page.volumePanel = V
        page.OpenVolume = openVolume
        ns.On("LiveLadder", function(id)
            if V:IsShown() and V.data and V.data.itemID == id then page.RefreshVolume() end
        end)
    end

    -- ------------------------------------------------------------ craft detail
    if crafts then
        local detailID, craftCount, complete = nil, 1, false
        local P
        P = detailPanel(body, color, { buy = L.GM_COST, buyTip = L.GM_COST_TIP, ahTip = L.GM_ITEM_AH_TIP,
            views = { { "mats", L.GM_VIEW_MATS }, { "why", L.GM_SHOW_WHY }, { "chart", L.GM_SHOW_CHART } },
            profitTip = function()
                GameTooltip:AddLine(string.format(L.GM_PROFIT_DETAIL_N, craftCount), 1, 0.82, 0)
                if complete then addProfitLines(P.data, craftCount)
                else GameTooltip:AddLine(L.GM_PROFIT_UNKNOWN_MAT, 1, 0.4, 0.4) end
            end })
        local ct, R = P.ct, P.R
        function page.SetCraftView(v) P.SetView(v) end
        -- prerequisites and cooldown, on a second line under the name
        local sub2 = W.Text(ct, "small", "LEFT")
        sub2:SetPoint("TOPLEFT", P.sub, "BOTTOMLEFT", 0, -4)
        sub2:SetPoint("RIGHT", ct, "RIGHT", -12, 0)
        sub2:SetWordWrap(false)

        -- the materials
        -- the materials
        local DCOLS = { { 0, "GM_MAT" }, { 390, "GM_QTY" }, { 470, "GM_UNIT_PRICE" }, { 610, "GM_TOTAL" }, { 730, "GM_AT_AH" } }
        local hbar = CreateFrame("Frame", nil, ct)
        hbar:SetHeight(22)
        W.Fill(hbar, "BACKGROUND", 1, 1, 1, 0.05)
        for _, c in ipairs(DCOLS) do
            local t = W.Text(hbar, "small", "LEFT")
            t:SetPoint("LEFT", hbar, "LEFT", c[1] + 8, 0)
            t:SetText(L[c[2]])
            t:SetTextColor(m[1], m[2], m[3])
        end
        local mrows = {}
        for i = 1, 10 do
            local row = CreateFrame("Button", nil, ct)
            row:SetHeight(24)
            row:SetPoint("TOPLEFT", hbar, "BOTTOMLEFT", 0, -2 - (i - 1) * 24)
            row:SetPoint("RIGHT", hbar, "RIGHT", 0, 0)
            if i % 2 == 0 then W.Fill(row, "BACKGROUND", 1, 1, 1, 0.025) end
            local hl = row:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0.05)
            row.cols = {}
            for j, c in ipairs(DCOLS) do
                local fs = W.Text(row, "small", "LEFT")
                fs:SetPoint("LEFT", row, "LEFT", c[1] + 8, 0)
                fs:SetWidth((DCOLS[j + 1] and DCOLS[j + 1][1] or 820) - c[1] - 8)
                fs:SetWordWrap(false)
                row.cols[j] = fs
            end
            row.toggle = W.Button(row, "X", 24, function()
                if row.r and detailID then G.ToggleExcluded(detailID, row.r.id); changed(); page.RefreshCraft() end
            end)
            row.toggle:SetHeight(20)
            row.toggle:SetPoint("RIGHT", row, "RIGHT", -6, 0)
            row.toggle:HookScript("OnEnter", function(self)
                if not row.r then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(row.r.excluded and L.GM_PUT_BACK or L.GM_LEAVE_OUT, 1, 0.82, 0)
                GameTooltip:AddLine(row.r.excluded and L.GM_PUT_BACK_TIP or L.GM_LEAVE_OUT_TIP, 1, 1, 1, true)
                GameTooltip:Show()
            end)
            row.toggle:HookScript("OnLeave", function() GameTooltip:Hide() end)
            row.buy = W.Button(row, "", 150, function()
                local rg = row.r
                if rg and (rg.missing or 0) > 0 then buyClick(rg.id, rg.missing, nil, nil, page.CraftCtx and page.CraftCtx()) end
            end)
            row.buy:SetHeight(20)
            row.buy:SetPoint("RIGHT", row.toggle, "LEFT", -6, 0)
            W.Tip(row.buy, L.GM_BUY_MAT, L.GM_BUY_MAT_TIP)
            row:SetScript("OnClick", function(self) if self.r then G.SearchAH(self.r.id) end end)
            row:SetScript("OnEnter", function(self)
                local r = self.r
                if not r then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetItemByID(r.id)
                GameTooltip:AddLine(" ")
                if r.source == "manual" then GameTooltip:AddLine(L.GM_MANUAL_PRICE, 0.6, 0.8, 1)
                elseif r.source == "none" then GameTooltip:AddLine(L.GM_NOT_FOUND_TIP, 1, 0.4, 0.4, true)
                else GameTooltip:AddLine(L.GM_UNIT_LOWEST, 0.8, 0.8, 0.8) end
                if r.market then GameTooltip:AddLine(L.GM_USUAL_PRICE .. " : " .. ns.Money(r.market), 1, 1, 1) end
                GameTooltip:AddLine(L.GM_CLICK_SEARCH, 0.35, 0.85, 0.45)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function() GameTooltip:Hide() end)
            mrows[i] = row
        end

        local note = W.Text(ct, "tiny", "LEFT")
        note:SetWordWrap(true)

        -- how many crafts, and buying what is missing for them: one material per
        -- click (two clicks each: the real price, then confirm), cheapest first
        local countBox, countLabel = box(ct, L.GM_CRAFTS_N, 40, function() return tostring(craftCount) end, function(t)
            local v = tonumber(t)
            if v and v >= 1 then craftCount = math.min(200, math.floor(v)) end
        end, L.GM_CRAFTS_N_TIP, function() page.RefreshCraft() end)
        local buyAll = W.Button(ct, "", 360, function()
            local st = ns.Buy.State()
            if st and st.step == "confirm" then ns.Buy.Confirm() return end
            for _, rg in ipairs(page.craftToBuy or {}) do
                return buyClick(rg.id, rg.missing, nil, nil, page.CraftCtx and page.CraftCtx())
            end
        end)
        W.Tip(buyAll, L.GM_BUY_ALL_T, L.GM_BUY_ALL_TIP)
        local buyAllHint = W.Text(ct, "small", "LEFT")
        buyAllHint:SetWordWrap(false)
        page.craftBuyAll, page.craftCountBox = buyAll, countBox
        -- what was bought here and is still in the mail: { [id] = { base = bags then, got = units } }
        local bought = {}
        ns.On("Bought", function(id, qty)
            local b = bought[id]
            if not b then b = { base = ns.Sell.InBags(id), got = 0 }; bought[id] = b end
            b.got = b.got + (qty or 0)
        end)
        local function owned(id)
            local bags, b = ns.Sell.InBags(id), bought[id]
            return b and math.max(bags, b.base + b.got) or bags
        end
        page.CraftOwned = owned

        -- the materials bought here: one operation on the item the crafts make
        function page.CraftCtx()
            local d = P.data
            if not (d and detailID) then return nil end
            local r = G.Recipes()[detailID]
            return { kind = "craft", recipe = detailID, out = d.itemID, units = craftCount * ((r and r.qty) or 1),
                     aim = d.market, sellHouse = ns.House() }
        end
        function page.RefreshCraft()
            if not P:IsShown() or not detailID then return end
            local r = G.Recipes()[detailID]
            if not r then P:Hide(); return end
            local d = G.EvaluateRecipe(detailID, r)
            P.data = d
            local wdt = math.max(600, P.sf:GetWidth() - 12)
            local qty = r.qty == math.floor(r.qty) and r.qty or ("~" .. r.qty)
            P.SetItem(d.itemID, d.label, G.ProfName(r.prof), string.format(L.GM_MAKES, qty),
                d.learned and (GREEN .. L.GM_KNOWN .. "|r" .. MUTED) or nil)

            -- prerequisites, on one line: what the game says, and the cooldown
            local prereqs = ns.Recipes.Prereqs(detailID)
            local pre = {}
            for _, p in ipairs(prereqs) do pre[#pre + 1] = (p.unmet and RED or WHITE) .. p.text .. "|r" end
            if d.cd then
                pre[#pre + 1] = WHITE .. L.GM_CD_LINE .. " " .. ns.Cooldown.Label(d.cd) .. (ns.Cooldown.IsTransmute(detailID) and (" " .. L.GM_CD_SHARED) or "") .. "|r"
            end
            sub2:SetText(MUTED .. L.GM_PREREQS .. " : |r" .. (#pre > 0 and table.concat(pre, MUTED .. "  ·  |r") or (MUTED .. L.GM_PREREQ_NONE .. "|r")))

            local top = P.LayoutHead(-66, wdt)
            local viewBottom = R.LayoutView(top, wdt)
            local mats = P.view == "mats"
            hbar:ClearAllPoints()
            hbar:SetPoint("TOPLEFT", ct, "TOPLEFT", 6, top)
            hbar:SetWidth(wdt - 12)
            hbar:SetShown(mats)
            note:SetShown(mats)
            local list2, total, nEx = G.ReagentDetails(r, craftCount, detailID), 0, 0
            local toBuy = {}
            complete = true
            for i, row in ipairs(mrows) do
                local rg = list2[i]
                row.r = rg
                if rg then
                    local it = ns.Item(rg.id)
                    local ic = it.icon and ("|T" .. it.icon .. ":18|t ") or ""
                    local nm = it.name or ("#" .. rg.id)
                    row.toggle.SetLabel(rg.excluded and "+" or "X")
                    row.toggle:SetShown(not rg.excludedGlobal)
                    -- what is missing for the crafts asked: bags and purchases still in the mail count
                    local have = owned(rg.id)
                    rg.missing = math.max(0, rg.need - have)
                    local buyable = not rg.excluded and rg.source ~= "vendor" and rg.source ~= "none" and rg.missing > 0
                    row.buy:SetShown(buyable)
                    if buyable then
                        buyLook(row.buy, rg.id, false, string.format(L.GM_BUY_N, rg.missing), true, nil)
                        toBuy[#toBuy + 1] = rg
                    end
                    if rg.excluded then
                        nEx = nEx + 1
                        row.cols[1]:SetText(ic .. MUTED .. nm .. "  " .. (rg.excludedGlobal and L.GM_OUT_SETTINGS or L.GM_OUT_RECIPE) .. "|r")
                        row.cols[2]:SetText(MUTED .. "x" .. rg.need .. "|r")
                        row.cols[3]:SetText(MUTED .. "-|r")
                        row.cols[4]:SetText(MUTED .. "-|r")
                        row.cols[5]:SetText(MUTED .. rg.available .. "|r")
                    else
                        row.cols[1]:SetText(ic .. nm)
                        row.cols[2]:SetText("x" .. rg.need .. (have > 0 and (MUTED .. "  " .. string.format(L.GM_IN_BAGS, math.min(have, rg.need)) .. "|r") or ""))
                        if rg.source == "none" then
                            row.cols[3]:SetText(RED .. L.GM_NOT_FOUND .. "|r")
                            row.cols[4]:SetText("-")
                            complete = false
                        else
                            row.cols[3]:SetText(ns.Money(rg.unit) .. (rg.source == "manual" and (MUTED .. " " .. L.GM_MANUAL .. "|r")
                                or rg.source == "vendor" and (" " .. AMBER .. L.FROM_VENDOR .. "|r") or ""))
                            row.cols[4]:SetText(ns.Money(rg.total))
                            total = total + rg.total
                        end
                        if rg.source == "manual" then row.cols[5]:SetText(MUTED .. L.GM_VENDOR_MANUAL .. "|r")
                        elseif rg.source == "vendor" then row.cols[5]:SetText(GREEN .. L.GM_ALWAYS .. "|r")
                        elseif rg.available < rg.need then row.cols[5]:SetText(RED .. rg.available .. "|r")
                        else row.cols[5]:SetText(GREEN .. rg.available .. "|r") end
                    end
                    row:SetShown(mats)
                else
                    row:Hide()
                end
            end
            local rowsY = top - 24 - math.min(#list2, #mrows) * 24 - 10
            -- the crafts asked and the button that buys what is missing
            page.craftToBuy = toBuy
            countLabel:ClearAllPoints()
            countLabel:SetPoint("TOPLEFT", ct, "TOPLEFT", 14, rowsY - 6)
            buyAll:ClearAllPoints()
            buyAll:SetPoint("LEFT", countBox, "RIGHT", 16, 0)
            buyAllHint:ClearAllPoints()
            buyAllHint:SetPoint("LEFT", buyAll, "RIGHT", 12, 0)
            buyAllHint:SetPoint("RIGHT", ct, "RIGHT", -12, 0)
            for _, f in ipairs({ countBox, countLabel, buyAll, buyAllHint }) do f:SetShown(mats) end
            countBox.Refresh()
            local st = ns.Buy.State()
            local current
            for _, rg in ipairs(toBuy) do if st and st.id == rg.id and not st.bid then current = rg end end
            if current and st.step == "confirm" then
                buyAll.SetLabel(string.format(L.GM_BUY_ALL_NEXT, ns.ItemName(current.id), ns.Money(st.total)))
                buyAll.SetTint(C().gold)
                buyAll.SetEnabledLook(true)
            elseif st then
                buyAll.SetLabel(L.BUY_WAIT)
                buyAll.SetTint(nil)
                buyAll.SetEnabledLook(false)
            elseif #toBuy > 0 then
                buyAll.SetLabel(string.format(L.GM_BUY_ALL, #toBuy))
                buyAll.SetTint(color)
                buyAll.SetEnabledLook(ns.Buy.ahOpen)
            else
                buyAll.SetLabel(L.GM_BUY_ALL_DONE)
                buyAll.SetTint(nil)
                buyAll.SetEnabledLook(false)
            end
            local mail = false
            for id, b in pairs(bought) do if ns.Sell.InBags(id) < b.base + b.got then mail = true end end
            buyAllHint:SetText(not ns.Buy.ahOpen and (MUTED .. L.BUY_AH_CLOSED .. "|r")
                or (mail and (GOLD .. L.GM_BUY_MAIL .. "|r")) or "")
            note:ClearAllPoints()
            note:SetPoint("TOPLEFT", ct, "TOPLEFT", 12, rowsY - 40)
            note:SetWidth(wdt - 24)
            note:SetText(MUTED .. (nEx > 0 and (GOLD .. string.format(L.GM_N_OUT_RECIPE, nEx) .. "|r" .. MUTED .. " ") or "") .. L.GM_NOTE .. "|r")
            ct:SetHeight(-(mats and (rowsY - 80) or viewBottom) + 12)
            -- the whole batch, the cut off its resale (d.sell is before the cut)
            local sale = d.sell and d.sell * (1 - G.Cut()) * craftCount
            P.SetTiles(d, complete and ns.Money(total) or (RED .. L.GM_INCOMPLETE .. "|r"), nil,
                ns.Money(G.ResaleShown(d)) .. (d.estimate and GUESS or ""), SOURCE_NOTE[d.source] and L[SOURCE_NOTE[d.source]],
                (complete and sale) and (sale - total - (d.cdPrice or 0) * craftCount) or nil)
            R.Fill(d, not mats and P.view or nil)
            P.sf.Update()
        end
        P.Refresh = page.RefreshCraft

        openCraft = function(recipeID)
            if detailID ~= recipeID then craftCount = 1 end
            detailID = recipeID
            P:Show()
            page.RefreshCraft()
        end
        page.craftPanel = P
        page.OpenCraft = openCraft

        -- ------------------------------------------------------------ settings (materials left out)
        local S = overlay(body)
        local state = { cat = "all", search = "" }
        local sback = W.Button(S, L.GM_BACK, 110, function() S:Hide(); changed() end)
        sback:SetPoint("TOPLEFT", S, "TOPLEFT", 10, -10)
        local stitle = W.Text(S, "title", "LEFT")
        stitle:SetPoint("LEFT", sback, "RIGHT", 14, 0)
        stitle:SetText(L.GM_SETTINGS_TITLE)
        stitle:SetTextColor(color[1], color[2], color[3])
        local sdesc = W.Text(S, "small", "LEFT")
        sdesc:SetPoint("TOPLEFT", S, "TOPLEFT", 16, -42)
        sdesc:SetPoint("RIGHT", S, "RIGHT", -16, 0)
        sdesc:SetWordWrap(true)
        sdesc:SetText(MUTED .. L.GM_SETTINGS_DESC .. "|r")
        local chips = W.Pick(S, L.GM_CATEGORY, { { "all", L.GM_CAT_ALL }, { "mining", L.GM_CAT.mining }, { "herb", L.GM_CAT.herb }, { "skin", L.GM_CAT.skin } },
            function() return state.cat end, function(v) state.cat = v; page.RefreshSettings() end)
        chips.color = color
        chips:SetPoint("TOPLEFT", S, "TOPLEFT", 16, -76)
        local CAT_TIPS = { all = L.GM_CAT_TIP_ALL, mining = L.GM_CAT_TIP_MINING, herb = L.GM_CAT_TIP_HERB, skin = L.GM_CAT_TIP_SKIN }
        W.Tip(chips, L.GM_CATEGORY, function() return CAT_TIPS[state.cat] end)
        local ssearch = W.Input(S, { width = 200, hint = L.GM_SEARCH_MAT, onChange = function(t) state.search = t or ""; page.RefreshSettings() end })
        ssearch:SetPoint("TOPLEFT", S, "TOPLEFT", 16, -108)

        local function settingsList()
            local out = {}
            local needle = state.search ~= "" and state.search:lower() or nil
            for _, e in ipairs(G.AllReagents()) do
                local ok = state.cat == "all" or e.cat == state.cat
                local nm = ns.Item(e.id).name
                if ok and needle then ok = nm and nm:lower():find(needle, 1, true) ~= nil end
                if ok then
                    e.name = nm or ("#" .. e.id)
                    out[#out + 1] = e
                end
            end
            table.sort(out, function(a, b)
                if a.catLabel ~= b.catLabel then return a.catLabel < b.catLabel end
                return a.name < b.name
            end)
            return out
        end
        local function setAll(on)
            for _, e in ipairs(settingsList()) do G.SetExcludedGlobal(e.id, on) end
            ns.Fire("GoldChanged")
            page.RefreshSettings()
        end
        local removeAll = W.Button(S, L.GM_REMOVE_ALL, 220, function() setAll(true) end)
        removeAll:SetPoint("LEFT", ssearch, "RIGHT", 24, 0)
        removeAll.SetTint(color)
        W.Tip(removeAll, L.GM_REMOVE_ALL, L.GM_REMOVE_ALL_TIP)
        local restoreAll = W.Button(S, L.GM_RESTORE_ALL, 220, function() setAll(false) end)
        restoreAll:SetPoint("LEFT", removeAll, "RIGHT", 8, 0)
        W.Tip(restoreAll, L.GM_RESTORE_ALL, L.GM_RESTORE_ALL_TIP)

        local sh = CreateFrame("Frame", nil, S)
        sh:SetHeight(22)
        sh:SetPoint("TOPLEFT", S, "TOPLEFT", 6, -142)
        sh:SetPoint("RIGHT", S, "RIGHT", -6, 0)
        W.Fill(sh, "BACKGROUND", 1, 1, 1, 0.05)
        for _, h in ipairs({ { 36, L.GM_MAT }, { 400, L.GM_CATEGORY }, { 540, L.GM_AH_PRICE }, { 690, L.GM_USED_BY } }) do
            local t = W.Text(sh, "small", "LEFT")
            t:SetPoint("LEFT", sh, "LEFT", h[1], 0)
            t:SetText(h[2])
            t:SetTextColor(m[1], m[2], m[3])
        end
        local function makeSet(parent)
            local row = CreateFrame("Button", nil, parent)
            local hl = row:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 1, 1, 0.05)
            row.box = CreateFrame("Frame", nil, row)
            row.box:SetSize(16, 16)
            row.box:SetPoint("LEFT", row, "LEFT", 10, 0)
            W.Fill(row.box, "BACKGROUND", 0, 0, 0, 0.45)
            row.boxLine = W.Outline(row.box, 1, 1, 1, 0.2)
            row.mark = row.box:CreateTexture(nil, "OVERLAY")
            row.mark:SetPoint("TOPLEFT", row.box, "TOPLEFT", 3, -3)
            row.mark:SetPoint("BOTTOMRIGHT", row.box, "BOTTOMRIGHT", -3, 3)
            row.mark:SetColorTexture(color[1], color[2], color[3], 1)
            row.name = W.Text(row, "small", "LEFT")
            row.name:SetPoint("LEFT", row, "LEFT", 36, 0)
            row.name:SetWidth(355)
            row.name:SetWordWrap(false)
            row.cat = W.Text(row, "small", "LEFT")
            row.cat:SetPoint("LEFT", row, "LEFT", 400, 0)
            row.price = W.Text(row, "small", "LEFT")
            row.price:SetPoint("LEFT", row, "LEFT", 540, 0)
            row.uses = W.Text(row, "small", "LEFT")
            row.uses:SetPoint("LEFT", row, "LEFT", 690, 0)
            row:SetScript("OnClick", function(self)
                if not self.e then return end
                G.SetExcludedGlobal(self.e.id, not G.IsExcludedGlobal(self.e.id))
                ns.Fire("GoldChanged")
                page.RefreshSettings()
            end)
            row:SetScript("OnEnter", function(self)
                if not self.e then return end
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetItemByID(self.e.id)
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(G.IsExcludedGlobal(self.e.id) and L.GM_CLICK_PUT_BACK or L.GM_CLICK_LEAVE_OUT, 0.35, 0.85, 0.45)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function() GameTooltip:Hide() end)
            return row
        end
        local function fillSet(row, e)
            row.e = e
            local on = G.IsExcludedGlobal(e.id)
            row.mark:SetShown(on)
            if on then row.boxLine.Color(color[1], color[2], color[3], 1) else row.boxLine.Color(1, 1, 1, 0.2) end
            local it = ns.Item(e.id)
            row.name:SetText((it.icon and ("|T" .. it.icon .. ":18|t ") or "") .. (on and (MUTED .. e.name .. "|r") or e.name))
            row.cat:SetText(MUTED .. e.catLabel .. "|r")
            local cur = G.Current(e.id)
            row.price:SetText(cur and ns.Money(cur.p) or (MUTED .. "-|r"))
            row.uses:SetText(MUTED .. string.format(L.GM_N_RECIPES, e.uses) .. "|r")
        end
        local slist = W.List(S, 26, makeSet, fillSet)
        slist:SetPoint("TOPLEFT", sh, "BOTTOMLEFT", 0, -2)
        slist:SetPoint("BOTTOMRIGHT", S, "BOTTOMRIGHT", -6, 30)
        slist.Color(color)
        local scount = W.Text(S, "small", "LEFT")
        scount:SetPoint("BOTTOMLEFT", S, "BOTTOMLEFT", 16, 10)

        function page.RefreshSettings()
            if not S:IsShown() then return end
            chips.Refresh()
            local lst = settingsList()
            local excludedTotal = 0
            for _ in pairs(ns.db.excludedGlobal or {}) do excludedTotal = excludedTotal + 1 end
            scount:SetText(MUTED .. string.format(L.GM_SETTINGS_COUNT, #lst, excludedTotal) .. "|r")
            slist.SetData(lst, true)
        end
        function page.OpenSettings()
            S:Show()
            page.RefreshSettings()
        end
        gear:SetScript("OnClick", page.OpenSettings)
        page.settingsPanel = S
    end

    -- ------------------------------------------------------------ refresh
    local function sortValue(d, key)
        if key == "name" then return (d.label or ns.Item(d.itemID).name or ""):lower() end
        return d[key] or -math.huge
    end

    function page.Refresh()
        local u = ui()
        local allList
        page.query = F().search or ""
        for _, r in ipairs(refreshers) do r() end
        scanInfo:SetText(G.ScanInfo())

        if deals then
            baseList, allList = {}, G.FindDeals()
            for _, d in ipairs(allList) do
                if G.IsTopDeal(d) then baseList[#baseList + 1] = d end
            end
        elseif plans then
            baseList, allList = {}, G.FindPlans()
            for _, d in ipairs(allList) do
                if G.IsTopPlan(d) then baseList[#baseList + 1] = d end
            end
        elseif transfer then
            -- the way of the tab chosen; each tab says how many Top offers it has
            local dir = u.trDir == "neutral" and "neutral" or "faction"
            local counts = { faction = 0, neutral = 0 }
            baseList, allList = {}, {}
            for _, d in ipairs(G.FindTransfers()) do
                local top = G.IsTopTransfer(d)
                if top then counts[d.from] = counts[d.from] + 1 end
                if d.from == dir then
                    allList[#allList + 1] = d
                    if top then baseList[#baseList + 1] = d end
                end
            end
            for _, b in ipairs(trTabs.buttons) do
                b.SetLabel(string.format(L.GM_TR_TAB, houseName(b.key), houseName(G.OTHER_HOUSE[b.key]), counts[b.key]))
            end
        elseif volume then
            local vf = u.volFilter or "top"
            local known = vf == "top"
            for _, c in ipairs(G.VOLUME_CATS) do if c.key == vf then known = true end end
            if not known then vf = "top"; u.volFilter = nil end
            if vf == "top" then
                baseList, allList = {}, G.FindVolume({})
                for _, d in ipairs(allList) do
                    if G.IsTopVolume(d) then baseList[#baseList + 1] = d end
                end
            else
                baseList = G.FindVolume({ cat = vf })
            end
            G.VolumeCheckLive(baseList)   -- the Auction House open: the cards on its real listings
        else
            local pf = u.profFilter
            if pf ~= "top" and not G.IsCraftProf(pf) then pf = "top"; u.profFilter = pf end
            if pf == "top" then
                baseList, allList = {}, G.FindCrafts({})
                for _, d in ipairs(allList) do
                    if G.IsTopCraft(d) then baseList[#baseList + 1] = d end
                end
            else
                baseList = G.FindCrafts({ prof = pf, all = u.craftsAll == true })
            end
        end
        data = {}
        local f = F()
        local boardNow = isBoard()
        if boardNow and f.minStars then
            -- the stars filter is hidden on the Top boards: not applied there
            f = { maxBuy = f.maxBuy, search = f.search }
        end
        local hidden = {}   -- lines hidden, by filter
        for _, d in ipairs(baseList) do
            local miss = G.FilterMiss(d, f)
            if miss then hidden[miss] = (hidden[miss] or 0) + 1 else data[#data + 1] = d end
        end
        local key, desc = u.sortKey or "profit", u.sortDesc
        table.sort(data, function(a, b)
            local va, vb = sortValue(a, key), sortValue(b, key)
            if va == vb then
                if a.itemID ~= b.itemID then return a.itemID < b.itemID end
                return (a.recipeID or 0) < (b.recipeID or 0)
            end
            if desc then return va > vb end
            return va < vb
        end)
        for _, h in ipairs(heads) do
            local txt = h.label or ""
            if key == h.key then txt = GOLD .. txt .. (desc and "  v" or "  ^") .. "|r" end
            h.text:SetText(txt)
            if key ~= h.key then h.text:SetTextColor(m[1], m[2], m[3]) else h.text:SetTextColor(1, 1, 1) end
        end

        local boardView = isBoard()
        board:SetShown(boardView)
        topCard:SetShown(not boardView)
        listCard:SetShown(not boardView)
        local nGroups = 0
        -- no Top yet because no sale is known at all (the first days): the best ones by
        -- usual prices instead. When sales are known, an empty Top stays empty: it is the
        -- filters (the profit min...) that leave nothing, and the board says so.
        local fallback, salesKnown = false, G.SalesKnown()
        page.emptyReason = (boardView and #data == 0 and salesKnown) and "filters" or nil
        if boardView and #data == 0 and allList and #allList > 0 and not salesKnown then
            for _, d in ipairs(allList) do
                if G.PassesFilters(d, f) then data[#data + 1] = d end
            end
            fallback = #data > 0
        end
        if boardView then
            nGroups = refreshBoard(data)
        else
            refreshTop(data)
            list.SetData(data, true)
            listEmpty:SetShown(#data == 0)
            listEmpty:SetText(not G.LastScan() and L.GM_NEED_SCAN or L.GM_NOTHING)
        end

        local txt
        if not G.LastScan() then
            txt = L.GM_STATUS_NO_SCAN
        elseif transfer and not G.HousesComparable() then
            -- both houses must be scanned, less than 48 h apart
            local _, a, b = G.HousesComparable()
            txt = GOLD .. string.format(L.GM_TR_NEED, houseName("faction"), a and ns.Duration(time() - a) or L.NO_SCAN,
                houseName("neutral"), b and ns.Duration(time() - b) or L.NO_SCAN) .. "|r"
        elseif crafts and not next(G.Recipes()) then
            txt = L.GM_STATUS_NO_RECIPES
        elseif page.emptyReason == "filters" then
            txt = GOLD .. L.GM_STATUS_TOP_FILTERED .. "|r"
        elseif fallback then
            local n = G.TotalSales()
            txt = GOLD .. string.format(pick(L.GM_FALLBACK_DEALS, L.GM_FALLBACK_CRAFTS, L.GM_FALLBACK_VOLUME, L.GM_FALLBACK_TR, L.GM_FALLBACK_PL), n) .. "|r"
        elseif boardView then
            txt = WHITE .. #data .. "|r " .. MUTED .. string.format(pick(L.GM_STATUS_TOP_DEALS, L.GM_STATUS_TOP_CRAFTS, L.GM_STATUS_TOP_VOLUME, L.GM_STATUS_TOP_TR, L.GM_STATUS_TOP_PL), nGroups) .. "|r"
        else
            txt = WHITE .. #data .. "|r " .. MUTED .. string.format(L.GM_STATUS_LIST, #baseList) .. "|r"
            -- why some are missing: the filters in use, and how many each one hides
            local why = {}
            for _, k in ipairs({ "stars", "maxBuy", "search" }) do
                if hidden[k] then why[#why + 1] = string.format(L["GM_HIDDEN_" .. string.upper(k)], hidden[k]) end
            end
            if #why > 0 then
                txt = txt .. "  " .. GOLD .. string.format(L.GM_STATUS_HIDDEN, #baseList - #data, table.concat(why, ", ")) .. "|r"
            end
            if (ns.db.minProfit or 0) > 0 and not (crafts and u.craftsAll) then
                txt = txt .. "  " .. GOLD .. L.GM_STATUS_MINPROFIT .. "|r"
            end
        end
        -- nothing to show yet while a scan or a reckoning runs: the loader, not an empty board
        local loading = #data == 0 and (ns.Scan.Running() or (volume and G.VolumeBusy()) or (transfer and G.TransferBusy())
            or (plans and G.PlanBusy()))
        if loading then
            boardEmpty:Hide()
            listEmpty:Hide()
            topEmpty:Hide()
            loader.Set(loadingWords())
        else
            loader:Hide()
        end
        if volume and G.VolumeBusy() then txt = GOLD .. L.GM_VOL_BUSY .. "|r  " .. MUTED .. (txt or "") .. "|r" end
        if transfer and G.TransferBusy() then txt = GOLD .. L.GM_TR_BUSY .. "|r  " .. MUTED .. (txt or "") .. "|r" end
        if plans and G.PlanBusy() then txt = GOLD .. L.GM_LOADING .. "|r  " .. MUTED .. (txt or "") .. "|r" end
        status:SetText(txt)
        page.statusText = txt
        if page.RefreshDeal then page.RefreshDeal() end
        if page.RefreshVolume then page.RefreshVolume() end
        if page.RefreshCraft then page.RefreshCraft() end
        if page.RefreshSettings then page.RefreshSettings() end
    end
    function page.OnResize() if page.frame:IsShown() then ns.UI.RefreshSoon() end end
end

ns.UI.AddPage("gmdeals", function(page) buildMarket(page, "deals") end)
ns.UI.AddPage("gmcrafts", function(page) buildMarket(page, "crafts") end)
ns.UI.AddPage("gmvolume", function(page) buildMarket(page, "volume") end)
ns.UI.AddPage("compare", function(page) buildMarket(page, "transfer") end)
ns.UI.AddPage("gmplans", function(page) buildMarket(page, "plans") end)
