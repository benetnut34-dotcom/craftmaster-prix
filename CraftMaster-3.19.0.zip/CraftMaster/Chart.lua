local _, ns = ...
local W = ns.W

-- A small line chart: days along the bottom, gold up the side, one line per
-- series, the value under the mouse in a tooltip.
local Chart = {}
ns.Chart = Chart

local PAD_L, PAD_B, PAD_T, PAD_R = 64, 20, 10, 10

local function dayText(day)
    local t = day * 86400 + 43200
    return date(ns.L.DATE_FMT, t)
end

function Chart.New(parent)
    local c = CreateFrame("Frame", nil, parent)
    c.lines, c.dots, c.grid, c.labels = {}, {}, {}, {}
    c.notes = {}
    c.plot = CreateFrame("Frame", nil, c)
    c.plot:SetPoint("TOPLEFT", c, "TOPLEFT", PAD_L, -PAD_T)
    c.plot:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", -PAD_R, PAD_B)
    W.Fill(c.plot, "BACKGROUND", 0, 0, 0, 0.18)
    c.empty = W.Text(c, "small", "CENTER")
    c.empty:SetPoint("CENTER", c.plot, "CENTER")
    local m = ns.Theme.C.muted
    c.empty:SetTextColor(m[1], m[2], m[3])
    c.cursor = c.plot:CreateTexture(nil, "OVERLAY")
    c.cursor:SetWidth(1)
    c.cursor:SetColorTexture(1, 1, 1, 0.35)
    c.cursor:Hide()

    local used = { line = 0, dot = 0, grid = 0, label = 0 }
    local function getLine()
        used.line = used.line + 1
        local l = c.lines[used.line]
        if not l then
            if c.plot.CreateLine then
                l = c.plot:CreateLine(nil, "ARTWORK")
                l:SetThickness(2)
            else
                l = false
            end
            c.lines[used.line] = l
        end
        return l
    end
    local function getDot()
        used.dot = used.dot + 1
        local d = c.dots[used.dot]
        if not d then
            d = c.plot:CreateTexture(nil, "OVERLAY")
            d:SetTexture(ns.MEDIA .. "rond.png")
            d:SetTexCoord(0.1, 0.9, 0.1, 0.9)
            c.dots[used.dot] = d
        end
        d:Show()
        return d
    end
    local function getGrid()
        used.grid = used.grid + 1
        local g = c.grid[used.grid]
        if not g then
            g = c.plot:CreateTexture(nil, "BORDER")
            g:SetHeight(1)
            g:SetColorTexture(1, 1, 1, 0.07)
            c.grid[used.grid] = g
        end
        g:Show()
        return g
    end
    local function getLabel()
        used.label = used.label + 1
        local fs = c.labels[used.label]
        if not fs then
            fs = W.Text(c, "tiny", "RIGHT")
            local lc = ns.Theme.C.label
            fs:SetTextColor(lc[1], lc[2], lc[3])
            c.labels[used.label] = fs
        end
        fs:Show()
        return fs
    end

    -- a note inside the plot (the legend, the highest and the lowest price)
    local function note(i)
        local fs = c.notes[i]
        if not fs then
            fs = W.Text(c.plot, "tiny", "LEFT")
            c.notes[i] = fs
        end
        fs:Show()
        return fs
    end

    -- series = { { points = { {day, value} }, color = {r,g,b}, label = "..." } }
    function c.Draw(series, days, emptyText)
        for _, fs in ipairs(c.notes) do fs:Hide() end
        for _, l in ipairs(c.lines) do if l then l:Hide() end end
        for _, d in ipairs(c.dots) do d:Hide() end
        for _, g in ipairs(c.grid) do g:Hide() end
        for _, fs in ipairs(c.labels) do fs:Hide() end
        used.line, used.dot, used.grid, used.label = 0, 0, 0, 0
        c.series = series
        local lo, hi, any = math.huge, 0, false
        for _, s in ipairs(series) do
            for _, p in ipairs(s.points) do
                lo = math.min(lo, p[2]); hi = math.max(hi, p[2]); any = true
            end
        end
        c.empty:SetShown(not any)
        if not any then c.empty:SetText(emptyText or "") return end
        if hi == lo then hi = hi * 1.1 + 1; lo = lo * 0.9 end
        local span = hi - lo
        lo = math.max(0, lo - span * 0.08)
        hi = hi + span * 0.08
        local today = ns.Today()
        local first = today - (days or 30)
        c.range = { first = first, last = today, lo = lo, hi = hi }
        local w, h = c.plot:GetWidth(), c.plot:GetHeight()
        if w < 10 or h < 10 then return end
        local function X(day) return (day - first) / math.max(1, today - first) * w end
        local function Y(v) return (v - lo) / (hi - lo) * h end
        c.X, c.Y = X, Y
        for i = 0, 3 do
            local v = lo + (hi - lo) * i / 3
            local g = getGrid()
            g:ClearAllPoints()
            g:SetPoint("BOTTOMLEFT", c.plot, "BOTTOMLEFT", 0, Y(v))
            g:SetPoint("BOTTOMRIGHT", c.plot, "BOTTOMRIGHT", 0, Y(v))
            local fs = getLabel()
            fs:SetJustifyH("RIGHT")
            fs:ClearAllPoints()
            fs:SetPoint("RIGHT", c.plot, "BOTTOMLEFT", -6, Y(v))
            fs:SetText(ns.Money(v, true))
        end
        for i = 0, 2 do
            local day = first + math.floor((today - first) * i / 2)
            local fs = getLabel()
            fs:ClearAllPoints()
            fs:SetPoint("TOP", c.plot, "BOTTOMLEFT", X(day), -4)
            fs:SetJustifyH("CENTER")
            fs:SetText(dayText(day))
        end
        for _, s in ipairs(series) do
            local col = s.color
            local prev
            for _, p in ipairs(s.points) do
                local x, y = X(p[1]), Y(p[2])
                if prev then
                    local l = getLine()
                    if l then
                        l:SetColorTexture(col[1], col[2], col[3], 0.95)
                        l:SetStartPoint("BOTTOMLEFT", c.plot, prev[1], prev[2])
                        l:SetEndPoint("BOTTOMLEFT", c.plot, x, y)
                        l:Show()
                    end
                end
                local d = getDot()
                local size = #s.points > 40 and 3 or 5
                d:SetSize(size, size)
                d:SetVertexColor(col[1], col[2], col[3], 1)
                d:ClearAllPoints()
                d:SetPoint("CENTER", c.plot, "BOTTOMLEFT", x, y)
                prev = { x, y }
            end
        end

        -- the highest and the lowest price of the main curve, written on it
        if main and #main.points >= 3 then
            local hiP, loP = main.points[1], main.points[1]
            for _, p in ipairs(main.points) do
                if p[2] > hiP[2] then hiP = p end
                if p[2] < loP[2] then loP = p end
            end
            if hiP ~= loP then
                local a = note(1)
                a:ClearAllPoints()
                a:SetPoint("BOTTOM", c.plot, "BOTTOMLEFT", math.max(30, math.min(w - 30, X(hiP[1]))), math.min(h - 12, Y(hiP[2]) + 5))
                a:SetText(ns.Money(hiP[2], true))
                a:SetTextColor(1, 0.55, 0.5)
                local b = note(2)
                b:ClearAllPoints()
                b:SetPoint("TOP", c.plot, "BOTTOMLEFT", math.max(30, math.min(w - 30, X(loP[1]))), math.max(12, Y(loP[2]) - 5))
                b:SetText(ns.Money(loP[2], true))
                b:SetTextColor(0.5, 0.9, 0.6)
            end
        end
        -- the legend: every curve with its last value, in its color
        local lx = 6
        for i, sr in ipairs(series) do
            local last = sr.points[#sr.points]
            if last and sr.label then
                local fs = note(2 + i)
                fs:ClearAllPoints()
                fs:SetPoint("TOPLEFT", c.plot, "TOPLEFT", lx, -4)
                fs:SetText(sr.label .. " : " .. ns.Money(last[2], true))
                fs:SetTextColor(sr.color[1], sr.color[2], sr.color[3])
                lx = lx + (fs:GetStringWidth() or 80) + 18
            end
        end
    end

    -- The value under the mouse.
    c.plot:EnableMouse(true)
    c.plot:SetScript("OnUpdate", function(self)
        if not self:IsMouseOver() or not c.range or not c.series then
            if c.cursor:IsShown() then c.cursor:Hide(); GameTooltip:Hide() end
            return
        end
        local x = GetCursorPosition() / self:GetEffectiveScale() - self:GetLeft()
        local w = self:GetWidth()
        local day = math.floor(c.range.first + x / w * (c.range.last - c.range.first) + 0.5)
        if day == c.hoverDay and c.cursor:IsShown() then return end
        c.hoverDay = day
        c.cursor:ClearAllPoints()
        c.cursor:SetPoint("TOP", self, "TOPLEFT", c.X(day), 0)
        c.cursor:SetPoint("BOTTOM", self, "BOTTOMLEFT", c.X(day), 0)
        c.cursor:Show()
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        GameTooltip:SetText(dayText(day), 1, 1, 1)
        for _, s in ipairs(c.series) do
            local v
            for _, p in ipairs(s.points) do if p[1] <= day then v = p[2] end end
            if v then GameTooltip:AddDoubleLine(s.label, ns.Money(v), s.color[1], s.color[2], s.color[3], 1, 1, 1) end
        end
        GameTooltip:Show()
    end)
    c:SetScript("OnSizeChanged", function()
        if c.series then c.Draw(c.series, c.range and (c.range.last - c.range.first) or 30) end
    end)
    return c
end

-- The last days of an item's price (daily lows, oldest first), for Chart.Spark.
function Chart.PriceSeries(id, days)
    local out = {}
    if not id then return out end
    for _, p in ipairs(ns.History.Series(id, days or 14)) do out[#out + 1] = p[2] end
    if #out < 2 then
        out = {}
        local n = 0
        for _, p in ipairs(ns.Deals.Lows(id, ns.House())) do
            if ns.Today() - p[1] < (days or 14) then out[#out + 1] = p[2] end
        end
    end
    return out
end

-- A tiny line for a row of a list (the last days of a price): no axis, no
-- legend, just the shape. Green when it ends higher than it started, red when
-- lower, like a market. c.Set(values, color): values oldest first; false when
-- there is nothing to draw (fewer than two points).
function Chart.Spark(parent, w, h)
    local c = CreateFrame("Frame", nil, parent)
    c:SetSize(w or 70, h or 16)
    c.segs = {}
    c.dot = c:CreateTexture(nil, "OVERLAY")
    c.dot:SetTexture(ns.MEDIA .. "rond.png")
    c.dot:SetTexCoord(0.1, 0.9, 0.1, 0.9)
    c.dot:SetSize(4, 4)
    function c.Set(values, color)
        for _, l in ipairs(c.segs) do l:Hide() end
        c.dot:Hide()
        local n = values and #values or 0
        if n < 2 or not c.CreateLine then return false end
        local lo, hi = math.huge, -math.huge
        for _, v in ipairs(values) do lo, hi = math.min(lo, v), math.max(hi, v) end
        local span = hi - lo
        local W_, H_ = c:GetWidth(), c:GetHeight() - 4
        local C = ns.Theme.C
        local col = color or (values[n] >= values[1] and C.profit or C.loss)
        local function X(i) return 2 + (i - 1) / (n - 1) * (W_ - 4) end
        local function Y(v) return 2 + (span > 0 and (v - lo) / span or 0.5) * H_ end
        for i = 2, n do
            local l = c.segs[i - 1]
            if not l then
                l = c:CreateLine(nil, "ARTWORK")
                l:SetThickness(1.5)
                c.segs[i - 1] = l
            end
            l:SetColorTexture(col[1], col[2], col[3], 0.95)
            l:SetStartPoint("BOTTOMLEFT", c, X(i - 1), Y(values[i - 1]))
            l:SetEndPoint("BOTTOMLEFT", c, X(i), Y(values[i]))
            l:Show()
        end
        c.dot:ClearAllPoints()
        c.dot:SetPoint("CENTER", c, "BOTTOMLEFT", X(n), Y(values[n]))
        c.dot:SetVertexColor(col[1], col[2], col[3], 1)
        c.dot:Show()
        return true
    end
    return c
end

-- A line over categories (the hours of the day, the days of the week, the
-- last days...): one value per slot, a gap (nil) breaks the line.
--   signed (default): around a zero line, below it green (cheaper than usual:
--   buy), above red (dearer: sell), `invert` swaps the colors;
--   positive = true: from zero up (a count), `it[5]` gives a dot its own color.
-- items = { { value, label, tip, count, color } }; marks = { [index] = color }
-- rings the best and the worst slots.
-- `bars` draws one column per slot instead of the line: the right shape to
-- compare separate categories (days of the week, counts); a line is the right
-- shape for something that flows (the hours of a day, a price over days).
function Chart.Line(parent, positive, bars)
    local c = CreateFrame("Frame", nil, parent)
    c.slots, c.segs = {}, {}
    c.plot = CreateFrame("Frame", nil, c)
    c.plot:SetPoint("TOPLEFT", c, "TOPLEFT", 44, -8)
    c.plot:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", -6, 20)
    W.Fill(c.plot, "BACKGROUND", 0, 0, 0, 0.18)
    c.zero = c.plot:CreateTexture(nil, "BORDER")
    c.zero:SetHeight(1)
    c.zero:SetColorTexture(1, 1, 1, 0.3)
    c.top = W.Text(c, "tiny", "RIGHT")
    c.bottom = W.Text(c, "tiny", "RIGHT")
    for _, fs in ipairs({ c.top, c.bottom }) do
        local lc = ns.Theme.C.label
        fs:SetTextColor(lc[1], lc[2], lc[3])
    end
    c.empty = W.Text(c, "small", "CENTER")
    c.empty:SetPoint("CENTER", c.plot, "CENTER")
    local m = ns.Theme.C.muted
    c.empty:SetTextColor(m[1], m[2], m[3])

    local function seg(i)
        local l = c.segs[i]
        if l == nil then
            if c.plot.CreateLine then
                l = c.plot:CreateLine(nil, "ARTWORK")
                l:SetThickness(2)
            else
                l = false                       -- no line API: dots only
            end
            c.segs[i] = l
        end
        return l
    end

    local function hideAll()
        for _, b in ipairs(c.slots) do b:Hide(); b.label:Hide(); b.dot:Hide(); b.col:Hide(); b.mark:Hide() end
        for _, l in ipairs(c.segs) do if l then l:Hide() end end
    end

    function c.Draw(items, marks, emptyText, fmt, invert)
        c.items, c.marks, c.emptyText, c.fmt, c.invert = items, marks, emptyText, fmt, invert
        local n = #items
        local peak = 0
        for _, it in ipairs(items) do
            if it[1] then peak = math.max(peak, positive and it[1] or math.abs(it[1])) end
        end
        hideAll()
        c.empty:SetShown(peak == 0)
        c.empty:SetText(emptyText or "")
        c.top:SetShown(peak > 0); c.bottom:SetShown(peak > 0)
        if n == 0 or peak == 0 then c.zero:Hide() return end
        peak = math.max(peak, positive and 1 or 0.02)
        local w, h = c.plot:GetWidth(), c.plot:GetHeight()
        if w < 10 or h < 10 then return end
        local zeroY = positive and 4 or h / 2
        local function Y(v)
            if positive then return zeroY + v / peak * (h - 12) end
            return zeroY + v / peak * (h / 2 - 8)
        end
        c.zero:Show()
        c.zero:ClearAllPoints()
        c.zero:SetPoint("LEFT", c.plot, "BOTTOMLEFT", 0, zeroY)
        c.zero:SetPoint("RIGHT", c.plot, "BOTTOMRIGHT", 0, zeroY)
        local f = fmt or (positive and function(v) return string.format("%d", math.floor(v + 0.5)) end
            or function(v) return string.format("%+d%%", math.floor(v * 100 + 0.5)) end)
        c.top:ClearAllPoints(); c.top:SetPoint("RIGHT", c.plot, "TOPLEFT", -6, -4)
        c.bottom:ClearAllPoints()
        if positive then c.bottom:SetPoint("RIGHT", c.plot, "BOTTOMLEFT", -6, zeroY) else c.bottom:SetPoint("RIGHT", c.plot, "BOTTOMLEFT", -6, 4) end
        c.top:SetText(f(peak)); c.bottom:SetText(positive and f(0) or f(-peak))

        local slot = w / n
        local C = ns.Theme.C
        local ar, ag, ab = W.Accent()
        local prev, nseg = nil, 0
        for i, it in ipairs(items) do
            local b = c.slots[i]
            if not b then
                b = CreateFrame("Button", nil, c.plot)
                b.dot = b:CreateTexture(nil, "OVERLAY")
                b.dot:SetTexture(ns.MEDIA .. "rond.png")
                b.dot:SetTexCoord(0.1, 0.9, 0.1, 0.9)
                b.label = W.Text(c, "tiny", "CENTER")
                b.col = b:CreateTexture(nil, "ARTWORK")
                b.mark = b:CreateTexture(nil, "OVERLAY")
                b.mark:SetTexture(ns.MEDIA .. "rond.png")
                b.mark:SetSize(13, 13)
                b:SetScript("OnEnter", function(self)
                    local d = c.items[self.i]
                    if not d then return end
                    GameTooltip:SetOwner(self, "ANCHOR_TOP")
                    GameTooltip:SetText(d[2] or "", 1, 1, 1)
                    if d[3] then GameTooltip:AddLine(d[3], 0.8, 0.82, 0.86, true) end
                    GameTooltip:Show()
                end)
                b:SetScript("OnLeave", function() GameTooltip:Hide() end)
                c.slots[i] = b
            end
            b.i = i
            b:Show()
            b:ClearAllPoints()
            b:SetPoint("BOTTOMLEFT", c.plot, "BOTTOMLEFT", (i - 1) * slot, 0)
            b:SetSize(slot, h)
            local v = it[1]
            local cx = (i - 0.5) * slot
            if v then
                local y = Y(v)
                local col = it[5]
                if not col then
                    if positive then col = { ar, ag, ab }
                    else col = ((v < 0) ~= (c.invert == true)) and C.profit or C.loss end
                end
                b.dot:Show()
                b.dot:ClearAllPoints()
                b.dot:SetPoint("CENTER", b, "BOTTOMLEFT", slot / 2, y)
                local size = bars and 4 or (n > 24 and 5 or 7)
                b.dot:SetSize(size, size)
                b.col:SetShown(bars == true)
                if bars then
                    local cw = math.max(2, slot * 0.6)
                    b.col:ClearAllPoints()
                    b.col:SetWidth(cw)
                    b.col:SetColorTexture(col[1], col[2], col[3], 0.8)
                    if y >= zeroY then
                        b.col:SetPoint("BOTTOM", b, "BOTTOMLEFT", slot / 2, zeroY)
                        b.col:SetHeight(math.max(1, y - zeroY))
                    else
                        b.col:SetPoint("TOP", b, "BOTTOMLEFT", slot / 2, zeroY)
                        b.col:SetHeight(math.max(1, zeroY - y))
                    end
                end
                b.dot:SetVertexColor(col[1], col[2], col[3], 1)
                -- the line from the previous dot
                if prev and not bars then
                    local l = seg(nseg + 1)
                    if l then
                        nseg = nseg + 1
                        l:SetColorTexture(ar, ag, ab, 0.9)
                        l:SetStartPoint("BOTTOMLEFT", c.plot, prev[1], prev[2])
                        l:SetEndPoint("BOTTOMLEFT", c.plot, cx, y)
                        l:Show()
                    end
                end
                prev = { cx, y }
            else
                prev = nil                      -- a gap: the line starts again after it
            end
            local mk = marks and marks[i]
            b.mark:SetShown(mk ~= nil and v ~= nil)
            if mk and v then
                b.mark:ClearAllPoints()
                b.mark:SetPoint("CENTER", b.dot, "CENTER", 0, 0)
                b.mark:SetVertexColor(mk[1], mk[2], mk[3], 0.45)
            end
            b.label:ClearAllPoints()
            b.label:SetPoint("TOP", c.plot, "BOTTOMLEFT", cx, -4)
            local every = n > 12 and 3 or 1
            b.label:SetText(((i - 1) % every == 0) and (it[4] or "") or "")
            b.label:Show()
        end
    end
    c:SetScript("OnSizeChanged", function() if c.items then c.Draw(c.items, c.marks, c.emptyText, c.fmt, c.invert) end end)
    return c
end
