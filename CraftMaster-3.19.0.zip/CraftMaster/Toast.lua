local _, ns = ...
local L = ns.L
local W = ns.W

-- A discreet notice at the top of the screen: it shows for a few seconds, does
-- not take the keyboard, and a click opens what it is about. Used for the
-- exceptional deal after a scan, instead of one more line in the chat.
local T = {}
ns.Toast = T

local frame
local SECONDS = 7

local function build()
    frame = CreateFrame("Button", "CraftMasterToast", UIParent)
    frame:SetSize(380, 56)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -130)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    W.Skin(frame, "window")
    local logo = frame:CreateTexture(nil, "ARTWORK")
    logo:SetSize(28, 28)
    logo:SetPoint("LEFT", frame, "LEFT", 12, 0)
    logo:SetTexture(ns.MEDIA .. "logo.png")
    frame.title = W.Text(frame, "head", "LEFT")
    frame.title:SetPoint("TOPLEFT", frame, "TOPLEFT", 50, -9)
    frame.title:SetPoint("RIGHT", frame, "RIGHT", -12, 0)
    frame.title:SetWordWrap(false)
    local gold = ns.Theme.C.gold
    frame.title:SetTextColor(gold[1], gold[2], gold[3])
    frame.text = W.Text(frame, "small", "LEFT")
    frame.text:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 50, 9)
    frame.text:SetPoint("RIGHT", frame, "RIGHT", -12, 0)
    frame.text:SetWordWrap(false)
    frame:RegisterForClicks("LeftButtonUp")
    frame:SetScript("OnClick", function(self)
        local fn = self.onClick
        self:Hide()
        if fn then fn() end
    end)
    frame:Hide()
end

-- T.Show(title, text, onClick, seconds)
function T.Show(title, text, onClick, seconds)
    if not frame then build() end
    frame.title:SetText(title or "")
    frame.text:SetText(text or "")
    frame.onClick = onClick
    frame:Show()
    frame.token = (frame.token or 0) + 1
    local mine = frame.token
    C_Timer.After(seconds or SECONDS, function()
        if frame.token == mine then frame:Hide() end
    end)
end

function T.IsShown() return frame ~= nil and frame:IsShown() end
