local _, ns = ...

-- Controls: Daylight UI's when it's installed and wanted, else our own flat
-- ones in Buffalo's look. Same sizes either way, so layouts don't care.
local W = {}
ns.W = W
local MEDIA = ns.MEDIA

local function API() return ns.DUI and ns.DUI() end
W.API = API

function W.Accent()
    local api = API()
    if api and api.Accent then
        local ok, r, g, b = pcall(api.Accent)
        if ok and type(r) == "number" then return r, g, b end
    end
    local c = ns.Theme.C.gold
    return c[1], c[2], c[3]
end

local SIZES = { title = 17, head = 13, body = 12, small = 11, tiny = 10 }
function W.Text(parent, size, justify)
    local api = API()
    if api and api.Text then
        local ok, fs = pcall(api.Text, parent, size, justify)
        if ok and fs then return ns.ApplyFont(fs, SIZES[size]) end
    end
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    if justify then fs:SetJustifyH(justify) end
    ns.ApplyFont(fs, SIZES[size] or 12)
    local c = ns.Theme.C.text
    fs:SetTextColor(c[1], c[2], c[3])
    return fs
end

function W.Fill(frame, layer, r, g, b, a)
    local t = frame:CreateTexture(nil, layer or "BACKGROUND")
    t:SetAllPoints()
    t:SetColorTexture(r, g, b, a)
    return t
end

function W.Outline(frame, r, g, b, a)
    local parts = {}
    for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 },
                         { "TOPLEFT", "BOTTOMLEFT", 1, nil }, { "TOPRIGHT", "BOTTOMRIGHT", 1, nil } }) do
        local t = frame:CreateTexture(nil, "BORDER")
        t:SetPoint(p[1]); t:SetPoint(p[2])
        if p[3] then t:SetWidth(1) else t:SetHeight(1) end
        t:SetColorTexture(r, g, b, a)
        parts[i] = t
    end
    function parts.Color(r2, g2, b2, a2) for i = 1, 4 do parts[i]:SetColorTexture(r2, g2, b2, a2) end end
    return parts
end

local function flatButton(parent, label)
    local b = CreateFrame("Button", nil, parent)
    b:SetHeight(24)
    if API() then
        b.bg = W.Fill(b, "BACKGROUND", 1, 1, 1, 0.07)
        b.line = W.Outline(b, 1, 1, 1, 0.14)
    else
        local p = ns.Theme.Panel(b, "button")
        b.bg, b.line = p.bg, p.line
    end
    b.text = W.Text(b, "small")
    b.text:SetPoint("CENTER")
    b.text:SetText(label or "")
    b.tint = nil
    function b.Paint(hover)
        local t = b.tint
        if t then
            b.bg:SetColorTexture(t[1], t[2], t[3], hover and 0.45 or 0.30)
            b.line.Color(t[1], t[2], t[3], hover and 1 or 0.7)
        else
            b.bg:SetColorTexture(1, 1, 1, hover and 0.13 or 0.07)
            if hover then local r, g, bl = W.Accent(); b.line.Color(r, g, bl, 0.9) else b.line.Color(1, 1, 1, 0.14) end
        end
    end
    b:SetScript("OnEnter", function() b.Paint(true) end)
    b:SetScript("OnLeave", function() b.Paint(false) end)
    b:SetScript("OnMouseDown", function(self) self.text:SetPoint("CENTER", 0, -1) end)
    b:SetScript("OnMouseUp", function(self) self.text:SetPoint("CENTER", 0, 0) end)
    return b
end

-- A button; SetLabel changes its words, SetTint(color or nil) fills it.
function W.Button(parent, label, width, onClick)
    local b = flatButton(parent, label)
    b:SetWidth(width or 100)
    if onClick then b:SetScript("OnClick", onClick) end
    function b.SetLabel(words) b.text:SetText(words or "") end
    function b.SetTint(c) b.tint = c; b.Paint(false) end
    function b.SetEnabledLook(on)
        b:SetEnabled(on)
        b:SetAlpha(on and 1 or 0.45)
    end
    return b
end

-- A drop-down with its label inside ("Tri : Profit"): for the filters and the
-- sorts with more than three choices, which a row of buttons would crowd. Same
-- arguments as W.Segments, plus the label after the parent.
function W.Pick(parent, label, items, get, set, width)
    local d = W.Dropdown(parent, width or 170, items, get, set)
    d.prefix = label and (label .. " : ") or nil
    d.buttons = {}
    d:SetHeight(24)
    d.Refresh()
    return d
end

-- A loader: dots in a ring that light up in turn, and a line of words under it.
-- Animated by the game itself (animation groups), no script on every frame;
-- the animations play only while it is shown. loader.Set(words) shows it.
function W.Loader(parent, color)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(320, 96)
    local c = color or ns.Theme.C.gold
    local groups = {}
    local N, R, CYCLE = 10, 20, 1.2
    for i = 1, N do
        local a = (i - 1) / N * 2 * math.pi
        local dot = f:CreateTexture(nil, "ARTWORK")
        dot:SetSize(7, 7)
        dot:SetPoint("CENTER", f, "TOP", math.sin(a) * R, -26 + math.cos(a) * R)
        dot:SetColorTexture(c[1], c[2], c[3], 1)
        dot:SetAlpha(0.15 + 0.85 * (i - 1) / N)   -- without animations: a still ring that fades
        -- each dot lights up in turn: the same cycle for all, shifted
        pcall(function()
            local ag = dot:CreateAnimationGroup()
            ag:SetLooping("REPEAT")
            local d = (i - 1) / N * CYCLE / 2
            local up = ag:CreateAnimation("Alpha")
            up:SetFromAlpha(0.15); up:SetToAlpha(1); up:SetDuration(CYCLE / 4); up:SetOrder(1); up:SetStartDelay(d)
            local down = ag:CreateAnimation("Alpha")
            down:SetFromAlpha(1); down:SetToAlpha(0.15); down:SetDuration(CYCLE / 4); down:SetOrder(2)
            down:SetEndDelay(CYCLE / 2 - d)
            groups[#groups + 1] = ag
        end)
    end
    f.text = W.Text(f, "body", "CENTER")
    f.text:SetPoint("BOTTOM", f, "BOTTOM", 0, 0)
    f.text:SetWidth(320)
    local C = ns.Theme.C
    f.text:SetTextColor(C.label[1], C.label[2], C.label[3])
    f:SetScript("OnShow", function() for _, ag in ipairs(groups) do pcall(ag.Play, ag) end end)
    f:SetScript("OnHide", function() for _, ag in ipairs(groups) do pcall(ag.Stop, ag) end end)
    function f.Set(words)
        f.text:SetText(words or "")
        f:Show()
    end
    f:Hide()
    return f
end

-- A row of n tiles that share the width: a small label on top, a big figure
-- under it (the figure is cut with "..." when it is too long for its tile).
-- The note goes on the label's line, on the right: the figure keeps the whole width.
-- tiles.Set(i, label, value, color, note)
function W.Tiles(parent, n, height)
    local f = CreateFrame("Frame", nil, parent)
    local h = height or 50
    f:SetHeight(h)
    f.tiles = {}
    local C = ns.Theme.C
    for i = 1, n do
        local t = CreateFrame("Frame", nil, f)
        t:SetHeight(h)
        W.Fill(t, "BACKGROUND", 1, 1, 1, 0.04)
        t.bar = t:CreateTexture(nil, "ARTWORK")
        t.bar:SetPoint("TOPLEFT"); t.bar:SetPoint("BOTTOMLEFT"); t.bar:SetWidth(3)
        t.label = W.Text(t, "tiny", "LEFT")
        t.label:SetPoint("TOPLEFT", t, "TOPLEFT", 12, -7)
        t.label:SetPoint("RIGHT", t, "RIGHT", -8, 0)
        t.label:SetWordWrap(false)
        t.label:SetTextColor(C.label[1], C.label[2], C.label[3])
        t.value = W.Text(t, "head", "LEFT")
        t.value:SetPoint("BOTTOMLEFT", t, "BOTTOMLEFT", 12, 8)
        t.value:SetPoint("RIGHT", t, "RIGHT", -8, 0)
        t.value:SetWordWrap(false)
        -- a small note on the right of the label (where it comes from, per unit...)
        t.note = W.Text(t, "tiny", "RIGHT")
        t.note:SetPoint("TOPRIGHT", t, "TOPRIGHT", -8, -7)
        t.note:SetWordWrap(false)
        t.note:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
        f.tiles[i] = t
    end
    local function layout()
        local w = f:GetWidth()
        if not w or w < 40 then w = 800 end
        local gap = 8
        local tw = (w - gap * (n - 1)) / n
        for i, t in ipairs(f.tiles) do
            t:ClearAllPoints()
            t:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * (tw + gap), 0)
            t:SetWidth(tw)
        end
    end
    f:SetScript("OnSizeChanged", layout)
    layout()
    function f.Set(i, label, value, color, note)
        local t = f.tiles[i]
        if not t then return end
        local c = color or C.label
        t.label:SetText(label or "")
        t.value:SetText(value or "")
        t.note:SetText(note or "")
        -- the label gives way to the note
        t.label:SetPoint("RIGHT", t, "RIGHT", -8, 0)
        if note and note ~= "" then
            t.note:SetWidth(0)
            local room = (t:GetWidth() or 0) - 20 - math.min(t.label:GetStringWidth() or 0, 120) - 10
            if room > 20 and (t.note:GetStringWidth() or 0) > room then t.note:SetWidth(room) end
            t.label:SetPoint("RIGHT", t.note, "LEFT", -10, 0)
        end
        t.value:SetTextColor(C.text[1], C.text[2], C.text[3])
        t.bar:SetColorTexture(c[1], c[2], c[3], 1)
    end
    return f
end

-- A row of mutually exclusive choices: { { key, label } }.
function W.Segments(parent, items, get, set, width)
    local f = CreateFrame("Frame", nil, parent)
    f:SetHeight(24)
    f.buttons = {}
    local x = 0
    for _, it in ipairs(items) do
        local w = width or math.max(54, #it[2] * 7 + 18)
        local b = W.Button(f, it[2], w, function() set(it[1]); f.Refresh() end)
        b:SetPoint("LEFT", f, "LEFT", x, 0)
        b.key = it[1]
        f.buttons[#f.buttons + 1] = b
        x = x + w + 4
    end
    f:SetWidth(x - 4)
    function f.Refresh()
        local cur = get()
        for _, b in ipairs(f.buttons) do
            if b.key == cur then
                if f.color then
                    b.SetTint(f.color)
                else
                    local r, g, bl = W.Accent()
                    b.SetTint({ r, g, bl })
                end
            else
                b.SetTint(nil)
            end
        end
    end
    f.Refresh()
    return f
end

local function flatSwitch(parent)
    local s = CreateFrame("Button", nil, parent)
    s:SetSize(38, 18)
    s.pill = s:CreateTexture(nil, "BACKGROUND")
    s.pill:SetAllPoints()
    s.pill:SetTexture(MEDIA .. "pilule.png")
    s.knob = s:CreateTexture(nil, "ARTWORK")
    s.knob:SetSize(14, 14)
    s.knob:SetTexture(MEDIA .. "rond.png")
    s.knob:SetTexCoord(0.1, 0.9, 0.1, 0.9)
    function s.SetOn(on)
        local r, g, b, a = 1, 1, 1, 0.16
        if on then r, g, b = W.Accent(); a = 1 end
        s.pill:SetVertexColor(r, g, b, a)
        s.knob:ClearAllPoints()
        s.knob:SetPoint(on and "RIGHT" or "LEFT", s, on and "RIGHT" or "LEFT", on and -2 or 2, 0)
        if on then s.knob:SetVertexColor(0.08, 0.08, 0.1, 1) else s.knob:SetVertexColor(0.85, 0.87, 0.92, 1) end
    end
    s.SetOn(false)
    return s
end

function W.Switch(parent, get, set)
    local api = API()
    local s
    if api and api.Switch then
        local ok, made = pcall(api.Switch, parent)
        if ok and made then s = made end
    end
    s = s or flatSwitch(parent)
    s:SetScript("OnClick", function() set(not get()); if s.SetOn then s.SetOn(get()) end end)
    function s.Refresh() if s.SetOn then s.SetOn(get()) end end
    s.Refresh()
    return s
end

-- An edit box. opts: { numeric, hint, onChange, onEnter, width }
function W.Input(parent, opts)
    opts = opts or {}
    local e = CreateFrame("EditBox", nil, parent)
    e:SetHeight(24)
    e:SetWidth(opts.width or 60)
    e:SetAutoFocus(false)
    if opts.numeric then e:SetNumeric(true) end
    e:SetFontObject("GameFontHighlightSmall")
    ns.ApplyFont(e, 11)
    e:SetTextInsets(8, 8, 0, 0)
    if API() then
        W.Fill(e, "BACKGROUND", 0, 0, 0, 0.35)
        W.Outline(e, 1, 1, 1, 0.14)
    else
        ns.Theme.Panel(e, "button")
    end
    if opts.hint then
        e.hint = W.Text(e, "small", "LEFT")
        e.hint:SetPoint("LEFT", e, "LEFT", 8, 0)
        e.hint:SetText(opts.hint)
        local m = ns.Theme.C.muted
        e.hint:SetTextColor(m[1], m[2], m[3])
    end
    e:SetScript("OnTextChanged", function(self, user)
        local t = self:GetText() or ""
        if self.hint then self.hint:SetShown(t == "") end
        if opts.onChange and user then opts.onChange(t) end
    end)
    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    e:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
        if opts.onEnter then opts.onEnter(self:GetText() or "") end
    end)
    e:SetScript("OnEditFocusLost", function(self) if opts.onEnter then opts.onEnter(self:GetText() or "") end end)
    return e
end

function W.Close(parent, onClick)
    local c = W.Button(parent, "", 24, onClick or function() parent:Hide() end)
    c:SetSize(24, 24)
    c.text:Hide()
    local x = c:CreateTexture(nil, "OVERLAY")
    x:SetSize(10, 10)
    x:SetPoint("CENTER")
    x:SetTexture(MEDIA .. "croix.png")
    x:SetVertexColor(0.88, 0.9, 0.94, 0.9)
    c.cross = x
    return c
end

function W.Skin(frame, kind)
    local api = API()
    if api and api.Skin and kind == "window" then
        if pcall(api.Skin, frame, { window = true }) then return end
    end
    ns.Theme.Panel(frame, kind or "window")
end

-- A card: a soft dark panel with an optional colored title.
function W.Card(parent, title, color)
    local c = CreateFrame("Frame", nil, parent)
    if API() then
        W.Fill(c, "BACKGROUND", 1, 1, 1, 0.035)
        W.Outline(c, 1, 1, 1, 0.05)
    else
        ns.Theme.Panel(c, "card")
    end
    c.top = 10
    if title then
        local dot = c:CreateTexture(nil, "ARTWORK")
        dot:SetSize(8, 8)
        dot:SetPoint("TOPLEFT", c, "TOPLEFT", 14, -14)
        dot:SetTexture(MEDIA .. "rond.png")
        dot:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        dot:SetVertexColor(color[1], color[2], color[3])
        local fs = W.Text(c, "head", "LEFT")
        fs:SetPoint("LEFT", dot, "RIGHT", 7, 0)
        fs:SetText(title)
        fs:SetTextColor(color[1], color[2], color[3])
        c.title = fs
        c.top = 36
    end
    return c
end

function W.Tip(owner, title, lines, anchor)
    owner:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, anchor or "ANCHOR_RIGHT")
        GameTooltip:SetText(type(title) == "function" and title() or title, 1, 1, 1)
        local l = type(lines) == "function" and lines() or lines
        if type(l) == "string" then GameTooltip:AddLine(l, 0.8, 0.82, 0.86, true)
        elseif type(l) == "table" then for _, s in ipairs(l) do GameTooltip:AddLine(s, 0.8, 0.82, 0.86, true) end end
        GameTooltip:Show()
    end)
    owner:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- An item icon with its tooltip.
function W.ItemIcon(parent, size)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size, size)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints()
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b:SetScript("OnEnter", function(self)
        if not self.itemID then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        -- the exact item when known (an item "of the eagle": its stats are in its link)
        if not (self.link and pcall(GameTooltip.SetHyperlink, GameTooltip, self.link)) then
            GameTooltip:SetItemByID(self.itemID)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function(self)
        if self.itemID and IsModifiedClick and IsModifiedClick("CHATLINK") then
            local i = ns.Item(self.itemID)
            local link = self.link or (i and i.link)
            if link then ChatEdit_InsertLink(link) end
        end
    end)
    -- link (optional): the exact item, shown by the tooltip
    function b.Set(itemID, icon, link)
        b.itemID, b.link = itemID, link
        b.icon:SetTexture(icon or (itemID and ns.Item(itemID) and ns.Item(itemID).icon) or 134400)
    end
    return b
end

-- A list that scrolls by rows, with a pool of row frames.
-- make(parent) -> row ; fill(row, data, index)
function W.List(parent, rowH, make, fill)
    local f = CreateFrame("Frame", nil, parent)
    f:EnableMouseWheel(true)
    f.rows, f.data, f.offset = {}, {}, 0
    f.thumb = f:CreateTexture(nil, "OVERLAY")
    f.thumb:SetWidth(3)
    f.thumb:SetColorTexture(1, 1, 1, 0.35)
    local function visible() return math.max(1, math.floor((f:GetHeight() or rowH) / rowH)) end
    function f.Update()
        local n = visible()
        for i = 1, n do
            if not f.rows[i] then
                local r = make(f)
                r:SetHeight(rowH)
                r:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(i - 1) * rowH)
                r:SetPoint("RIGHT", f, "RIGHT", -6, 0)
                f.rows[i] = r
            end
        end
        local max = math.max(0, #f.data - n)
        f.offset = math.max(0, math.min(f.offset, max))
        for i, r in ipairs(f.rows) do
            local d = i <= n and f.data[i + f.offset]
            if d then r:Show(); fill(r, d, i + f.offset) else r:Hide() end
        end
        if max > 0 then
            local h = f:GetHeight()
            local th = math.max(20, h * n / #f.data)
            f.thumb:SetHeight(th)
            f.thumb:ClearAllPoints()
            f.thumb:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -(h - th) * f.offset / max)
            f.thumb:Show()
        else
            f.thumb:Hide()
        end
    end
    function f.SetData(data, keep)
        f.data = data or {}
        if not keep then f.offset = 0 end
        f.Update()
    end
    function f.Color(c) f.thumb:SetColorTexture(c[1], c[2], c[3], 0.7) end
    f:SetScript("OnMouseWheel", function(_, delta)
        f.offset = f.offset - delta * 3
        f.Update()
    end)
    f:SetScript("OnSizeChanged", function() f.Update() end)
    return f
end

-- Profit in green, loss in red, with a sign.
function W.ProfitText(fs, v)
    if type(v) ~= "number" then
        fs:SetText("-")
        local m = ns.Theme.C.muted
        fs:SetTextColor(m[1], m[2], m[3])
        return
    end
    local c = v >= 0 and ns.Theme.C.profit or ns.Theme.C.loss
    fs:SetText((v > 0 and "+" or "") .. ns.Money(v, true))
    fs:SetTextColor(c[1], c[2], c[3])
end

-- A column of text lines that flows down: headings, lines with an optional
-- icon, an amount on the right, and a map-pin button. Rebuilt with Clear().
function W.Flow(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetHeight(10)
    local pool, used, y = {}, 0, 0
    local C = ns.Theme.C

    local function row()
        used = used + 1
        local r = pool[used]
        if not r then
            r = CreateFrame("Frame", nil, f)
            r.text = W.Text(r, "small", "LEFT")
            r.text:SetWordWrap(true)
            r.right = W.Text(r, "small", "RIGHT")
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(16, 16)
            r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            r.pin = W.Button(r, "", 22)
            r.pin:SetSize(22, 18)
            r.pin.text:Hide()
            r.pin.glyph = r.pin:CreateTexture(nil, "OVERLAY")
            r.pin.glyph:SetSize(12, 12)
            r.pin.glyph:SetPoint("CENTER")
            r.pin.glyph:SetTexture(ns.MEDIA .. "pin.png")
            r.pin.glyph:SetVertexColor(1, 0.45, 0.6)
            pool[used] = r
        end
        r:Show()
        r.icon:Hide(); r.right:Hide(); r.pin:Hide()
        r.text:SetText(""); r.right:SetText("")
        return r
    end

    local function place(r, indent, gap)
        local hasIcon, hasRight, hasPin = r.icon:IsShown(), r.right:IsShown(), r.pin:IsShown()
        local rightW = (hasRight and 96 or 0) + (hasPin and 26 or 0)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -y)
        r:SetPoint("RIGHT", f, "RIGHT", 0, 0)
        r.text:ClearAllPoints()
        r.text:SetPoint("TOPLEFT", r, "TOPLEFT", (indent or 0) + (hasIcon and 22 or 0), 0)
        r.text:SetPoint("RIGHT", r, "RIGHT", -rightW, 0)
        r.icon:ClearAllPoints()
        r.icon:SetPoint("TOPLEFT", r, "TOPLEFT", indent or 0, 1)
        r.pin:ClearAllPoints()
        r.pin:SetPoint("TOPRIGHT", r, "TOPRIGHT", 0, 2)
        r.right:ClearAllPoints()
        r.right:SetPoint("TOPRIGHT", r, "TOPRIGHT", hasPin and -26 or 0, 0)
        r.right:SetWidth(94)
        local h = math.max(r.text:GetStringHeight() or 12, hasIcon and 16 or 0, hasPin and 18 or 0)
        r:SetHeight(h)
        y = y + h + (gap or 4)
        f:SetHeight(math.max(10, y))
    end

    function f.Clear()
        for _, r in ipairs(pool) do r:Hide() end
        used, y = 0, 0
        f:SetHeight(10)
    end
    function f.Gap(n) y = y + (n or 6) end
    function f.Head(text, color)
        local r = row()
        ns.ApplyFont(r.text, 13)
        r.text:SetText(text)
        r.text:SetTextColor(color[1], color[2], color[3])
        y = y + 4
        place(r, 0, 5)
        return r
    end
    -- opts: { color, right, rightColor, icon, indent, pin = function, pinTip }
    function f.Line(text, opts)
        opts = opts or {}
        local r = row()
        ns.ApplyFont(r.text, 11)
        r.text:SetText(text)
        local c = opts.color or C.text
        r.text:SetTextColor(c[1], c[2], c[3])
        if opts.icon then r.icon:SetTexture(opts.icon); r.icon:Show() end
        if opts.right then
            r.right:SetText(opts.right)
            local rc = opts.rightColor or C.text
            r.right:SetTextColor(rc[1], rc[2], rc[3])
            r.right:Show()
        end
        if opts.onClick then
            r:EnableMouse(true)
            r:SetScript("OnMouseUp", function(_, button) opts.onClick(button) end)
            r:SetScript("OnEnter", opts.clickTip and function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(opts.clickTip, 1, 1, 1, 1, true)
                GameTooltip:Show()
            end or nil)
            r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        else
            r:EnableMouse(false)
            r:SetScript("OnMouseUp", nil)
            r:SetScript("OnEnter", nil)
            r:SetScript("OnLeave", nil)
        end
        if opts.pin then
            r.pin:Show()
            r.pin:SetScript("OnClick", opts.pin)
            r.pin:SetScript("OnEnter", function(self)
                self.Paint(true)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(opts.pinTip or ns.L.MAP_GO, 1, 1, 1)
                GameTooltip:Show()
            end)
            r.pin:SetScript("OnLeave", function(self) self.Paint(false); GameTooltip:Hide() end)
        end
        place(r, opts.indent, opts.gap)
        return r
    end
    -- label on the left, amount on the right
    function f.Money(label, v, profit)
        local r = f.Line(label, { color = C.label, right = "-" })
        if profit then W.ProfitText(r.right, v)
        else r.right:SetText(v and ns.Money(v, true) or "-") end
        return r
    end
    function f.Height() return y end
    return f
end

-- The colors of the skill-up colors (orange, yellow, green, grey).
W.SKILL_COLORS = { { 1, 0.5, 0.25 }, { 1, 1, 0 }, { 0.25, 0.75, 0.25 }, { 0.5, 0.5, 0.5 } }

-- The skill bar of a recipe: the four colours it goes through as the skill rises, as one small
-- design bar (orange, yellow, green, grey), and a tick where the player stands.
--   bar.Set(sk, skill): sk = { learn, orange, yellow, green, grey } (the skills at which the recipe
--   changes colour), skill = the player's skill (nil: no tick). Dimmed while the recipe cannot be
--   learned yet (skill under `learn`). Each colour keeps its real share of the points.
function W.SkillBar(parent, width, height)
    local f = CreateFrame("Frame", nil, parent)
    width, height = width or 86, height or 10
    f:SetSize(width, height)
    f.segs = {}
    local rail = f:CreateTexture(nil, "BACKGROUND")
    rail:SetAllPoints()
    rail:SetColorTexture(1, 1, 1, 0.06)
    for i = 1, 4 do f.segs[i] = f:CreateTexture(nil, "ARTWORK") end
    f.tick = f:CreateTexture(nil, "OVERLAY")
    f.tick:SetColorTexture(1, 1, 1, 1)
    f.tick:SetSize(2, height + 4)
    function f.Set(sk, skill)
        if not sk or not sk[5] then for _, t in ipairs(f.segs) do t:Hide() end f.tick:Hide() return end
        local start = (sk[2] and sk[2] > 0) and sk[2] or sk[1]
        local stops = { start, sk[3], sk[4], sk[5] }
        local span = math.max(1, sk[5] - start)
        local total = span + math.max(6, span * 0.25)        -- a grey tail: what comes after
        local w = f:GetWidth()
        local gap = 1
        local at = 0
        for i = 1, 4 do
            local from = stops[i]
            local to = stops[i + 1] or (start + total)
            local len = math.max(0, to - from)
            local seg = f.segs[i]
            local sw = math.max(2, len / total * w - gap)
            seg:ClearAllPoints()
            seg:SetPoint("LEFT", f, "LEFT", at, 0)
            seg:SetSize(sw, height - 2)
            local c = W.SKILL_COLORS[i]
            local a = (skill and skill < sk[1]) and 0.35 or 0.95        -- not learnable yet: dimmed
            seg:SetColorTexture(c[1], c[2], c[3], a)
            seg:Show()
            at = at + sw + gap
        end
        if skill then
            local x = (math.max(start, math.min(start + total, skill)) - start) / total * w
            f.tick:ClearAllPoints()
            f.tick:SetPoint("CENTER", f, "LEFT", x, 0)
            f.tick:Show()
        else
            f.tick:Hide()
        end
    end
    f:EnableMouse(true)
    return f
end

-- A drop-down: a button showing the choice, a menu under it.
-- items = { { key, label } } (or a function returning them).
function W.Dropdown(parent, width, items, get, set)
    local b = W.Button(parent, "", width)
    b.text:ClearAllPoints()
    b.text:SetPoint("LEFT", b, "LEFT", 10, 0)
    b.text:SetPoint("RIGHT", b, "RIGHT", -22, 0)
    b.text:SetJustifyH("LEFT")
    local arrow = b:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(10, 10)
    arrow:SetPoint("RIGHT", b, "RIGHT", -8, 0)
    arrow:SetTexture(ns.MEDIA .. "chevron.png")
    arrow:SetVertexColor(0.85, 0.87, 0.92)
    local menu
    local function list() return type(items) == "function" and items() or items end
    function b.Refresh()
        for _, it in ipairs(list()) do
            if it[1] == get() then b.SetLabel(b.prefix and (b.prefix .. it[2]) or it[2]) end
        end
    end
    b:SetScript("OnClick", function()
        if menu and menu:IsShown() then menu:Hide() return end
        if not menu then
            menu = CreateFrame("Frame", nil, b)
            menu:SetFrameStrata("FULLSCREEN_DIALOG")
            ns.Theme.Panel(menu, "menu")
            menu.buttons = {}
        end
        for _, mb in ipairs(menu.buttons) do mb:Hide() end
        for i, it in ipairs(list()) do
            local mb = menu.buttons[i]
            if not mb then
                mb = W.Button(menu, "", width - 12)
                mb:SetPoint("TOPLEFT", menu, "TOPLEFT", 6, -6 - (i - 1) * 26)
                menu.buttons[i] = mb
            end
            mb.SetLabel(it[2])
            mb.SetTint(it[1] == get() and { W.Accent() } or nil)
            mb:SetScript("OnClick", function()
                menu:Hide()
                set(it[1])
                b.Refresh()
            end)
            mb:Show()
        end
        menu:SetSize(width, 12 + #list() * 26)
        menu:ClearAllPoints()
        menu:SetPoint("TOPLEFT", b, "BOTTOMLEFT", 0, -4)
        menu:Show()
    end)
    b:HookScript("OnHide", function() if menu then menu:Hide() end end)
    b.Refresh()
    return b
end
