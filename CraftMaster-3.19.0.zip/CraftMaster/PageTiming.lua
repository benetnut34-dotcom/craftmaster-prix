local _, ns = ...
local L = ns.L
local W = ns.W

-- Timing: when prices are low (buy) and high (sell), hour by hour and day
-- by day, for the whole market or one item of my professions. Built from
-- every scan, mine and the guild's.

local LIST_W = 280

ns.UI.AddPage("timing", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    page.search = L.SEARCH_ITEM

    local left = W.Card(body)
    left:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0)
    left:SetWidth(LIST_W)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(18, 18)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        r.info = W.Text(r, "tiny", "RIGHT")
        r.info:SetWidth(70)
        r.info:SetPoint("RIGHT", r, "RIGHT", -4, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
        r.name:SetPoint("RIGHT", r.info, "LEFT", -4, 0)
        r.name:SetWordWrap(false)
        r:SetScript("OnClick", function(self)
            ns.char.timingItem = self.data.id
            page.Refresh()
        end)
        return r
    end
    local function fillRow(r, d)
        r.data = d
        r.sel:SetShown(ns.char.timingItem == d.id)
        if d.id == 0 then
            r.icon:SetTexture(133784)
            r.name:SetText(L.TIME_MARKET)
            r.name:SetTextColor(color[1], color[2], color[3])
        else
            local i = ns.Item(d.id)
            r.icon:SetTexture(i and i.icon or 134400)
            r.name:SetText(ns.ItemName(d.id))
            r.name:SetTextColor(ns.QualityColor(i and i.quality or 1))
        end
        r.info:SetText(string.format(L.TIME_HOURS, d.hours))
        r.info:SetTextColor(C.label[1], C.label[2], C.label[3])
    end
    local list = W.List(left, 24, makeRow, fillRow)
    list:SetPoint("TOPLEFT", left, "TOPLEFT", 8, -10)
    list:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -6, 10)
    list.Color(color)

    local right = W.Card(body)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 12, 0)
    right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    local title = W.Text(right, "head", "LEFT")
    title:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -14)
    local coverage = W.Text(right, "small", "RIGHT")
    coverage:SetPoint("TOPRIGHT", right, "TOPRIGHT", -14, -15)
    coverage:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- the verdict boxes
    local boxes = {}
    for i, k in ipairs({ "TIME_BUY_HOUR", "TIME_SELL_HOUR", "TIME_BUY_DAY", "TIME_SELL_DAY" }) do
        local box = CreateFrame("Frame", nil, right)
        box:SetSize(150, 46)
        box:SetPoint("TOPLEFT", right, "TOPLEFT", 14 + (i - 1) * 158, -40)
        W.Fill(box, "BACKGROUND", 1, 1, 1, 0.04)
        box.bar = box:CreateTexture(nil, "ARTWORK")
        box.bar:SetPoint("TOPLEFT"); box.bar:SetPoint("BOTTOMLEFT"); box.bar:SetWidth(3)
        local c = (i % 2 == 1) and C.profit or C.loss
        box.bar:SetColorTexture(c[1], c[2], c[3], 1)
        box.label = W.Text(box, "tiny", "LEFT")
        box.label:SetPoint("TOPLEFT", box, "TOPLEFT", 10, -6)
        box.label:SetText(L[k])
        box.label:SetTextColor(C.label[1], C.label[2], C.label[3])
        box.value = W.Text(box, "head", "LEFT")
        box.value:SetPoint("BOTTOMLEFT", box, "BOTTOMLEFT", 10, 7)
        boxes[i] = box
    end

    local hoursTitle = W.Text(right, "small", "LEFT")
    hoursTitle:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -100)
    hoursTitle:SetText(L.TIME_BY_HOUR)
    hoursTitle:SetTextColor(color[1], color[2], color[3])
    local hours = ns.Chart.Line(right)
    hours:SetPoint("TOPLEFT", hoursTitle, "BOTTOMLEFT", -14, -4)
    hours:SetPoint("RIGHT", right, "RIGHT", -10, 0)
    hours:SetHeight(150)
    local supplyTitle = W.Text(right, "small", "LEFT")
    supplyTitle:SetPoint("TOPLEFT", hours, "BOTTOMLEFT", 14, -8)
    supplyTitle:SetText(L.TIME_SUPPLY)
    supplyTitle:SetTextColor(color[1], color[2], color[3])
    local supply = ns.Chart.Line(right, nil, true)
    supply:SetPoint("TOPLEFT", supplyTitle, "BOTTOMLEFT", -14, -4)
    supply:SetPoint("RIGHT", right, "RIGHT", -10, 0)
    supply:SetHeight(90)
    local daysTitle = W.Text(right, "small", "LEFT")
    daysTitle:SetPoint("TOPLEFT", supply, "BOTTOMLEFT", 14, -8)
    daysTitle:SetText(L.TIME_BY_DAY)
    daysTitle:SetTextColor(color[1], color[2], color[3])
    local days = ns.Chart.Line(right, nil, true)
    days:SetPoint("TOPLEFT", daysTitle, "BOTTOMLEFT", -14, -4)
    days:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -10, 30)
    local note = W.Text(right, "tiny", "LEFT")
    note:SetPoint("BOTTOMLEFT", right, "BOTTOMLEFT", 14, 10)
    note:SetPoint("RIGHT", right, "RIGHT", -14, 0)
    note:SetWordWrap(true)
    note:SetText(L.TIME_NOTE)
    note:SetTextColor(C.muted[1], C.muted[2], C.muted[3])

    local function pct(v) return v and string.format("%+d%%", math.floor(v * 100 + 0.5)) or "-" end
    local function hourName(h) return string.format(L.TIME_HOUR, h) end

    function page.Refresh()
        local house = ns.House()
        -- the list: the market first, then the items of my professions with data
        local items = { { id = 0, hours = (ns.Timing.Coverage(house)) } }
        local q = page.query and page.query ~= "" and string.lower(page.query) or nil
        local s = ns.db.timing and ns.db.timing[ns.HouseKey(house)]
        local per = {}
        for id, hs in pairs(s and s.i or {}) do
            local n = 0
            for _ in pairs(hs) do n = n + 1 end
            if n >= 2 and (not q or string.find(string.lower(ns.ItemName(id)), q, 1, true)) then
                per[#per + 1] = { id = id, hours = n }
            end
        end
        table.sort(per, function(a, b)
            if a.hours ~= b.hours then return a.hours > b.hours end
            return ns.ItemName(a.id) < ns.ItemName(b.id)
        end)
        for _, it in ipairs(per) do items[#items + 1] = it end
        list.SetData(items, true)

        local id = ns.char.timingItem or 0
        local found = false
        for _, it in ipairs(items) do if it.id == id then found = true end end
        if not found then id = 0; ns.char.timingItem = 0 end
        title:SetText(id == 0 and (L.TIME_MARKET .. " — " .. ns.HouseName(house)) or ns.ItemName(id))
        if id == 0 then title:SetTextColor(color[1], color[2], color[3])
        else local i = ns.Item(id); title:SetTextColor(ns.QualityColor(i and i.quality or 1)) end
        local hoursCovered, scans = ns.Timing.Coverage(house)
        local pipeAt = s and s.pipeAt
        coverage:SetText(string.format(L.TIME_COVER, scans, hoursCovered) .. (pipeAt and L.TIME_PIPE or ""))

        local hd = ns.Timing.Hours(house, id ~= 0 and id or nil)
        local priceBars, supplyBars = {}, {}
        for h = 0, 23 do
            local e = hd[h]
            local tip = e[1] and string.format(L.TIME_TIP, pct(e[1]), pct(e[2]), e[3]) or L.TIME_NO_DATA
            priceBars[h + 1] = { e[1], hourName(h), tip, tostring(h) }
            supplyBars[h + 1] = { e[2], hourName(h), tip, tostring(h) }
        end
        local buyH, sellH = ns.Timing.Best(hd, 0, 23, id == 0 and 2 or 1)
        local marks = {}
        if buyH then marks[buyH + 1] = C.profit end
        if sellH then marks[sellH + 1] = C.loss end
        hours.Draw(priceBars, marks, L.TIME_EMPTY)
        supply.Draw(supplyBars, nil, L.TIME_EMPTY, nil, true)
        local flat = L.TIME_FLAT
        boxes[1].value:SetText(buyH and (hourName(buyH) .. "  " .. pct(hd[buyH][1])) or flat)
        boxes[2].value:SetText(sellH and (hourName(sellH) .. "  " .. pct(hd[sellH][1])) or flat)

        local dd = ns.Timing.Days(house)
        local dayBars = {}
        for d = 1, 7 do
            local e = dd[d]
            dayBars[d] = { e[1], L.WEEKDAYS[d], e[1] and string.format(L.TIME_TIP, pct(e[1]), pct(e[2]), e[3]) or L.TIME_NO_DATA,
                L.WEEKDAYS_SHORT[d] }
        end
        local buyD, sellD = ns.Timing.Best(dd, 1, 7, 2)
        local dmarks = {}
        if buyD then dmarks[buyD] = C.profit end
        if sellD then dmarks[sellD] = C.loss end
        days.Draw(dayBars, dmarks, L.TIME_EMPTY)
        boxes[3].value:SetText(buyD and (L.WEEKDAYS[buyD] .. "  " .. pct(dd[buyD][1])) or flat)
        boxes[4].value:SetText(sellD and (L.WEEKDAYS[sellD] .. "  " .. pct(dd[sellD][1])) or flat)
    end
    function page.OnSearch() page.Refresh() end
    ns.On("TimingChanged", function() if page.frame:IsShown() then ns.UI.RefreshSoon() end end)
end)
