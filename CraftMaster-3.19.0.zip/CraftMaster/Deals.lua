local _, ns = ...
local L = ns.L

-- The daily lows: every scan of CraftMaster keeps the daily low of every item
-- it lists (14 days, both houses). That is what the usual price is measured
-- against (the good deals, the price curves). And the scan by itself when the
-- Auction House opens.
local D = {}
ns.Deals = D

local KEEP = 14   -- daily lows kept per item
local HALF = 5    -- days for a low's weight to halve
local MIN_DAYS = 3

-- ---------------------------------------------------------------------
-- Daily lows of every scanned item
-- ---------------------------------------------------------------------

local function store(house)
    ns.db.mkt = ns.db.mkt or {}
    local k = ns.HouseKey(house or "faction")
    ns.db.mkt[k] = ns.db.mkt[k] or {}
    return ns.db.mkt[k]
end

local function addLow(list, day, price)
    local n = #list
    local at = n - 1
    while at >= 1 and list[at] > day do at = at - 2 end
    if at >= 1 and list[at] == day then
        if price < list[at + 1] then list[at + 1] = price end
        return
    end
    table.insert(list, at + 2, day)
    table.insert(list, at + 3, price)
    while #list > KEEP * 2 do table.remove(list, 1); table.remove(list, 1) end
end

-- After a scan: every item's low of the day.
function D.NoteScan(house, items)
    local day = ns.Today()
    local s = store(house)
    for id, e in pairs(items) do
        local list = s[id]
        if not list then list = {}; s[id] = list end
        addLow(list, day, e[1])
    end
end

-- Lows a guild mate saw (any day): merged, the lowest price stays.
function D.MergeDay(house, day, items)
    local s = store(house)
    for id, e in pairs(items) do
        local list = s[id]
        if not list then list = {}; s[id] = list end
        addLow(list, day, e[1])
    end
end

-- The store of a house key ("PvP-Horde"...), for the imports.
function D.StoreOf(key)
    ns.db.mkt = ns.db.mkt or {}
    ns.db.mkt[key] = ns.db.mkt[key] or {}
    return ns.db.mkt[key]
end
D.AddLow = addLow

-- The usual price: weighted median of the lows before today (recent days
-- weigh more). Also how many days it rests on and how much they spread.
function D.Usual(id, house)
    local list = store(house)[id]
    if not list then return nil end
    local today = ns.Today()
    local prices, weights, total = {}, {}, 0
    local lo, hi = math.huge, 0
    for i = 1, #list - 1, 2 do
        if list[i] < today then
            local w = 0.5 ^ ((today - list[i]) / HALF)
            local p = list[i + 1]
            local j = #prices
            while j >= 1 and prices[j] > p do prices[j + 1], weights[j + 1] = prices[j], weights[j]; j = j - 1 end
            prices[j + 1], weights[j + 1] = p, w
            total = total + w
            lo, hi = math.min(lo, p), math.max(hi, p)
        end
    end
    if #prices < MIN_DAYS then return nil, #prices end
    local half, sum = total / 2 - 1e-12, 0
    for i = 1, #prices do
        sum = sum + weights[i]
        if sum >= half then return prices[i], #prices, lo, hi end
    end
    return prices[#prices], #prices, lo, hi
end

-- { {day, price} } of the kept lows, for the chart.
function D.Lows(id, house)
    local out = {}
    local list = store(house)[id]
    if not list then return out end
    for i = 1, #list - 1, 2 do out[#out + 1] = { list[i], list[i + 1] } end
    return out
end

-- Scans fill the daily lows.
ns.On("ScanDone", function(house, items) D.NoteScan(house, items) end)

-- Scan by itself when the Auction House opens and the last scan is old.
ns.Register("AUCTION_HOUSE_SHOW", function()
    if not ns.db.autoScan then return end
    C_Timer.After(1.5, function()
        local house = ns.Scan.OpenHouse()
        local kind = ns.Scan.AutoKind(house)       -- "any", "quick", "full" or nil (nothing)
        if not kind or ns.Scan.Running() then return end
        local at = ns.Scan.LastAt(house)
        local old = not at or time() - at > (ns.db.autoScanMin or 30) * 60
        if kind == "full" then
            ns.Scan.Start("full")
        elseif kind == "quick" then
            if old then ns.Scan.Start("quick") end
        else
            -- as it has always been: a full scan when Blizzard allows one, else a quick one when the last is old
            local fullDue = ns.db.fullScan ~= false and ns.Scan.FullWait() == 0
            if fullDue or old then ns.Scan.Start() end
        end
    end)
end)
