local addonName, ns = ...
local L = ns.L

ns.version = "3.19.0"
-- Version de la tache planifiee du compagnon (CraftMaster_Data\Companion\VERSION)
-- que cet addon attend : si Data.lua en annonce une plus ancienne, il faut
-- relancer Installer.cmd (alerte sur la page Accueil).
ns.COMPANION_TASK = 4
ns.name = "CraftMaster"

-- ---------------------------------------------------------------------
-- Saved data
-- ---------------------------------------------------------------------

local ACCOUNT_DEFAULTS = {
    source = "auto",      -- auto | am | daylight | auctionator
    cut = 5,              -- % kept by the faction Auction House
    cutN = 15,            -- % kept by the shared (neutral) Auction House
    bags = true,          -- count bags and bank against the shopping list
    tooltip = true,       -- CraftMaster lines in item tooltips
    dealGap = 30,         -- % under the usual price that makes a deal
    -- the market pages (Good deals, Crafts, Buying in volume, Sharing)
    dealThreshold = 0.70, -- a good deal: listed at 70 % or less of what it sells for
    minProfit = 5000,     -- a deal or a craft must earn at least this (copper)
    topMinStars = 4,      -- "top offers": resale backed by sales, at least this many stars
    topMinPerDay = 1,     -- ... and at least this many sold a day
    shareGuild = true,    -- share with the whole guild
    shareRecipes = true,  -- send my recipes to players who know fewer
    gmRecipes = {},       -- [spellID] = { name, out, qty, reagents = { {id, n} }, prof } shared or imported
    gmUI = { profFilter = "top", sortKey = "profit", sortDesc = true,
             filters = { search = "", maxBuy = 0 } },
    scanCount = 0,
    fullScan = true,      -- full scans (every listing, sales seen) when Blizzard allows one
    readOthers = true,    -- read the full scans other addons ask for
    readChat = true,      -- read cooldown offers in chat
    scanReminder = true,  -- say when a full scan is allowed again
    customPrices = {},    -- [itemID] = copper set by hand
    excluded = {},        -- [recipeID] = { [itemID] = true } left out of the cost
    excludedGlobal = {},  -- [itemID] = true, left out of every recipe
    sales = {},           -- [house key] = { [itemID] = events } (Tracker.lua)
    snapFull = {},        -- [house key] = { time, items } the last full scan's listings
    friends = {},         -- names of players outside the guild to share with
    toast = true,         -- a notice on screen for an exceptional deal after a scan
    profitInWindow = true, -- what each craft earns, in the game's profession window
    autoScan = true,      -- scan by itself when the Auction House opens and the scan is old
    autoScanMin = 30,     -- minutes
    share = true,         -- share scans with the guild
    histDays = 90,
    warn = 150,           -- % of the usual price that asks for a second look
    skin = "daylight",    -- daylight (when installed) | own
    minimap = { angle = 200, hide = false },
    schem = {},           -- [spellID] = { o = itemID, n = count, m = { { itemID, qty } } }
    vendorBuy = {},       -- [itemID] = copper, seen at merchants
    histBy = {},          -- [house key] = { [itemID] = { day, price, day, price, ... } }
}
local CHAR_DEFAULTS = {
    cart = {},            -- { { id = spellID, n = crafts } }
    bought = {},          -- [itemID] = units bought at the AH not in the bags yet
    baseline = {},        -- [itemID] = bag count when bought
    known = {},           -- [spellID] = true, read from the profession window
    prof = nil,           -- the profession shown on the Recipes page
    filter = "all",       -- all | known | unknown
    sellAt = "ah",        -- ah | vendor | best
    mult = 1,
    onlyProfit = false,
    sort = "profit",
    sortDown = true,
    page = "home",
    win = nil,            -- { w, h }
    histItem = nil,
    histDays = 30,
    histType = "all",     -- all | crafts | mats
    histProf = "all",     -- all | a profession key
    histSort = "up",      -- up | down | price | name
    guideWay = "profit",  -- profit | fast | cheap
    house = "faction",    -- faction | neutral: the Auction House every page shows
    cmpScope = "mine",    -- mine | all
    cmpWhere = "all",     -- all | faction | neutral
    cmpSort = "gap",
    dealSort = "profit",
    lootFilter = "all",
}

local function merge(dst, src)
    for k, v in pairs(src) do
        if dst[k] == nil then
            if type(v) == "table" then
                dst[k] = {}
                merge(dst[k], v)
            else
                dst[k] = v
            end
        elseif type(v) == "table" and type(dst[k]) == "table" then
            merge(dst[k], v)
        end
    end
end

-- ---------------------------------------------------------------------
-- Small helpers
-- ---------------------------------------------------------------------

function ns.Print(fmt, ...)
    local msg = select("#", ...) > 0 and string.format(fmt, ...) or fmt
    DEFAULT_CHAT_FRAME:AddMessage("|cffd9a441CraftMaster|r " .. tostring(msg))
end

function ns.Debug(...)
    if ns.db and ns.db.debug then ns.Print(...) end
end

-- 12g 34s 56c, colored like the game's coins. Rounded to silver above 10g.
function ns.Money(copper, plain)
    if type(copper) ~= "number" then return "-" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    local G, S, C = "|cffffd700g|r", "|cffc7c7cfs|r", "|cffeda55fc|r"
    if plain then G, S, C = "g", "s", "c" end
    local out
    if g > 0 then
        out = g .. G
        if g < 100 then out = out .. " " .. s .. S end
        if g < 10 and c > 0 then out = out .. " " .. c .. C end
    elseif s > 0 then
        out = s .. S
        if c > 0 then out = out .. " " .. c .. C end
    else
        out = c .. C
    end
    return (neg and "-" or "") .. out
end

-- "3 h", "2 d" — how long a number of seconds is, short.
function ns.Duration(sec)
    if type(sec) ~= "number" then return nil end
    if sec < 3600 then return math.max(1, math.floor(sec / 60)) .. " min" end
    if sec < 86400 * 2 then return math.floor(sec / 3600) .. " h" end
    return math.floor(sec / 86400) .. " " .. L.DAY_SHORT
end

function ns.Today() return math.floor(time() / 86400) end

-- My faction, in English whatever the game's language: "Horde" or "Alliance".
-- Forever has three Auction Houses: the Horde's (Horde characters only), the
-- Alliance's (Alliance characters only) and the shared one (Booty Bay,
-- Gadgetzan, Everlook) for both. Each keeps its own scans and history.
function ns.FactionKey()
    local f = UnitFactionGroup and UnitFactionGroup("player")
    return (f == "Alliance" or f == "Horde") and f or "Horde"
end
-- The server type (ruleset). Forever has one megaserver per ruleset (PvE,
-- PvP, RP, RP-PvP, Hardcore), each with its own three Auction Houses; the
-- realm name is only a shard and may change from one login to the next, so
-- data is kept by ruleset, never by realm. The game says which one through
-- its game rules; until it can, the last one known stands in.
local RULESETS = { PvE = true, PvP = true, RP = true, RPvP = true, Hardcore = true }
ns.RULESETS = RULESETS
local rulesetKept

function ns.RulesetFromGame()
    local rules = Enum and Enum.GameRule
    if not (C_GameRules and C_GameRules.IsGameRuleActive and type(rules) == "table") then return nil end
    if rules.PvPRuleset == nil or rules.RPRuleset == nil then return nil end
    local function on(rule)
        if rule == nil then return false end
        local ok, v = pcall(C_GameRules.IsGameRuleActive, rule)
        return ok and v == true
    end
    if on(rules.HardcoreRuleset) then return "Hardcore" end
    local pvp, rp = on(rules.PvPRuleset), on(rules.RPRuleset)
    if pvp and rp then return "RPvP" end
    if pvp then return "PvP" end
    if rp then return "RP" end
    return "PvE"
end

-- The game mode record of this ruleset (AuctionMaster keys its data by it).
function ns.GameModeID()
    if C_GameRules and C_GameRules.GetCurrentGameModeRecordID then
        local ok, id = pcall(C_GameRules.GetCurrentGameModeRecordID)
        if ok and type(id) == "number" and id ~= 0 then return id end
    end
end

-- "PvE" | "PvP" | "RP" | "RPvP" | "Hardcore"; the second answer is false
-- while it is only the last one known.
function ns.Ruleset()
    if rulesetKept then return rulesetKept, true end
    local rs = ns.RulesetFromGame()
    if rs then return rs, true end
    return (ns.char and ns.char.ruleset) or (ns.db and ns.db.lastRuleset) or "PvE", false
end

function ns.RulesetLabel(rs)
    rs = rs or ns.Ruleset()
    return L["RS_" .. rs] or rs
end

-- Where a house's data is kept: "<ruleset>-Neutral", "<ruleset>-Horde" or
-- "<ruleset>-Alliance".
function ns.HouseKey(house)
    local side = (house or ns.House()) == "neutral" and "Neutral" or ns.FactionKey()
    return (ns.Ruleset()) .. "-" .. side
end

-- The Auction House every page shows: always the faction's (Horde). The shared house is
-- only read by the comparison of the houses (Gold.lua / the Comparison tab), which names the
-- two houses itself; no page switches to it.
function ns.House() return "faction" end
function ns.FactionName()
    local _, loc = UnitFactionGroup and UnitFactionGroup("player")
    return loc or (UnitFactionGroup and UnitFactionGroup("player")) or "?"
end
function ns.HouseName(house)
    return (house or ns.House()) == "neutral" and ns.L.HOUSE_NEUTRAL or ns.FactionName()
end
function ns.CutPct(house)
    house = house or ns.House()
    if house == "neutral" then return ns.db.cutN or 15 end
    return ns.db.cut or 5
end

-- The Forever client follows Retail: several old globals are gone and live
-- under C_Item / C_MerchantFrame now. These pick whichever exists.
function ns.GetItemInfo(id)
    if C_Item and C_Item.GetItemInfo then return C_Item.GetItemInfo(id) end
    if GetItemInfo then return GetItemInfo(id) end
end
function ns.GetItemIcon(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    if GetItemIcon then return GetItemIcon(id) end
end
-- A merchant's slot: price, units per purchase, stock left (-1 = endless),
-- paid in something else than gold.
function ns.MerchantInfo(i)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local info = C_MerchantFrame.GetItemInfo(i)
        if type(info) ~= "table" then return nil end
        return info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
    end
    if GetMerchantItemInfo then
        local _, _, price, stack, avail, _, _, extended = GetMerchantItemInfo(i)
        return price, stack, avail, extended
    end
end

-- Item facts, asked once the game has them. GetItemInfo is lazy: the first
-- call starts the load and GET_ITEM_INFO_RECEIVED says when it's there.
local itemCache = {}
function ns.Item(id)
    if not id then return nil end
    local c = itemCache[id]
    if c then return c end
    local name, link, quality, ilvl, _, _, _, stack, equip, icon, sell, classID, _, bind = ns.GetItemInfo(id)
    if not name then
        if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
        local fileIcon = ns.GetItemIcon(id)
        return { name = nil, icon = fileIcon, quality = 1, stack = 1, sell = 0, loading = true }
    end
    c = { name = name, link = link, quality = quality or 1, stack = stack or 1, icon = icon, sell = sell or 0,
          ilvl = ilvl or 0, equip = equip, classID = classID, bind = bind }
    itemCache[id] = c
    return c
end

function ns.ItemName(id)
    local i = ns.Item(id)
    return (i and i.name) or ("#" .. tostring(id))
end

function ns.QualityColor(q)
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q or 1]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

function ns.SpellName(id)
    if C_Spell and C_Spell.GetSpellName then
        local ok, n = pcall(C_Spell.GetSpellName, id)
        if ok and n then return n end
    end
    if GetSpellInfo then
        local n = GetSpellInfo(id)
        if n then return n end
    end
    return nil
end

function ns.Count(id)
    if not id then return 0 end
    local n
    if C_Item and C_Item.GetItemCount then
        n = C_Item.GetItemCount(id, ns.db.bags, false, ns.db.bags)
    elseif GetItemCount then
        n = GetItemCount(id, ns.db.bags)
    end
    return tonumber(n) or 0
end

-- ---------------------------------------------------------------------
-- Professions of this character
-- ---------------------------------------------------------------------

ns.SKILLLINES = {
    [171] = "alchemy", [164] = "blacksmithing", [333] = "enchanting", [202] = "engineering",
    [165] = "leatherworking", [197] = "tailoring", [185] = "cooking", [129] = "firstaid", [186] = "mining",
}
ns.PROF_ORDER = { "alchemy", "blacksmithing", "enchanting", "engineering", "leatherworking", "tailoring",
                  "cooking", "firstaid", "mining" }
ns.PROF_ICONS = {
    alchemy = 136240, blacksmithing = 136241, enchanting = 136244, engineering = 136243,
    leatherworking = 133611, tailoring = 136249, cooking = 133971, firstaid = 135966, mining = 136248,
}
-- Names the classic skill list may give, in both languages.
local NAMES = {
    ["alchemy"] = "alchemy", ["alchimie"] = "alchemy", ["blacksmithing"] = "blacksmithing", ["forge"] = "blacksmithing",
    ["enchanting"] = "enchanting", ["enchantement"] = "enchanting", ["engineering"] = "engineering",
    ["ingénierie"] = "engineering", ["leatherworking"] = "leatherworking", ["travail du cuir"] = "leatherworking",
    ["tailoring"] = "tailoring", ["couture"] = "tailoring", ["cooking"] = "cooking", ["cuisine"] = "cooking",
    ["first aid"] = "firstaid", ["secourisme"] = "firstaid", ["premiers soins"] = "firstaid",
    ["mining"] = "mining", ["minage"] = "mining",
}

ns.profs = {} -- [key] = { rank, max }

function ns.ReadProfessions()
    local found = {}
    if GetProfessions and GetProfessionInfo then
        local list = { GetProfessions() }
        for i = 1, 6 do
            local idx = list[i]
            if idx then
                local ok, name, _, rank, max, _, _, skillLine = pcall(GetProfessionInfo, idx)
                local key = ok and (ns.SKILLLINES[skillLine] or NAMES[string.lower(name or "")])
                if key then found[key] = { rank = rank or 0, max = max or 0 } end
            end
        end
    end
    if next(found) == nil and GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, header, _, rank, _, _, max = GetSkillLineInfo(i)
            local key = name and not header and NAMES[string.lower(name)]
            if key then found[key] = { rank = rank or 0, max = max or 0 } end
        end
    end
    ns.profs = found
    return found
end

function ns.MyProfs()
    local out = {}
    for _, k in ipairs(ns.PROF_ORDER) do
        if ns.profs[k] then out[#out + 1] = k end
    end
    return out
end

-- ---------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------

local listeners = {}
function ns.On(event, fn)
    listeners[event] = listeners[event] or {}
    table.insert(listeners[event], fn)
end
function ns.Fire(event, ...)
    for _, fn in ipairs(listeners[event] or {}) do
        local ok, err = pcall(fn, ...)
        if not ok then ns.Debug("error in %s: %s", event, tostring(err)) end
    end
end

-- Like Fire, but the listeners are called one per frame (ns.Work): for an event
-- whose listeners are heavy (a scan has just finished: bargains, best times...),
-- all of them in one frame froze the game for 60 ms.
function ns.FireSpread(event, ...)
    local args, n = { ... }, select("#", ...)
    local list, i = listeners[event] or {}, 0
    ns.Work.Add(event, function()
        i = i + 1
        local fn = list[i]
        if not fn then return true end
        local ok, err = pcall(fn, unpack(args, 1, n))
        if not ok then ns.Debug("error in %s: %s", event, tostring(err)) end
        return false
    end)
end

local frame = CreateFrame("Frame")
ns.frame = frame
local handlers = {}
ns.handlers = handlers

function ns.Register(event, fn)
    if not handlers[event] then
        handlers[event] = {}
        pcall(frame.RegisterEvent, frame, event)
    end
    table.insert(handlers[event], fn)
end

frame:SetScript("OnEvent", function(_, event, ...)
    for _, fn in ipairs(handlers[event] or {}) do
        local ok, err = pcall(fn, ...)
        if not ok then ns.Debug("%s: %s", event, tostring(err)) end
    end
end)

ns.Register("ADDON_LOADED", function(name)
    if name ~= addonName then return end
    if type(CraftMasterDB) ~= "table" then CraftMasterDB = {} end
    if type(CraftMasterChar) ~= "table" then CraftMasterChar = {} end
    merge(CraftMasterDB, ACCOUNT_DEFAULTS)
    merge(CraftMasterChar, CHAR_DEFAULTS)
    ns.db, ns.char = CraftMasterDB, CraftMasterChar
    if ns.db.source == "mastercraft" then ns.db.source = "auto" end   -- 2.0: Mastercraft is no longer read
    -- 3.1: the market pages are on their own again; the old pages are back as they were
    if ns.char.sellAt == "sales" then ns.char.sellAt = "ah" end
    if not ns.db.v31 then
        if ns.db.dealGap and ns.db.dealGap ~= 30 and ns.db.dealThreshold == 0.70 then
            ns.db.dealThreshold = math.max(0.05, math.min(0.95, 1 - ns.db.dealGap / 100))
        end
        ns.db.v31 = true
    end
    -- 1.9: the faction house's data moves under the faction it came from
    -- (everything so far was scanned by Horde characters)
    if not ns.db.byFaction then
        local db = ns.db
        db.histBy = db.histBy or {}
        if type(db.hist) == "table" and next(db.hist) then db.histBy.Horde = db.hist end
        db.hist = nil
        for _, k in ipairs({ "mkt", "timing", "qavg" }) do
            if type(db[k]) == "table" and db[k].faction then
                db[k].Horde = db[k].faction
                db[k].faction = nil
            end
        end
        db.byFaction = true
    end
    ns.Fire("Loaded")
end)

-- Daily lists { day, price, day, price, ... }: the lowest price of a day wins.
function ns.MergeDays(into, from)
    if type(from) ~= "table" then return into end
    for i = 1, #from - 1, 2 do
        local d, p = from[i], from[i + 1]
        if type(d) == "number" and type(p) == "number" and p > 0 then
            local at = #into - 1
            while at >= 1 and into[at] > d do at = at - 2 end
            if at >= 1 and into[at] == d then
                if p < into[at + 1] then into[at + 1] = p end
            else
                table.insert(into, at + 2, d)
                table.insert(into, at + 3, p)
            end
        end
    end
    return into
end

-- 2.0: data kept by ruleset. What was kept before (by faction, the shared
-- house as "neutral", scans by realm name) belongs to the ruleset played
-- now: the first character to log in after the update takes it over.
local function toRuleset(rs)
    local db = ns.db
    local function side(k)
        if k == "neutral" or k == "Neutral" then return "Neutral" end
        if k == "Horde" or k == "Alliance" then return k end
    end
    for _, name in ipairs({ "mkt", "histBy" }) do
        local t = db[name]
        if type(t) == "table" then
            local old = {}
            for k, items in pairs(t) do if side(k) then old[k] = items end end
            for k, items in pairs(old) do
                local sd = side(k)
                if type(items) == "table" then
                    local nk = rs .. "-" .. sd
                    t[nk] = t[nk] or {}
                    for id, list in pairs(items) do
                        t[nk][id] = ns.MergeDays(t[nk][id] or {}, list)
                    end
                    t[k] = nil
                end
            end
        end
    end
    if type(db.histN) == "table" and next(db.histN) then
        db.histBy = db.histBy or {}
        local nk = rs .. "-Neutral"
        db.histBy[nk] = db.histBy[nk] or {}
        for id, list in pairs(db.histN) do db.histBy[nk][id] = ns.MergeDays(db.histBy[nk][id] or {}, list) end
    end
    db.histN, db.hist, db.seeded, db.mktSeeded = nil, nil, nil, nil
    for _, name in ipairs({ "timing", "qavg" }) do
        local t = db[name]
        if type(t) == "table" then
            local old = {}
            for k, v in pairs(t) do if side(k) then old[k] = v end end
            for k, v in pairs(old) do
                local sd = side(k)
                do
                    local nk = rs .. "-" .. sd
                    if t[nk] == nil then t[nk] = v end
                    t[k] = nil
                end
            end
        end
    end
    if type(db.scans) == "table" then
        local moved = {}
        for k, b in pairs(db.scans) do
            local sd = type(k) == "string" and k:match("%-(%a+)$")
            if sd and not RULESETS[k:match("^(%a+)%-") or ""] and (sd == "Horde" or sd == "Alliance" or sd == "Neutral") then
                local nk = rs .. "-" .. sd
                local cur = moved[nk] or db.scans[nk]
                if not cur or (b.at or 0) > (cur.at or 0) then moved[nk] = b end
                db.scans[k] = nil
            end
        end
        for k, b in pairs(moved) do db.scans[k] = b end
    end
    db.byRuleset = rs
    db.since2 = db.since2 or ns.Today()
end

local function settleRuleset()
    local rs = ns.RulesetFromGame()
    if not rs then return end
    local before = rulesetKept
    rulesetKept = rs
    ns.char.ruleset = rs
    ns.db.lastRuleset = rs
    local mode = ns.GameModeID()
    if mode then
        ns.db.modes = ns.db.modes or {}
        ns.db.modes[mode] = rs
    end
    if not ns.db.byRuleset then toRuleset(rs) end
    if before ~= rs then ns.Fire("RulesetChanged", rs) end
end
ns.Register("PLAYER_ENTERING_WORLD", settleRuleset)
ns.Register("GAME_RULES_CHANGED", function()
    rulesetKept = nil
    settleRuleset()
end)

ns.Register("PLAYER_LOGIN", function()
    ns.ReadProfessions()
    settleRuleset()
    ns.Fire("Login")
    ns.Print(L.LOADED, "|cffd9a441/craftmaster|r")
end)

ns.Register("SKILL_LINES_CHANGED", function()
    ns.ReadProfessions()
    ns.Fire("ProfessionsChanged")
end)

ns.Register("GET_ITEM_INFO_RECEIVED", function(id, ok)
    if ok and id then itemCache[id] = nil end
    if not ns.itemPending then
        ns.itemPending = true
        C_Timer.After(0.3, function()
            ns.itemPending = false
            ns.Fire("ItemsLoaded")
        end)
    end
end)

-- ---------------------------------------------------------------------
-- Slash command
-- ---------------------------------------------------------------------

SLASH_CRAFTMASTER1 = "/craftmaster"
SLASH_CRAFTMASTER2 = "/cmaster"
-- /gg: the short command of the market pages
SLASH_CRAFTMASTERGG1 = "/gg"

-- The commands of the market pages (thresholds, prices by hand, sharing...): true when handled.
local function goldCommands(raw)
    local word, rest = raw:match("^(%S*)%s*(.-)$")
    word = string.lower(word or "")
    local num = tonumber(((rest or ""):gsub(",", ".")))
    local db = ns.db
    if word == "seuil" then
        if not (num and num > 0 and num < 100) then return false end
        db.dealThreshold = num / 100
        ns.Print(L.CMD_THRESHOLD, num)
    elseif word == "profit" then
        if not (num and num >= 0) then return false end
        db.minProfit = math.floor(num * 10000)
        ns.Print(L.CMD_PROFIT, ns.Money(db.minProfit))
    elseif word == "prix" then
        local g, link = rest:match("^([%d%.,]+)%s+(.+)$")
        local id = link and tonumber(link:match("item:(%d+)"))
        g = g and tonumber((g:gsub(",", ".")))
        if not (id and g) then ns.Print(L.CMD_PRICE_USAGE) return true end
        ns.Gold.SetCustomPrice(id, g > 0 and g * 10000 or nil)
        ns.Print("%s : %s", link, g > 0 and ns.Money(g * 10000) or L.CMD_PRICE_REMOVED)
    elseif word == "auto" then
        db.autoScan = not db.autoScan
        ns.Print(db.autoScan and L.CMD_AUTO_ON or L.CMD_AUTO_OFF)
    elseif word == "rappel" then
        db.scanReminder = db.scanReminder == false
        ns.Print(db.scanReminder and L.CMD_REMIND_ON or L.CMD_REMIND_OFF)
    elseif word == "ventes" then
        local id = tonumber(rest:match("item:(%d+)") or "")
        if not id then ns.Print(L.CMD_SALES_USAGE) return true end
        local st = ns.Tracker.Stats(id)
        if not st or (st.n or 0) == 0 then ns.Print(L.CMD_SALES_NONE, rest) return true end
        ns.Print("%s : %s (%d/5)", rest, ns.Tracker.StarString(st.score), ns.Tracker.Stars(st.score))
        ns.Print(L.SALES_LINE, math.floor(st.n + 0.5), st.days, st.perDay)
        ns.Print(L.SALES_PRICES, ns.Money(st.p25), ns.Money(st.p50), ns.Money(st.p75))
    elseif word == "sync" then
        ns.Sync.RequestSync(true)
    elseif word == "partage" or word == "ami" then
        if rest == "" then return false end
        if not ns.Sync.AddFriend(rest) then ns.Sync.RemoveFriend(ns.Sync.Normalize(rest)); ns.Print(L.SHARE_FRIEND_REMOVED, ns.Sync.Normalize(rest)) end
    elseif word == "jours" then
        if not (num and num >= 1) then return false end
        db.minDays = math.floor(num)
        ns.Print(L.CMD_DAYS, db.minDays)
    elseif word == "decouvrir" or word == "découvrir" then
        ns.Recipes.ReadAllSchematics(true, true)
    elseif word == "affaires" then
        ns.UI.Open("gmdeals")
        return true
    elseif word == "crafts" then
        ns.UI.Open("gmcrafts")
        return true
    elseif word == "scan" and (rest == "force" or rest == "complet") then
        ns.Scan.Start("full")
    elseif word == "scan" and rest == "rapide" then
        ns.Scan.Start("quick")
    else
        return false
    end
    ns.Fire("DealsChanged")
    return true
end

SlashCmdList.CRAFTMASTER = function(msg)
    local cmd = string.lower(strtrim(msg or ""))
    if goldCommands(strtrim(msg or "")) then return end
    if cmd == "" then
        -- /gg alone opens the window
        ns.UI.Toggle()
    elseif cmd == "panier" then
        ns.UI.Open("cart")
    elseif cmd == "accueil" or cmd == "nouveautes" or cmd == "nouveautés" or cmd == "changelog" then
        ns.UI.Open("home")
    elseif cmd == "reglages" or cmd == "réglages" or cmd == "config" then
        ns.UI.Open("settings")
    elseif cmd == "minimap" then
        ns.db.minimap.hide = not ns.db.minimap.hide
        ns.Minimap.Refresh()
    elseif cmd == "scan" then
        ns.Recipes.ReadAllSchematics(true)
    elseif cmd == "import" or cmd == "importer" then
        ns.Import.Run(true)
    elseif cmd == "diag" then
        ns.Diag()
    elseif cmd == "debug" then
        ns.db.debug = not ns.db.debug
        ns.Print("debug %s", ns.db.debug and "on" or "off")
    else
        ns.Print(L.HELP)
    end
end

SlashCmdList.CRAFTMASTERGG = function(msg)
    msg = strtrim(msg or "")
    if msg == "" then
        if ns.UI.IsShown() and (ns.UI.Current() == "gmdeals" or ns.UI.Current() == "gmcrafts") then
            ns.UI.Toggle()
        else
            ns.UI.Open("gmdeals")
        end
        return
    end
    SlashCmdList.CRAFTMASTER(msg)
end

-- What the game gives on this client: the answers decide how CraftMaster
-- reads recipes and buys, and the player can paste them in a bug report.
function ns.Diag()
    local function has(t, f) return (t and t[f]) and "yes" or "no" end
    ns.Print("Interface %s", tostring(select(4, GetBuildInfo())))
    ns.Print("C_TradeSkillUI.GetRecipeSchematic: %s, GetAllRecipeIDs: %s",
        has(C_TradeSkillUI, "GetRecipeSchematic"), has(C_TradeSkillUI, "GetAllRecipeIDs"))
    ns.Print("C_AuctionHouse.StartCommoditiesPurchase: %s", has(C_AuctionHouse, "StartCommoditiesPurchase"))
    for _, line in ipairs(ns.Buy.Trace()) do ns.Print("Last purchase: %s", line) end
    local tls = ns.db.timeLeftScan
    ns.Print("C_AuctionHouse.GetReplicateItemTimeLeft: %s%s", has(C_AuctionHouse, "GetReplicateItemTimeLeft"),
        tls and string.format(" · last full scan: values %s-%s, scale %s", tostring(tls.min), tostring(tls.max),
            tls.shift == 1 and "0-3" or (tls.shift == 0 and "1-4" or "unknown")) or "")
    ns.Print("Professions: %s", table.concat(ns.MyProfs(), ", "))
    local house, how = ns.Scan.DetectHouse()
    local rs, sure = ns.Ruleset()
    ns.Print("Server type: %s (%s) · game mode %s · data key %s", rs, sure and "from the game" or "last known",
        tostring(ns.GameModeID() or "?"), ns.HouseKey("faction"))
    if type(CraftMasterData) == "table" and type(CraftMasterData.houses) == "table" then
        for key, h in pairs(CraftMasterData.houses) do
            local c = ns.db.blizz and ns.db.blizz.check and ns.db.blizz.check[key]
            ns.Print("Blizzard API: %s = house %s, data %s ago%s", key, tostring(h.id), ns.Duration(time() - (h.at or 0)),
                c and string.format(", %d%% like my scan (%d items)", math.floor(c.share * 100), c.n) or "")
        end
    else
        ns.Print("Blizzard API: no data (companion not installed or not run yet)")
    end
    for _, h in ipairs({ "faction", "neutral" }) do
        local b = ns.Scan.Book(h)
        local n = 0
        for _ in pairs(b.items or {}) do n = n + 1 end
        ns.Print("Prices kept for %s: %s, %d items, %s ago", ns.HouseKey(h),
            b.from == "blizzard" and "Blizzard" or (b.fromGuild and "guild" or "my scan"), n,
            b.at and ns.Duration(time() - b.at) or "never")
    end
    ns.Print("Faction: %s · Auction House here: %s (found by %s) · map %s · zone %s / %s", ns.FactionKey(), house, how,
        tostring(C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")),
        tostring(GetZoneText and GetZoneText()), tostring(GetSubZoneText and GetSubZoneText()))
    local list = {}
    for _, s in ipairs(ns.Prices.Sources()) do list[#list + 1] = s.name end
    ns.Print("Price sources: %s", #list > 0 and table.concat(list, ", ") or "none")
    local known, total, schem = 0, 0, 0
    for id, r in pairs(ns.RECIPES) do
        if ns.profs[r.p] then
            total = total + 1
            if ns.Recipes.IsKnown(id) then known = known + 1 end
            if ns.Recipes.Materials(id) then schem = schem + 1 end
        end
    end
    ns.Print("Recipes of my professions: %d, known %d, with materials %d", total, known, schem)
    -- One unlearned recipe of my professions: can the game give its materials?
    for id, r in pairs(ns.RECIPES) do
        if ns.profs[r.p] and not ns.Recipes.IsKnown(id) and C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic then
            local ok, s = pcall(C_TradeSkillUI.GetRecipeSchematic, id, false)
            ns.Print("Schematic of unlearned %d: %s", id,
                (ok and type(s) == "table" and s.reagentSlotSchematics and #s.reagentSlotSchematics > 0) and "yes" or "no")
            break
        end
    end
end
