local _, ns = ...
local L = ns.L
local W = ns.W

-- Loot advisor: for every item in the bags, what pays the most — a vendor,
-- the Auction House or disenchanting — or whether to keep it because one of
-- my professions or the cart uses it. Click one to see why.

local DETAIL_W = 320
local VERDICT = {
    vendor = { "LOOT_VENDOR", { 0.94, 0.62, 0.24 } },
    ah = { "LOOT_AH", { 0.38, 0.66, 0.96 } },
    de = { "LOOT_DE", { 0.69, 0.55, 0.95 } },
    keep = { "LOOT_KEEP", { 0.45, 0.85, 0.50 } },
}

local function bagItems()
    local out, byId = {}, {}
    if not (C_Container and C_Container.GetContainerNumSlots) then return out end
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID then
                local e = byId[info.itemID]
                if not e then
                    e = { id = info.itemID, count = 0, bound = info.isBound, link = info.hyperlink }
                    byId[info.itemID] = e
                    out[#out + 1] = e
                end
                e.count = e.count + (info.stackCount or 1)
                if info.isBound then e.bound = true end
            end
        end
    end
    return out
end

-- Worth of each way for one bag entry, and the verdict.
local function judge(e, cartNeeds)
    local i = ns.Item(e.id)
    local cut = 1 - ns.CutPct() / 100
    e.vendor = (i and i.sell and i.sell > 0) and i.sell * e.count or nil
    local ah = not e.bound and ns.Prices.AH(e.id)
    e.ah = ah and ah * e.count * cut or nil
    local de = ns.Disenchant.Can(e.id) and ns.Disenchant.Value(e.id)
    e.de = de and de * e.count or nil
    e.enchanter = ns.Disenchant.IsEnchanter()
    e.cart = cartNeeds[e.id]
    e.mine = ns.Recipes.UsedByMe(e.id)
    if e.cart or (e.mine and not ns.Disenchant.MATERIALS[e.id]) then
        e.verdict = "keep"
        e.value = math.max(e.vendor or 0, e.ah or 0)
        return e
    end
    local best, way = e.vendor or 0, "vendor"
    if e.ah and e.ah > best then best, way = e.ah, "ah" end
    if e.de and e.enchanter and e.de > best then best, way = e.de, "de" end
    e.verdict, e.value = way, best
    if best <= 0 then return nil end
    return e
end

ns.UI.AddPage("loot", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local items, selected = {}, nil

    local bar = CreateFrame("Frame", nil, body)
    bar:SetHeight(24)
    bar:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    bar:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local filter = W.Pick(bar, nil, { { "all", L.HIST_ALL }, { "vendor", L.LOOT_VENDOR }, { "ah", L.LOOT_AH },
        { "de", L.LOOT_DE }, { "keep", L.LOOT_KEEP } }, function() return ns.char.lootFilter or "all" end,
        function(v) ns.char.lootFilter = v; page.Refresh() end)
    filter.color = color
    filter:SetPoint("LEFT", bar, "LEFT", 0, 0)
    local total = W.Text(bar, "body", "RIGHT")
    total:SetPoint("RIGHT", bar, "RIGHT", -DETAIL_W - 14, 0)

    local listCard = W.Card(body)
    listCard:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -10)
    listCard:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -DETAIL_W - 12, 0)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.icon = W.ItemIcon(r, 22)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.gain = W.Text(r, "small", "RIGHT")
        r.gain:SetWidth(80)
        r.gain:SetPoint("RIGHT", r, "RIGHT", -6, 0)
        r.value = W.Text(r, "body", "RIGHT")
        r.value:SetWidth(90)
        r.value:SetPoint("RIGHT", r.gain, "LEFT", -6, 0)
        r.badge = CreateFrame("Frame", nil, r)
        r.badge:SetSize(110, 18)
        r.badge:SetPoint("RIGHT", r.value, "LEFT", -10, 0)
        r.badge.bg = r.badge:CreateTexture(nil, "BACKGROUND")
        r.badge.bg:SetAllPoints()
        r.badge.bg:SetTexture(ns.MEDIA .. "pilule.png")
        r.badge.text = W.Text(r.badge, "tiny", "CENTER")
        r.badge.text:SetPoint("CENTER")
        r.spark = ns.Chart.Spark(r, 56, 16)
        r.spark:SetPoint("RIGHT", r.badge, "LEFT", -10, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
        r.name:SetPoint("RIGHT", r.spark, "LEFT", -8, 0)
        r.name:SetWordWrap(false)
        r:SetScript("OnClick", function(self)
            selected = self.data.id
            page.RefreshDetail()
            page.list.Update()
        end)
        return r
    end
    local function fillRow(r, e)
        r.data = e
        r.sel:SetShown(selected == e.id)
        r.icon.Set(e.id)
        local i = ns.Item(e.id)
        r.name:SetText(ns.ItemName(e.id) .. (e.count > 1 and ("  |cff999999x" .. e.count .. "|r") or ""))
        r.name:SetTextColor(ns.QualityColor(i and i.quality or 1))
        r.spark.Set(ns.Chart.PriceSeries(e.id))
        local v = VERDICT[e.verdict]
        r.badge.text:SetText(string.upper(L[v[1]]))
        r.badge.text:SetTextColor(0.08, 0.08, 0.1)
        r.badge.bg:SetVertexColor(v[2][1], v[2][2], v[2][3], 1)
        r.value:SetText(ns.Money(e.value, true))
        local gain = e.value - (e.vendor or 0)
        if e.verdict ~= "vendor" and e.verdict ~= "keep" and gain > 0 then
            r.gain:SetText("+" .. ns.Money(gain, true))
            r.gain:SetTextColor(C.profit[1], C.profit[2], C.profit[3])
        else
            r.gain:SetText("")
        end
    end
    local list = W.List(listCard, 28, makeRow, fillRow)
    list:SetPoint("TOPLEFT", listCard, "TOPLEFT", 8, -8)
    list:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -6, 8)
    list.Color(color)
    page.list = list
    local empty = W.Text(listCard, "body", "CENTER")
    empty:SetPoint("TOPLEFT", list, "TOPLEFT", 20, -40)
    empty:SetPoint("TOPRIGHT", list, "TOPRIGHT", -20, -40)
    empty:SetWordWrap(true)
    empty:SetText(L.LOOT_EMPTY)
    empty:SetTextColor(C.label[1], C.label[2], C.label[3])

    local det = W.Card(body)
    det:SetPoint("TOPRIGHT", bar, "BOTTOMRIGHT", 0, -10)
    det:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    det:SetWidth(DETAIL_W)
    local dIcon = W.ItemIcon(det, 36)
    dIcon:SetPoint("TOPLEFT", det, "TOPLEFT", 14, -14)
    local dName = W.Text(det, "head", "LEFT")
    dName:SetPoint("TOPLEFT", dIcon, "TOPRIGHT", 10, -2)
    dName:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    local dVerdict = W.Text(det, "small", "LEFT")
    dVerdict:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -3)
    local flow = W.Flow(det)
    flow:SetPoint("TOPLEFT", dIcon, "BOTTOMLEFT", 0, -12)
    flow:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    local codex = W.Button(det, L.LOOT_CODEX, 160, function() if selected then ns.UI.ShowItem(selected) end end)
    codex:SetPoint("BOTTOMLEFT", det, "BOTTOMLEFT", 14, 12)
    codex.SetTint(ns.Theme.SECTIONS.codex)

    function page.RefreshDetail()
        flow.Clear()
        local e
        for _, x in ipairs(items) do if x.id == selected then e = x end end
        for _, part in ipairs({ dIcon, dName, dVerdict, flow, codex }) do part:SetShown(e ~= nil) end
        if not e then return end
        dIcon.Set(e.id)
        dName:SetText(ns.ItemName(e.id) .. (e.count > 1 and (" x" .. e.count) or ""))
        local i = ns.Item(e.id)
        dName:SetTextColor(ns.QualityColor(i and i.quality or 1))
        local v = VERDICT[e.verdict]
        dVerdict:SetText(L[v[1]])
        dVerdict:SetTextColor(v[2][1], v[2][2], v[2][3])
        flow.Head(L.LOOT_WHY, color)
        flow.Money(L.LOOT_VENDOR, e.vendor)
        if e.bound then flow.Line(L.LOOT_BOUND, { color = C.muted })
        else flow.Money(L.LOOT_AH .. string.format(" (-%d%%)", ns.CutPct()), e.ah) end
        if ns.Disenchant.Can(e.id) then
            flow.Money(L.LOOT_DE, e.de)
            local _, res = ns.Disenchant.Value(e.id)
            for _, x in ipairs(res or {}) do
                flow.Line(string.format("%d%%  %.1f× %s", math.floor(x[2] * 100 + 0.5), x[3], ns.ItemName(x[1])),
                    { color = C.muted, indent = 12, icon = ns.Item(x[1]) and ns.Item(x[1]).icon })
            end
            if not e.enchanter then flow.Line(L.LOOT_NOT_ENCHANTER, { color = C.muted }) end
            flow.Line(L.LOOT_DE_NOTE, { color = C.muted })
        end
        flow.Gap(4)
        if e.verdict == "keep" then
            flow.Line(e.cart and L.LOOT_KEEP_CART or L.LOOT_KEEP_MINE, { color = VERDICT.keep[2] })
        elseif e.verdict == "ah" then
            local _, age, qty = ns.Prices.AH(e.id)
            flow.Line(string.format(L.LOOT_AH_WHY, qty or 0, age and ns.Duration(age) or "?"), { color = VERDICT.ah[2] })
        elseif e.verdict == "de" then
            flow.Line(L.LOOT_DE_WHY, { color = VERDICT.de[2] })
        else
            flow.Line(L.LOOT_VENDOR_WHY, { color = VERDICT.vendor[2] })
        end
    end

    function page.Refresh()
        filter.Refresh()
        local needs = {}
        items = {}
        local want = ns.char.lootFilter or "all"
        local sum = 0
        for _, e in ipairs(bagItems()) do
            local j = judge(e, needs)
            if j then
                if j.verdict ~= "keep" then sum = sum + j.value end
                if want == "all" or want == j.verdict then items[#items + 1] = j end
            end
        end
        table.sort(items, function(a, b)
            if a.value ~= b.value then return a.value > b.value end
            return ns.ItemName(a.id) < ns.ItemName(b.id)
        end)
        list.SetData(items, true)
        page.items = items
        empty:SetShown(#items == 0)
        total:SetText(string.format(L.LOOT_TOTAL, ns.Money(sum)))
        page.RefreshDetail()
    end
end)
