local _, ns = ...
local L = ns.L
local W = ns.W

-- My operations: one line per operation made through CraftMaster (a good deal,
-- a lot in volume, the materials of a craft, an item for the other house, a
-- plan at a merchant): what it cost, what the mail brought back, success or
-- failure, one column each. A click on a line shows its detail in place of the
-- list, step by step (Ops.lua keeps them); "< Retour" goes back to the list.

local LOG_ROWS = 14
local HEX = ns.Theme.HEX
local MUTED = HEX.muted

ns.UI.AddPage("gmops", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local O = ns.Ops
    local data, selected = {}, nil

    -- the state of an operation in words and colour
    local function stateWords(op)
        local st = O.State(op)
        if st == "bid" then return L.OPS_ST_BID, C.sky end
        if st == "won" then return L.OPS_ST_WON, C.profit end
        if st == "lost" then return L.OPS_ST_LOST, C.loss end
        if O.Result(op) >= 0 and (op.sold or 0) > 0 then return L.OPS_ST_PAID, C.profit end
        return L.OPS_ST_OPEN, C.amber
    end
    local function houseName(h) return h == "neutral" and L.HOUSE_NEUTRAL or (h and ns.FactionName() or "-") end

    -- ---------------------------------------------------------- filter and figures
    local bar = CreateFrame("Frame", nil, body)
    bar:SetHeight(24)
    bar:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    bar:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local filter = W.Segments(bar, { { "open", L.OPS_F_OPEN }, { "done", L.OPS_F_DONE }, { "all", L.OPS_F_ALL } },
        function() return ns.char.opsFilter or "all" end, function(v) ns.char.opsFilter = v; selected = nil; page.Refresh() end, 110)
    filter.color = color
    filter:SetPoint("LEFT", bar, "LEFT", 0, 0)

    local tiles = W.Tiles(body, 4, 46)
    tiles:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -10)
    tiles:SetPoint("RIGHT", body, "RIGHT", 0, 0)

    -- ---------------------------------------------------------- the list
    local listCard = W.Card(body)
    listCard:SetPoint("TOPLEFT", tiles, "BOTTOMLEFT", 0, -10)
    listCard:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    -- the item on the left, then one column per figure
    -- (the type and the date are in the detail)
    local COLS = { { "qty", 60 }, { "sold", 56 }, { "cost", 84 }, { "price", 84 },
                   { "aim", 88 }, { "revenue", 84 }, { "result", 88 }, { "left", 96 }, { "state", 100 } }
    local header = CreateFrame("Frame", nil, listCard)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", listCard, "TOPLEFT", 10, -8)
    header:SetPoint("RIGHT", listCard, "RIGHT", -10, 0)
    -- the figures from the right; returns where the item part ends
    local function placeCols(row, texts)
        local x = -6
        for i = #COLS, 1, -1 do
            texts[i]:SetWidth(COLS[i][2])
            texts[i]:SetJustifyH("RIGHT")
            texts[i]:SetPoint("RIGHT", row, "RIGHT", x, 0)
            x = x - COLS[i][2] - 8
        end
        return x
    end
    local heads = {}
    for i, c in ipairs(COLS) do
        heads[i] = W.Text(header, "small", "RIGHT")
        heads[i]:SetText(L["OPS_COL_" .. string.upper(c[1])])
        heads[i]:SetTextColor(C.label[1], C.label[2], C.label[3])
    end
    local hx = placeCols(header, heads)
    local headItem = W.Text(header, "small", "LEFT")
    headItem:SetText(L.OPS_COL_ITEM)
    headItem:SetTextColor(C.label[1], C.label[2], C.label[3])
    headItem:SetPoint("LEFT", header, "LEFT", 4, 0)
    headItem:SetPoint("RIGHT", header, "RIGHT", hx, 0)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.t = {}
        for i = 1, #COLS do
            r.t[i] = W.Text(r, i == #COLS and "small" or "body", "RIGHT")
            r.t[i]:SetWordWrap(false)
        end
        local x = placeCols(r, r.t)
        r.icon = W.ItemIcon(r, 24)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
        r.name:SetPoint("RIGHT", r, "RIGHT", x, 0)
        r.name:SetWordWrap(false)
        r:SetScript("OnClick", function(self)
            selected = self.data and self.data.id
            page.Refresh()
        end)
        return r
    end
    local function fillRow(r, op)
        r.data = op
        r.sel:SetShown(selected == op.id)
        r.icon.Set(op.item, nil, op.link)
        r.name:SetText(ns.ItemName(op.item))
        local i = ns.Item(op.item)
        r.name:SetTextColor(ns.QualityColor(i and i.quality or 1))
        -- the units bought (an auction under way: one), then how many are sold
        r.t[1]:SetText("x" .. math.max(1, op.bought or 0))
        r.t[2]:SetText(tostring(op.sold or 0))
        r.t[3]:SetText(ns.Money((op.cost or 0) > 0 and op.cost or op.bid, true))
        -- the price per unit it is posted at (else aimed at, in grey), and the gain that makes
        local unit = O.SellUnit(op)
        r.t[4]:SetText(op.postUnit and ns.Money(op.postUnit, true) or (unit and (MUTED .. ns.Money(unit, true) .. "|r") or (MUTED .. "-|r")))
        local aimed = O.AimedGain(op)
        if aimed then W.ProfitText(r.t[5], aimed) else r.t[5]:SetText(MUTED .. "-|r") end
        r.t[6]:SetText((op.revenue or 0) > 0 and ns.Money(op.revenue, true) or (MUTED .. "-|r"))
        local res = O.Result(op)
        if O.State(op) == "bid" or ((op.revenue or 0) == 0 and O.State(op) == "open") then
            r.t[7]:SetText(MUTED .. "-|r")
        else
            W.ProfitText(r.t[7], res)
        end
        -- the time left on sale: green over 12 h, amber over 2 h, red under, grey once over
        local left = O.TimeLeft(op)
        if not left then
            r.t[8]:SetText(MUTED .. "-|r")
        elseif left <= 0 then
            r.t[8]:SetText(MUTED .. L.OPS_LEFT_OVER .. "|r")
        else
            local hx = left > 12 * 3600 and HEX.profit or (left > 2 * 3600 and HEX.amber or HEX.loss)
            r.t[8]:SetText(hx .. ns.Duration(left) .. "|r")
        end
        local words, col = stateWords(op)
        r.t[9]:SetText(words)
        r.t[9]:SetTextColor(col[1], col[2], col[3])
    end
    local list = W.List(listCard, 30, makeRow, fillRow)
    list:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -6)
    list:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -6, 8)
    list.Color(color)
    page.list = list
    local empty = W.Text(listCard, "body", "CENTER")
    empty:SetPoint("TOPLEFT", list, "TOPLEFT", 20, -30)
    empty:SetPoint("TOPRIGHT", list, "TOPRIGHT", -20, -30)
    empty:SetWordWrap(true)
    empty:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- ---------------------------------------------------------- the detail
    -- in place of the list, the line clicked
    local det = W.Card(body)
    det:SetPoint("TOPLEFT", listCard, "TOPLEFT", 0, 0)
    det:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", 0, 0)
    det:Hide()
    local back = W.Button(det, L.GM_BACK, 110, function() selected = nil; page.Refresh() end)
    back:SetPoint("TOPLEFT", det, "TOPLEFT", 12, -10)
    local TOP = -44   -- under the back button
    local dIcon = W.ItemIcon(det, 36)
    dIcon:SetPoint("TOPLEFT", det, "TOPLEFT", 12, TOP - 4)
    local dName = W.Text(det, "head", "LEFT")
    dName:SetPoint("TOPLEFT", dIcon, "TOPRIGHT", 10, -2)
    dName:SetPoint("RIGHT", det, "RIGHT", -12, 0)
    dName:SetWordWrap(false)
    local dSub = W.Text(det, "small", "LEFT")
    dSub:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -4)
    dSub:SetPoint("RIGHT", det, "RIGHT", -12, 0)
    dSub:SetWordWrap(false)
    -- the figures, one line each: label on the left, value on the right
    local figs = {}
    for k = 1, 6 do
        local l = W.Text(det, "small", "LEFT")
        l:SetPoint("TOPLEFT", det, "TOPLEFT", 14, TOP - 54 - (k - 1) * 20)
        l:SetTextColor(C.label[1], C.label[2], C.label[3])
        local v = W.Text(det, "body", "LEFT")
        v:SetPoint("TOPLEFT", det, "TOPLEFT", 240, TOP - 54 - (k - 1) * 20)
        figs[k] = { l, v }
    end
    local logTitle = W.Text(det, "head", "LEFT")
    logTitle:SetPoint("TOPLEFT", det, "TOPLEFT", 14, TOP - 184)
    logTitle:SetText(L.OPS_LOG)
    logTitle:SetTextColor(color[1], color[2], color[3])
    local logRows = {}
    for k = 1, LOG_ROWS do
        local d = W.Text(det, "small", "LEFT")
        d:SetPoint("TOPLEFT", det, "TOPLEFT", 14, TOP - 206 - (k - 1) * 18)
        d:SetTextColor(C.label[1], C.label[2], C.label[3])
        local t = W.Text(det, "small", "LEFT")
        t:SetPoint("TOPLEFT", det, "TOPLEFT", 110, TOP - 206 - (k - 1) * 18)
        t:SetPoint("RIGHT", det, "RIGHT", -12, 0)
        t:SetWordWrap(false)
        logRows[k] = { d, t }
    end
    local closeBtn = W.Button(det, "", 150, function()
        local op = selected and O.Find(selected)
        if op then O.SetClosed(op, not op.closed) end
    end)
    closeBtn:SetPoint("LEFT", back, "RIGHT", 12, 0)
    W.Tip(closeBtn, L.OPS_CLOSE, L.OPS_CLOSE_TIP)
    local delBtn = W.Button(det, L.OPS_DELETE, 120, function()
        local op = selected and O.Find(selected)
        if op then O.Delete(op); selected = nil end
    end)
    delBtn:SetPoint("LEFT", closeBtn, "RIGHT", 8, 0)
    W.Tip(delBtn, L.OPS_DELETE, L.OPS_DELETE_TIP)

    local LOG_WORDS = { buy = "OPS_LOG_BUY", bid = "OPS_LOG_BID", won = "OPS_LOG_WON", post = "OPS_LOG_POST",
                        sold = "OPS_LOG_SOLD", expired = "OPS_LOG_EXPIRED", closed = "OPS_LOG_CLOSED", reopened = "OPS_LOG_REOPENED" }
    function page.RefreshDetail()
        local op = selected and O.Find(selected)
        det:SetShown(op ~= nil)
        listCard:SetShown(op == nil)
        if not op then selected = nil return end
        dIcon.Set(op.item, nil, op.link)
        dName:SetText(ns.ItemName(op.item))
        local i = ns.Item(op.item)
        dName:SetTextColor(ns.QualityColor(i and i.quality or 1))
        local words, col = stateWords(op)
        local hexCol = string.format("|cff%02x%02x%02x", col[1] * 255, col[2] * 255, col[3] * 255)
        dSub:SetText(hexCol .. words .. "|r" .. MUTED .. "  ·  " .. (L.OPS_KIND[op.kind] or op.kind)
            .. "  ·  " .. date("%d/%m %H:%M", op.at) .. "|r")
        local res = O.Result(op)
        local lines = {
            { L.OPS_F_COST, ns.Money((op.cost or 0) > 0 and op.cost or op.bid, true) },
            { L.OPS_F_REVENUE, ns.Money(op.revenue or 0, true) },
            { L.OPS_F_RESULT, (res >= 0 and HEX.profit or HEX.loss) .. (res < 0 and "-" or "+") .. "|r" .. ns.Money(math.abs(res), true) },
            { L.OPS_F_SOLD, string.format(L.OPS_SOLD_OF, op.sold or 0, op.bought or 0, op.posted or 0) },
            { L.OPS_F_WHERE, string.format(L.OPS_WHERE, houseName(op.house), houseName(op.sellHouse or op.house)) },
            { L.OPS_F_AIM, op.aim and ns.Money(op.aim, true) or "-" },
        }
        if op.kind == "plan" then lines[5][2] = string.format(L.OPS_WHERE_PLAN, houseName(op.sellHouse)) end
        for k, f in ipairs(figs) do f[1]:SetText(lines[k][1]); f[2]:SetText(lines[k][2]) end
        local log = op.log or {}
        for k, r in ipairs(logRows) do
            local e = log[#log - k + 1]   -- newest first
            if e then
                r[1]:SetText(date("%d/%m %H:%M", e[1]))
                local what = L[LOG_WORDS[e[2]] or "OPS_LOG_BUY"]
                local txt = string.format(what, e[3] or 0, e[4] and ns.Money(e[4], true) or "-")
                if e[5] then txt = txt .. MUTED .. "  " .. ns.ItemName(e[5]) .. "|r" end
                r[2]:SetText(txt)
                r[1]:Show(); r[2]:Show()
            else
                r[1]:Hide(); r[2]:Hide()
            end
        end
        closeBtn.SetLabel(op.closed and L.OPS_REOPEN or L.OPS_CLOSE)
        -- settled by the mail (all sold, a success or a failure): nothing left to close
        -- nor to delete; closed by hand: it can be opened again
        local st = O.State(op)
        local settled = (st == "won" or st == "lost") and not op.closed
        closeBtn:SetShown(not settled)
        delBtn:SetShown(not settled and not op.closed)
    end

    function page.Refresh()
        O.Repair()
        filter.Refresh()
        local want = ns.char.opsFilter or "all"
        data = {}
        local done, profit, won, open, invested = 0, 0, 0, 0, 0
        local all = O.List()
        for k = #all, 1, -1 do   -- newest first
            local op = all[k]
            local st = O.State(op)
            local settled = st == "won" or st == "lost"
            if settled then
                done = done + 1
                profit = profit + O.Result(op)
                if st == "won" then won = won + 1 end
            else
                open = open + 1
                invested = invested + math.max(0, (op.cost or 0) - (op.revenue or 0))
            end
            if want == "all" or (want == "done") == settled then data[#data + 1] = op end
        end
        tiles.Set(1, L.OPS_T_PROFIT, (profit >= 0 and "+" or "-") .. ns.Money(math.abs(profit), true), profit >= 0 and C.profit or C.loss)
        tiles.Set(2, L.OPS_T_RATE, done > 0 and string.format("%d %%", math.floor(won / done * 100 + 0.5)) or "-", C.gold)
        tiles.Set(3, L.OPS_T_OPEN, tostring(open), C.amber)
        tiles.Set(4, L.OPS_T_INVESTED, ns.Money(invested, true), C.sky)
        list.SetData(data, true)
        empty:SetShown(#data == 0)
        empty:SetText(#all == 0 and L.OPS_EMPTY or L.OPS_EMPTY_FILTER)
        page.RefreshDetail()
    end
    ns.On("OpsChanged", function() if page.frame and page.frame:IsShown() then page.Refresh() end end)
    local ticker
    page.frame:HookScript("OnShow", function()
        if not ticker and C_Timer and C_Timer.NewTicker then
            ticker = C_Timer.NewTicker(60, function() if list:IsShown() then list.SetData(data, true) end end)
        end
    end)
    page.frame:HookScript("OnHide", function() if ticker then ticker:Cancel(); ticker = nil end end)
end)
