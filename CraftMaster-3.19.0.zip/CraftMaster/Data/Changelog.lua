-- Genere par build/gen_changelog.py depuis CHANGELOG.md : ne pas modifier a la main.
local _, ns = ...

ns.CHANGELOG = {
    { v = "3.19.0", date = "2026-11-27", summary = "Le panier revient dans les métiers, les niveaux des recettes en barre colorée, et la mise à jour se pilote depuis le menu.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aLe panier est de retour|r (groupe Métiers, à côté de Recettes et Voie du maître) : c'est ta liste de courses. Il sert quand il faut acheter : tu y mets des recettes avec le bouton |cfff2b53a+|r (Recettes, Voie du maître, ou « Ajouter au panier » dans la fiche), il en tire les composants à acheter, moins ce que tu as déjà. Chaque ligne dit |cfff2b53aoù|r : |cfff2b53aChez le vendeur|r (avec le nom du vendeur le plus proche et sa zone) ou |cfff2b53aÀ l'hôtel des ventes|r (avec son bouton d'achat). Pour les vendeurs : un |cfff2b53amarqueur sur la carte|r par composant (le vendeur le plus proche), et un bouton |cfff2b53aMarqueurs des vendeurs|r qui pose un arrêt par vendeur à visiter. Un badge sur l'onglet donne le nombre de recettes dans le panier. Le panier n'est pas dans « Faire du pognon » : il est réservé aux métiers.",
            "|cfff2b53aNiveaux des recettes en barre|r (page Recettes) : chaque recette montre sa barre orange, jaune, verte, grise (chaque couleur garde sa vraie part de points) avec un trait blanc à ton niveau ; elle est atténuée tant que tu ne peux pas l'apprendre. L'info-bulle donne les paliers exacts.",
            "|cfff2b53aVersion dans le menu|r : en bas du menu, la version dit si c'est la dernière, ou que la nouvelle est disponible ; un bouton |cfff2b53aMettre à jour|r (puis |cfff2b53aRecharger|r quand elle est installée) et un bouton |cfff2b53aForcer|r qui réinstalle la dernière version même si tu l'as déjà, puis recharge l'interface.",
        } },
        { title = "Modifications", items = {
            "Le groupe « Faire de l'or » devient |cfff2b53aFaire du pognon|r.",
            "Boutons des métiers en icônes (Recettes et Voie du maître) : l'icône et le niveau suffisent, le nom est dans l'info-bulle.",
            "Le compagnon accepte |cff9ad1ff-Force|r pour réinstaller la dernière version (jamais une plus ancienne).",
            "Décision du propriétaire : le panier avait été retiré en 3.11.0 ; il revient, réservé aux métiers.",
        } },
    } },
    { v = "3.18.0", date = "2026-11-27", summary = "La montée de métier a son nom : « Voie du maître », avec trois parcours revus et des prix de l'HV vérifiés.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aNouveau nom|r : l'onglet « Guide de montée » devient |cfff2b53aVoie du maître|r (les rangs d'un métier vont d'apprenti à maître).",
            "|cfff2b53aLe plus rapide : un point à chaque craft, ou presque|r : seules les recettes qui donnent un point au moins |cfff2b53a70 %|r du temps sont retenues (orange d'abord, puis la plus sûre), la moins chère à égalité, apprentissage compris. Si aucune n'atteint 70 % à un niveau, la plus sûre est prise et l'étape le signale en rouge. La fiche d'une étape donne la chance de point au début et à la fin de l'étape.",
            "|cfff2b53aLe moins cher : pour quand il n'y a pas d'or pour les composants|r : ce qui coûte le moins entre le prix d'achat des composants et la revente au vendeur (l'argent revient tout de suite), la plus petite mise de départ à égalité. Le plan indique la |cfff2b53amise de départ la plus forte|r d'une étape.",
            "|cfff2b53aLe plus rentable|r : inchangé dans l'esprit (le plus d'or à la revente, HV après taxe ou vendeur), mais sur des prix vérifiés.",
            "|cfff2b53aPrix de l'HV vérifiés|r : un prix de revente très au-dessus du prix habituel (marché mince, annonce isolée) est remplacé par le prix habituel ; un objet sans annonce mais avec un prix habituel est chiffré à ce prix ; les recettes sans prix sont écartées et comptées ; l'âge du scan est affiché (en rouge s'il a plus de 24 h ou n'existe pas).",
        } },
    } },
    { v = "3.17.1", date = "2026-11-27", summary = "Le gain des crafts s'affiche aussi dans la fenêtre de métier de Daylight UI.", sections = {
        { title = "Corrections", items = {
            "|cfff2b53aGain des crafts avec Daylight UI|r : Daylight UI remplace la fenêtre de métier du jeu par la sienne, donc le gain de la 3.17.0 n'y apparaissait pas. Il s'affiche maintenant sur chaque ligne de recette de la fenêtre de Daylight UI, sur la ligne du nom, à gauche du nombre de crafts, avec la même info-bulle. L'accroche passe par l'interface officielle de Daylight UI pour les extensions (rien n'est modifié dans ses cadres) ; la fenêtre du jeu reste prise en charge quand Daylight UI n'est pas utilisé.",
        } },
    } },
    { v = "3.17.0", date = "2026-11-27", summary = "Ce que rapporte chaque craft, directement dans ta fenêtre de métier.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aGain de chaque recette dans la fenêtre de métier|r : à droite de chaque recette de la liste, le montant gagné entre le prix des composants et la meilleure revente, en vert (gain) ou en rouge (perte), avec la source du meilleur prix à côté : |cfff2b53aHV|r (après la taxe de l'HV) ou |cfff2b53aPNJ|r (revente au vendeur). Les composants sont comptés chez le vendeur d'abord, sinon à l'HV. Un « ~ » après la source signale un prix de revente seulement estimé.",
            "|cfff2b53aInfo-bulle du calcul|r : en passant la souris sur le montant : chaque composant avec son prix et sa source, le coût total, la revente à l'HV et chez le vendeur (la meilleure est marquée) et le gain.",
            "|cfff2b53aRéglage|r : Configuration, « Gain des crafts dans la fenêtre de métier » (activé par défaut). Rien n'est ajouté aux cadres du jeu : les chiffres sont sur des cadres à nous, accrochés aux lignes de la fenêtre, et ne sont recalculés que fenêtre ouverte.",
        } },
    } },
    { v = "3.16.3", date = "2026-11-27", summary = "Mes opérations : le prix de vente et le gain visé, et l'objet exact dans l'info-bulle.", sections = {
        { title = "Nouveautés", items = {
            "Mes opérations : le type et la date passent dans le détail de l'opération, pour laisser la place au nom de l'objet.",
            "Mes opérations : deux colonnes, |cfff2b53aPrix de vente|r (le prix à l'unité de ta mise en vente ; en gris, le prix visé quand ce n'est pas encore en vente) et |cfff2b53aGain visé|r (toutes les unités vendues à ce prix, commission de l'HV déduite, moins le coût).",
        } },
        { title = "Corrections", items = {
            "Mes opérations : l'info-bulle d'un objet acheté montre l'objet exact de l'annonce, avec son suffixe et ses caractéristiques (« Anneau d'opale de l'aigle » : Intelligence, Endurance...), au lieu de l'objet de base qui semblait sans statistiques. Vaut pour les achats faits à partir de cette version ; un Maj-clic sur l'icône met aussi le bon lien dans le chat.",
        } },
    } },
    { v = "3.16.2", date = "2026-11-27", summary = "Mes opérations : un vrai tableau, une colonne par information.", sections = {
        { title = "Modifications", items = {
            "Mes opérations : une colonne par information (Type, Date, Quantité, Vendus, Coût, Reçu, Résultat, État), plus rien en gris sous le nom. Le détail d'une opération s'ouvre au clic sur sa ligne, à la place du tableau, avec un bouton « < Retour ».",
            "Mes opérations : une colonne |cfff2b53aTemps restant|r dit combien de temps tes annonces mises en vente avec CraftMaster restent à l'HV : en vert au-delà de 12 h, en orange de 2 à 12 h, en rouge sous 2 h.",
        } },
        { title = "Corrections", items = {
            "Achats en volume : l'alerte « tu n'es pas à la bonne HV » dit d'aller à l'HV Horde (le sélecteur d'HV de l'en-tête n'existe plus depuis la 3.16.0).",
            "Mes opérations : un courrier de vente relu après avoir pris son or comptait une seconde vente à 0 (« 2 sur 1 vendus »). Il n'est plus compté deux fois, et les opérations touchées sont corrigées toutes seules.",
            "Mes opérations : une opération réglée par le courrier (succès ou échec) ne propose plus Clore ni Supprimer ; une opération close à la main garde Rouvrir.",
            "Un objet acheté à l'HV comptait toutes les annonces identiques de sa ligne (4 patrons pareils : 4 achetés) alors qu'un seul était acheté. Il compte maintenant un objet, et les opérations déjà enregistrées sont corrigées toutes seules.",
        } },
    } },
    { v = "3.16.1", date = "2026-11-27", summary = "Le compteur de membres avec CraftMaster ne dit plus zéro quand ton co-dev est connecté, et l'icône de la minimap est bien centrée.", sections = {
        { title = "Corrections", items = {
            "|cfff2b53a« 0 membre(s) avec CraftMaster vus »|r : un membre n'était compté que s'il t'envoyait des données. Quelqu'un de connecté qui n'avait rien de nouveau à partager ne répondait donc rien et restait invisible. Maintenant chaque « bonjour » reçoit une courte réponse « je suis là » (quelques octets, une fois par minute au plus par joueur), même sans données, et l'addon redit bonjour toutes les 15 minutes : les membres qui se connectent plus tard sont comptés. Les membres vus le sont pendant deux heures au lieu d'une. |cfff2b53aLes deux joueurs doivent avoir la 3.16.1|r pour se voir.",
            "|cfff2b53aIcône de la minimap|r : l'icône est maintenant centrée sur son bouton (elle restait en bas à droite de sa case dans le tiroir de Daylight UI) et ses éléments portent les noms standard des boutons de minimap (icon, background, border), que les tiroirs utilisent pour masquer l'anneau et recadrer l'icône.",
        } },
    } },
    { v = "3.16.0", date = "2026-11-27", summary = "L'addon et les prix se mettent à jour tout seuls : on installe une fois, et c'est autonome.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aMise à jour automatique de l'addon|r : à chaque passage du compagnon (au démarrage du PC, au réveil, toutes les heures), il compare la version installée à la dernière publiée et installe la nouvelle tout seul. Rien n'est installé si l'empreinte du zip ne correspond pas ; seuls des fichiers d'addon sont acceptés (jamais de script ni d'exécutable) ; l'ancienne version est gardée et remise en place si l'installation échoue. Les scripts du compagnon ne sont jamais mis à jour automatiquement.",
            "|cfff2b53aVersion de l'addon en jeu|r (page Données) : la version chargée, la dernière publiée, et si c'est la dernière. Quand une nouvelle version existe : un bouton |cfff2b53aMettre à jour|r (il demande au compagnon, l'interface se recharge une fois), puis un bouton |cfff2b53aRecharger|r pour l'activer. La page Accueil le signale aussi.",
            "|cfff2b53aVersion de l'addon dans l'icône du compagnon|r : un clic droit sur la pièce montre la version, si c'est la dernière, et propose |cfff2b53aMettre à jour l'addon|r quand une nouvelle version existe. Une bulle prévient quand elle est installée.",
            "|cfff2b53aInstallation une seule fois, partout|r : le zip d'installation se décompresse n'importe où ; Installer.cmd cherche tout seul le dossier AddOns de WoW Forever (emplacement habituel, registre, disques). S'il ne le trouve pas, une fenêtre permet de le choisir (le dossier où est installé WoW Forever, jusqu'à son dossier AddOns). Il y copie l'addon et le compagnon, et règle les téléchargements automatiques.",
            "|cfff2b53aOutils pour publier|r : |cff9ad1ffbuild/make_release.py|r fabrique le zip de mise à jour, le fichier |cff9ad1fflatest.json|r et le zip d'installation ; |cff9ad1ffbuild/publish_release.py|r les publie sur la branche |cff9ad1ffrelease|r du dépôt des prix.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aLes prix Horde priment partout|r : toutes les pages affichent l'HV Horde ; le sélecteur d'HV de l'en-tête disparaît, et l'info-bulle des objets ne montre plus que le prix Horde. L'HV commune n'est lue que par l'onglet Comparaison, où les deux onglets rapides se lisent mieux : « Acheter à l'HV Horde, revendre à l'HV Commune (N) » et l'inverse, chacun classé par profit (les objets les moins chers à acheter, remontés en tête).",
            "|cfff2b53aPlus d'HV Alliance|r : le dépôt des prix ne collecte et ne publie que la Horde et la commune (Data.lua plus léger).",
            "Les tâches du compagnon n'utilisent plus |cff9ad1ff-ExecutionPolicy Bypass|r (seul l'installateur, une fois, en a besoin) : moins de ressemblance avec ce que les antivirus surveillent.",
            "Compagnon en version 4 : relancer Installer.cmd après la mise à jour.",
        } },
        { title = "Important", items = {
            "Après cette version, relance |cff9ad1ffInstaller.cmd|r (choix 1, région eu) pour installer la nouvelle icône et le contrôle des mises à jour.",
        } },
    } },
    { v = "3.15.2", date = "2026-11-27", summary = "Achats en volume : les prix relus à l'HV avant d'acheter, plus de mauvaise surprise à la confirmation.", sections = {
        { title = "Corrections", items = {
            "Achats en volume : quand l'HV est ouvert, la fiche relit les vraies annonces de l'objet (tes propres annonces mises à part) et calcule le plan dessus. Le scan complet pouvait encore compter des annonces bon marché déjà parties, d'où un prix réel toujours plus cher à la confirmation. Sous le tableau des plans, une ligne dit d'où viennent les prix.",
            "Les cartes des Achats en volume suivent aussi les annonces relues : l'HV ouverte, les lots affichés sont relus un par un et leur carte se met à jour (ou disparaît si le lot ne rapporte plus assez). La carte et sa fiche disent la même chose.",
            "Un scan en cours ne bloque plus la mise en vente, ni l'achat d'une marchandise vendue à l'unité (composants, viandes, étoffes...) : seul l'achat d'un objet à l'unité (une arme, une armure) attend la fin du scan.",
            "La fiche prévient quand l'HV ouverte n'est pas celle du plan (par exemple l'HV commune alors que le plan est calculé pour l'HV de ta faction).",
        } },
    } },
    { v = "3.15.1", date = "2026-11-27", summary = "Des tuiles où les chiffres ne se marchent plus dessus.", sections = {
        { title = "Corrections", items = {
            "Tuiles des fiches et des pages : la petite note (unités, places de sac, prix à l'unité) passe sur la ligne du titre et ne recouvre plus le chiffre.",
        } },
    } },
    { v = "3.15.0", date = "2026-11-27", summary = "Achats en volume : fini de risquer une fortune pour trois sous.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aRentabilité minimum des achats en volume|r (« Rentab. min (%) », 5 % par défaut) : un lot doit rapporter au moins ce pourcentage de ce qu'il coûte. Risquer 700 po pour en gagner 2 (0,3 %) est écarté, 30 po pour 2 (6,7 %) passe. Quand le gros lot ne rapporte pas assez, l'addon propose un lot plus petit qui y arrive ; les plans de la fiche (Prudent, Équilibré, Maximum, Risqué) suivent la même règle.",
            "|cfff2b53aLa mise sur chaque carte|r des Achats en volume : « + 2g 9s pour 30g », pour voir d'un coup d'œil ce qui demande un gros investissement et ce qui est accessible.",
            "|cfff2b53aLa taille de la mise se voit en couleur|r sur les cartes des Achats en volume : une bande et un cadre verts pour une petite mise (moins de 50 po), orange pour une mise moyenne (50 à 250 po), rouges pour une grosse (250 po ou plus).",
            "|cfff2b53aLes places de sac du plan|r : la tuile Achat dit combien de places de sac le lot demande (« 836 unités, 5 place(s) de sac »), et la fiche prévient quand tes sacs n'ont pas assez de place libre.",
            "|cfff2b53aLa fiche d'un achat en volume suit le plan choisi|r : le plan (Maximum, Risqué...) est écrit en haut, et les tuiles Achat, Revente visée et Profit changent quand tu cliques sur un autre plan.",
        } },
        { title = "Corrections", items = {
            "Le bouton « Acheter » d'un plan en volume n'est plus grisé sans explication : la fiche dit ce qui bloque (un autre achat ou une mise en vente qui attend sa confirmation, un scan en cours) et le bouton Annuler libère l'achat en attente. Un prix affiché et jamais confirmé est abandonné tout seul au bout d'une minute et demie.",
            "Achats en volume : le gain et la mise ne dépassent plus du cadre des cartes (montants arrondis).",
            "|cfff2b53aMes opérations|r : le nom de l'objet ne chevauche plus la colonne Coût. Chaque ligne tient sur deux niveaux : l'objet en haut, et dessous son type, sa date et le compteur « 0 / 4 vendus » ; à droite, Coût, Reçu, Résultat et État. Le texte d'invite de la fiche reste dans son cadre.",
        } },
    } },
    { v = "3.14.0", date = "2026-11-27", summary = "Chaque achat suivi jusqu'à l'or reçu : tu sais enfin ce qui rapporte vraiment.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aOnglet Mes opérations|r (groupe Faire de l'or, sous Plans à revendre) : une ligne par opération faite avec CraftMaster, avec la date, le type (Bonne affaire, Entre HV, Volume, Craft, Plan), l'objet, le coût, ce que tu as reçu au courrier, le résultat et l'état (En cours, Déjà rentable, Succès, Échec, Enchère en cours).",
            "|cfff2b53aSuivi automatique|r : un achat depuis Bonnes affaires, Comparaison des HV, Achats en volume (le lot, même acheté en plusieurs fois) ou la fiche d'un craft (tous ses composants réunis) crée l'opération, tout comme un plan acheté chez un marchand. Chaque mise en vente est ajoutée, puis la |cfff2b53aboîte aux lettres|r fait le reste : chaque vente reçue ajoute son or (déjà net de la taxe), chaque objet revenu invendu est noté, une enchère gagnée devient un achat. Un courrier n'est compté qu'une fois, même si tu ouvres la boîte plusieurs fois.",
            "|cfff2b53aCompteur des lots en volume|r : « 12 / 40 vendus », et dans la fiche combien sont encore en vente.",
            "|cfff2b53aLa fiche d'une opération|r (clic sur une ligne) : coût, reçu, résultat, vendus, HV d'achat et de revente, revente visée, et toutes les étapes datées. Boutons pour la clore telle quelle (le reste gardé ou utilisé) ou la supprimer.",
            "En haut : profit réalisé, taux de réussite, opérations en cours et or encore investi. Filtres En cours, Terminées, Toutes.",
        } },
        { title = "Important", items = {
            "|cfff2b53aDe nouveaux fichiers|r : quitte complètement le jeu puis relance-le.",
            "Seuls les achats faits à partir de cette version sont suivis. Les ventes sont lues quand tu ouvres ta boîte aux lettres.",
        } },
    } },
    { v = "3.13.0", date = "2026-11-27", summary = "Les plans des marchands reviennent, dans leur propre onglet : achète au marchand, revends à l'HV qui paie le mieux.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aOnglet Plans à revendre|r (groupe Faire de l'or, sous Comparaison des HV) : les plans qu'un marchand de ta faction vend moins cher que l'HV ne les paie. Pour chacun, l'addon compare la revente à l'HV de ta faction et à la commune et garde la meilleure. Même calcul que les autres onglets : prix du marchand, prix de revente (ventes vues, sinon prix habituel), taxe de l'HV déduite, étoiles, mêmes filtres (profit min, achat max, prix max) et même Top (4 étoiles, au moins une vente par jour). Une ligne par métier.",
            "|cfff2b53a« Pourquoi cette note » dit de quelle HV parlent les ventes et les prix|r : « vendu 44 po à 49 po à l'HV Horde », dans tous les onglets (l'HV de revente pour la Comparaison et les Plans). Le bloc « Ce qui s'est passé » aussi : « Ce qui s'est passé à l'HV Horde ».",
            "|cfff2b53aLes plans difficiles à obtenir sont signalés|r par un |cff9ad1ff[!]|r sur leur carte, avec le détail dans la bulle et la fiche : |cfff2b53astock limité|r chez le marchand (noté à chacune de tes visites : le jeu dit quand un objet n'est pas en vente sans fin), |cfff2b53aréputation|r à atteindre (faction et niveau, celle de ton camp) et |cfff2b53aévènement|r de l'année (Foire de Sombrelune, Fête lunaire, Voile d'hiver).",
            "|cfff2b53aLa fiche d'un plan|r dit chez quel marchand l'acheter et où (zone), avec un bouton « Voir le marchand sur la carte » qui ouvre la carte sur sa zone, un marqueur posé sur le plus proche. Une fois le plan dans tes sacs, « Mettre en vente » le poste à l'HV de revente.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aBons moments passe dans le groupe Configuration|r du menu, après Scans : il sert à choisir quand scanner, acheter et vendre. Faire de l'or garde Bonnes affaires, Crafts, Achats en volume et Comparaison des HV.",
        } },
    } },
    { v = "3.12.0", date = "2026-11-27", summary = "La comparaison des HV parle enfin pognon : acheter d'un côté, revendre de l'autre, avec la même note que les bonnes affaires.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aComparaison des HV refaite|r sur le modèle des Bonnes affaires : un tableau des |cfff2b53aTop écarts|r, avec un onglet par sens en haut (Horde vers Commune, Commune vers Horde) et le nombre d'écarts de chacun. Dans chaque onglet, une ligne par sorte d'objet : Plans, Équipements, Composants de craft, Consommables, puis le reste. Pour chaque objet : acheté au plus bas d'une HV, revendu dans l'autre, taxe de l'HV de revente déduite. Le prix de revente, les étoiles, les ventes et la concurrence sont ceux de l'HV où tu revends ; les mêmes filtres (profit min, achat max, prix max) et la même fiche (verdict, « Pourquoi cette note », courbe des deux HV, achat direct, enchère, mise en vente).",
            "|cfff2b53aUn chargeur au milieu de l'écran|r : tant qu'un scan ou un calcul tourne et qu'il n'y a encore rien à montrer, les onglets qui font de l'or (Bonnes affaires, Crafts, Achats en volume, Comparaison) affichent un anneau de points qui s'allument tour à tour, avec l'avancement du scan dessous.",
            "|cfff2b53aLa fiche te dit où aller|r : « Pour acheter : va à l'HV Commune », puis « Pour revendre : va à l'HV Horde ». L'achat n'est possible que devant l'HV d'achat, la mise en vente que devant l'autre.",
            "Il faut un scan de chaque HV à moins de 48 h d'écart ; sinon la page dit lequel manque.",
            "|cfff2b53aUne seule base de calcul|r pour les quatre onglets qui font de l'or (Bonnes affaires, Crafts, Achats en volume, Comparaison) : mêmes champs, même Top, même calcul étalé dans le temps.",
        } },
        { title = "Corrections", items = {
            "|cfff2b53aPlus d'à-coup à la première ouverture d'une HV|r : les ventes et annonces publiées par Blizzard sont lues à l'avance, par petits morceaux, après la connexion (avant : 30 à 80 ms d'un coup).",
            "Les onglets de marché ne plantent plus quand aucune vente n'est encore connue et qu'il n'y a pas de fichier de prix Blizzard.",
        } },
        { title = "Important", items = {
            "|cfff2b53aUn fichier de l'addon en moins|r : quitte complètement le jeu puis relance-le.",
        } },
    } },
    { v = "3.11.0", date = "2026-11-27", summary = "Un menu rangé par usage, et deux onglets de moins : on sait tout de suite où aller pour faire de l'or.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aMenu en quatre groupes|r, sous l'Accueil : |cfff2b53aFaire de l'or|r (Bonnes affaires, Crafts, Achats en volume, Bons moments, Comparaison des HV), |cfff2b53aMétiers|r (Recettes, Guide de montée), |cfff2b53aSacs et butin|r (Codex, Butin) et |cfff2b53aConfiguration|r (Scans, Données, Réglages). Chaque groupe a son petit titre.",
            "|cfff2b53aOnglets Panier et Historique retirés.|r Le panier disparaît avec eux : plus de bouton « + » ni « Ajouter au panier » dans Recettes et le Guide de montée, plus de tuile Panier à l'Accueil, et le clic droit sur l'icône de la minicarte ouvre les Bonnes affaires. Pour acheter les composants d'une recette, passe par sa fiche dans Crafts (« Acheter les composants manquants »). L'historique des prix reste enregistré : courbes des fiches, Comparaison des HV et Codex s'en servent toujours.",
        } },
        { title = "Corrections", items = {
            "|cfff2b53aAchat direct d'un objet vendu en plusieurs exemplaires|r : une annonce de 7 exemplaires à 19 po passait devant une annonce à 15 po (son prix était divisé par 7), et la confirmation demandait 19 po. L'addon prend maintenant l'annonce la moins chère comme l'HV les trie.",
        } },
        { title = "Important", items = {
            "|cfff2b53aDes fichiers de l'addon en moins|r : quitte complètement le jeu puis relance-le (un |cff9ad1ff/reload|r ne suffit pas).",
        } },
    } },
    { v = "3.10.2", date = "2026-11-27", summary = "Tes achats ne gonflent plus les ventes : la note reste honnête.", sections = {
        { title = "Corrections", items = {
            "|cfff2b53aTes achats ne comptent plus comme des ventes|r : une annonce que tu achètes disparaît de l'HV, et le scan suivant la prenait pour une vente du marché (plus de ventes par jour, plus d'étoiles). L'addon retient maintenant tes achats et les reconnaît : dans « Ce qui s'est passé » ils sont marqués « (ton achat : pas compté) », en gris, et ils sont retirés des ventes, de la note et du partage en guilde.",
            "|cfff2b53aAchats en volume après un scan rapide|r : la fiche d'un achat gardait les annonces du dernier scan complet (jusqu'à 6 h) même quand un scan plus récent montrait qu'elles étaient parties : le plan proposait d'acheter des unités déjà vendues. Maintenant, tout ce qui est moins cher que le prix le plus bas du dernier scan est retiré, et ce prix passe en tête. Les plans, le délai et les étoiles (concurrence) suivent.",
        } },
        { title = "Nouveautés", items = {
            "|cfff2b53a« (ta vente) »|r dans « Ce qui s'est passé » quand c'est une de tes annonces qui s'est vendue (elle compte : c'est un vrai acheteur).",
        } },
        { title = "Important", items = {
            "Seuls les achats faits à partir de cette version sont reconnus : ceux d'avant (comme la Dague d'hémorragie du 27/11) restent comptés comme des ventes jusqu'à ce qu'ils sortent de la fenêtre de 14 jours.",
        } },
    } },
    { v = "3.10.1", date = "2026-11-27", summary = "Acheter, passer au courrier, revendre : la boucle se ferme sans quitter la fiche.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aMettre en vente depuis la fiche d'une bonne affaire|r : une fois l'objet récupéré au courrier, un bouton le met en vente pour 24 h au prix de revente visé (un second clic si le jeu demande de confirmer). Un objet part une annonce par clic, un composant toutes les unités de tes sacs. Tant que ton achat est au courrier, la fiche te le rappelle. Une offre à revendre à un marchand n'a pas ce bouton.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aBonnes affaires sur un seul écran|r : le choix « Voir : Top offres / Légendaire / Épique / Rare / Inhabituel » disparaît. L'onglet montre directement les Top offres, rangées par rareté, avec les filtres profit min, achat max et prix max.",
            "|cfff2b53aBulle à côté de l'HV allégée|r : elle ne montre plus que l'HV et le scan (avancement, prochain scan, boutons). Les bonnes affaires restent à l'Accueil, dans l'onglet Bonnes affaires et dans le chat après un scan ; le panier dans son onglet.",
        } },
    } },
    { v = "3.10.0", date = "2026-11-27", summary = "Un seul onglet pour les bonnes affaires : N@@b'z s'efface devant Bonnes affaires.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aOnglet N@@b'z retiré|r : les bonnes affaires se trouvent dans l'onglet |cfff2b53aBonnes affaires|r (Top offres, rareté, achat direct ou enchère). Les types propres à N@@b'z disparaissent avec lui : plans de vendeur à revendre, désenchantement, écart entre les deux HV.",
            "|cfff2b53aLes résumés suivent Bonnes affaires|r : la bulle à côté de l'HV (« Bonnes affaires : 217 (Top 5)... Voir »), les tuiles « Meilleure affaire » et « Top offres » de l'Accueil, la ligne dans le chat après un scan, l'alerte d'affaire exceptionnelle (45 % sous le prix de revente) et le chiffre sur l'onglet Bonnes affaires. Un clic ouvre Bonnes affaires.",
            "|cfff2b53aPlus fluide en fin de scan|r : le calcul des bonnes affaires se fait par petits morceaux après le scan au lieu d'un bloc d'une vingtaine de millisecondes ; la bulle et l'Accueil affichent « calcul en cours » le temps qu'il finisse.",
        } },
        { title = "Important", items = {
            "|cfff2b53aUn fichier de l'addon en moins|r : quitte complètement le jeu puis relance-le (un |cff9ad1ff/reload|r ne suffit pas).",
        } },
    } },
    { v = "3.9.1", date = "2026-11-27", summary = "L'HV garde la main quand tu tapes dans sa recherche.", sections = {
        { title = "Corrections", items = {
            "|cfff2b53aCraftMaster derrière l'HV|r : un clic dans la barre de recherche (ou un autre bouton) de l'HV ne fait plus repasser CraftMaster devant quand sa fenêtre est cachée juste dessous. C'est l'élément réellement cliqué qui décide, plus la simple position de la souris.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aCraftMaster se range comme une fenêtre du jeu|r : un clic sur tes sacs, ta fiche de personnage ou une autre fenêtre posée sur CraftMaster la fait passer devant, HV ouvert ou non ; un clic sur CraftMaster le ramène devant. Le chat, les barres d'action et le reste de l'interface ne le renvoient jamais derrière.",
        } },
    } },
    { v = "3.9.0", date = "2026-11-27", summary = "Acheter sans quitter CraftMaster : une bonne affaire en deux clics, et tous les composants d'un craft à la chaîne.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aBonnes affaires : Achat direct ou Enchérir|r depuis la fiche d'une offre. Achat direct prend l'annonce la moins chère au prix d'achat immédiat ; Enchérir place l'enchère minimum sur l'annonce où elle est la plus basse (l'objet arrive au courrier si personne ne surenchérit). Un clic montre le vrai prix, un second confirme ; l'addon prévient si l'offre a renchéri depuis ton scan. Les objets vendus à l'unité n'ont que l'achat direct.",
            "|cfff2b53aCrafts : acheter les composants|r depuis la fiche d'une recette. Un bouton par composant achète ce qui manque, et « Acheter les composants manquants » les enchaîne un par un (deux clics chacun : le prix réel, puis la confirmation). Tes sacs et tes achats encore au courrier comptent : rien n'est acheté deux fois. Les composants du vendeur et ceux retirés du calcul sont laissés de côté.",
            "|cfff2b53aNombre de crafts|r dans la fiche d'une recette : les quantités, le coût, le profit et les achats suivent.",
        } },
        { title = "Corrections", items = {
            "|cfff2b53aAchat d'une arme ou d'une armure|r : l'objet est d'abord trouvé par son nom, comme dans la fenêtre de l'HV, puis acheté avec sa clé exacte (niveau d'objet compris). Avant : « Achat raté : unavailable » alors qu'il était en vente. Une réponse vide du jeu relance la recherche, les raisons d'un achat raté s'affichent en français et |cff9ad1ff/craftmaster diag|r montre les étapes du dernier achat.",
        } },
        { title = "Important", items = {
            "Le jeu exige un clic pour chaque achat : impossible de tout acheter en un seul clic, l'addon prépare chaque étape.",
        } },
    } },
    { v = "3.8.3", date = "2026-11-27", summary = "CraftMaster et l'HV se partagent l'écran comme deux fenêtres du jeu.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aDevant ou derrière l'HV|r : quand l'hôtel des ventes est ouvert, un clic sur sa fenêtre la fait passer devant CraftMaster, un clic sur CraftMaster le ramène devant. À la fermeture de l'HV, CraftMaster repasse au-dessus de tout, comme avant.",
        } },
    } },
    { v = "3.8.2", date = "2026-11-27", summary = "Bonnes affaires, Crafts et Achats en volume parlent enfin la même langue : mêmes chiffres, même Top, mêmes fiches. Et l'addon maigrit sans rien perdre.", sections = {
        { title = "Modifications", items = {
            "|cfff2b53aUne seule fiche pour les trois onglets|r : une offre, un craft et un achat en volume s'ouvrent sur la même fiche, avec quatre tuiles (achat, revente visée, profit en vert ou en rouge, confiance), le verdict et les mêmes vues. Les chiffres ne changent pas.",
            "|cfff2b53aUn seul Top|r : Top offres, Top crafts et Top achats suivent la même règle (prix de revente lu sur de vraies ventes, au moins 4 étoiles, assez de ventes par jour) et le même classement (profit × confiance).",
            "|cfff2b53aFiltres en listes déroulantes|r : la rareté des Bonnes affaires (« Voir : Top offres », « Voir : Rare »...), la note minimum (« Note : ») et la catégorie des composants retirés du calcul sont des listes déroulantes, comme partout ailleurs dans CraftMaster.",
            "|cfff2b53aAncien addon de marché oublié|r : CraftMaster ne relit plus ses données à la connexion et sa commande d'origine disparaît (|cff9ad1ff/gg|r et |cff9ad1ff/craftmaster|r restent). Le guide et le mode d'emploi n'en parlent plus.",
            "|cfff2b53aDonnées des recettes 28 % plus légères|r : les listes de formateurs, de vendeurs et de lieux répétées d'une recette à l'autre ne sont plus écrites qu'une fois (197 Ko au lieu de 274 Ko). Les recettes chargées en jeu sont exactement les mêmes.",
        } },
        { title = "Corrections", items = {
            "|cfff2b53aAchats en volume|r : la fiche d'un achat se met à jour après chaque clic. Avant, les boutons « Acheter » et « Mettre en vente » gardaient leur ancien texte (pas de « Confirmer » affiché après le premier clic).",
            "|cfff2b53aDélai de vente d'un craft qui produit plusieurs objets|r : il compte maintenant tout le lot fabriqué, plus seulement un objet.",
        } },
    } },
    { v = "3.8.1", date = "2026-11-27", summary = "Le compagnon des prix travaille en silence, et une petite pièce en bas à droite de Windows dit s'il va bien et te laisse le couper.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aIcône du compagnon dans la zone de notification|r (en bas à droite de Windows) : une pièce dorée quand les prix sont à jour, bleue pendant un téléchargement, grise en pause, orange quand les prix sont en retard, rouge si le dernier passage a échoué (avec une bulle d'alerte). Clic droit : synchroniser maintenant, mettre en pause ou reprendre, arrêter le téléchargement en cours, ouvrir le journal, fermer l'icône. Double-clic : synchroniser maintenant. Elle se lance à l'ouverture de session.",
            "|cfff2b53aPause|r : tant que le compagnon est en pause, la tâche horaire ne télécharge plus rien, même après un redémarrage du PC. |cff9ad1ffLancer.cmd|r et « Synchroniser maintenant » passent outre.",
        } },
        { title = "Corrections", items = {
            "|cfff2b53aPlus de fenêtre de console|r : la tâche planifiée « CraftMaster - prix Blizzard » lance le compagnon dans une console invisible. Avant, une fenêtre noire s'ouvrait un court instant, au premier plan, toutes les heures, à l'ouverture de session et au réveil du PC.",
        } },
        { title = "Important", items = {
            "|cffffa733[!]|r Relancer |cff9ad1ffCraftMaster_Data\\Companion\\Installer.cmd|r (choix 1) une fois pour mettre à jour la tâche planifiée et installer l'icône : sans ça, la fenêtre continue d'apparaître et l'icône n'est pas là.",
        } },
    } },
    { v = "3.8.0", date = "2026-11-26", summary = "Le bon moment pour acheter et vendre, lu sur les clichés Blizzard de chaque heure, et des courbes partout : plus aucune barre.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aProfil horaire Blizzard|r : le dépôt des prix publie maintenant, pour chaque heure et chaque jour de la semaine, l'écart du prix moyen du marché à son prix habituel (médiane des 14 derniers jours). La page « Meilleurs moments » le mêle à tes scans et à ceux de ta guilde : 24 clichés par jour au lieu d'un scan de temps en temps.",
            "|cfff2b53aLe vendeur d'abord pour les composants|r : un composant que les marchands vendent sans limite (fil, teintures, fioles, flux, sel, bois...) est chiffré à son prix chez le vendeur, jamais à celui de l'HV (fini le fil runique « valeur HV »). Toutes les pages de crafts suivent la même règle : prix fixé à la main, puis vendeur, puis HV. La liste des composants affiche « Vendeur » et « Toujours » (en stock). Quand tu visites un marchand, l'addon note son nom et sa position.",
            "|cfff2b53aPlans à revendre|r (page Bonnes affaires, onglet « Plans à revendre ») : tous les plans que les marchands vendent et que l'HV paie plus cher, que tu connaisses la recette ou non. Pour chacun : le vendeur (nom, zone, position, marqueur sur la carte), son prix, le prix à l'HV, les ventes par jour et le gain par plan, taxe de l'HV déduite. La fiche d'une recette affiche le même bloc « Plan à acheter », même quand tu la connais.",
            "|cfff2b53aBase des vendeurs complète|r : |cff9ad1ffbuild/make_vendors.py|r construit |cff9ad1ffData/Vendors.lua|r depuis la base publique cmangos classic-db : prix chez le vendeur de 394 composants et plans, et leurs marchands avec zone et position.",
            "|cfff2b53aMini-courbes dans les listes d'objets|r : chaque ligne des Bonnes affaires, de l'Historique, du Codex, de la Comparaison, du Butin et des Crafts montre la forme du prix des derniers jours (vert si ça monte, rouge si ça baisse), à côté du prix, de la remise et du profit.",
            "|cfff2b53aCrafts : filtres de niveau et d'origine|r (inspirés de la page Métiers de Metaforge) : par palier de métier (Apprenti 1-75, Compagnon, Expert, Maître) et par origine (apprise d'office, formateur, vendeur, butin, quête, réputation). La fiche d'une recette affiche aussi les paliers de gain de niveau en couleurs : orange, jaune, vert, gris.",
            "|cfff2b53aVendeurs : Questie en renfort, et la base se corrige toute seule|r : quand ma table de vendeurs ne connaît pas un objet, l'addon demande à Questie (adapté à Forever) qui le vend et où. Et chaque visite chez un marchand compare ses prix à ma base (issue de Classic) : tu es prévenu des écarts, et ton prix vu prime toujours.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aChaque graphique a la forme de son besoin|r : courbe pour ce qui évolue (prix au fil des jours, heures d'une journée), colonnes pour comparer des catégories (jours de la semaine, quantité en vente, couverture par jour). Les tiges parasites sous les courbes sont supprimées. Le test de design impose de passer par le composant de graphique, plus de dessin à la main dans une page.",
            "|cfff2b53aMeilleurs moments plus honnêtes|r : une heure ou un jour n'est désigné que si l'écart entre le meilleur et le pire créneau dépasse 1,5 point ; sinon la page dit « Pas de vrai écart » au lieu de proclamer un gagnant sorti du bruit. Titres des graphiques reformulés en questions.",
            "|cfff2b53aComparaison entre hôtels des ventes|r : elle exige que les deux scans datent de moins de 48 h l'un de l'autre, sinon l'écart affiché pouvait n'être qu'une photo périmée.",
        } },
    } },
    { v = "3.7.0", date = "2026-11-26", summary = "Un nouvel onglet pour rafler les composants en volume, des étoiles enfin justes, et des fiches d'offre et de craft qui disent pourquoi.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aOnglet Achats en volume|r (sous Crafts) : acheter en nombre les composants les moins chers (herbes, minerais, cuirs, étoffes, viandes, enchantement...) et les revendre un poil plus cher : le profit vient du nombre. Top achats, une catégorie par type de composant, les mêmes filtres et la même notation que Bonnes affaires et Crafts.",
            "|cfff2b53aDes plans au choix|r dans la fiche d'un achat : Prudent, Équilibré, Maximum et, quand ça vaut le coup, |cfff2b53aRisqué|r (racheter assez pour faire monter le prix). Pour chacun : quantité, prix maximum, coût, revente à l'unité, profit, rentabilité, délai et note. Clique sur un plan pour voir les annonces à acheter.",
            "|cfff2b53aFaire ce plan en quelques clics|r : un bouton achète tout le lot (un clic pour le prix, un pour confirmer), un autre le met en vente pour 24 h au prix du plan. L'addon prévient si le prix a bougé depuis ton scan, et rappelle de passer au courrier.",
            "|cfff2b53aFiches d'offre et de craft repensées|r : quatre tuiles (achat, revente visée, profit, confiance), une phrase qui résume la note, un petit tableau « Pourquoi cette note » (ventes, prix visé, concurrence, prix, avec la source de chaque chiffre), ce qui s'est passé récemment, et la courbe des prix à un clic.",
            "|cfff2b53aFiltrer les crafts par note|r, et voir |cfff2b53atoutes les recettes d'un métier|r, celles qui font perdre de l'argent comprises.",
            "|cfff2b53aFiltres actifs en or|r, et le bas de page dit combien de lignes chaque filtre cache.",
            "Le |cfff2b53ascan complet lit la durée restante|r des annonces : l'addon sait mieux si une annonce a été vendue ou si elle a juste expiré.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aLes étoiles tiennent compte du marché|r : la concurrence moins chère déjà en vente, et les annonces expirées au prix visé baissent la note. Une offre à 4 étoiles avec 10 annonces bien moins chères, c'est fini.",
            "Les étoiles restent justes sur les marchés très actifs (beaucoup de ventes et beaucoup d'expirées, c'est normal) : bien plus de Top crafts qu'au premier essai.",
            "Top offres, Top crafts et Top achats : toujours 4 étoiles au moins, et plus de filtre d'étoiles sur ces vues.",
            "Les ventes par jour se comptent sur la vraie durée de suivi (« 6 ventes en 24 h ») au lieu des jours du calendrier.",
            "Crafts : plus d'enchantement ni de secourisme. La fiche d'un craft perd la liste dans le chat, le nombre de crafts, le panier et les cases de recharge.",
            "Les options de scan quittent Bonnes affaires et Crafts : « Rappel de scan » est dans Réglages, à côté du scan automatique. « Paramètres des crafts » s'appelle « Filtrage avancé ».",
        } },
        { title = "Corrections", items = {
            "Les Top offres n'affichent plus d'affaires non vérifiées quand c'est ton profit min qui les vide : le Top reste vide et dit pourquoi.",
            "L'onglet Crafts ne reste plus vide à cause d'une recette importée d'un métier de récolte.",
            "Les noms des composants s'affichent dès qu'ils sont chargés, au lieu de rester sur leur numéro.",
        } },
        { title = "Important", items = {
            "|cfff2b53aQuitte complètement le jeu|r et relance-le : nouvel onglet, nouvelle icône et nouveau fichier. Un |cff9ad1ff/reload|r ne suffit pas.",
            "Achats en volume : fais un |cfff2b53ascan complet|r pour avoir toutes les annonces. Essaie d'abord « Faire ce plan » sur un petit lot.",
        } },
    } },
    { v = "3.6.0", date = "2026-11-26", summary = "Des chiffres qui sautent aux yeux, des courbes qui parlent, une alerte quand une affaire en or passe, des touches pour aller vite et des phrases qui piquent.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aTuiles de chiffres|r : en haut de l'Accueil (meilleure affaire du dernier scan, affaires en vue, âge des prix Blizzard, panier) et de la page Recettes (meilleur craft de la liste, combien rapportent, panier).",
            "|cfff2b53aCourbes de prix plus parlantes|r : chaque courbe a sa légende avec sa dernière valeur, le prix le plus haut et le plus bas sont écrits dessus, et une zone légère remplit le dessous de la courbe principale.",
            "|cfff2b53aPremiers pas guidés|r sur l'Accueil : « Faire du pognon en 3 étapes » (prix Blizzard chargés, un scan fait, les affaires regardées). Les étapes disparaissent toutes seules quand tout est fait, ou avec le bouton « Je connais, masquer ».",
            "|cfff2b53aAlerte d'affaire exceptionnelle|r : une petite notification à l'écran (clique dessus pour ouvrir les affaires) quand un scan trouve une affaire à 45 % sous son prix habituel ou plus et au moins au profit minimum. Les autres affaires restent une ligne dans le chat. Se coupe dans Réglages.",
            "|cfff2b53aTouches configurables|r : Échap > Raccourcis clavier > AddOns > CraftMaster : ouvrir ou fermer la fenêtre, et chercher (ouvre la fenêtre, curseur dans la recherche).",
            "Phrases d'accroche : « C'est les Tarides ici putain », « C'est pas retail ici », « Du pognon, encore du pognon », « Va pex au lieu de farmer l'HV, péon », « Bling bling, j'ai les bourses pleines » et « Serre les fesses, ça va bien se passer ».",
        } },
        { title = "Modifications", items = {
            "Les filtres et tris que tu règles étaient déjà gardés par personnage d'une session à l'autre : rien à changer.",
        } },
    } },
    { v = "3.5.0", date = "2026-11-26", summary = "Un coup de neuf sur l'interface : des courbes partout, des listes déroulantes, des titres nets, une icône de plus et du pognon dans le ton.", sections = {
        { title = "Nouveautés", items = {
            "|cfff2b53aCourbes partout|r : la page Bons moments et la couverture de la page Données passent des barres aux courbes (avec un trait léger vers la ligne zéro pour lire le signe d'un coup d'œil), comme les graphiques de prix.",
            "|cfff2b53aListes déroulantes|r pour les tris et filtres à plus de trois choix (Recettes, Historique, Comparaison des HV, N@@b'z, Butin) : « Tri : Profit », « Vente : HV »... Les petits choix à deux ou trois boutons restent des boutons.",
            "Sur l'Accueil, une ligne « pognon » : la meilleure affaire du dernier scan.",
            "Nouvelle icône pour la page Scans (un viseur : elle ressemblait trop à la loupe du Codex).",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aTitres et sous-titres|r : le titre et sa phrase d'explication ne sont plus répétés dans la page (Accueil, Données, Scans) ; toutes les phrases sont courtes, sur une ligne, et sans mots en double (page « Comparer les HV » devenue « Comparaison des HV », « Conseiller de butin » devenu « Butin »).",
            "|cfff2b53aLe ton|r : plus de blagues sur le pognon et les gobelins (12 phrases d'accroche au lieu de 5, des messages de panier vide, d'historique vide, de scan terminé... plus savoureux).",
            "|cfff2b53aOptimisations|r : le guetteur de la carte ne tourne plus que pendant un itinéraire (il tournait à chaque image de la session), et le calcul des affaires n'est plus fait deux fois de suite après un scan.",
        } },
    } },
    { v = "3.4.0", date = "2026-11-26", summary = "Un jeu plus fluide pendant les scans et à la connexion, le choix entre scan rapide et complet, et un partage de guilde bien plus léger. Aucune donnée supprimée.", sections = {
        { title = "Nouveautés", items = {
            "Page |cfff2b53aScans|r : ce que fait l'ouverture de l'HV (rien, scan rapide, scan complet ou automatique), deux boutons pour lancer un scan rapide ou complet à la main, ce que change chaque scan, ce que tu possèdes déjà (photo Blizzard, derniers scans) et une |cfff2b53arecommandation|r d'après ces données.",
            "Le panneau de l'HV a maintenant deux boutons : |cfff2b53aRapide|r et |cfff2b53aComplet|r.",
            "Mode |cfff2b53aAutomatique|r (recommandé) : photo Blizzard de moins de 70 min, aucun scan ; jusqu'à 3 h, scan rapide ; plus ancienne ou absente, scan complet. Par défaut, rien ne change : l'ouverture de l'HV lance un scan complet quand Blizzard l'autorise, sinon un rapide.",
        } },
        { title = "Modifications", items = {
            "|cfff2b53aFluidité|r : la lecture d'un scan complet, celle des prix Blizzard à la connexion et la fin de scan sont réparties sur plusieurs images (5 ms par image au plus). Mesuré sur 120 000 annonces : pire image 134 ms avant, 19 ms après ; connexion : 267 ms d'un coup avant, 5 ms par image après, et plus rien du tout quand le fichier de prix n'a pas changé.",
            "|cfff2b53aPartage de guilde|r : n'envoie plus que les prix qui ont bougé de 3 % ou plus depuis la photo Blizzard (environ 2 Ko au lieu de 26 Ko pour le même scan, préparé 4 fois plus vite). Sans photo Blizzard, le scan est envoyé en entier.",
            "|cfff2b53aAucune donnée supprimée|r : mêmes prix, mêmes historiques, mêmes ventes. Des tests vérifient que la lecture par morceaux donne exactement le même résultat que la lecture d'un coup.",
            "Le dernier scan rapide et le dernier scan complet (objets, annonces, durée) sont mémorisés et affichés sur la page Scans.",
        } },
        { title = "Important", items = {
            "Pour recevoir les prix des scans de tes coéquipiers, chacun doit avoir la 3.4.0 : les versions précédentes ignorent ces nouveaux messages (rien n'est cassé chez elles).",
        } },
    } },
    { v = "3.3.1", date = "2026-11-26", summary = "Le partage en guilde n'envoie plus que tes propres scans de l'HV.", sections = {
        { title = "Corrections", items = {
            "Partage de guilde : quand un coéquipier se connecte, ton addon ne lui renvoie plus les prix de l'API Blizzard (chaque PC les reçoit tout seul par le compagnon) ni l'historique des prix bas (un mélange d'API et d'imports). Ne partent plus que |cfff2b53ates scans de l'HV|r (quand ils sont plus récents que la photo Blizzard) et |cfff2b53ales ventes que tes scans ont vues|r.",
            "Les historiques de prix bas envoyés par d'anciennes versions sont ignorés à la réception.",
        } },
        { title = "Modifications", items = {
            "Tant que tout le monde n'a pas la 3.3.1, les versions précédentes peuvent encore envoyer ces anciennes données : elles sont simplement ignorées chez toi.",
        } },
    } },
    { v = "3.3.0", date = "2026-11-26", summary = "Page d'accueil avec le journal des nouveautés, addon uniquement en français, et alerte quand le compagnon Windows doit être réinstallé.", sections = {
        { title = "Nouveautés", items = {
            "Page |cfff2b53aAccueil|r : les nouveautés de la dernière version, un menu déroulant pour lire les versions précédentes, un résumé de l'état des données et des raccourcis vers les onglets. La fenêtre s'ouvre dessus après chaque mise à jour.",
            "Ce journal des modifications (|cff9ad1ffCHANGELOG.md|r) est tenu à jour à chaque évolution et lisible en jeu.",
            "Alerte sur l'Accueil et dans le chat à la connexion quand la tâche planifiée du compagnon est trop ancienne : il faut relancer |cff9ad1ffInstaller.cmd|r.",
            "Commande |cff9ad1ff/craftmaster accueil|r (ou |cff9ad1ffnouveautes|r, |cff9ad1ffchangelog|r).",
            "|cff9ad1ffVerifier.ps1|r (dossier |cff9ad1ffCompanion|r) : dit si |cff9ad1ffInstaller.cmd|r doit être relancé. Les |cff9ad1ffCLAUDE.md|r demandent à Claude de le lancer après chaque |cff9ad1ffgit pull|r et de te le proposer.",
        } },
        { title = "Modifications", items = {
            "L'addon n'existe plus qu'en français : l'anglais, l'espagnol et les alias de commandes dans ces langues sont retirés (|cff9ad1ff/gg seuil|r, |cff9ad1ff/gg prix|r, |cff9ad1ff/gg ami|r... restent).",
            "La page Données affiche aussi la version de la tâche planifiée du compagnon.",
        } },
        { title = "Important", items = {
            "|cffffa733[!]|r Une fois : relancer |cff9ad1ffCraftMaster_Data\\Companion\\Installer.cmd|r (choix 1) pour mettre à jour la tâche planifiée, sauf si c'est déjà fait depuis la 3.2.0. Voir les messages |cff9ad1ffVerifier.ps1|r ou l'alerte de l'Accueil.",
        } },
    } },
    { v = "3.2.0", date = "2026-11-26", summary = "Onglet Données et synchronisation des prix au démarrage du PC, serveur JcJ (PvP) uniquement.", sections = {
        { title = "Nouveautés", items = {
            "Onglet |cfff2b53aDonnées|r : fraîcheur du fichier Blizzard, copie sur le PC, nombre de photos reçues chaque jour (pour repérer les trous), historique par HV, provenance des prix (Blizzard, scan, guilde) et état du partage de guilde.",
            "La tâche planifiée du compagnon se relance aussi à l'ouverture de session Windows et au réveil de veille (|cff9ad1ffPlanifier.ps1|r), avec 4 essais si le réseau n'est pas prêt.",
            "Le compagnon écrit la date de sa dernière synchronisation dans |cff9ad1ffData.lua|r.",
        } },
        { title = "Modifications", items = {
            "Prix partagés : seul le serveur JcJ (PvP) est publié et copié ; les autres types de serveur sont purgés.",
            "Dépôt |cff9ad1ffcraftmaster-prix|r : 3 passages GitHub par heure (au lieu d'un), publication seulement quand Blizzard a une photo nouvelle, historique glissant de 14 jours purgé automatiquement.",
        } },
        { title = "Important", items = {
            "|cffffa733[!]|r Relancer |cff9ad1ffCraftMaster_Data\\Companion\\Installer.cmd|r (choix 1) une fois pour installer les nouveaux déclencheurs de la tâche planifiée.",
        } },
    } },
    { v = "3.1.1", date = "2026-11-26", summary = "L'onglet Partage disparaît du menu.", sections = {
        { title = "Modifications", items = {
            "L'onglet Partage n'apparaît plus dans le menu de gauche ; le partage reste réglable dans Réglages et par |cff9ad1ff/cmaster partage Nom|r.",
        } },
    } },
    { v = "3.1.0", date = "2026-11-25", summary = "De nouvelles pages de marché, avec les prix de Blizzard toutes les heures.", sections = {
        { title = "Nouveautés", items = {
            "Nouvelles pages : |cfff2b53aBonnes affaires|r (objets vendus sous leur prix habituel), |cfff2b53aCrafts|r (recettes rentables, détail, composants à retirer du calcul) et |cfff2b53aPartage|r.",
            "Scan complet de l'HV en une passe (une fois toutes les 15 min), scan rapide en secours, bulle d'avancement à côté de l'HV.",
            "Prix de l'API Blizzard toutes les heures, même quand personne n'est connecté (compagnon Windows |cff9ad1ffCraftMaster_Data|r).",
        } },
        { title = "Modifications", items = {
            "Prix rangés par type de serveur (JcJ, JcE, RP, RP-JcJ) et par HV (Horde, Alliance, neutre).",
            "Interface en français, anglais et espagnol.",
        } },
    } },
}
