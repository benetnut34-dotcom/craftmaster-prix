local _, ns = ...
local L = ns.L
local W = ns.W

-- The Sharing page: what goes out, to whom, and what came in.
-- After each scan, the prices and the sales seen go to the players allowed
-- who are online (the guild, and the players of the list); theirs come in
-- at login. Hidden addon messages, market data only (Sync.lua).

local G = ns.Gold
local HEX = ns.Theme.HEX
local MUTED, GREEN, GOLD = HEX.muted, HEX.profit, HEX.gold

ns.UI.AddPage("gmshare", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local refreshers = {}

    local desc = W.Text(body, "small", "LEFT")
    desc:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    desc:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    desc:SetWordWrap(true)
    desc:SetText(MUTED .. L.GM_SHARE_DESC .. "|r")

    -- ------------------------------------------------------------ switches
    local opts = W.Card(body)
    opts:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -10)
    opts:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    opts:SetHeight(110)
    local house = W.Text(opts, "small", "RIGHT")
    house:SetPoint("TOPRIGHT", opts, "TOPRIGHT", -14, -12)
    house:SetTextColor(C.label[1], C.label[2], C.label[3])
    local function toggle(y, label, get, set, tip)
        local s = W.Switch(opts, get, set)
        s:SetPoint("TOPLEFT", opts, "TOPLEFT", 14, y)
        local t = W.Text(opts, "body", "LEFT")
        t:SetPoint("LEFT", s, "RIGHT", 10, 0)
        t:SetText(label)
        W.Tip(s, label, tip)
        refreshers[#refreshers + 1] = s.Refresh
        return s
    end
    toggle(-12, L.GM_SHARE_ON, function() return ns.db.share ~= false end,
        function(v) ns.db.share = v; ns.Fire("SyncChanged") end, L.GM_SHARE_ON_TIP)
    toggle(-44, L.GM_SHARE_GUILD, function() return ns.db.shareGuild ~= false end,
        function(v) ns.db.shareGuild = v; ns.Fire("SyncChanged") end, L.GM_SHARE_GUILD_TIP)
    toggle(-76, L.GM_SHARE_RECIPES, function() return ns.db.shareRecipes ~= false end,
        function(v) ns.db.shareRecipes = v; ns.Fire("SyncChanged") end, L.GM_SHARE_RECIPES_TIP)

    -- ------------------------------------------------------------ players allowed
    local left = W.Card(body, L.GM_PLAYERS, color)
    left:SetPoint("TOPLEFT", opts, "BOTTOMLEFT", 0, -10)
    left:SetPoint("BOTTOMRIGHT", body, "BOTTOM", -6, 0)
    local leftSub = W.Text(left, "tiny", "LEFT")
    leftSub:SetPoint("TOPLEFT", left, "TOPLEFT", 14, -34)
    leftSub:SetPoint("RIGHT", left, "RIGHT", -14, 0)
    leftSub:SetWordWrap(true)
    leftSub:SetText(MUTED .. L.GM_PLAYERS_SUB .. "|r")
    local input
    local function addFromInput()
        local name = input:GetText()
        if name and name:match("%S") then ns.Sync.AddFriend(name) end
        input:SetText("")
        input:ClearFocus()
        page.Refresh()
    end
    input = W.Input(left, { width = 200, hint = L.GM_CHAR_NAME })
    input:SetScript("OnEnterPressed", addFromInput)
    input:SetPoint("TOPLEFT", left, "TOPLEFT", 14, -54)
    local add = W.Button(left, L.GM_ADD, 90, addFromInput)
    add:SetPoint("LEFT", input, "RIGHT", 6, 0)
    add.SetTint(color)
    W.Tip(add, L.GM_ADD_PLAYER, L.GM_ADD_PLAYER_TIP)

    local function makePlayer(parent)
        local r = CreateFrame("Frame", nil, parent)
        r.bg = W.Fill(r, "BACKGROUND", 1, 1, 1, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r, "LEFT", 8, 0)
        r.name:SetWidth(140)
        r.status = W.Text(r, "small", "LEFT")
        r.status:SetPoint("LEFT", r, "LEFT", 156, 0)
        r.status:SetPoint("RIGHT", r, "RIGHT", -34, 0)
        r.status:SetWordWrap(false)
        r.remove = W.Button(r, "X", 22, function()
            if r.player then ns.Sync.RemoveFriend(r.player); page.Refresh() end
        end)
        r.remove:SetHeight(18)
        r.remove:SetPoint("RIGHT", r, "RIGHT", -4, 0)
        W.Tip(r.remove, L.GM_REMOVE_PLAYER, L.GM_REMOVE_PLAYER_TIP)
        return r
    end
    local function fillPlayer(r, name, i)
        r.player = name
        r.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.025 or 0)
        r.name:SetText(name)
        local online = ns.Sync.IsOnline(name)
        local st
        if online == true then st = GREEN .. L.GM_ONLINE .. "|r"
        elseif online == false then st = MUTED .. L.GM_OFFLINE .. "|r"
        else st = HEX.amber .. L.GM_STATUS_UNKNOWN .. "|r" end
        local seen = ns.Sync.Peer(name)
        if seen then st = st .. MUTED .. " · " .. string.format(L.GM_RECEIVED, G.Ago(seen)) .. "|r" end
        r.status:SetText(st)
    end
    local players = W.List(left, 24, makePlayer, fillPlayer)
    players:SetPoint("TOPLEFT", input, "BOTTOMLEFT", 0, -10)
    players:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -8, 10)
    players.Color(color)
    local none = W.Text(left, "small", "LEFT")
    none:SetPoint("TOPLEFT", players, "TOPLEFT", 8, -6)
    none:SetText(MUTED .. L.GM_NO_PLAYERS .. "|r")

    -- ------------------------------------------------------------ sync and activity
    local right = W.Card(body, L.GM_SYNC, color)
    right:SetPoint("TOPLEFT", opts, "BOTTOM", 6, -10)
    right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    local info = W.Text(right, "small", "LEFT")
    info:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -36)
    info:SetPoint("RIGHT", right, "RIGHT", -14, 0)
    info:SetWordWrap(true)
    info:SetJustifyV("TOP")
    info:SetHeight(48)
    local sync = W.Button(right, L.GM_SYNC_NOW, 200, function() ns.Sync.RequestSync(true); page.Refresh() end)
    sync:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -88)
    sync.SetTint(color)
    W.Tip(sync, L.GM_SYNC_NOW, L.GM_SYNC_NOW_TIP)
    local actTitle = W.Text(right, "head", "LEFT")
    actTitle:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -124)
    actTitle:SetText(L.GM_ACTIVITY)
    actTitle:SetTextColor(color[1], color[2], color[3])
    local function makeLog(parent)
        local r = CreateFrame("Frame", nil, parent)
        r.text = W.Text(r, "small", "LEFT")
        r.text:SetAllPoints()
        r.text:SetWordWrap(false)
        return r
    end
    local function fillLog(r, e)
        if e.dir == "req" then
            r.text:SetText(MUTED .. date("%H:%M", e.t) .. "|r  " .. HEX.sky .. (e.text or "") .. "|r")
        else
            local arrow = e.dir == "in" and (GREEN .. L.GM_FROM .. "|r ") or (GOLD .. L.GM_TO .. "|r ")
            r.text:SetText(MUTED .. date("%H:%M", e.t) .. "|r  " .. arrow .. (e.who or "?") .. MUTED .. " — " .. (e.text or "") .. "|r")
        end
    end
    local log = W.List(right, 18, makeLog, fillLog)
    log:SetPoint("TOPLEFT", actTitle, "BOTTOMLEFT", 0, -8)
    log:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -8, 10)
    log.Color(color)
    local noLog = W.Text(right, "small", "LEFT")
    noLog:SetPoint("TOPLEFT", log, "TOPLEFT", 0, -2)
    noLog:SetText(MUTED .. L.GM_NO_EXCHANGE .. "|r")

    function page.Refresh()
        for _, r in ipairs(refreshers) do r() end
        house:SetText(string.format(L.GM_HOUSE, ns.RulesetLabel() .. " – " .. ns.HouseName("faction")))
        local f = ns.Sync.Friends()
        players.SetData(f, true)
        none:SetShown(#f == 0)
        local lines = { string.format(L.GM_LAST_SYNC, G.Ago(ns.Sync.LastSync())) }
        local b = ns.Scan.Book("faction")
        if b.fromGuild and b.fromWho and b.at then
            lines[#lines + 1] = string.format(L.GM_PRICES_FROM, b.fromWho, G.Ago(b.at))
        elseif b.at then
            lines[#lines + 1] = string.format(L.GM_PRICES_MINE, G.Ago(b.at))
        end
        if ns.db.share == false then lines[#lines + 1] = HEX.loss .. L.GM_SHARE_DISABLED .. "|r" end
        info:SetText(table.concat(lines, "\n"))
        local l = ns.Sync.Log()
        log.SetData(l, true)
        noLog:SetShown(#l == 0)
    end
end)
