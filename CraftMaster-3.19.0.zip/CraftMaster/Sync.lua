local _, ns = ...
local L = ns.L

-- Sharing with other players: the guild, and friends
-- outside it named in the settings. Hidden addon messages, compressed
-- (AceComm + LibSerialize + LibDeflate). Only market data goes out, never
-- anything about the characters:
--   * the newest prices of each Auction House (lowest price and quantity),
--   * the daily lows (for the usual prices),
--   * the sales seen in full scans (for the resale prices and the stars).
-- Everything is kept per server type and house ("PvP-Horde"...): data of a
-- house nobody here plays still fills its history.
--
-- Messages (prefix "CraftMaster", version 2):
--   HELLO { have = { [house key] = newest prices }, since }   on login / button
--   DATA  { h = house key, scan, hour, wday, cur, hist, sales, sb, reply }
local S = {}
ns.Sync = S

local PREFIX = "CraftMaster"
local VERSION = 2
local FIRST_SYNC = 86400          -- first time: one day of history
local REPLY_COOLDOWN = 10 * 60    -- the same player gets everything once per 10 min at most
local SHARE_MIN_PRICE = 10000     -- sales of items worth 1 gold or more
local MAX_SHARED_EVENTS = 6000
local LOG_MAX = 30
local NOT_FOUND_PAUSE = 10 * 60

local AceComm = LibStub and LibStub("AceComm-3.0", true)
local LibDeflate = LibStub and LibStub("LibDeflate", true)
local LibSerialize = LibStub and LibStub("LibSerialize", true)

local comm = {}
if AceComm then AceComm:Embed(comm) end

local stats = { sent = 0, got = 0 }
local peers = {}        -- [name] = time seen
local lastReply = {}
local guild = {}        -- [name] = online
local notFound = {}     -- [name] = when the game said nobody of that name is on
local recentTargets = {}

local SESSION
local function session()
    if not SESSION then SESSION = (UnitGUID and UnitGUID("player") or "?") .. ":" .. string.format("%x", math.random(0, 0x7fffffff)) end
    return SESSION
end

local function on() return ns.db and ns.db.share ~= false and AceComm ~= nil end

function S.Normalize(name)
    if type(name) ~= "string" then return nil end
    name = name:gsub("%s+", ""):gsub("%-.*$", "")
    if name == "" then return nil end
    return name:sub(1, 1):upper() .. name:sub(2)
end
local function me() return S.Normalize(UnitName and UnitName("player")) end

local function log(dir, who, text)
    ns.db.shareLog = ns.db.shareLog or {}
    local l = ns.db.shareLog
    table.insert(l, 1, { t = time(), dir = dir, who = who, text = text })
    for i = #l, LOG_MAX + 1, -1 do l[i] = nil end
    ns.Fire("SyncChanged")
end
function S.Log() return ns.db.shareLog or {} end

local function friends() ns.db.friends = ns.db.friends or {}; return ns.db.friends end
local function isFriend(name)
    for _, n in ipairs(friends()) do if n == name then return true end end
    return false
end

function S.IsOnline(name)
    if notFound[name] and time() - notFound[name] < NOT_FOUND_PAUSE then return false end
    if guild[name] ~= nil then return guild[name] end
    if C_FriendList and C_FriendList.GetFriendInfo then
        local info = C_FriendList.GetFriendInfo(name)
        if info then return info.connected and true or false end
    end
    if (UnitInParty and UnitInParty(name)) or (UnitInRaid and UnitInRaid(name)) then
        return UnitIsConnected(name) and true or false
    end
    return nil
end

-- ---------------------------------------------------------------------
-- What goes out
-- ---------------------------------------------------------------------

local function encode(msg)
    msg.v, msg.sid = VERSION, session()
    local ser = LibSerialize:Serialize(msg)
    local comp = LibDeflate:CompressDeflate(ser, { level = 5 })
    return LibDeflate:EncodeForWoWAddonChannel(comp)
end

-- To the guild and the friends online, or to one player.
local function send(msg, target)
    if not on() then return 0 end
    local payload = encode(msg)
    if target then
        if target == me() or S.IsOnline(target) == false then return 0 end
        recentTargets[target] = true
        comm:SendCommMessage(PREFIX, payload, "WHISPER", target, "BULK")
        stats.sent = stats.sent + 1
        return 1
    end
    local sent = 0
    if ns.db.shareGuild ~= false and IsInGuild and IsInGuild() then
        comm:SendCommMessage(PREFIX, payload, "GUILD", nil, "BULK")
        sent = sent + 1
    end
    for _, name in ipairs(friends()) do
        local viaGuild = ns.db.shareGuild ~= false and guild[name] ~= nil
        if name ~= me() and not viaGuild and S.IsOnline(name) == true then
            recentTargets[name] = true
            comm:SendCommMessage(PREFIX, payload, "WHISPER", name, "BULK")
            sent = sent + 1
        end
    end
    stats.sent = stats.sent + sent
    return sent
end

-- The prices of a house, packed: ids sorted and sent as gaps; prices of
-- 1 gold and more rounded to silver (sent negative).
local function flatCurrent(items)
    local ids = {}
    for id in pairs(items) do ids[#ids + 1] = id end
    table.sort(ids)
    local flat, prev = {}, 0
    for _, id in ipairs(ids) do
        local e = items[id]
        flat[#flat + 1] = id - prev
        flat[#flat + 1] = e[1] >= 10000 and -math.floor(e[1] / 100 + 0.5) or e[1]
        flat[#flat + 1] = e[2] or 0
        prev = id
    end
    return flat
end
local function unpackPrice(v) return v < 0 and -v * 100 or v end

-- What of my scan is worth sending. Every PC already holds the Blizzard
-- picture of the house (the companion brings it every hour), so sending the
-- 7000 prices of a scan would send the same numbers again. What the others
-- lack is what my scan saw MOVE since that picture: the items whose price
-- differs by 3% or more, or that the picture does not have. At most 1500, the
-- biggest moves first. Without a picture to compare with (no companion), the
-- whole scan is sent, as before: data first.
local DELTA_PCT, DELTA_MAX = 0.03, 1500
local function deltaOf(key, items)
    local ref = ns.Import and ns.Import.apiRef and ns.Import.apiRef[key]
    if not ref then return nil end
    local moved, n = {}, 0
    for id, e in pairs(items) do
        local r = ref.items[id]
        local move = 9
        if r and r[1] > 0 then move = math.abs(e[1] - r[1]) / r[1] end
        if not r or move >= DELTA_PCT then
            n = n + 1
            moved[n] = { id, e, move }
        end
    end
    if n > DELTA_MAX then
        table.sort(moved, function(a, b) return a[3] > b[3] end)
        for i = n, DELTA_MAX + 1, -1 do moved[i] = nil end
        n = DELTA_MAX
    end
    local out = {}
    for i = 1, n do out[moved[i][1]] = moved[i][2] end
    return out, n, ref.at
end

-- The prices of a scan as they go in a message: { dcur = ..., ref = ... } (what
-- moved since the Blizzard picture) or { cur = ... } (everything).
local function pricesField(key, items)
    local d, n, refAt = deltaOf(key, items)
    if d then return { dcur = flatCurrent(d), ref = refAt }, n end
    return { cur = flatCurrent(items) }, nil
end

local function selectEvents(events)
    local kept = {}
    for _, pair in ipairs(events) do
        if pair[2][2] >= SHARE_MIN_PRICE and not pair[2][6] then kept[#kept + 1] = pair end
    end
    table.sort(kept, function(a, b) return a[2][1] > b[2][1] end)
    for i = #kept, MAX_SHARED_EVENTS + 1, -1 do kept[i] = nil end
    return kept
end

local function flatEvents(events)
    local base
    for _, pair in ipairs(events) do
        if not base or pair[2][1] < base then base = pair[2][1] end
    end
    local out = {}
    for _, pair in ipairs(events) do
        local id, e = pair[1], pair[2]
        local t = out[id]
        if not t then t = {}; out[id] = t end
        t[#t + 1] = e[1] - base; t[#t + 1] = e[2]; t[#t + 1] = e[3]; t[#t + 1] = e[4]; t[#t + 1] = e[5] or "0"
    end
    return out, base or 0
end

local function eventsSince(key, since)
    local events = {}
    for id, list in pairs(ns.Tracker.Store(key)) do
        for _, e in ipairs(list) do
            if e[1] >= since and e[9] ~= "buy" then events[#events + 1] = { id, e } end   -- not my own purchases
        end
    end
    events = selectEvents(events)
    return events, #events
end

-- My recipes, as they are sent: { [id] = { name, out, qty, {id, n, id, n...}, skill line } }
local function flatRecipes()
    local out = {}
    for id, r in pairs(ns.Gold.Recipes()) do
        local reag = {}
        for _, rg in ipairs(r.reagents) do reag[#reag + 1] = rg.id; reag[#reag + 1] = rg.n end
        out[id] = { ns.Gold.RecipeName(id, r), r.out, r.qty, reag, ns.Gold.SKILL_OF[r.prof] or r.prof }
    end
    return out
end

-- A book worth sending is one of MY scans: not one received from the guild,
-- and not the Blizzard API picture (book.from == "blizzard"): every PC gets
-- that one by itself from the companion, so sending it would only duplicate it.
local function isMyScan(b)
    return b ~= nil and b.at ~= nil and not b.fromGuild and b.from ~= "blizzard"
end

-- The houses I have prices of (my own scans only): { [key] = book }
local function myBooks()
    local out = {}
    for key, b in pairs(ns.db.scans or {}) do
        if isMyScan(b) and next(b.items or {}) then out[key] = b end
    end
    return out
end

-- After one of my scans: its prices and the sales it found.
local function shareScan(house, items)
    if not on() then return end
    local key = ns.HouseKey(house)
    local t = date("*t")
    local msg = { t = "DATA", h = key, scan = time(), hour = t.hour, wday = t.wday }
    local pf = pricesField(key, items)
    msg.cur, msg.dcur, msg.ref = pf.cur, pf.dcur, pf.ref
    local events = selectEvents(ns.Tracker.lastNew or {})
    if #events > 0 then msg.sales, msg.sb = flatEvents(events) end
    ns.Tracker.lastNew = nil
    if send(msg) > 0 then
        log("out", L.SHARE_EVERYONE, string.format(L.SHARE_SENT, #(msg.cur or msg.dcur) / 3, #events))
    end
end

function S.RequestSync(manual)
    if not on() then
        if manual then ns.Print(L.SHARE_OFF) end
        return
    end
    local have = {}
    for key, b in pairs(ns.db.scans or {}) do if b.at then have[key] = b.at end end
    local since = ns.db.lastSync or (time() - FIRST_SYNC)
    local sent = send({ t = "HELLO", have = have, since = since, rc = ns.Gold.RecipeCount() })
    if manual then ns.Print(sent > 0 and L.SHARE_ASKED or L.SHARE_NOBODY) end
    if sent > 0 then log("req", nil, L.SHARE_ASKED) end
end

-- ---------------------------------------------------------------------
-- What comes in
-- ---------------------------------------------------------------------

local handlers = {}

-- What I answer to a HELLO: ONLY what my own scans produced, i.e. my last scan
-- of a house (when it is newer than what the other player has) and the sales
-- my scans saw. Never the Blizzard API data (the companion brings it to every
-- PC) and never the daily lows (they mix the API and the other addons).
function S.BuildReplies(msg)
    local since = tonumber(msg.since) or (time() - FIRST_SYNC)
    local theirs = type(msg.have) == "table" and msg.have or {}
    local replies, keys = {}, {}
    for key in pairs(ns.db.mkt or {}) do keys[key] = true end
    for key in pairs(myBooks()) do keys[key] = true end
    for key in pairs(keys) do
        local out, parts = { t = "DATA", h = key, reply = true }, {}
        local b = ns.db.scans and ns.db.scans[key]
        if isMyScan(b) and b.at > (tonumber(theirs[key]) or 0) + 300 then
            local pf = pricesField(key, b.items)
            out.scan, out.cur, out.dcur, out.ref = b.at, pf.cur, pf.dcur, pf.ref
            parts[#parts + 1] = string.format(L.SHARE_PRICES, #(out.cur or out.dcur) / 3)
        end
        local events, ne = eventsSince(key, since)
        if ne > 0 then
            out.sales, out.sb = flatEvents(events)
            parts[#parts + 1] = string.format(L.SHARE_SALES, ne)
        end
        if out.cur or out.dcur or out.sales then
            replies[#replies + 1] = { key = key, out = out, parts = parts }
        end
    end
    return replies
end

-- "I am here": the answer to a HELLO even when I have nothing to give. Without it, a player
-- who logs in and asks only learns about the others who happen to have something new to
-- send, so a co-developer online with nothing new shows up as nobody. Costs a few bytes,
-- at most once a minute per player.
local lastHere = {}
function handlers.HERE() end        -- the message itself is what counts: the sender is noted as seen

function handlers.HELLO(msg, sender)
    local now = time()
    if not lastHere[sender] or now - lastHere[sender] > 60 then
        lastHere[sender] = now
        C_Timer.After(1 + math.random() * 2, function() send({ t = "HERE" }, sender) end)
    end
    if lastReply[sender] and now - lastReply[sender] < REPLY_COOLDOWN then return end
    lastReply[sender] = now
    C_Timer.After(2 + math.random() * 4, function()
        local sentAny = false
        for _, r in ipairs(S.BuildReplies(msg)) do
            send(r.out, sender)
            sentAny = true
            log("out", sender, r.key .. " : " .. (#r.parts > 0 and table.concat(r.parts, ", ") or L.SHARE_HISTORY))
        end
        -- my recipes, to a player who knows fewer
        local mine, theirsRc = ns.Gold.RecipeCount(), tonumber(msg.rc) or 0
        if ns.db.shareRecipes ~= false and mine > theirsRc and (theirsRc == 0 or mine > theirsRc + 10) then
            send({ t = "DATA", h = ns.HouseKey("faction"), rec = flatRecipes(), reply = true }, sender)
            log("out", sender, string.format(L.SHARE_RECIPES, mine))
            sentAny = true
        end
        if not sentAny then ns.Fire("SyncChanged") end
    end)
end

function handlers.DATA(msg, sender)
    local key = msg.h
    if type(key) ~= "string" or not key:match("^%a+%-%a+$") then return end
    local house = (key == ns.HouseKey("faction") and "faction") or (key == ns.HouseKey("neutral") and "neutral") or nil
    local parts = {}

    -- newest prices: only when fresher than mine
    if type(msg.cur) == "table" and tonumber(msg.scan) then
        ns.db.scans = ns.db.scans or {}
        local book = ns.db.scans[key]
        if not book then book = { items = {} }; ns.db.scans[key] = book end
        local items, cur, id = {}, msg.cur, 0
        for i = 1, #cur - 2, 3 do
            id = id + cur[i]
            items[id] = { unpackPrice(cur[i + 1]), cur[i + 2] }
        end
        local day = math.floor(msg.scan / 86400)
        local lows = ns.Deals.StoreOf(key)
        for iid, e in pairs(items) do
            lows[iid] = lows[iid] or {}
            ns.Deals.AddLow(lows[iid], day, e[1])
        end
        if msg.scan > (book.at or 0) + 60 then
            book.items, book.at, book.fromGuild, book.from, book.house = items, msg.scan, true, nil, nil
            book.fromWho = sender
            if house and msg.hour and time() - msg.scan < 7200 then ns.Timing.Observe(house, items, msg.hour, msg.wday or 1) end
            ns.Prices.Reset()
            ns.Fire("PricesChanged")
        end
        parts[#parts + 1] = string.format(L.SHARE_PRICES, #cur / 3)
    end

    -- newest prices, as a difference with the Blizzard picture (dcur): merged
    -- over the book I have (a copy: the book may be the picture itself) so that
    -- the prices the sender did not need to send are kept
    if type(msg.dcur) == "table" and tonumber(msg.scan) then
        ns.db.scans = ns.db.scans or {}
        local book = ns.db.scans[key]
        if not book then book = { items = {} }; ns.db.scans[key] = book end
        local moved, cur, id = {}, msg.dcur, 0
        for i = 1, #cur - 2, 3 do
            id = id + cur[i]
            moved[id] = { unpackPrice(cur[i + 1]), cur[i + 2] }
        end
        local day = math.floor(msg.scan / 86400)
        local lows = ns.Deals.StoreOf(key)
        for iid, e in pairs(moved) do
            lows[iid] = lows[iid] or {}
            ns.Deals.AddLow(lows[iid], day, e[1])
        end
        if msg.scan > (book.at or 0) + 60 then
            local merged = {}
            for iid, e in pairs(book.items or {}) do merged[iid] = e end
            for iid, e in pairs(moved) do merged[iid] = e end
            book.items, book.at, book.fromGuild, book.from, book.house = merged, msg.scan, true, nil, nil
            book.fromWho = sender
            ns.Prices.Reset()
            ns.Fire("PricesChanged")
        end
        parts[#parts + 1] = string.format(L.SHARE_PRICES, #cur / 3)
    end

    -- daily lows (msg.hist, sent by versions before 3.3.1): ignored. They mixed
    -- the Blizzard API with other sources, and the API history already comes
    -- from the companion; only players' scans are taken in.

    -- sales, without the ones already known
    if type(msg.sales) == "table" then
        local added, cutoff = 0, time() - 14 * 86400
        local Key = ns.Tracker.EventKey
        local store = ns.Tracker.Store(key)
        for iid, t in pairs(msg.sales) do
            local known = {}
            for _, e in ipairs(store[iid] or {}) do
                local k = Key(e[1], e[2], e[3], e[4], e[5])
                known[k] = (known[k] or 0) + 1
                for _, alias in ipairs(e[8] or {}) do known[alias] = (known[alias] or 0) + 1 end
            end
            for i = 1, #t - 4, 5 do
                local et, p, q, w, o = (msg.sb or 0) + t[i], t[i + 1], t[i + 2], t[i + 3], t[i + 4]
                local k = Key(et, p, q, w, o)
                if (known[k] or 0) > 0 then
                    known[k] = known[k] - 1
                elseif et >= cutoff and ns.Tracker.AddEvent(key, iid, et, p, q, w, o, true) then
                    added = added + 1
                end
            end
        end
        parts[#parts + 1] = string.format(L.SHARE_SALES, added)
        ns.Fire("SalesChanged", key)
    end

    -- recipes
    if type(msg.rec) == "table" then
        local added = 0
        for id, r in pairs(msg.rec) do
            if type(id) == "number" and type(r) == "table" and type(r[4]) == "table" then
                local reagents = {}
                for i = 1, #r[4] - 1, 2 do reagents[#reagents + 1] = { id = r[4][i], n = r[4][i + 1] } end
                if ns.Gold.AddRecipe(id, r[1], r[2], r[3], reagents, r[5]) then added = added + 1 end
            end
        end
        if added > 0 then
            parts[#parts + 1] = string.format(L.SHARE_RECIPES_GOT, added)
            ns.Fire("RecipesChanged")
        end
    end

    if msg.reply then ns.db.lastSync = time() end
    stats.got = stats.got + 1
    log("in", sender, key .. " : " .. (#parts > 0 and table.concat(parts, ", ") or L.SHARE_HISTORY))
end

function comm:OnCommReceived(prefix, text, distribution, sender)
    if prefix ~= PREFIX or not on() then return end
    sender = S.Normalize(sender)
    if not sender or sender == me() then return end
    -- the guild channel is the guild; a whisper must come from a friend of the list (or the guild)
    local guildOK = ns.db.shareGuild ~= false
    if distribution == "GUILD" and not guildOK then return end
    if distribution ~= "GUILD" and not isFriend(sender) and not (guildOK and guild[sender] ~= nil) then return end
    local decoded = LibDeflate:DecodeForWoWAddonChannel(text)
    local raw = decoded and LibDeflate:DecompressDeflate(decoded)
    if not raw then return end
    local ok, msg = LibSerialize:Deserialize(raw)
    if not ok or type(msg) ~= "table" or msg.v ~= VERSION or msg.sid == session() then return end
    S.Dispatch(msg, sender)
end

-- A decoded message from another player: noted as seen, then handled.
function S.Dispatch(msg, sender)
    peers[sender] = time()
    ns.db.peers = ns.db.peers or {}
    ns.db.peers[sender] = time()
    local h = handlers[msg.t]
    if h then
        local ok2, err = pcall(h, msg, sender)
        if not ok2 then ns.Debug("share: %s", tostring(err)) end
    end
    ns.Fire("SyncChanged")
end

-- ---------------------------------------------------------------------
-- Friends outside the guild
-- ---------------------------------------------------------------------

function S.Friends() return friends() end

function S.AddFriend(name)
    name = S.Normalize(name)
    if not name or name == me() then return false end
    if isFriend(name) then return false end
    table.insert(friends(), name)
    table.sort(friends())
    ns.Print(L.SHARE_FRIEND_ADDED, name)
    ns.Fire("SyncChanged")
    return true
end

function S.RemoveFriend(name)
    for i, n in ipairs(friends()) do
        if n == name then table.remove(friends(), i); ns.Fire("SyncChanged"); return true end
    end
    return false
end

-- ---------------------------------------------------------------------
-- Guild roster, quiet whispers to friends who are offline
-- ---------------------------------------------------------------------

local function updateGuild()
    wipe(guild)
    if not (IsInGuild and IsInGuild()) or not GetNumGuildMembers then return end
    for i = 1, GetNumGuildMembers() do
        local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
        name = S.Normalize(name)
        if name then guild[name] = online and true or false end
    end
end

local function systemFilter(_, _, text)
    local pattern = ERR_CHAT_PLAYER_NOT_FOUND_S and ERR_CHAT_PLAYER_NOT_FOUND_S:gsub("%%s", "(.+)")
    local name = pattern and type(text) == "string" and text:match(pattern)
    name = name and S.Normalize(name:gsub("[\"'«»]", ""))
    if name and recentTargets[name] then
        notFound[name] = time()
        return true
    end
end

ns.Register("GUILD_ROSTER_UPDATE", updateGuild)

ns.On("ScanDone", function(house, items)
    -- after the sales of a full scan are counted
    C_Timer.After(1, function() shareScan(house, items) end)
end)

ns.On("Login", function()
    if not AceComm then return end
    comm:RegisterComm(PREFIX)
    if ChatFrame_AddMessageEventFilter then ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", systemFilter) end
    if C_GuildInfo and C_GuildInfo.GuildRoster then pcall(C_GuildInfo.GuildRoster) end
    C_Timer.After(30, function() updateGuild(); S.RequestSync(false) end)
    -- every 15 minutes: say hello again, so the members who log in later (or whose first answer got
    -- lost) are counted; whoever has nothing new answers with a few bytes
    if C_Timer.NewTicker then C_Timer.NewTicker(15 * 60, function() S.RequestSync(false) end) end
end)

-- When a player's data last came in (nil: never this session or before).
function S.Peer(name)
    return peers[name] or (ns.db.peers and ns.db.peers[name])
end
function S.LastSync() return ns.db.lastSync end

-- For the window: players seen in the last two hours, messages sent and received.
function S.Status()
    local n = 0
    for _, t in pairs(peers) do if time() - t < 2 * 3600 then n = n + 1 end end
    return { peers = n, sent = stats.sent, got = stats.got, queued = 0, on = on(), friends = #friends() }
end
