local _, ns = ...
local L = ns.L

-- The cart: recipes and how many crafts of each. From it, the shopping
-- list: every material, how many are needed, how many are already owned
-- (bags, bank, and what was just bought at the Auction House and is still in
-- the mailbox), and where it is cheapest.
local C = {}
ns.Cart = C

function C.Lines() return ns.char.cart end

function C.Find(id)
    for i, line in ipairs(ns.char.cart) do
        if line.id == id then return line, i end
    end
end

function C.Add(id, n)
    n = math.max(1, math.floor(tonumber(n) or 1))
    local line = C.Find(id)
    if line then line.n = line.n + n else table.insert(ns.char.cart, { id = id, n = n }) end
    ns.Print(L.ADDED, n, ns.Recipes.Name(id))
    ns.Fire("CartChanged")
end

function C.Set(id, n)
    local line, i = C.Find(id)
    if not line then return end
    n = math.floor(tonumber(n) or 0)
    if n <= 0 then table.remove(ns.char.cart, i) else line.n = n end
    ns.Fire("CartChanged")
end

function C.Remove(id) C.Set(id, 0) end

function C.Clear()
    wipe(ns.char.cart)
    wipe(ns.char.bought)
    wipe(ns.char.baseline)
    ns.Fire("CartChanged")
end

function C.Count() return #ns.char.cart end

-- Owned, counting what's on its way by mail.
function C.Have(id)
    return ns.Count(id) + (ns.char.bought[id] or 0)
end

-- { vendor = { rows }, ah = { rows }, none = { rows }, cost, value, profit }
-- with row = { id, need, have, buy, unit, total, from }.
function C.Shopping()
    local need, order = {}, {}
    local value, valueOk = 0, true
    for _, line in ipairs(ns.char.cart) do
        local mats = ns.Recipes.Materials(line.id)
        if mats then
            for _, m in ipairs(mats) do
                if not need[m[1]] then need[m[1]] = 0; order[#order + 1] = m[1] end
                need[m[1]] = need[m[1]] + m[2] * line.n
            end
        end
        local p = ns.Recipes.Price(line.id)
        if p.value then value = value + p.value * line.n else valueOk = false end
    end
    local out = { vendor = {}, ah = {}, none = {}, cost = 0, value = valueOk and value or nil }
    for _, id in ipairs(order) do
        local have = C.Have(id)
        local buy = math.max(0, need[id] - have)
        local unit, from = ns.Prices.Cheapest(id)
        local row = { id = id, need = need[id], have = have, buy = buy, unit = unit, from = from,
                      total = unit and unit * buy or nil }
        if buy > 0 then
            if from == "vendor" then table.insert(out.vendor, row)
            elseif from == "ah" then table.insert(out.ah, row)
            else table.insert(out.none, row) end
            if row.total then out.cost = out.cost + row.total end
        end
    end
    local function byName(a, b) return ns.ItemName(a.id) < ns.ItemName(b.id) end
    table.sort(out.vendor, byName)
    table.sort(out.ah, byName)
    if out.value then
        -- the profit counts every material, owned ones too: they could be sold instead
        local full = 0
        for _, line in ipairs(ns.char.cart) do
            local p = ns.Recipes.Price(line.id)
            full = full + (p.cost or 0) * line.n
        end
        out.profit = out.value - full
    end
    return out
end

-- Bought at the Auction House: it comes by mail, so count it until it's in
-- the bags.
function C.NoteBought(id, qty)
    ns.char.bought[id] = (ns.char.bought[id] or 0) + qty
    ns.char.baseline[id] = ns.Count(id)
    ns.Fire("CartChanged")
end

ns.Register("BAG_UPDATE_DELAYED", function()
    local changed = false
    for id, waiting in pairs(ns.char.bought) do
        local now = ns.Count(id)
        local base = ns.char.baseline[id] or now
        if now > base then
            local arrived = math.min(waiting, now - base)
            ns.char.bought[id] = waiting - arrived > 0 and (waiting - arrived) or nil
            ns.char.baseline[id] = now
            changed = true
        end
    end
    ns.Fire("BagsChanged", changed)
end)

-- At a merchant: buy what the shopping list wants from it. BuyMerchantItem
-- takes at most one stack per call.
function C.BuyFromMerchant()
    if not (GetMerchantNumItems and BuyMerchantItem) then return end
    local shop = C.Shopping()
    local want = {}
    for _, row in ipairs(shop.vendor) do want[row.id] = row.buy end
    for _, row in ipairs(shop.ah) do want[row.id] = want[row.id] or row.buy end
    for i = 1, GetMerchantNumItems() do
        local link = GetMerchantItemLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local qty = id and want[id]
        if qty and qty > 0 then
            local price, stack, avail, extended = ns.MerchantInfo(i)
            if not extended and price and price > 0 then
                stack = math.max(1, stack or 1)
                local packs = math.ceil(qty / stack)
                if avail and avail > 0 then packs = math.min(packs, avail) end
                local maxStack = GetMerchantItemMaxStack and GetMerchantItemMaxStack(i) or 20
                local left = packs * stack
                local bought = 0
                if stack == 1 then
                    while left > 0 do
                        local n = math.min(left, maxStack)
                        BuyMerchantItem(i, n)
                        left = left - n
                        bought = bought + n
                    end
                else
                    for _ = 1, packs do BuyMerchantItem(i, 1) end
                    bought = packs * stack
                end
                ns.Print(L.BUY_MERCHANT_DONE, bought, ns.ItemName(id))
                want[id] = nil
            end
        end
    end
end

-- Whether the open merchant sells something on the list.
function C.MerchantHasAny()
    if not (MerchantFrame and MerchantFrame:IsShown() and GetMerchantNumItems) then return false end
    local shop = C.Shopping()
    local want = {}
    for _, row in ipairs(shop.vendor) do want[row.id] = true end
    for _, row in ipairs(shop.ah) do want[row.id] = true end
    for i = 1, GetMerchantNumItems() do
        local link = GetMerchantItemLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        if id and want[id] then return true end
    end
    return false
end

-- ---------------------------------------------------------------------
-- Where to buy from a merchant: the nearest one, on the map
-- ---------------------------------------------------------------------

-- The merchants that sell an item, as map pins (my table first, Questie as a fallback).
function C.VendorPins(id)
    local pins = {}
    for _, v in ipairs(ns.Prices.VendorsOf(id)) do pins[#pins + 1] = v.pin end
    return pins
end

-- The merchant to go to for an item: name, zone, and its pin (nil if none is known).
function C.VendorOf(id)
    local pins = C.VendorPins(id)
    local p = ns.Map.Nearest(pins)
    if not p then return nil end
    return p.name, p.zoneName or p.zone, p
end

-- The stops of a trip to the merchants for the vendor part of the list: the nearest merchant of
-- each item, one stop per merchant (several items from the same one make one stop).
function C.VendorStops(shop)
    local stops, seen = {}, {}
    for _, row in ipairs(shop.vendor) do
        local p = ns.Map.Nearest(C.VendorPins(row.id))
        if p then
            local key = tostring(p.name) .. "|" .. tostring(p.zone)
            if not seen[key] then
                seen[key] = true
                stops[#stops + 1] = p
            end
        end
    end
    return stops
end
