local _, ns = ...
local L = ns.L
local W = ns.W

-- Cart: the recipes picked and how many crafts of each, and the shopping
-- list they make: what to buy, and where. Two parts, said in full on every line:
-- at a vendor (with a marker for the nearest merchant, and one button for the whole trip)
-- or at the Auction House (with a buy button on every line).

local CART_W = 380

ns.UI.AddPage("cart", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C

    -- ---------------------------------------------------------- cart lines
    local left = W.Card(body, L.CART_LINES, color)
    left:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0)
    left:SetWidth(CART_W)

    local function makeLine(parent)
        local r = CreateFrame("Frame", nil, parent)
        r.icon = W.ItemIcon(r, 20)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.remove = W.Close(r, function(self) ns.Cart.Remove(self:GetParent().data.id) end)
        r.remove:SetSize(20, 20)
        r.remove:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        r.plus = W.Button(r, "+", 20, function(self)
            local d = self:GetParent().data
            ns.Cart.Set(d.id, d.n + 1)
        end)
        r.plus:SetHeight(20)
        r.plus:SetPoint("RIGHT", r.remove, "LEFT", -8, 0)
        r.qty = W.Input(r, { numeric = true, width = 40, onEnter = function(t)
            local d = r.data
            if d and tonumber(t) and tonumber(t) ~= d.n then ns.Cart.Set(d.id, tonumber(t)) end
        end })
        r.qty:SetHeight(20)
        r.qty:SetPoint("RIGHT", r.plus, "LEFT", -2, 0)
        r.minus = W.Button(r, "-", 20, function(self)
            local d = self:GetParent().data
            ns.Cart.Set(d.id, d.n - 1)
        end)
        r.minus:SetHeight(20)
        r.minus:SetPoint("RIGHT", r.qty, "LEFT", -2, 0)
        r.profit = W.Text(r, "small", "RIGHT")
        r.profit:SetWidth(80)
        r.profit:SetPoint("RIGHT", r.minus, "LEFT", -8, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
        r.name:SetPoint("RIGHT", r.profit, "LEFT", -6, 0)
        r.name:SetWordWrap(false)
        return r
    end
    local function fillLine(r, d)
        r.data = d
        local p = ns.Recipes.Price(d.id)
        r.icon.Set(p.out, ns.Recipes.Icon(d.id))
        r.name:SetText(ns.Recipes.Name(d.id))
        local q = p.out and ns.Item(p.out) and ns.Item(p.out).quality or 1
        r.name:SetTextColor(ns.QualityColor(q))
        if not r.qty:HasFocus() then r.qty:SetText(tostring(d.n)) end
        W.ProfitText(r.profit, p.profit and p.profit * d.n)
    end
    local lines = W.List(left, 28, makeLine, fillLine)
    lines:SetPoint("TOPLEFT", left, "TOPLEFT", 10, -left.top)
    lines:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -8, 96)
    lines.Color(color)
    local emptyCart = W.Text(left, "body", "CENTER")
    emptyCart:SetPoint("TOPLEFT", lines, "TOPLEFT", 10, -30)
    emptyCart:SetPoint("TOPRIGHT", lines, "TOPRIGHT", -10, -30)
    emptyCart:SetWordWrap(true)
    emptyCart:SetText(L.CART_EMPTY)
    emptyCart:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- totals
    local totals = {}
    local function totalLine(i, label)
        local l = W.Text(left, "small", "LEFT")
        l:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 14, 70 - (i - 1) * 18)
        l:SetText(label)
        l:SetTextColor(C.label[1], C.label[2], C.label[3])
        local v = W.Text(left, "body", "RIGHT")
        v:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -14, 70 - (i - 1) * 18)
        totals[i] = v
    end
    totalLine(1, L.CART_COST)
    totalLine(2, L.CART_VALUE)
    totalLine(3, L.CART_PROFIT)
    local clear = W.Button(left, L.CLEAR_CART, 140, function() ns.Cart.Clear() end)
    clear:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 12, 10)

    -- ---------------------------------------------------------- shopping list
    local right = W.Card(body)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 12, 0)
    right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)

    -- the vendors' part: one marker per merchant to visit, the nearest of each item
    local tripBtn = W.Button(right, L.CART_TRIP, 190, function()
        local stops = ns.Cart.VendorStops(shopping)
        if #stops == 0 then ns.Print(L.MAP_NOTHING) else ns.Map.Route(stops) end
    end)
    tripBtn:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -10)
    tripBtn.SetTint({ 1, 0.45, 0.6 })
    W.Tip(tripBtn, L.CART_TRIP, L.CART_TRIP_TIP)
    local merchantBtn = W.Button(right, L.BUY_MERCHANT, 190, function() ns.Cart.BuyFromMerchant() end)
    merchantBtn:SetPoint("LEFT", tripBtn, "RIGHT", 8, 0)
    merchantBtn.SetTint(C.amber)
    local nextBtn = W.Button(right, L.BUY_NEXT, 210)
    nextBtn:SetPoint("TOPRIGHT", right, "TOPRIGHT", -12, -10)
    nextBtn.SetTint(C.sky)
    local ahHint = W.Text(right, "small", "RIGHT")
    ahHint:SetPoint("RIGHT", nextBtn, "LEFT", -10, 0)
    ahHint:SetTextColor(C.label[1], C.label[2], C.label[3])

    local shopping = { ah = {}, vendor = {} }
    nextBtn:SetScript("OnClick", function()
        local st = ns.Buy.State()
        if st and st.step == "confirm" then ns.Buy.Confirm() return end
        if st then return end
        for _, row in ipairs(shopping.ah) do
            if row.buy > 0 then ns.Buy.Start(row.id, row.buy) return end
        end
    end)

    local function buyLabel(btn, id, buy)
        local st = ns.Buy.State()
        if st and st.id == id then
            if st.step == "confirm" then
                btn.SetLabel(string.format(L.BUY_CONFIRM, ns.Money(st.total, true)))
                btn.SetTint(C.gold)
            else
                btn.SetLabel(L.BUY_WAIT)
                btn.SetTint(nil)
            end
            btn.SetEnabledLook(true)
        else
            btn.SetLabel(L.BUY)
            btn.SetTint(nil)
            btn.SetEnabledLook(ns.Buy.ahOpen and not st and buy > 0)
        end
    end

    local function makeShop(parent)
        local r = CreateFrame("Frame", nil, parent)
        r.head = W.Text(r, "head", "LEFT")
        r.head:SetPoint("LEFT", r, "LEFT", 4, -2)
        r.icon = W.ItemIcon(r, 20)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.buy = W.Button(r, L.BUY, 130, function(self)
            local d = self:GetParent().data
            local st = ns.Buy.State()
            if st and st.id == d.row.id and st.step == "confirm" then ns.Buy.Confirm()
            elseif not st then ns.Buy.Start(d.row.id, d.row.buy) end
        end)
        r.buy:SetHeight(20)
        r.buy:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        -- a vendor line: the marker for its nearest merchant (instead of the buy button)
        r.pin = W.Button(r, "", 26)
        r.pin:SetSize(26, 20)
        r.pin.text:Hide()
        local g = r.pin:CreateTexture(nil, "OVERLAY")
        g:SetSize(12, 12); g:SetPoint("CENTER"); g:SetTexture(ns.MEDIA .. "pin.png"); g:SetVertexColor(1, 0.45, 0.6)
        r.pin:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        r.pin:SetScript("OnClick", function(self)
            local d = self:GetParent().data
            if not d or not d.row then return end
            local p = ns.Map.Nearest(ns.Cart.VendorPins(d.row.id))
            if p then ns.Map.Go(p) else ns.Print(L.MAP_NO_SPOT, ns.ItemName(d.row.id)) end
        end)
        W.Tip(r.pin, L.CART_PIN, L.CART_PIN_TIP)
        r.total = W.Text(r, "body", "RIGHT")
        r.total:SetWidth(90)
        r.total:SetPoint("RIGHT", r.buy, "LEFT", -10, 0)
        r.count = W.Text(r, "body", "RIGHT")
        r.count:SetWidth(50)
        r.count:SetPoint("RIGHT", r.total, "LEFT", -8, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 2)
        r.name:SetPoint("RIGHT", r.count, "LEFT", -6, 0)
        r.name:SetWordWrap(false)
        r.sub = W.Text(r, "tiny", "LEFT")
        r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -1)
        r.sub:SetTextColor(C.label[1], C.label[2], C.label[3])
        return r
    end
    local function fillShop(r, d)
        r.data = d
        local isHead = d.kind == "head"
        r.head:SetShown(isHead)
        for _, part in ipairs({ r.icon, r.buy, r.total, r.count, r.name, r.sub }) do part:SetShown(not isHead) end
        if isHead then r.pin:Hide() end
        if isHead then
            r.head:SetText(d.text)
            r.head:SetTextColor(d.color[1], d.color[2], d.color[3])
            return
        end
        local row = d.row
        r.icon.Set(row.id)
        r.name:SetText(ns.ItemName(row.id))
        local q = ns.Item(row.id) and ns.Item(row.id).quality or 1
        r.name:SetTextColor(ns.QualityColor(q))
        local sub = string.format(L.SHOP_NEED, row.need, row.have)
            .. (row.unit and ("  ·  " .. ns.Money(row.unit, true) .. " " .. L.UNIT) or ("  ·  " .. L.SHOP_NOPRICE))
        -- where, in words: a merchant (and which, the nearest) or the Auction House
        if d.where == "vendor" then
            local name, zone = ns.Cart.VendorOf(row.id)
            sub = sub .. "  ·  |cffef9e3d" .. L.FROM_VENDOR .. "|r" .. (name and (" " .. name .. (zone and (" (" .. ns.Place(tostring(zone)) .. ")") or "")) or "")
        elseif d.where == "ah" then
            sub = sub .. "  ·  |cff61a8f5" .. L.FROM_AH .. "|r"
        end
        r.sub:SetText(sub)
        r.count:SetText("×" .. row.buy)
        r.total:SetText(row.total and ns.Money(row.total, true) or "-")
        r.buy:SetShown(d.where == "ah")
        if d.where == "ah" then buyLabel(r.buy, row.id, row.buy) end
        r.pin:SetShown(d.where == "vendor" and #ns.Cart.VendorPins(row.id) > 0)
    end
    local shop = W.List(right, 34, makeShop, fillShop)
    shop:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -44)
    shop:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -8, 10)
    shop.Color(color)
    local shopEmpty = W.Text(right, "body", "CENTER")
    shopEmpty:SetPoint("TOPLEFT", shop, "TOPLEFT", 10, -40)
    shopEmpty:SetPoint("TOPRIGHT", shop, "TOPRIGHT", -10, -40)
    shopEmpty:SetWordWrap(true)
    shopEmpty:SetTextColor(C.label[1], C.label[2], C.label[3])

    function page.Refresh()
        local data = ns.Cart.Lines()
        lines.SetData(data, true)
        emptyCart:SetShown(#data == 0)
        shopping = ns.Cart.Shopping()
        local items = {}
        if #shopping.vendor > 0 then
            items[#items + 1] = { kind = "head", text = L.SHOP_VENDOR, color = C.amber }
            for _, row in ipairs(shopping.vendor) do items[#items + 1] = { kind = "item", row = row, where = "vendor" } end
        end
        if #shopping.ah > 0 then
            items[#items + 1] = { kind = "head", text = L.SHOP_AH, color = C.sky }
            for _, row in ipairs(shopping.ah) do items[#items + 1] = { kind = "item", row = row, where = "ah" } end
        end
        if #shopping.none > 0 then
            items[#items + 1] = { kind = "head", text = L.SHOP_NOPRICE, color = C.loss }
            for _, row in ipairs(shopping.none) do items[#items + 1] = { kind = "item", row = row, where = "none" } end
        end
        shop.SetData(items, true)
        shopEmpty:SetShown(#items == 0)
        shopEmpty:SetText(#data == 0 and "" or L.SHOP_HAVE)
        totals[1]:SetText(ns.Money(shopping.cost))
        totals[2]:SetText(shopping.value and ns.Money(shopping.value) or "-")
        W.ProfitText(totals[3], shopping.profit)
        merchantBtn:SetShown(ns.Cart.MerchantHasAny())
        tripBtn:SetShown(#shopping.vendor > 0)
        local st = ns.Buy.State()
        if st and st.step == "confirm" then
            nextBtn.SetLabel(string.format(L.BUY_CONFIRM, ns.Money(st.total, true)))
            nextBtn.SetTint(C.gold)
            nextBtn.SetEnabledLook(true)
        elseif st then
            nextBtn.SetLabel(L.BUY_WAIT)
            nextBtn.SetEnabledLook(false)
        else
            nextBtn.SetLabel(L.BUY_NEXT)
            nextBtn.SetTint(C.sky)
            nextBtn.SetEnabledLook(ns.Buy.ahOpen and #shopping.ah > 0)
        end
        ahHint:SetText(ns.Buy.ahOpen and "" or L.BUY_AH_CLOSED)
    end
end)
