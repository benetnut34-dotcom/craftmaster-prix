local _, ns = ...

-- What sells, and at what price. Two sources:
--   * in game, after each full scan: every listing is
--     compared with the previous full scan of the same Auction House; a
--     listing gone before it could expire most likely sold (or was taken
--     back: cheaper ones still for sale make that more likely). Each listing
--     keeps the window it ends in, from its time left at each scan (narrowed
--     scan after scan): gone after it, it expired; before it, it sold; in
--     between, the more likely one wins and a sale weighs less. Without the
--     time left (old scans), a listing gone after 12 hours or more expired.
--   * Blizzard's hourly pictures, compared on GitHub (craftmaster-prix),
--     with the listings' own numbers and their time left (to tell an expiry
--     from a sale), and the cheapest-first rule of commodities (to tell a
--     sale from a listing taken back): published per item and per house in
--     CraftMasterData.houses[key].sales, with the cheapest prices for sale
--     now in .depth.
-- From the sales: how many a day, at what prices (quartiles), how much of
-- what was listed sold, and a confidence score shown as 1 to 5 stars,
-- lowered for one offer by what is for sale under its price (OfferScore).
local T = {}
ns.Tracker = T

local MIN_DURATION = 12 * 3600  -- the shortest listing: gone before that, it didn't expire
local MAX_GAP = 48 * 3600       -- two scans further apart can't be compared
local WINDOW = 14 * 86400       -- sales kept
local MAX_EVENTS = 150          -- per item
local UNKNOWN = "0"             -- seller unknown (the game only names the player's own)
local MATCH_WINDOW = 3 * 3600   -- two players see the same sale a few hours apart

T.statsCache = {}

local function store(key)
    ns.db.sales = ns.db.sales or {}
    ns.db.sales[key] = ns.db.sales[key] or {}
    return ns.db.sales[key]
end
T.Store = store

-- Inside the scan's coroutine: give the frame back when its time slice is used up.
local function maybeYield(n)
    if n % 20 == 0 and ns.Work.Due() and coroutine.running() then coroutine.yield() end
end

-- A short print of the seller's name (the name itself is not kept).
function T.Hash(name)
    if not name or name == "" then return UNKNOWN end
    local h = 5381
    for i = 1, #name do h = (h * 33 + name:byte(i)) % 16777213 end
    return string.format("%x", h + 1)
end

-- An event: { time, unit price, quantity, weight, seller, shared, matched, aliases, mine }
--   weight > 0: a sale (1 sure, less when it may have been taken back); -1: expired
--   mine: "buy" a listing I bought myself (not a sale to the market: left out of
--   the figures and of the sharing), "sell" one of my own listings sold

-- My purchases, kept a while (14 days, per house and item): { time, unit price, units left }.
-- A listing I bought vanishes from the next scan like a sale: it is told apart by them.
local function myBuys(key)
    ns.db.myBuys = ns.db.myBuys or {}
    ns.db.myBuys[key] = ns.db.myBuys[key] or {}
    return ns.db.myBuys[key]
end
ns.On("Bought", function(id, qty, total)
    if not (id and qty and qty > 0 and total) then return end
    local s = myBuys(ns.HouseKey(ns.Scan.OpenHouse()))
    local l = s[id]
    if not l then l = {}; s[id] = l end
    l[#l + 1] = { time(), total / qty, qty }
    while #l > 30 do table.remove(l, 1) end
end)
-- a sale seen at time t, unit price p, q units: one of my purchases? (it is used up)
local function takeMyBuy(key, itemID, t, p, q)
    local l = ns.db.myBuys and ns.db.myBuys[key] and ns.db.myBuys[key][itemID]
    if not l then return false end
    for i, b in ipairs(l) do
        if b[1] <= t and t - b[1] <= 48 * 3600 and math.abs(b[2] - p) <= 1 and b[3] > 0 then
            b[3] = b[3] - q
            if b[3] <= 0 then table.remove(l, i) end
            return true
        end
    end
    return false
end
-- the seller print of my own listings (the game names the seller of mine only)
local function isMine(o)
    if not o or o == "0" or not UnitName then return false end
    local name = UnitName("player")
    if not name then return false end
    local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and (GetRealmName() or ""):gsub("%s", "")) or ""
    return o == T.Hash(name) or o == T.Hash(name .. "-" .. realm)
end
T.IsMine = isMine
function T.EventKey(t, p, q, w, o)
    return t .. ":" .. p .. ":" .. q .. ":" .. w .. ":" .. (o or "0")
end

local function findMatch(list, t, p, q, w, o)
    for _, e in ipairs(list) do
        if not e[7] and e[2] == p and e[3] == q and (e[4] > 0) == (w > 0) and (e[5] or "0") == (o or "0")
            and math.abs(e[1] - t) <= MATCH_WINDOW then
            return e
        end
    end
end

local counted   -- the scan being compared: { found, expired, new = {} }

-- Adds an event; false when it is one already known from another source.
function T.AddEvent(key, itemID, t, p, q, w, o, shared)
    p = math.floor(p + 0.5)
    local s = store(key)
    local list = s[itemID]
    if not list then list = {}; s[itemID] = list end
    local m = findMatch(list, t, p, q, w, o)
    if m and (m[6] or shared) then
        m[7] = true
        if shared then
            m[8] = m[8] or {}
            m[8][#m[8] + 1] = T.EventKey(t, p, q, w, o)
        end
        return false
    end
    local e = { t, p, q, w, o, shared or nil }
    if not shared and w > 0 then
        if takeMyBuy(key, itemID, t, p, q) then e[9] = "buy" elseif isMine(o) then e[9] = "sell" end
    end
    list[#list + 1] = e
    if #list > MAX_EVENTS then table.remove(list, 1) end
    if not shared and counted and e[9] ~= "buy" then
        if w > 0 then counted.found = counted.found + w else counted.expired = counted.expired + 1 end
        counted.new[#counted.new + 1] = { itemID, e }
    end
    T.statsCache[key] = nil
    return true
end

local function classify(key, itemID, gone, news, minKept, tB)
    for _, d in ipairs(gone) do
        -- 1) part of a stack bought: same seller, same unit price, fewer left
        if d.o ~= UNKNOWN then
            for _, nw in ipairs(news) do
                if not nw.used and nw.o == d.o and nw.c < d.c and nw.b * d.c == d.b * nw.c then
                    nw.used, d.done, nw.fs = true, true, d.fs
                    T.AddEvent(key, itemID, tB, d.b / d.c, d.c - nw.c, 1, d.o)
                    break
                end
            end
        end
        -- 2) taken back and listed again: same seller, same quantity, another price
        if not d.done and d.o ~= UNKNOWN then
            for _, nw in ipairs(news) do
                if not nw.used and nw.o == d.o and nw.c == d.c then
                    nw.used, d.done = true, true
                    break
                end
            end
        end
        -- 3) a sale, or an expiry: by its end window when the scans gave its
        --    time left, else by its age
        if not d.done then
            local unit = d.b / d.c
            local pExp
            if d.hi then
                local lo = math.max(d.lo, d.seen or d.lo)
                if tB >= d.hi then pExp = 1
                elseif tB <= lo then pExp = 0
                else pExp = (tB - lo) / math.max(1, d.hi - lo) end
            else
                pExp = (tB - d.fs >= MIN_DURATION) and 1 or 0
            end
            if pExp >= 0.5 then
                T.AddEvent(key, itemID, tB, unit, d.c, -1, d.o)
            else
                -- buyers take the cheapest: gone while much cheaper ones stay, it was more likely taken back
                local w = (not minKept or unit <= minKept * 1.05) and 1 or 0.25
                if d.o == UNKNOWN then w = w * 0.5 end
                w = w * (1 - pExp)
                T.AddEvent(key, itemID, tB, unit, d.c, w, d.o)
            end
        end
    end
end

-- Time left of a listing, as the scan gives it (1 short ... 4 very long):
-- when it may end, from now. Forever sells for 2, 8 or 24 hours (as Classic,
-- confirmed in game): short < 30 min, medium 30 min - 2 h, long 2 - 8 h, very long 8 - 24 h.
local BANDS = { { 0, 1800 }, { 1800, 7200 }, { 7200, 8 * 3600 }, { 8 * 3600, 24 * 3600 } }
local MAX_LISTING = 24 * 3600
T.BANDS = BANDS
local tlShift   -- the scan being compared: added to the game's time left to get 1-4 (nil: unknown)

-- The end window of a listing seen at tB: its band now, narrowed by the
-- window of the previous scan (both are true), never past 48 h after it was first seen.
local function window(band, tB, fs, plo, phi)
    local b = band and BANDS[band]
    local lo, hi
    if b then lo, hi = tB + b[1], tB + b[2] end
    if plo then
        if not lo then lo, hi = plo, phi
        elseif math.max(lo, plo) <= math.min(hi, phi) then lo, hi = math.max(lo, plo), math.min(hi, phi) end
    end
    if not lo then return nil end
    hi = math.max(lo, math.min(hi, fs + MAX_LISTING))
    return lo, hi
end

-- One item between two scans; returns its new print: "seller,count,buyout,first seen[/end from/end to];..."
local function diff(key, itemID, curList, prevStr, tA, tB, canDiff)
    local prevMap = {}
    if prevStr then
        for o, c, b, fs, w in prevStr:gmatch("(%x+),(%d+),(%d+),(%d+)([/%d]*)") do
            local k = o .. "," .. c .. "," .. b
            local t = prevMap[k]
            if not t then t = {}; prevMap[k] = t end
            local lo, hi = w:match("^/(%d+)/(%d+)$")
            t[#t + 1] = { tonumber(fs), tonumber(lo), tonumber(hi) }
        end
    end
    local news, minKept = {}, nil
    for _, a in ipairs(curList or {}) do
        local t = prevMap[a.o .. "," .. a.c .. "," .. a.b]
        local u = a.b / a.c
        if not minKept or u < minKept then minKept = u end
        local p
        if t and #t > 0 then
            p = table.remove(t)
            a.fs = p[1]
        else
            a.fs = tA or tB   -- new since the last scan
            news[#news + 1] = a
        end
        local band = a.t and tlShift and a.t + tlShift
        if band and not BANDS[band] then band = nil end
        a.lo, a.hi = window(band, tB, a.fs, p and p[2], p and p[3])
    end
    if canDiff then
        local gone = {}
        for k, t in pairs(prevMap) do
            if #t > 0 then
                local o, c, b = k:match("^(%x+),(%d+),(%d+)$")
                c, b = tonumber(c), tonumber(b)
                for _, p in ipairs(t) do
                    gone[#gone + 1] = { o = o, c = c, b = b, fs = p[1], lo = p[2], hi = p[3], seen = tA }
                end
            end
        end
        if #gone > 0 then classify(key, itemID, gone, news, minKept, tB) end
    end
    if not curList or #curList == 0 then return nil end
    local parts = {}
    for i, a in ipairs(curList) do
        parts[i] = a.o .. "," .. a.c .. "," .. a.b .. "," .. a.fs .. (a.lo and ("/" .. a.lo .. "/" .. a.hi) or "")
    end
    return table.concat(parts, ";")
end

-- After a full scan of `house` ("faction"/"neutral"): listings = { [id] = { {o, c, b, t}, ... } }
-- (t: the game's time left, raw; `shift` turns it into 1 short ... 4 very long, nil when unknown).
-- Returns sales found, expiries, seconds since the previous scan; nil when
-- the two can't be compared (first scan, or too far apart).
function T.Process(house, listings, tB, shift)
    tlShift = shift
    local key = ns.HouseKey(house)
    ns.db.snapFull = ns.db.snapFull or {}
    local prev = ns.db.snapFull[key] or {}
    local tA = prev.time
    local canDiff = tA ~= nil and (tB - tA) > 60 and (tB - tA) < MAX_GAP
    local prevItems = prev.items or {}
    local newItems, n = {}, 0
    counted = { found = 0, expired = 0, new = {} }
    for itemID in pairs(listings) do
        newItems[itemID] = diff(key, itemID, listings[itemID], prevItems[itemID], tA, tB, canDiff)
        n = n + 1
        maybeYield(n)
    end
    for itemID in pairs(prevItems) do
        if not listings[itemID] then
            newItems[itemID] = diff(key, itemID, nil, prevItems[itemID], tA, tB, canDiff)
            n = n + 1
            maybeYield(n)
        end
    end
    ns.db.snapFull[key] = { time = tB, items = newItems }
    ns.db.trackSince = ns.db.trackSince or {}
    ns.db.trackSince[key] = ns.db.trackSince[key] or tB
    T.Prune(key)
    T.statsCache[key] = nil
    T.lastNew = counted.new
    local c = counted
    counted = nil
    ns.Fire("SalesChanged", key)
    if not canDiff then return nil end
    return c.found, c.expired, tB - tA
end

function T.Prune(key)
    local cutoff = time() - WINDOW
    local s = store(key)
    for itemID, list in pairs(s) do
        local keep = {}
        for _, e in ipairs(list) do if e[1] >= cutoff then keep[#keep + 1] = e end end
        s[itemID] = (#keep > 0) and keep or nil
    end
end

-- ---------------------------------------------------------------------
-- Statistics and the resale score
-- ---------------------------------------------------------------------

local function percentile(pts, total, pct)
    local target, acc = total * pct, 0
    for _, s in ipairs(pts) do
        acc = acc + s.w
        if acc >= target then return s.p end
    end
    return pts[#pts].p
end

-- The score (0-100): enough sales, on several days, at a steady price,
-- most of what was listed sold, and recently.
local function score(n, nDays, spread, through, age)
    local sAmount = math.min(1, n / 8)
    local sDays = math.min(1, nDays / 3)
    local sStab = math.max(0, 1 - spread)
    local recency = age < 3 * 86400 and 1 or 0.6
    return math.floor(100 * (0.35 * sAmount + 0.25 * sDays + 0.2 * sStab + 0.2 * through) * recency + 0.5)
end
T.Score = score

-- In-game sales of one item at one house: { n (sales), units, days (calendar
-- days with a sale), span (days watched, 1 to 14), p25, p50, p75, perDay
-- (units / span), through, expired, last, score, from = "scans" } or nil.
local function fromScans(key, itemID)
    local list = ns.db.sales and ns.db.sales[key] and ns.db.sales[key][itemID]
    if not list then return nil end
    local now = time()
    local cutoff = now - WINDOW
    local pts, wsum, units, expired, days, last, first = {}, 0, 0, 0, {}, 0, now
    for _, e in ipairs(list) do
        if e[1] >= cutoff and e[9] ~= "buy" then
            if e[1] < first then first = e[1] end
            if e[4] > 0 then
                pts[#pts + 1] = { p = e[2], w = e[4] }
                wsum = wsum + e[4]
                units = units + e[3] * e[4]
                days[math.floor(e[1] / 86400)] = true
                if e[1] > last then last = e[1] end
            else
                expired = expired + e[3]
            end
        end
    end
    if wsum <= 0 then
        if expired > 0 then return { n = 0, units = 0, days = 0, span = 1, perDay = 0, through = 0, expired = expired, score = 0, from = "scans" } end
        return nil
    end
    table.sort(pts, function(a, b) return a.p < b.p end)
    local p25, p50, p75 = percentile(pts, wsum, 0.25), percentile(pts, wsum, 0.5), percentile(pts, wsum, 0.75)
    local nDays = 0
    for _ in pairs(days) do nDays = nDays + 1 end
    -- watched since the first scan compared, or the oldest event kept (imported, shared)
    local since = math.min(ns.db.trackSince and ns.db.trackSince[key] or now, first)
    local span = math.min(14, math.max(1, (now - since) / 86400))
    local through = units / (units + expired)
    local spread = p50 > 0 and (p75 - p25) / p50 or 1
    local snap = ns.db.snapFull and ns.db.snapFull[key]
    return { n = wsum, units = units, days = nDays, span = span, p25 = p25, p50 = p50, p75 = p75, perDay = units / span,
             through = through, expired = expired, last = last, from = "scans", at = snap and snap.time or last,
             score = score(wsum, nDays, spread, through, now - last) }
end

-- Blizzard's hourly sales, as published: "id=n,units,expired,days,p25,p50,p75,last,span;..."
local blizz = {}   -- [key] = { at, items = { [id] = stats } }
local SALES_LINE = "(%d+)=([%d.]+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),([%d.]+);"
local function addSale(b, id, n, units, expired, days, p25, p50, p75, last, span)
    b.items[tonumber(id)] = { tonumber(n), tonumber(units), tonumber(expired), tonumber(days), tonumber(p25),
        tonumber(p50), tonumber(p75), tonumber(last), tonumber(span) }
end
local function fromBlizzard(key, itemID)
    local d = CraftMasterData
    local h = type(d) == "table" and type(d.houses) == "table" and d.houses[key]
    if not h or type(h.sales) ~= "string" then return nil end
    local b = blizz[key]
    if not b or b.at ~= h.at then
        -- not read ahead yet (T.Warm): all of it now
        b = { at = h.at, items = {} }
        for id, n, units, expired, days, p25, p50, p75, last, span in h.sales:gmatch(SALES_LINE) do
            addSale(b, id, n, units, expired, days, p25, p50, p75, last, span)
        end
        blizz[key] = b
    end
    local e = b.items[itemID]
    if not e then return nil end
    local n, units, expired, nDays, p25, p50, p75, last, span = unpack(e)
    local through = (units + expired) > 0 and units / (units + expired) or 0
    local spread = p50 > 0 and (p75 - p25) / p50 or 1
    return { n = n, units = units, days = nDays, span = math.max(1, span), p25 = p25, p50 = p50, p75 = p75,
             perDay = units / math.max(1, span), through = through, expired = expired, last = last,
             from = "blizzard", at = h.at, score = n > 0 and score(n, nDays, spread, through, time() - last) or 0 }
end

-- The sales of an item at a house ("faction"/"neutral", default: the one shown).
-- Blizzard's when it has some (every hour, day and night), else the scans'.
function T.Stats(itemID, house)
    local key = ns.HouseKey(house)
    local cache = T.statsCache[key]
    if not cache then cache = {}; T.statsCache[key] = cache end
    local c = cache[itemID]
    if c ~= nil then return c or nil end
    local st = fromBlizzard(key, itemID)
    local own = fromScans(key, itemID)
    if not st or (own and own.n > st.n) then st = own end
    cache[itemID] = st or false
    return st
end
ns.SaleStats = T.Stats

-- 1 to 5 stars (0: no sale seen yet)
local STAR_AT = { 85, 70, 50, 30, 1 }
function T.Stars(sc)
    if not sc or sc <= 0 then return 0 end
    for i, t in ipairs(STAR_AT) do
        if sc >= t then return 6 - i end
    end
    return 0
end

local STAR = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:%d:%d:0:0:64:64:0:64:0:64%s|t"
function T.StarString(sc, size)
    size = size or 12
    local n, out = T.Stars(sc), {}
    for i = 1, 5 do out[i] = STAR:format(size, size, i <= n and "" or ":70:70:70") end
    return table.concat(out)
end

-- ---------------------------------------------------------------------
-- Competition: what is for sale now under a price
-- ---------------------------------------------------------------------

-- Blizzard's cheapest prices for sale, as published for the items that sell:
-- "id=price:units,price:units;..." (the 6 lowest prices, units added up).
local depths = {}   -- [key] = { at, items = { [id] = { {price, units}, ... } } }
local DEPTH_LINE = "(%d+)=([%d:,]+);"
local function addDepth(b, id, lv)
    local ladder = {}
    for p, q in lv:gmatch("(%d+):(%d+)") do ladder[#ladder + 1] = { tonumber(p), tonumber(q) } end
    b.items[tonumber(id)] = ladder
end
local function blizzDepth(key, itemID)
    local d = CraftMasterData
    local h = type(d) == "table" and type(d.houses) == "table" and d.houses[key]
    if not h or type(h.depth) ~= "string" then return nil end
    local b = depths[key]
    if not b or b.at ~= h.at then
        -- not read ahead yet (T.Warm): all of it now
        b = { at = h.at, items = {} }
        for id, lv in h.depth:gmatch(DEPTH_LINE) do addDepth(b, id, lv) end
        depths[key] = b
    end
    return b.items[itemID], h.at
end

-- Reading what Blizzard publishes for a house (the sales and the listings of
-- every item) takes 30 to 80 ms at once: read ahead, a few hundred lines per
-- frame, after the login, so that the first look at a house does not stall.
-- The same lines, the same tables as the reading at once.
function T.Warm(key)
    local d = CraftMasterData
    local h = type(d) == "table" and type(d.houses) == "table" and d.houses[key]
    if not h then return end
    local at = h.at
    local sb = type(h.sales) == "string" and not (blizz[key] and blizz[key].at == at) and { at = at, items = {} } or nil
    local db = type(h.depth) == "string" and not (depths[key] and depths[key].at == at) and { at = at, items = {} } or nil
    if not sb and not db then return end
    local sp, dp, n = 1, 1, 0
    ns.Work.Add("blizz", function()
        while sb do
            local s, e, id, a, b, c, d2, e2, f, g, i2, j = h.sales:find(SALES_LINE, sp)
            if not s then
                if not (blizz[key] and blizz[key].at == at) then blizz[key] = sb end
                sb = nil
                break
            end
            addSale(sb, id, a, b, c, d2, e2, f, g, i2, j)
            sp, n = e + 1, n + 1
            if n % 64 == 0 and ns.Work.Due() then return false end
        end
        while db do
            local s, e, id, lv = h.depth:find(DEPTH_LINE, dp)
            if not s then
                if not (depths[key] and depths[key].at == at) then depths[key] = db end
                db = nil
                break
            end
            addDepth(db, id, lv)
            dp, n = e + 1, n + 1
            if n % 64 == 0 and ns.Work.Due() then return false end
        end
        return true
    end)
end
-- for the tests: forget what was read
function T.ForgetBlizzard() blizz, depths = {}, {}; T.statsCache = {} end
local function warmBoth()
    T.Warm(ns.HouseKey("faction"))
    T.Warm(ns.HouseKey("neutral"))
end
ns.On("Login", function() if C_Timer and C_Timer.After then C_Timer.After(3, warmBoth) else warmBoth() end end)
ns.On("RulesetChanged", warmBoth)

local FULL_FRESH = 6 * 3600   -- an in-game full scan older than that loses to a newer Blizzard picture

-- What is for sale now, cheapest first: { {unit price, units, listings}, ... }, when, from.
-- "scans": the last full scan (every listing), when newer than Blizzard's
-- picture or under 6 hours old; else "blizzard": the picture's cheapest prices.
-- nil when nothing tells.
-- Read once while the listings stay the same (same scan text, same picture).
local ladders = {}   -- [key][id] = { lv, at, from, s, st, bAt }

-- The listings of a commodity read at the open Auction House just now (a search),
-- for the volume plans: the full scan (ReplicateItems) may still hold cheap listings
-- that the purchase does not find any more. My own listings are left out (I cannot
-- buy them). Newer than the full scan and under 30 minutes old, they win.
local live, liveAsked = {}, {}   -- live[key][id] = { lv, at } ; liveAsked[id] = { at, key }
T.LIVE_FRESH = 1800
function T.LiveAge(id)
    local l = live[ns.HouseKey(ns.House())]
    l = l and l[id]
    return l and (time() - l.at) or nil
end
function T.ForgetLive(id) for _, t in pairs(live) do t[id] = nil end end
-- Asks the game for the listings of a commodity (the Auction House open, no scan running).
function T.ReadLive(id)
    local AH = C_AuctionHouse
    if not (id and ns.Buy.ahOpen and AH and AH.SendSearchQuery and AH.MakeItemKey and AH.GetCommoditySearchResultInfo) then return false end
    if ns.Scan.Running() or not ns.Buy.IsCommodity(id) then return false end
    local a = liveAsked[id]
    if a and time() - a.at < 20 then return false end
    liveAsked[id] = { at = time(), key = ns.HouseKey(ns.Scan.OpenHouse()) }
    return (pcall(AH.SendSearchQuery, AH.MakeItemKey(id), {}, true))
end
ns.Register("COMMODITY_SEARCH_RESULTS_UPDATED", function(id)
    local a = id and liveAsked[id]
    if not a then return end
    local AH = C_AuctionHouse
    if AH.HasFullCommoditySearchResults and AH.RequestMoreCommoditySearchResults and not a.more then
        local okF, full = pcall(AH.HasFullCommoditySearchResults, id)
        if okF and full == false then
            a.more = true   -- once: the cheapest come first, that is what a plan buys
            if pcall(AH.RequestMoreCommoditySearchResults, id) then return end
        end
    end
    local n = AH.GetNumCommoditySearchResults and AH.GetNumCommoditySearchResults(id) or 0
    local lv, by = {}, {}
    for i = 1, n do
        local ok, r = pcall(AH.GetCommoditySearchResultInfo, id, i)
        if ok and type(r) == "table" and r.unitPrice and (r.quantity or 0) > 0 and not r.containsOwnerItem then
            local e = by[r.unitPrice]
            if not e then e = { r.unitPrice, 0, 0 }; by[r.unitPrice] = e; lv[#lv + 1] = e end
            e[2], e[3] = e[2] + r.quantity, e[3] + 1
        end
    end
    table.sort(lv, function(x, y) return x[1] < y[1] end)
    liveAsked[id] = nil
    live[a.key] = live[a.key] or {}
    live[a.key][id] = { lv = lv, at = time() }
    ns.Fire("LiveLadder", id)
end)
-- a purchase changes what is left: read again
ns.On("Bought", function(id) if id then T.ForgetLive(id) end end)
function T.Ladder(itemID, house)
    local key = ns.HouseKey(house)
    local snap = ns.db.snapFull and ns.db.snapFull[key]
    local lk = live[key] and live[key][itemID]
    if lk and time() - lk.at < T.LIVE_FRESH and lk.at >= ((snap and snap.time) or 0) then
        if #lk.lv == 0 then return nil end
        return lk.lv, lk.at, "live"
    end
    local s = snap and snap.items and snap.items[itemID]
    local d = CraftMasterData
    local h = type(d) == "table" and type(d.houses) == "table" and d.houses[key]
    local st, bAt = snap and snap.time, h and h.at
    local cache = ladders[key]
    if not cache then cache = {}; ladders[key] = cache end
    local hit = cache[itemID]
    if not (hit and hit.s == s and hit.st == st and hit.bAt == bAt) then
        local lv, at, from = T.ReadLadder(itemID, key, snap)
        hit = { lv, at, from, s = s, st = st, bAt = bAt }
        cache[itemID] = hit
    end
    local lv, at, from = hit[1], hit[2], hit[3]
    -- A later scan (a quick one: the cheapest price of each item only) says what
    -- is the cheapest for sale now: whatever the listings list under it is gone
    -- (bought or taken back); a cheaper price new since then is added (its
    -- units: what the later scan counted, less the ones kept).
    local b = ns.Scan.Book(house)
    local e = lv and at and b and b.at and b.at > at and b.items and b.items[itemID]
    if e and e[1] and lv[1] and lv[1][1] ~= e[1] then
        local kept, n = {}, 0
        for _, l in ipairs(lv) do
            if l[1] >= e[1] then kept[#kept + 1] = l; n = n + l[2] end
        end
        if not kept[1] or kept[1][1] > e[1] then
            table.insert(kept, 1, { e[1], math.max(1, (e[2] or 0) - n), 1 })
        end
        return kept, b.at, from
    end
    return lv, at, from
end

function T.ReadLadder(itemID, key, snap)
    local s = snap and snap.items and snap.items[itemID]
    local ladder, bAt = blizzDepth(key, itemID)
    if s and (not ladder or (snap.time or 0) >= (bAt or 0) or time() - (snap.time or 0) < FULL_FRESH) then
        -- one level per unit price (many listings share one): { price, units, listings }
        local lv, by = {}, {}
        for _, c, b in s:gmatch("(%x+),(%d+),(%d+),%d+") do
            c = tonumber(c)
            local u = tonumber(b) / c
            local e = by[u]
            if not e then e = { u, 0, 0 }; by[u] = e; lv[#lv + 1] = e end
            e[2], e[3] = e[2] + c, e[3] + 1
        end
        table.sort(lv, function(a, b) return a[1] < b[1] end)
        return lv, snap.time, "scans"
    end
    if ladder then
        local lv = {}
        for i, l in ipairs(ladder) do lv[i] = { l[1], l[2], 1 } end
        return lv, bAt, "blizzard"
    end
    return nil
end

-- Units for sale under a price: { units, listings, at, from }. `skip` leaves
-- out what I buy myself: true, the cheapest listing (a good deal); a number,
-- that many of the cheapest units (buying in volume). nil when nothing tells.
function T.Competition(itemID, price, house, skip)
    if not price then return nil end
    local lv, at, from = T.Ladder(itemID, house)
    if not lv then return nil end
    local left = type(skip) == "number" and skip or 0
    local units, n = 0, 0
    for i, l in ipairs(lv) do
        if l[1] < price then
            local c, k = l[2], l[3] or 1
            if skip == true and i == 1 then
                -- one listing of the cheapest price (its average size when several share it)
                c, k = c - c / k, k - 1
            elseif left > 0 then
                local t = math.min(left, c)
                k = c > 0 and math.ceil(k * (c - t) / c) or 0
                left, c = left - t, c - t
            end
            if c > 0 then units, n = units + c, n + k end
        end
    end
    return { units = units, listings = n, at = at, from = from }
end

-- Units for sale under a price, not counting the cheapest listing (the one I'd buy).
function T.CompetitionBelow(itemID, price, house)
    local c = T.Competition(itemID, price, house, true)
    return c and c.units or 0
end

-- Days to sell one at `price`, nil when unknown.
function T.DaysToSell(itemID, price, house)
    local st = T.Stats(itemID, house)
    if not st or not st.perDay or st.perDay <= 0 or not price then return nil end
    return (T.CompetitionBelow(itemID, price, house) + 1) / st.perDay
end

-- What the listings seen in game say about one price. Recent events weigh
-- more (last 2 days: 1, up to a week: 0.5, older: 0.25). An expiry at or
-- under the price counts in full against it (it didn't sell even that cheap);
-- above it, less and less (30 % above: nothing, it was only too dear).
-- { sold, expired (weighted units), through, sold24, expired24 (listings of
-- the last 24 hours, expiries at or near the price only) } or nil.
local DAY = 86400
local function recency(age)
    if age <= 2 * DAY then return 1 elseif age <= 7 * DAY then return 0.5 end
    return 0.25
end
local function expiryWeight(p, price)
    if p <= price then return 1 end
    return math.max(0, 1 - (p / price - 1) / 0.3)
end
T.ExpiryWeight = expiryWeight

function T.PriceEvidence(itemID, price, house)
    if not price or price <= 0 then return nil end
    local key = ns.HouseKey(house)
    local list = ns.db.sales and ns.db.sales[key] and ns.db.sales[key][itemID]
    if not list then return nil end
    local now = time()
    local sold, exp, sold24, exp24 = 0, 0, 0, 0
    for _, e in ipairs(list) do
        local age = math.max(0, now - e[1])
        if age < WINDOW and e[9] ~= "buy" then
            local r = recency(age)
            if e[4] > 0 then
                -- the game never names the seller, so every sale was halved for it
                -- (classify): that says nothing about the price, an expiry is not halved
                local w = ((e[5] or UNKNOWN) == UNKNOWN) and math.min(1, e[4] * 2) or e[4]
                sold = sold + e[3] * w * r
                if age <= DAY then sold24 = sold24 + w end
            else
                local w = expiryWeight(e[2], price)
                exp = exp + e[3] * w * r
                if age <= DAY and w >= 0.5 then exp24 = exp24 + 1 end
            end
        end
    end
    if sold + exp <= 0 then return nil end
    return { sold = sold, expired = exp, through = sold / (sold + exp), sold24 = sold24, expired24 = exp24 }
end

-- The confidence of one offer (0-100): the item's score (it sells, often, at
-- a steady price), lowered by what is for sale under my resale price now. A
-- buyer takes the cheapest first: units under my price that need days of
-- sales to go make my sale late or unlikely.
--   a day of sales or less under my price: score kept;
--   3 days: halved; 7 days: a quarter.
-- Then what the listings say about my price (PriceEvidence). On a busy
-- Auction House 30 to 45 % of what is listed sells: that is normal, not a risk.
--   less than 30 % sold: lowered (15 %: x0.75, nothing: x0.5);
--   less than 15 % sold, or more expiries than sales in 24 hours while it
--   sells little (under 3 a day): 2 stars at most;
--   3 expiries or more in 24 hours and no sale: 1 star.
-- More than 10 cheaper listings: 2 stars at most when they need more than a day of sales.
-- Second answer: { units, listings, days, from } (nil when nothing tells);
-- third: the evidence (nil when none).
local CAP_LISTINGS, CAP_SCORE, CAP_ONE = 10, 49, 29
local OK_THROUGH, LOW_THROUGH, FEW_SALES = 0.3, 0.15, 3

-- "hard": the listings say this price is not selling (2 stars at most);
-- "none": expiries and not one sale in 24 hours (1 star); nil: nothing alarming.
function T.EvidenceAlarm(ev)
    if not ev then return nil end
    if ev.expired24 >= 3 and ev.sold24 == 0 then return "none" end
    if ev.through < LOW_THROUGH or (ev.expired24 > ev.sold24 and ev.sold24 < FEW_SALES) then return "hard" end
    return nil
end
T.OK_THROUGH = OK_THROUGH

function T.OfferScore(itemID, price, house, skipCheapest)
    local st = T.Stats(itemID, house)
    if not st or (st.score or 0) <= 0 then return 0, nil, nil end
    local sc = st.score
    local c = T.Competition(itemID, price, house, skipCheapest)
    if c then
        local perDay = math.max(st.perDay or 0, 0.1)
        c.days = c.units / perDay
        if c.days > 1 then sc = sc / (1 + (c.days - 1) / 2) end
        if c.listings > CAP_LISTINGS and c.days > 1 then sc = math.min(sc, CAP_SCORE) end
    end
    local ev = T.PriceEvidence(itemID, price, house)
    if ev then
        if ev.through < OK_THROUGH then sc = sc * (0.5 + ev.through / OK_THROUGH * 0.5) end
        local alarm = T.EvidenceAlarm(ev)
        if alarm == "none" then sc = math.min(sc, CAP_ONE)
        elseif alarm == "hard" then sc = math.min(sc, CAP_SCORE) end
    end
    return math.max(1, math.floor(sc + 0.5)), c, ev
end

-- The price it really sells at: the low quartile of the sales seen (careful),
-- else nil. Second answer: the stats.
function T.Resale(itemID, house)
    local st = T.Stats(itemID, house)
    if st and st.n >= 2 and st.p25 then return st.p25, st end
    return nil, st
end

ns.On("Login", function() T.statsCache = {}; depths = {}; ladders = {} end)
ns.On("SalesChanged", function(key) if key then ladders[key] = nil end end)
