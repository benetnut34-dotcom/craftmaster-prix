local _, ns = ...
local L = ns.L

-- Keeping the history of the other Auction House addons.
--
-- Every addon that scans the Auction House keeps its own prices, in its own
-- saved file, and they are gone the day it is removed. CraftMaster copies
-- their daily lows into its own history, sorted by server type (ruleset) and
-- Auction House, so nothing is lost when an addon is changed.
--
--   Daylight UI    DaylightUIAuctionDB.rulesets["EU-PvP"].items[id].l = { day, low, ... }
--                  one book per ruleset, the three houses mixed together
--   Auctionator    AUCTIONATOR_PRICE_DATABASE["PvP Horde"] = CBOR of
--                  { [id] = { l = { [day] = low }, h = { [day] = price }, a = ... } }
--                  (days since 1 Jan 2020); one book per ruleset and faction
--   AuctionMaster  AuctionMasterDB.factions["Horde-14"].items.data[id] = { low, qty }
--                  (14 = game mode record of the ruleset); its last scan
--                  only, and never the shared house (it skips it)
--   AHDB           AuctionDBForeverSaved.houses["eu-forever-pvp Horde"].daily[id]
--                  = "ts,min,median,qty,scans ..." (180 days, the three houses apart)
--   Blizzard API   CraftMasterData (addon CraftMaster_Data, written every hour
--                  by the companion script): the three houses, 14 days
--   Auctioneer, TradeSkillMaster, Auctionator (when the book can't be read)
--                  their public price functions: today's price only
--   Files left by removed addons: converted out of the game into
--                  Data\Legacy.lua (ns.LEGACY), taken in once.
--
-- A book that mixes houses (Daylight UI), or one kept by faction but filled
-- at the shared house too (Auctionator), is only trusted on the days when
-- one house of that kind was opened: CraftMaster notes which houses its
-- characters open each day. Before CraftMaster noted it, every price was
-- scanned by Horde characters at the Horde house.
local I = {}
ns.Import = I

local LEGACY_FACTION = "Horde"
local AUCTIONATOR_DAY0 = 18262   -- 1 January 2020, in days since 1970
local stats = {}                 -- [source key] = { items, days, at }
I.stats = stats

-- ---------------------------------------------------------------------
-- Which house a day of a mixed book belongs to
-- ---------------------------------------------------------------------

function I.NoteOpened(houseKey)
    ns.db.opened = ns.db.opened or {}
    local day = ns.Today()
    ns.db.opened[day] = ns.db.opened[day] or {}
    ns.db.opened[day][houseKey] = true
    for d in pairs(ns.db.opened) do
        if d < day - 60 then ns.db.opened[d] = nil end
    end
end

ns.Register("AUCTION_HOUSE_SHOW", function()
    C_Timer.After(0.5, function()
        local house = ns.Scan.OpenHouse()
        I.NoteOpened(ns.HouseKey(house))
    end)
end)

-- The house a day of a book belongs to. `sides` lists the houses the book
-- may hold ("Horde", "Alliance", "Neutral"); nil when unsure.
local function houseOn(day, rs, sides, legacySide)
    local since = ns.db.since2 or ns.Today()
    if day < since then
        if legacySide then return rs .. "-" .. legacySide end
        return nil
    end
    local seen = ns.db.opened and ns.db.opened[day]
    if not seen then return nil end
    local found
    for _, side in ipairs(sides) do
        if seen[rs .. "-" .. side] then
            if found then return nil end
            found = rs .. "-" .. side
        end
    end
    return found
end

-- ---------------------------------------------------------------------
-- Writing
-- ---------------------------------------------------------------------

local wanted
local function want(id)
    if not wanted then wanted = ns.Recipes.Index().all end
    return wanted[id]
end
ns.On("RecipesChanged", function() wanted = nil end)

-- One price of one day of one house. Every item goes to the daily lows
-- (the usual price, 14 days); the items of a recipe also to the long history.
local function put(key, id, day, price, s)
    if type(id) ~= "number" or type(day) ~= "number" or type(price) ~= "number" or price <= 0 then return end
    day = math.floor(day)
    local lows = ns.Deals.StoreOf(key)
    lows[id] = lows[id] or {}
    ns.Deals.AddLow(lows[id], day, price)
    if want(id) and day >= ns.Today() - (ns.db.histDays or 90) then
        local h = ns.History.StoreOf(key)
        h[id] = ns.MergeDays(h[id] or {}, { day, price })
    end
    s.items[id] = true
    s.days[day] = true
end

local function newStats(key)
    local s = { items = {}, days = {} }
    return s, function()
        local ni, nd = 0, 0
        for _ in pairs(s.items) do ni = ni + 1 end
        for _ in pairs(s.days) do nd = nd + 1 end
        stats[key] = { items = ni, days = nd, at = time() }
    end
end

-- ---------------------------------------------------------------------
-- The readers
-- ---------------------------------------------------------------------

local function rulesetOf(name)
    if type(name) ~= "string" then return nil end
    for rs in pairs(ns.RULESETS) do
        if name == rs then return rs end
    end
    if name == "RP-PvP" or name == "RPPvP" then return "RPvP" end
end

local function itemOf(key)
    if type(key) == "number" then return key end
    if type(key) == "string" then return tonumber(key) or tonumber(key:match("^(%d+):")) end
end

local READERS = {}

-- Daylight UI: every ruleset it keeps, days given to a house when only one
-- was opened (any of the three).
READERS[#READERS + 1] = {
    key = "daylight", name = "Daylight UI",
    here = function() return type(DaylightUIAuctionDB) == "table" and type(DaylightUIAuctionDB.rulesets) == "table" end,
    read = function(s, since)
        for name, book in pairs(DaylightUIAuctionDB.rulesets) do
            local rs = rulesetOf(type(name) == "string" and name:match("%-(%w+)$"))
            if rs and type(book) == "table" and type(book.items) == "table" then
                local cache = {}
                for k, e in pairs(book.items) do
                    local id = itemOf(k)
                    if id and type(e) == "table" and type(e.l) == "table" then
                        for i = 1, #e.l - 1, 2 do
                            local day = e.l[i]
                            if type(day) == "number" and day >= since then
                                local key = cache[day]
                                if key == nil then
                                    key = houseOn(day, rs, { "Horde", "Alliance", "Neutral" }, LEGACY_FACTION) or false
                                    cache[day] = key
                                end
                                if key then put(key, id, day, e.l[i + 1], s) end
                            end
                        end
                    end
                end
            end
        end
    end,
}

-- Auctionator: its book of each ruleset and faction (the shared house may
-- be in it too, so a day counts only when one of the two was opened).
local function auctionatorBook(v)
    if type(v) == "table" then return v end
    if type(v) == "string" and C_EncodingUtil and C_EncodingUtil.DeserializeCBOR then
        local ok, t = pcall(C_EncodingUtil.DeserializeCBOR, v)
        if ok and type(t) == "table" then return t end
    end
end

READERS[#READERS + 1] = {
    key = "auctionator", name = "Auctionator",
    here = function() return type(AUCTIONATOR_PRICE_DATABASE) == "table" end,
    read = function(s, since)
        for name, raw in pairs(AUCTIONATOR_PRICE_DATABASE) do
            local rsName, side
            if type(name) == "string" then rsName, side = name:match("^(.-) (%a+)$") end
            local rs = rulesetOf(rsName)
            if rs and (side == "Horde" or side == "Alliance") then
                local book = auctionatorBook(raw)
                if book then
                    local cache = {}
                    for k, e in pairs(book) do
                        local id = itemOf(k)
                        if id and type(e) == "table" then
                            local days = {}
                            for _, t in ipairs({ "h", "l" }) do
                                if type(e[t]) == "table" then
                                    for d, p in pairs(e[t]) do
                                        d = tonumber(d)
                                        if d and type(p) == "number" and (not days[d] or p < days[d]) then days[d] = p end
                                    end
                                end
                            end
                            for d, p in pairs(days) do
                                local day = d + AUCTIONATOR_DAY0
                                if day >= since then
                                    local key = cache[day]
                                    if key == nil then
                                        key = houseOn(day, rs, { side, "Neutral" }, side) or false
                                        cache[day] = key
                                    end
                                    if key then put(key, id, day, p, s) end
                                end
                            end
                        end
                    end
                end
            end
        end
    end,
}

-- AuctionMaster: the last scan of each faction house (it keeps no daily
-- history and skips the shared house).
READERS[#READERS + 1] = {
    key = "am", name = "AuctionMaster",
    here = function() return type(AuctionMasterDB) == "table" and type(AuctionMasterDB.factions) == "table" end,
    read = function(s, since)
        for name, f in pairs(AuctionMasterDB.factions) do
            local side, mode
            if type(name) == "string" then side, mode = name:match("^(%a+)%-?(%d*)$") end
            mode = tonumber(mode)
            local rs = mode and ns.db.modes and ns.db.modes[mode]
            if not rs and (not mode or mode == ns.GameModeID()) then rs = (ns.Ruleset()) end
            local items = type(f) == "table" and f.items and f.items.data
            local at = type(f) == "table" and f.scan and f.scan.data and f.scan.data.lastSuccess
            if rs and (side == "Horde" or side == "Alliance") and type(items) == "table" and type(at) == "number" then
                local day = math.floor(at / 86400)
                if day >= since then
                    local key = rs .. "-" .. side
                    local low = {}
                    for k, e in pairs(items) do
                        local id = itemOf(k)
                        local p = type(e) == "table" and e[1]
                        if id and type(p) == "number" and (not low[id] or p < low[id]) then low[id] = p end
                    end
                    for id, p in pairs(low) do put(key, id, day, p, s) end
                end
            end
        end
    end,
}

-- AHDB (Auction House DataBase): AuctionDBForeverSaved.houses["eu-forever-pvp Horde"]
-- (region, ruleset, then "Horde", "Alliance" or "Neutral"), each with
-- daily[id] = "ts,min,median,qty,scans ..." (older days) and
-- items[id] = "ts,min,median,qty ..." (the scans of the last days).
local AHDB_RULESETS = { pve = "PvE", pvp = "PvP", rp = "RP", ["rp-pvp"] = "RPvP" }
local function ahdbRuleset(r)
    if type(r) ~= "string" then return nil end
    if r:find("hardcore", 1, true) then return "Hardcore" end
    return AHDB_RULESETS[r]
end

READERS[#READERS + 1] = {
    key = "ahdb", name = "AHDB",
    here = function() return type(AuctionDBForeverSaved) == "table" and type(AuctionDBForeverSaved.houses) == "table" end,
    read = function(s, since)
        for name, h in pairs(AuctionDBForeverSaved.houses) do
            local rsName, side
            if type(name) == "string" then rsName, side = name:match("%-forever%-(%S+) (%a+)$") end
            local rs = ahdbRuleset(rsName)
            if rs and (side == "Horde" or side == "Alliance" or side == "Neutral") and type(h) == "table" then
                local key = rs .. "-" .. side
                for _, part in ipairs({ "daily", "items" }) do
                    local list = h[part]
                    if type(list) == "table" then
                        for k, str in pairs(list) do
                            local id = type(k) == "number" and k or (type(k) == "string" and k:match("^%d+$") and tonumber(k))
                            if id and type(str) == "string" then
                                for entry in str:gmatch("%S+") do
                                    local ts, low = entry:match("^(%d+),(%d+)")
                                    local day = ts and math.floor(tonumber(ts) / 86400)
                                    low = tonumber(low)
                                    if day and day >= since and low > 0 then put(key, id, day, low, s) end
                                end
                            end
                        end
                    end
                end
            end
        end
    end,
}

-- Blizzard's Auction House API, through the CraftMaster companion (a script
-- on the PC, run every hour, that writes the CraftMaster_Data addon):
--   CraftMasterData = { at, ruleset, houses = { ["PvP-Horde"] = { id, at,
--     items = "id:price:qty;...", lows = "id=day:price,day:price;..." } } }
-- The three houses of the server type, even the ones never visited.
local function blizzHouses()
    local d = CraftMasterData
    if type(d) ~= "table" or type(d.houses) ~= "table" then return nil end
    return d.houses
end

local function parseItems(str)
    local items = {}
    if type(str) ~= "string" then return items end
    for id, p, q in str:gmatch("(%d+):(%d+):(%d+)") do
        p = tonumber(p)
        if p > 0 then items[tonumber(id)] = { p, tonumber(q) } end
    end
    return items
end
I.ParseBlizzard = parseItems

local function blizzKey(key)
    local rs, side = nil, nil
    if type(key) == "string" then rs, side = key:match("^(%a+)%-(%a+)$") end
    if rs and ns.RULESETS[rs] and (side == "Horde" or side == "Alliance" or side == "Neutral") then return key end
end

-- The daily lows of the Blizzard file, spread over several frames (ns.Work):
-- 3 houses x ~7000 items x up to 14 days is hundreds of thousands of small
-- writes, which in one go froze the game for a good fraction of a second.
-- Once the older days are known (`since` > 0), only the last entries of each
-- item are looked at.
local function lowsJob(s, since, finish)
    -- per house, two passes: the daily lows, then the picture itself (the
    -- price of the picture is a price of its day, even when the file's lows
    -- do not hold it yet)
    -- a house whose file has not changed since I last read it is skipped: what
    -- it holds is already in the saved history (`since` = 0 reads everything)
    ns.db.blizz = ns.db.blizz or { seen = {}, check = {} }
    ns.db.blizz.lowsAt = ns.db.blizz.lowsAt or {}
    local doneAt = ns.db.blizz.lowsAt
    local queue, houses = {}, {}
    for key, h in pairs(blizzHouses()) do
        if blizzKey(key) and type(h) == "table" and not (since > 0 and type(h.at) == "number" and doneAt[key] == h.at) then
            queue[#queue + 1] = { key = key, h = h, kind = "lows" }
            queue[#queue + 1] = { key = key, h = h, kind = "items" }
            houses[key] = h.at
        end
    end
    local qi, cur = 1, nil
    local function open(e)
        local h = e.h
        if e.kind == "lows" then
            if type(h.lows) == "string" and #h.lows > 0 then
                return { key = e.key, it = h.lows:gmatch("(%d+)=([^;]+)"), kind = "lows" }
            end
        elseif type(h.at) == "number" and math.floor(h.at / 86400) >= since and type(h.items) == "string" then
            return { key = e.key, it = h.items:gmatch("(%d+):(%d+):%d+"), kind = "items", day = math.floor(h.at / 86400) }
        end
    end
    ns.Work.Add("prix Blizzard", function()
        local n = 0
        while true do
            if not cur then
                local e = queue[qi]
                if not e then
                    for key, at in pairs(houses) do doneAt[key] = at end    -- read completely
                    return true
                end
                qi = qi + 1
                cur = open(e)
            end
            if cur then
                local a, b = cur.it()
                if not a then
                    cur = nil
                elseif cur.kind == "lows" then
                    local id = tonumber(a)
                    local seg = since > 0 and b:sub(-48) or b       -- the last days only
                    for d, p in seg:gmatch("(%d+):(%d+)") do
                        d = tonumber(d)
                        if d >= since then put(cur.key, id, d, tonumber(p), s) end
                    end
                else
                    put(cur.key, tonumber(a), cur.day, tonumber(b), s)
                end
                n = n + 1
                if n % 40 == 0 and ns.Work.Due() then return false end
            end
        end
    end, finish)
end

READERS[#READERS + 1] = {
    key = "blizzard", name = "Blizzard (API)",
    here = function() return blizzHouses() ~= nil end,
    async = true,
    -- finish() is called when everything is read (at once when ns.Work.Sync)
    read = function(s, since, finish) lowsJob(s, since, finish) end,
}

-- The newest Blizzard picture of each house becomes that house's scan, when
-- it is newer than mine; for the houses I use, it also feeds the hourly
-- trends (once per picture, and only if recent). Before that, it is checked
-- against my own scan of the same hour: if the two disagree, the house
-- numbers the companion uses are probably not mine.
-- The pictures kept in memory (not saved) for the houses I use: what the
-- companion brought, to compare my own scans with (Sync.lua sends only what
-- differs). I.apiRef[key] = { at, items }.
I.apiRef = {}

local function applyPictures(houses, pics)
    ns.db.scans = ns.db.scans or {}
    ns.db.blizz = ns.db.blizz or { seen = {}, check = {} }
    local mine = { [ns.HouseKey("faction")] = "faction", [ns.HouseKey("neutral")] = "neutral" }
    local n = 0
    for key, h in pairs(houses) do
        if blizzKey(key) and type(h) == "table" and type(h.at) == "number" then
            local book = ns.db.scans[key]
            if not book then book = { items = {} }; ns.db.scans[key] = book end
            local items
            -- the check: my own scan within 3 hours of the picture
            if book.at and book.from ~= "blizzard" and not book.fromGuild and math.abs(book.at - h.at) < 3 * 3600 then
                items = items or pics[key] or parseItems(h.items)
                local both, close = 0, 0
                for id, e in pairs(book.items) do
                    local b = items[id]
                    if b and e[1] and e[1] > 0 then
                        both = both + 1
                        local r = b[1] / e[1]
                        if r > 0.75 and r < 1.33 then close = close + 1 end
                    end
                end
                if both >= 30 then
                    local share = close / both
                    ns.db.blizz.check[key] = { share = share, n = both, house = h.id, at = time() }
                    if share < 0.4 then ns.Print(L.BLIZZ_MISMATCH, h.id or "?", key, math.floor(share * 100)) end
                end
            end
            if (h.at or 0) > (book.at or 0) then
                items = items or pics[key] or parseItems(h.items)
                book.items, book.at, book.from, book.fromGuild, book.house = items, h.at, "blizzard", nil, h.id
                n = n + 1
                local house = mine[key]
                if house and time() - h.at < 3 * 3600 and (ns.db.blizz.seen[key] or 0) < h.at then
                    ns.db.blizz.seen[key] = h.at
                    local t = date("*t", h.at)
                    ns.Timing.Observe(house, items, t.hour, t.wday)
                end
            end
            if mine[key] and type(h.prof) == "string" and ns.Timing.SetPipe(mine[key], h.prof, h.at) then n = n + 1 end
            if items and mine[key] then I.apiRef[key] = { at = h.at, items = items } end
        end
    end
    if n > 0 then
        ns.Prices.Reset()
        ns.Fire("PricesChanged")
        ns.Fire("TimingChanged")
    end
    return n
end

-- A picture is read (parsed) only when it is going to be used: newer than the
-- house's book, or close enough to my own scan to check it against.
local function needsPicture(key, h)
    local book = ns.db.scans and ns.db.scans[key]
    if not book or not book.at then return true end
    if (h.at or 0) > book.at then return true end
    return book.from ~= "blizzard" and not book.fromGuild and math.abs(book.at - h.at) < 3 * 3600
end

-- Applies the pictures. The reading of each picture (7000 items) is spread
-- over several frames; the result is the same as reading it in one go.
function I.ApplyBlizzard()
    local houses = blizzHouses()
    if not houses then return 0 end
    ns.db.scans = ns.db.scans or {}
    local pics, queue = {}, {}
    for key, h in pairs(houses) do
        if blizzKey(key) and type(h) == "table" and type(h.at) == "number" and type(h.items) == "string" and needsPicture(key, h) then
            queue[#queue + 1] = key
        end
    end
    local result = 0
    local qi, it, items = 1, nil, nil
    ns.Work.Add("photos Blizzard", function()
        local n = 0
        while true do
            if not it then
                local key = queue[qi]
                if not key then return true end
                qi = qi + 1
                it, items = houses[key].items:gmatch("(%d+):(%d+):(%d+)"), {}
                pics[key] = items
            end
            local id, p, q = it()
            if not id then
                it = nil
            else
                p = tonumber(p)
                if p > 0 then items[tonumber(id)] = { p, tonumber(q) } end
                n = n + 1
                if n % 200 == 0 and ns.Work.Due() then return false end
            end
        end
    end, function() result = applyPictures(houses, pics) end)
    return result
end

-- Public price functions: what they say today, for the house open now (or
-- the faction one), for the items of the recipes.
local function apiReader(key, name, here, price)
    return {
        key = key, name = name, here = here, api = true,
        read = function(s)
            local house = ns.Scan.OpenHouse and ns.Scan.OpenHouse()
            if not here() then return end
            local hk = ns.HouseKey(house == "neutral" and "neutral" or "faction")
            local day = ns.Today()
            for id in pairs(ns.Recipes.Index().all) do
                local ok, p = pcall(price, id)
                if ok and type(p) == "number" and p > 0 then put(hk, id, day, p, s) end
            end
        end,
    }
end

READERS[#READERS + 1] = apiReader("tsm", "TradeSkillMaster",
    function() return TSM_API and TSM_API.GetCustomPriceValue end,
    function(id) return TSM_API.GetCustomPriceValue("DBMinBuyout", "i:" .. id) end)

READERS[#READERS + 1] = apiReader("auctioneer", "Auctioneer",
    function() return AucAdvanced and AucAdvanced.API and AucAdvanced.API.GetMarketValue end,
    function(id)
        local link = "|cffffffff|Hitem:" .. id .. "::::::::::::|h[x]|h|r"
        return (AucAdvanced.API.GetMarketValue(link))
    end)

READERS[#READERS + 1] = apiReader("auctionatorApi", "Auctionator (API)",
    function()
        return Auctionator and Auctionator.API and Auctionator.API.v1 and Auctionator.API.v1.GetAuctionPriceByItemID
            and not (type(AUCTIONATOR_PRICE_DATABASE) == "table" and C_EncodingUtil and C_EncodingUtil.DeserializeCBOR)
    end,
    function(id) return Auctionator.API.v1.GetAuctionPriceByItemID("CraftMaster", id) end)

-- Files of removed addons, converted out of the game (Data\Legacy.lua).
READERS[#READERS + 1] = {
    key = "legacy", name = L.IMPORT_LEGACY,
    here = function() return type(ns.LEGACY) == "table" and type(ns.LEGACY.houses) == "table" end,
    once = function() return ns.LEGACY.id end,
    read = function(s)
        for key, items in pairs(ns.LEGACY.houses) do
            for id, list in pairs(items) do
                for i = 1, #list - 1, 2 do put(key, id, list[i], list[i + 1], s) end
            end
        end
    end,
}
I.READERS = READERS

-- ---------------------------------------------------------------------
-- Running
-- ---------------------------------------------------------------------

-- The readers whose addon is here.
function I.Found()
    local out = {}
    for _, r in ipairs(READERS) do
        local ok, yes = pcall(r.here)
        if ok and yes then out[#out + 1] = r end
    end
    return out
end

-- Takes in what is new (the last days again: a day still running may have
-- gone lower). `all` reads everything again.
function I.Run(all, quiet)
    if not ns.db then return 0 end
    ns.db.importAt = ns.db.importAt or {}
    ns.db.importDone = ns.db.importDone or {}
    local total = 0
    for _, r in ipairs(I.Found()) do
        local skip = false
        if r.once then
            local tag = r.once()
            if not all and ns.db.importDone[r.key] == tag then skip = true end
        end
        if not skip and r.async then
            -- read over several frames; what follows happens when it is done
            local since = all and 0 or ((ns.db.importAt[r.key] or 0) - 2)
            local s, done = newStats(r.key)
            local finished = false
            local ok, err = pcall(r.read, s, since, function()
                finished = true
                done()
                ns.db.importAt[r.key] = ns.Today()
                if stats[r.key].items > 0 then
                    ns.Prices.Reset()
                    ns.Fire("HistoryChanged")
                    if not quiet then ns.Print(L.IMPORT_DONE, stats[r.key].items) end
                end
                ns.Fire("ImportDone", stats[r.key].items)
            end)
            if not ok then ns.Debug("import %s: %s", r.key, tostring(err)) end
        elseif not skip then
            local since = all and 0 or ((ns.db.importAt[r.key] or 0) - 2)
            local s, done = newStats(r.key)
            local ok, err = pcall(r.read, s, since)
            done()
            if ok then
                ns.db.importAt[r.key] = ns.Today()
                if r.once then ns.db.importDone[r.key] = r.once() end
                total = total + stats[r.key].items
            else
                ns.Debug("import %s: %s", r.key, tostring(err))
            end
        end
    end
    if total > 0 then
        ns.Prices.Reset()
        ns.Fire("HistoryChanged")
        if not quiet then ns.Print(L.IMPORT_DONE, total) end
    end
    ns.Fire("ImportDone", total)
    return total
end

ns.On("Login", function()
    -- after the other addons' own start, and after the server type is known
    -- Blizzard's prices right away; the other addons' history a bit later,
    -- once they have started
    C_Timer.After(2, function() I.ApplyBlizzard() end)
    C_Timer.After(20, function()
        I.Run(false, true)
        I.ApplyBlizzard()
    end)
end)
-- the other addons write their scan when the house closes
ns.Register("AUCTION_HOUSE_CLOSED", function()
    C_Timer.After(3, function() I.Run(false, true) end)
end)
