local addonName, ns = ...

-- The look shared with Buffalo Forever: solid panels in a deep grey gradient
-- with soft corners, one plain color per page, Barlow for the text. With
-- Daylight UI installed (and wanted), its own controls are used instead.

local MEDIA = "Interface\\AddOns\\" .. addonName .. "\\Media\\"
ns.MEDIA = MEDIA

do
    local function usable(path)
        if not CreateFont then return false end
        local probe = CreateFont("CraftMasterFontProbe")
        local _, size = GameFontNormal:GetFont()
        local ok, res = pcall(probe.SetFont, probe, path, size or 12, "")
        return ok and res and true or false
    end
    for _, file in ipairs({ "Expressway.ttf", "Barlow-Medium.ttf" }) do
        if usable(MEDIA .. file) then ns.fontPath = MEDIA .. file break end
    end
    function ns.ApplyFont(fs, size)
        if not ns.fontPath or not fs or not fs.GetFont then return fs end
        local _, cur, flags = fs:GetFont()
        pcall(fs.SetFont, fs, ns.fontPath, size or cur or 12, flags)
        return fs
    end
end

local T = {}
ns.Theme = T

T.C = {
    gold = { 0.96, 0.77, 0.32 },    -- the brand
    profit = { 0.45, 0.85, 0.50 },  -- money made
    loss = { 0.94, 0.36, 0.26 },    -- money lost
    amber = { 0.94, 0.62, 0.24 },   -- vendor, "careful"
    sky = { 0.38, 0.66, 0.96 },     -- Auction House
    text = { 0.94, 0.945, 0.953 },
    label = { 0.64, 0.66, 0.69 },
    muted = { 0.50, 0.52, 0.56 },
}

-- The same meanings as colour codes, for text written in one piece ("|cff...").
T.HEX = {
    muted = "|cff8c8c99",
    profit = "|cff59d973",
    gold = "|cfff2b53a",
    loss = "|cffff6060",
    amber = "|cfff09e3d",
    sky = "|cff66bbff",
    guess = "|cffff8000",   -- a figure guessed, not read
    white = "|cffffffff",
}

T.SECTIONS = {
    recipes = { 1, 0.78, 0.12 },
    guide = { 1, 0.45, 0.6 },
    cart = { 0.25, 0.85, 0.45 },
    codex = { 0.2, 0.85, 0.75 },
    loot = { 1, 0.6, 0.15 },
    compare = { 1, 0.42, 0.35 },
    timing = { 0.85, 0.45, 1 },
    settings = { 0.68, 0.56, 1 },
    gmdeals = { 0.95, 0.71, 0.23 },
    gmcrafts = { 0.88, 0.58, 0.36 },
    gmvolume = { 0.52, 0.80, 0.42 },
    gmplans = { 0.85, 0.75, 0.50 },
    gmops = { 0.95, 0.45, 0.85 },
    gmshare = { 0.55, 0.82, 0.95 },
    data = { 0.3, 0.88, 0.78 },
    scans = { 0.42, 0.78, 1 },
    home = { 1, 0.78, 0.12 },
}

function ns.HasDaylight()
    local d = DaylightUI and DaylightUI.API
    return (d and d.major == 1) and true or false
end

function ns.DUI()
    local d = DaylightUI and DaylightUI.API
    if d and d.major == 1 and not (ns.db and ns.db.skin == "own") then return d end
end

-- A rounded shape that stretches: nine pieces of one 64 px texture whose
-- corners are 14 px, drawn `radius` px wide on screen.
local EDGE = 14 / 64
local function nine(frame, file, layer, radius, sub)
    local o = { parts = {}, radius = radius }
    local xs = { { 0, EDGE }, { EDGE, 1 - EDGE }, { 1 - EDGE, 1 } }
    for row = 1, 3 do
        for col = 1, 3 do
            local t = frame:CreateTexture(nil, layer, nil, sub or 0)
            t:SetTexture(MEDIA .. file)
            t:SetTexCoord(xs[col][1], xs[col][2], xs[row][1], xs[row][2])
            o.parts[(row - 1) * 3 + col] = t
        end
    end
    local p = o.parts
    p[1]:SetSize(radius, radius); p[1]:SetPoint("TOPLEFT")
    p[3]:SetSize(radius, radius); p[3]:SetPoint("TOPRIGHT")
    p[7]:SetSize(radius, radius); p[7]:SetPoint("BOTTOMLEFT")
    p[9]:SetSize(radius, radius); p[9]:SetPoint("BOTTOMRIGHT")
    p[2]:SetPoint("TOPLEFT", p[1], "TOPRIGHT"); p[2]:SetPoint("BOTTOMRIGHT", p[3], "BOTTOMLEFT")
    p[8]:SetPoint("TOPLEFT", p[7], "TOPRIGHT"); p[8]:SetPoint("BOTTOMRIGHT", p[9], "BOTTOMLEFT")
    p[4]:SetPoint("TOPLEFT", p[1], "BOTTOMLEFT"); p[4]:SetPoint("BOTTOMRIGHT", p[7], "TOPRIGHT")
    p[6]:SetPoint("TOPLEFT", p[3], "BOTTOMLEFT"); p[6]:SetPoint("BOTTOMRIGHT", p[9], "TOPRIGHT")
    p[5]:SetPoint("TOPLEFT", p[1], "BOTTOMRIGHT"); p[5]:SetPoint("BOTTOMRIGHT", p[9], "TOPLEFT")
    function o.Color(r, g, b, a) for i = 1, 9 do p[i]:SetVertexColor(r, g, b, a or 1) end end
    local function mix(a, b, t) return { a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, a[4] + (b[4] - a[4]) * t } end
    function o.Gradient(height, top, bottom)
        local f = (height and height > radius * 2) and radius / height or 0.5
        local stops = { 0, f, 1 - f, 1 }
        for row = 1, 3 do
            local hi, lo = mix(top, bottom, stops[row]), mix(top, bottom, stops[row + 1])
            for col = 1, 3 do
                local t = p[(row - 1) * 3 + col]
                local ok
                if t.SetGradient and CreateColor then
                    ok = pcall(t.SetGradient, t, "VERTICAL", CreateColor(lo[1], lo[2], lo[3], lo[4]), CreateColor(hi[1], hi[2], hi[3], hi[4]))
                end
                if not ok then t:SetVertexColor((hi[1] + lo[1]) / 2, (hi[2] + lo[2]) / 2, (hi[3] + lo[3]) / 2, (hi[4] + lo[4]) / 2) end
            end
        end
    end
    function o:SetColorTexture(r, g, b, a) o.Color(r, g, b, a) end
    function o:Show() for i = 1, 9 do p[i]:Show() end end
    function o:Hide() for i = 1, 9 do p[i]:Hide() end end
    return o
end

function T.Fill(frame, radius, layer, sub) return nine(frame, "panel.png", layer or "BACKGROUND", radius or 12, sub) end
function T.Edge(frame, radius, layer, sub) return nine(frame, "panel-edge.png", layer or "BORDER", radius or 12, sub) end

local KINDS = {
    window = { top = { 0.215, 0.225, 0.250, 1 }, bottom = { 0.070, 0.075, 0.090, 1 },
        lineTop = 0.26, lineBottom = 0.05, radius = 16 },
    float = { top = { 0.215, 0.225, 0.250, 1 }, bottom = { 0.070, 0.075, 0.090, 1 },
        lineTop = 0.26, lineBottom = 0.05, radius = 12 },
    card = { 0, 0, 0, alpha = 0.30, radius = 12, line = 0.06 },
    menu = { 0.120, 0.127, 0.147, alpha = 1, radius = 10, line = 0.16 },
    button = { 1, 1, 1, alpha = 0.07, radius = 8, line = 0.14 },
}

function T.Panel(frame, kind)
    if frame.cmPanel then return frame.cmPanel end
    local k = KINDS[kind] or KINDS.card
    local o = { kind = k }
    o.bg = T.Fill(frame, k.radius, "BACKGROUND", -6)
    o.line = T.Edge(frame, k.radius, "BACKGROUND", -5)
    function o.Paint()
        if k.top then
            local h = frame.GetHeight and frame:GetHeight() or 0
            o.bg.Gradient(h, k.top, k.bottom)
            o.line.Gradient(h, { 1, 1, 1, k.lineTop }, { 1, 1, 1, k.lineBottom })
        else
            o.bg.Color(k[1], k[2], k[3], k.alpha)
            o.line.Color(1, 1, 1, k.line)
        end
    end
    o.Paint()
    if k.top and frame.HookScript then frame:HookScript("OnSizeChanged", function() o.Paint() end) end
    frame.cmPanel = o
    return o
end
