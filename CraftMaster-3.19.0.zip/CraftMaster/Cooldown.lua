local _, ns = ...

-- Recipes with a cooldown (transmutes, mooncloth, salt...): how long it is,
-- and what other players pay for one, from the trade offers seen in chat
-- A craft on cooldown is ranked by its profit per day,
-- after taking off what the cooldown itself is worth.
local CD = {}
ns.Cooldown = CD

local MIN_CD = 3600            -- under an hour isn't a cooldown
local WINDOW = 14 * 86400      -- chat offers kept
local SAME_AUTHOR = 6 * 3600   -- a player repeating an offer counts once per 6 h
local MAX_OBS = 60

-- Known when the game can't tell (spell = recipe)
local KNOWN = {
    [17187] = 2 * 86400, -- Transmute: Arcanite
    [18560] = 4 * 86400, -- Mooncloth
}

local noCD = {}   -- checked this session: none

local UNITS = {
    { "(%d+)%s*jour", 86400 }, { "(%d+)%s*day", 86400 }, { "(%d+)%s*d[ií]a", 86400 },
    { "(%d+)%s*heure", 3600 }, { "(%d+)%s*hour", 3600 }, { "(%d+)%s*hora", 3600 }, { "(%d+)%s*h%f[%A]", 3600 },
    { "(%d+)%s*min", 60 },
}

local function parseDuration(text)
    text = text:lower()
    for _, u in ipairs(UNITS) do
        local n = text:match(u[1])
        if n then return tonumber(n) * u[2] end
    end
end

local function db()
    ns.db.cdOverride = ns.db.cdOverride or {}
    ns.db.cdPrice = ns.db.cdPrice or {}
    ns.db.cdObs = ns.db.cdObs or {}
    ns.db.cdKnown = ns.db.cdKnown or {}
    return ns.db
end

-- Seconds of cooldown (0 = none)
function CD.Get(recipeID)
    local d = db()
    local override = d.cdOverride[recipeID]
    if override then return override end
    if d.cdKnown[recipeID] then return d.cdKnown[recipeID] end
    if noCD[recipeID] then return 0 end
    local cd = KNOWN[recipeID] or 0
    if cd == 0 and GetSpellBaseCooldown then
        local ok, ms = pcall(GetSpellBaseCooldown, recipeID)
        if ok and type(ms) == "number" and ms > 0 then cd = ms / 1000 end
    end
    if cd < MIN_CD and C_TooltipInfo and C_TooltipInfo.GetSpellByID then
        local ok, data = pcall(C_TooltipInfo.GetSpellByID, recipeID)
        if ok and type(data) == "table" and type(data.lines) == "table" then
            for _, line in ipairs(data.lines) do
                for _, t in ipairs({ line.leftText, line.rightText }) do
                    if type(t) == "string" then
                        local low = t:lower()
                        if low:find("recharge", 1, true) or low:find("cooldown", 1, true) or low:find("reutiliz", 1, true) then
                            local s = parseDuration(t)
                            if s and s > cd then cd = s end
                        end
                    end
                end
            end
        end
    end
    if cd >= MIN_CD then
        d.cdKnown[recipeID] = cd
        return cd
    end
    noCD[recipeID] = true
    return 0
end

function CD.Label(seconds)
    if not seconds or seconds <= 0 then return nil end
    if seconds >= 86400 then
        local d = seconds / 86400
        return (d == math.floor(d) and string.format("%d %s", d, ns.L.CD_DAYS) or string.format("%.1f %s", d, ns.L.CD_DAYS))
    end
    return string.format("%d h", math.floor(seconds / 3600 + 0.5))
end

local function isTransmute(name)
    return name and name:lower():find("transmut", 1, true) ~= nil
end
-- Transmutes share one cooldown.
function CD.IsTransmute(recipeID)
    return isTransmute(ns.Recipes and ns.Recipes.Name(recipeID))
end

-- What a cooldown is worth: the price set by hand, else the median of the
-- chat offers. price, "manual"|"chat", how many offers, lowest, highest.
function CD.Price(recipeID)
    local d = db()
    local manual = d.cdPrice[recipeID]
    if manual then return manual, "manual", 0 end
    local obs = d.cdObs[recipeID]
    if not obs then return nil end
    local cutoff, vals = time() - WINDOW, {}
    for _, o in ipairs(obs) do if o.t >= cutoff then vals[#vals + 1] = o.p end end
    if #vals == 0 then return nil end
    table.sort(vals)
    local n = #vals
    local med = (n % 2 == 1) and vals[(n + 1) / 2] or (vals[n / 2] + vals[n / 2 + 1]) / 2
    return med, "chat", n, vals[1], vals[n]
end

-- ---------------------------------------------------------------------
-- Reading the chat
-- ---------------------------------------------------------------------

local STOP = {
    ["transmutation"] = true, ["transmute"] = true, ["transmutar"] = true, ["barre"] = true, ["barres"] = true,
    ["des"] = true, ["les"] = true, ["une"] = true, ["pour"] = true, ["avec"] = true, ["with"] = true, ["para"] = true,
}
local SELL = { "wts", "vends", "vend ", "dispo", "propose", "lfw", "je fais", "je peux", "offre", "vendo", "hago" }
local BUY = { "wtb", "cherche", "achète", "achete", "besoin", "recherche", "lf ", "busco", "compro" }

local index   -- the cooldown recipes of my professions and their words

local function tokens(text)
    local out = {}
    text = text:lower():gsub("[%p]", " ")
    for w in text:gmatch("%S+") do
        if #w >= 4 and not STOP[w] then out[#out + 1] = w end
    end
    return out
end

local function buildIndex()
    index = {}
    for id, r in pairs(ns.RECIPES) do
        if ns.profs and ns.profs[r.p] and CD.Get(id) > 0 then
            local name = ns.SpellName(id) or ""
            local base = name:match(":%s*(.+)$") or name
            local tk = tokens(base)
            local out = ns.Recipes.Output(id)
            if #tk == 0 and out then tk = tokens(ns.ItemName(out) or "") end
            index[#index + 1] = { id = id, out = out, tokens = tk, transmute = isTransmute(name) }
        end
    end
end
ns.On("ProfessionsChanged", function() index = nil end)

local function parseGold(low)
    for _, pat in ipairs({ "(%d+)%s*po%f[%A]", "(%d+)%s*p%.?o%.?", "(%d+)%s*g%f[%A]", "(%d+)%s*gold", "(%d+)%s*pi[eè]ce", "(%d+)%s*oro" }) do
        local n = tonumber(low:match(pat) or "")
        if n and n >= 1 and n <= 5000 then return n * 10000 end
    end
end

local function intent(low)
    for _, w in ipairs(BUY) do if low:find(w, 1, true) then return "buy" end end
    for _, w in ipairs(SELL) do if low:find(w, 1, true) then return "sell" end end
    return "?"
end

local function record(recipeID, price, kind, author)
    local d = db()
    local obs = d.cdObs[recipeID] or {}
    d.cdObs[recipeID] = obs
    local now = time()
    for _, o in ipairs(obs) do
        if o.a == author and now - o.t < SAME_AUTHOR then
            o.t, o.p, o.k = now, price, kind
            return
        end
    end
    obs[#obs + 1] = { t = now, p = price, k = kind, a = author }
    local cutoff = now - WINDOW
    for i = #obs, 1, -1 do if obs[i].t < cutoff then table.remove(obs, i) end end
    while #obs > MAX_OBS do table.remove(obs, 1) end
end

function CD.OnChat(text, author)
    if not ns.db or type(text) ~= "string" then return end
    if not index then buildIndex() end
    if #index == 0 then return end
    local raw = text
    local low = text:gsub("|H.-|h(.-)|h", "%1"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):lower()
    local price = parseGold(low)
    if not price then return end
    local talksCD = low:find("transmu", 1, true) or low:find("%f[%a]cd%f[%A]") or low:find("craft", 1, true)
        or low:find("tips?%f[%A]") or low:find("recharge", 1, true)
    if not talksCD then return end
    for _, e in ipairs(index) do
        -- a link to the item alone is often a sale of the item: the message must talk about the craft
        local hit = (e.out and raw:find("item:" .. e.out .. ":", 1, true)) or raw:find("spell:" .. e.id, 1, true)
            or raw:find("enchant:" .. e.id, 1, true)
        if not hit and #e.tokens > 0 then
            hit = true
            for _, w in ipairs(e.tokens) do
                if not low:find(w, 1, true) then hit = false; break end
            end
            if hit and not e.transmute and not low:find("%f[%a]cd%f[%A]") then hit = false end
        end
        if hit then
            record(e.id, price, intent(low), author or "?")
            return
        end
    end
end

for _, ev in ipairs({ "CHAT_MSG_CHANNEL", "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_GUILD" }) do
    ns.Register(ev, function(text, author)
        if ns.db and ns.db.readChat == false then return end
        local ok = pcall(CD.OnChat, text, author)
        if not ok then index = nil end
    end)
end
