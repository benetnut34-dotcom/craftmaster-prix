local _, ns = ...
local L = ns.L

-- A few CraftMaster lines under every item tooltip: the Auction House price
-- (both houses when both were scanned) and its trend, what a vendor asks and
-- pays, what crafting it costs and earns, what a recipe teaches and earns,
-- and what disenchanting gives. Hold Shift for a whole stack.

local GOLD = "|cffd9a441"
local GREY = "|cff9a9da3"

local function money(v) return v and ns.Money(v) or "-" end

local function trend(id, house)
    local s = ns.History.Series(id, 30, house)
    if #s < 2 then return "" end
    local t = ns.History.Stats(s).trend
    local c = t > 0 and "|cff73d982" or t < 0 and "|cffef5c42" or GREY
    return string.format("  %s%+d%%|r", c, math.floor(t * 100 + 0.5))
end

local function profitText(v)
    if not v then return "-" end
    local c = v >= 0 and "|cff73d982+" or "|cffef5c42"
    return c .. ns.Money(v, true) .. "|r"
end

local function add(tip, id)
    if not (ns.db and ns.db.tooltip ~= false) or not id then return end
    local i = ns.Item(id)
    if not i or not i.name then return end
    local n = (IsShiftKeyDown and IsShiftKeyDown() and (i.stack or 1) > 1) and i.stack or 1
    local each = n > 1 and (" |cff9a9da3x" .. n .. "|r") or ""
    local lines = {}

    -- Auction House: the faction's (Horde) price; the shared house is for the comparison tab only
    for _, house in ipairs({ "faction" }) do
        local p, _, qty = ns.Prices.AH(id, house)
        if p then
            local label = (house == "neutral" and L.HOUSE_NEUTRAL or ns.FactionName())
            local listed = qty and (GREY .. " (" .. qty .. ")|r") or ""
            lines[#lines + 1] = { L.HOUSE_PREFIX .. label .. each .. listed, money(p * n) .. trend(id, house) }
        end
    end
    local vb, guess = ns.Prices.VendorBuy(id)
    if vb and not guess then lines[#lines + 1] = { L.CODEX_VENDOR_BUY .. each, money(vb * n) } end
    if i.sell and i.sell > 0 then lines[#lines + 1] = { L.CODEX_VENDOR_SELL .. each, money(i.sell * n) } end

    local idx = ns.Recipes.Index()
    -- crafted: the cheapest recipe I know (or any) that makes it
    local made = idx.madeBy[id]
    if made then
        local best
        for _, sid in ipairs(made) do
            local p = ns.Recipes.Price(sid)
            local mine = ns.Recipes.IsKnown(sid)
            if p.cost and (not best or (mine and not best.mine) or (mine == best.mine and p.cost < best.p.cost)) then
                best = { sid = sid, p = p, mine = mine }
            end
        end
        if best then
            local p = best.p
            local each1 = p.n and p.n > 0 and p.n or 1
            lines[#lines + 1] = { L.TIP_CRAFT .. (best.mine and "" or (GREY .. " (" .. L.UNKNOWN .. ")|r")),
                money(p.cost / each1 * n) }
            if p.profit then
                local m = p.margin and string.format(" " .. GREY .. "(%+d%%)|r", math.floor(p.margin * 100 + 0.5)) or ""
                lines[#lines + 1] = { L.COL_PROFIT, profitText(p.profit / each1 * n) .. m }
            end
        end
    end
    -- a recipe item: what it teaches and earns
    local teaches = idx.teaches[id]
    if teaches then
        local r = ns.RECIPES[teaches]
        local known = ns.Recipes.IsKnown(teaches)
        local prof = ns.profs[r.p]
        local state = known and ("|cff73d982" .. L.KNOWN .. "|r")
            or (prof and r.sk and r.sk[1] <= prof.rank) and ("|cffd9a441" .. L.REACH .. "|r")
            or (GREY .. string.format(L.SKILL_NEED_NOPROF, L.PROF[r.p], r.sk and r.sk[1] or 0) .. "|r")
        lines[#lines + 1] = { L.CODEX_TEACHES .. ": " .. ns.Recipes.Name(teaches), state }
        local p = ns.Recipes.Price(teaches)
        if p.profit then lines[#lines + 1] = { L.TIP_RECIPE_PROFIT, profitText(p.profit) } end
    end
    -- gear: disenchanting
    if ns.Disenchant.Can(id) then
        local de = ns.Disenchant.Value(id)
        if de then lines[#lines + 1] = { L.LOOT_DE .. (ns.Disenchant.IsEnchanter() and "" or (GREY .. " *|r")), money(de) } end
    end
    -- a material of my professions
    local used = 0
    for _, sid in ipairs(idx.usedIn[id] or {}) do
        if ns.profs[ns.RECIPES[sid].p] then used = used + 1 end
    end
    if used > 0 then lines[#lines + 1] = { string.format(L.TIP_USED, used), "" } end

    if #lines == 0 then return end
    tip:AddLine(" ")
    tip:AddLine(GOLD .. "CraftMaster|r")
    for _, l in ipairs(lines) do tip:AddDoubleLine(l[1], l[2], 0.8, 0.82, 0.86, 1, 1, 1) end
    if n == 1 and (i.stack or 1) > 1 then tip:AddLine(GREY .. string.format(L.TIP_SHIFT, i.stack) .. "|r") end
    tip:Show()
end

local function idOf(tip, data)
    if type(data) == "table" and type(data.id) == "number" then return data.id end
    if tip and tip.GetItem then
        local _, link = tip:GetItem()
        local id = link and tonumber(link:match("item:(%d+)"))
        if id then return id end
    end
end

ns.On("Loaded", function()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tip, data)
            if tip ~= GameTooltip and tip ~= ItemRefTooltip then return end
            local ok, err = pcall(add, tip, idOf(tip, data))
            if not ok then ns.Debug("tooltip: %s", tostring(err)) end
        end)
    elseif GameTooltip and GameTooltip.HookScript then
        for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
            if tip then
                tip:HookScript("OnTooltipSetItem", function(self)
                    pcall(add, self, idOf(self))
                end)
            end
        end
    end
end)

ns.Tooltip = { Add = add }
