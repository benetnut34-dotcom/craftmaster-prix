local _, ns = ...

-- When to buy, when to sell: every scan (mine or a guild mate's) says, for
-- the hour and the day of the week it was made, how far prices stood from
-- their usual level and how much was for sale. Averaged over the whole
-- market, and per item for the items of my professions and my cart.
-- A price index under 0 % = cheaper than usual = a good time to buy.
local T = {}
ns.Timing = T

local function store(house)
    ns.db.timing = ns.db.timing or {}
    local k = ns.HouseKey(house or "faction")
    local s = ns.db.timing[k]
    if not s then
        s = { g = {}, w = {}, i = {}, pipe = {} }
        ns.db.timing[k] = s
    end
    s.g, s.w, s.i, s.pipe = s.g or {}, s.w or {}, s.i or {}, s.pipe or {}
    return s
end

local function qavg(house)
    ns.db.qavg = ns.db.qavg or {}
    local k = ns.HouseKey(house or "faction")
    ns.db.qavg[k] = ns.db.qavg[k] or {}
    return ns.db.qavg[k]
end

local function bump(t, key, r, q)
    local b = t[key]
    if not b then b = { 0, 0, 0, 0 }; t[key] = b end  -- sum of price ratios, count, sum of supply ratios, supply count
    b[1] = b[1] + r
    b[2] = b[2] + 1
    if q then b[3] = b[3] + q; b[4] = b[4] + 1 end
end

-- items: { [id] = { price, qty } } seen at `hour` (0-23) on `wday` (1 = Sunday).
function T.Observe(house, items, hour, wday)
    local s = store(house)
    local qa = qavg(house)
    local tracked = ns.History.Tracked()
    -- one point per item and hour: the market's mean of the ratios
    local sumR, n, sumQ, nq = 0, 0, 0, 0
    for id, e in pairs(items) do
        local usual = ns.Deals.Usual(id, house)
        if usual and usual > 0 and e[1] and e[1] > 0 then
            local r = math.max(0.2, math.min(3, e[1] / usual))
            local q
            local avg = qa[id]
            if avg and avg > 0 and e[2] then q = math.max(0.1, math.min(5, e[2] / avg)) end
            sumR, n = sumR + r, n + 1
            if q then sumQ, nq = sumQ + q, nq + 1 end
            if tracked[id] then
                s.i[id] = s.i[id] or {}
                bump(s.i[id], hour, r, q)
            end
        end
        if e[2] and e[2] > 0 then
            local avg = qa[id]
            qa[id] = avg and (avg * 0.7 + e[2] * 0.3) or e[2]
        end
    end
    if n >= 20 then
        local r, q = sumR / n, nq > 0 and sumQ / nq or nil
        bump(s.g, hour, r, q)
        bump(s.w, wday * 100 + hour, r, q)
        s.scans = (s.scans or 0) + 1
    end
end

local function index(b)
    if not b or b[2] == 0 then return nil end
    return b[1] / b[2] - 1, b[4] > 0 and (b[3] / b[4] - 1) or nil, b[2]
end

-- The hourly profile the price pipeline publishes (one photo an hour, 24 a day,
-- far more than my own scans): "weekday:hour:index:days;..." in UTC, index in
-- thousandths of the usual price. Put back on the local clock, kept apart from
-- my own scans and blended with them when read.
function T.SetPipe(house, str, at)
    local s = store(house)
    if type(str) ~= "string" or str == "" or (s.pipeAt or 0) >= (at or 0) then return false end
    local sunday = math.floor((time() / 86400 - 3) / 7) * 7 + 3     -- epoch day 3 is a Sunday
    local pipe = {}
    for wd, h, milli, n in str:gmatch("(%d+):(%d+):(%d+):(%d+);") do
        wd, h, milli, n = tonumber(wd), tonumber(h), tonumber(milli), tonumber(n)
        local t = date("*t", (sunday + wd - 1) * 86400 + h * 3600)
        local k = t.wday * 100 + t.hour
        local b = pipe[k]
        if not b then b = { 0, 0 }; pipe[k] = b end
        b[1] = b[1] + milli / 1000 * n
        b[2] = b[2] + n
    end
    s.pipe, s.pipeAt = pipe, at
    return true
end

-- my own bucket and the pipeline's, as one { price sum, count, supply sum, supply count }
local function blend(own, pipeSum, pipeN)
    if pipeN == 0 then return own end
    local o = own or { 0, 0, 0, 0 }
    return { o[1] + pipeSum, o[2] + pipeN, o[3], o[4] }
end

-- { [0..23] = { price, supply, count } } for the market or one item.
function T.Hours(house, id)
    local s = store(house)
    local src = id and s.i[id] or s.g
    local out = {}
    for h = 0, 23 do
        local b = src and src[h]
        if not id then
            local ps, pn = 0, 0
            for wd = 1, 7 do
                local pb = s.pipe[wd * 100 + h]
                if pb then ps, pn = ps + pb[1], pn + pb[2] end
            end
            b = blend(b, ps, pn)
        end
        local p, q, c = index(b)
        out[h] = { p, q, c or 0 }
    end
    return out
end

-- { [1..7] = { price, supply, count } } by day of the week (1 = Sunday).
function T.Days(house)
    local s = store(house)
    local out = {}
    for d = 1, 7 do
        local r, c, q, cq = 0, 0, 0, 0
        for h = 0, 23 do
            local b = blend(s.w[d * 100 + h], (s.pipe[d * 100 + h] or {})[1] or 0, (s.pipe[d * 100 + h] or {})[2] or 0)
            if b then r, c, q, cq = r + b[1], c + b[2], q + b[3], cq + b[4] end
        end
        out[d] = { c > 0 and (r / c - 1) or nil, cq > 0 and (q / cq - 1) or nil, c }
    end
    return out
end

-- The best moments: lowest price index to buy, highest to sell (slots with at
-- least `min` scans only). A moment is only named when the market really moves:
-- under FLAT points between the best and the worst slot it is noise, and no
-- moment is better than another (nil). Returns buy, sell (keys) or nil.
T.FLAT = 0.015
function T.Best(list, first, last, min)
    local buy, sell
    for k = first, last do
        local e = list[k]
        if e and e[1] and e[3] >= (min or 2) then
            if not buy or e[1] < list[buy][1] then buy = k end
            if not sell or e[1] > list[sell][1] then sell = k end
        end
    end
    if buy and list[sell][1] - list[buy][1] < T.FLAT then return nil, nil end
    return buy, sell
end

function T.Coverage(house)
    local s = store(house)
    local hours = 0
    for h = 0, 23 do
        local seen = s.g[h]
        for wd = 1, 7 do if s.pipe[wd * 100 + h] then seen = true end end
        if seen then hours = hours + 1 end
    end
    return hours, s.scans or 0
end

-- Our own scans.
ns.On("ScanDone", function(house, items)
    local t = date("*t")
    T.Observe(house, items, t.hour, t.wday)
    ns.Fire("TimingChanged")
end)
