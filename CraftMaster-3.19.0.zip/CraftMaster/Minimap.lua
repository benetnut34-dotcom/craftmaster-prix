local addonName, ns = ...
local L = ns.L

-- A minimap button of our own (named, clickable, button-sized), so Daylight
-- UI's addon drawer picks it up like any other. Without it, it sits on the
-- map's edge and can be dragged around it.
local MM = {}
ns.Minimap = MM

local button

local function place()
    if not button or button:GetParent() ~= Minimap then return end
    local a = math.rad(ns.db.minimap.angle or 200)
    local r = (Minimap:GetWidth() or 140) / 2 + 8
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

local function onDragUpdate()
    local mx, my = Minimap:GetCenter()
    local cx, cy = GetCursorPosition()
    local s = Minimap:GetEffectiveScale()
    ns.db.minimap.angle = math.deg(math.atan2(cy / s - my, cx / s - mx)) % 360
    place()
end

function MM.Init()
    if button or not Minimap then return end
    button = CreateFrame("Button", "CraftMasterMinimapButton", Minimap)
    button:SetSize(31, 31)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    button:SetHighlightTexture(136477)
    -- The icon and the disc are centred on the button (not pinned to a corner), so they stay
    -- in the middle when another addon resizes the button (Daylight UI's drawer squares).
    -- They are also named icon / background / border: the convention minimap-button
    -- libraries use, which the drawers read to hide the ring and re-fit the icon.
    local back = button:CreateTexture(nil, "BACKGROUND")
    back:SetSize(20, 20)
    back:SetTexture(136467)
    back:SetPoint("CENTER", button, "CENTER", 0, 0)
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetSize(17, 17)
    icon:SetTexture(ns.MEDIA .. "logo.png")
    icon:SetPoint("CENTER", button, "CENTER", 0, 0)
    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetSize(53, 53)
    ring:SetTexture(136430)
    ring:SetPoint("TOPLEFT")
    button.icon, button.background, button.border = icon, back, ring
    button:SetScript("OnClick", function(_, mouse)
        GameTooltip:Hide()
        if mouse == "RightButton" then ns.UI.Open("gmdeals") else ns.UI.Toggle() end
    end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("CraftMaster")
        GameTooltip:AddLine(L.MM_LEFT, 1, 1, 1)
        GameTooltip:AddLine(L.MM_RIGHT, 1, 1, 1)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnDragStart", function(self)
        if self:GetParent() ~= Minimap then return end
        self:SetScript("OnUpdate", onDragUpdate)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    place()
    MM.Refresh()
end

function MM.Refresh()
    if not button then return end
    button:SetShown(not ns.db.minimap.hide)
end

ns.On("Login", function() MM.Init() end)
