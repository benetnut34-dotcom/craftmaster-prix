local _, ns = ...
local L = ns.L
local W = ns.W

-- The Auction House companion: a small panel beside the Auction House
-- window (the game's, or Daylight UI's) while it is open. Which house this
-- is, whether CraftMaster is scanning it and how far along, how fresh the
-- prices are, the bargains found and what the cart still needs here.
-- It can be dragged; right-click its title to put it back beside the window.
local P = {}
ns.AHPanel = P

local WIDTH = 270
local panel
local open = false

-- The Auction House window on screen: the game's, or Daylight UI's (which
-- has no name: a big shown window with its money line and sub-title).
local function hostFrame()
    local g = _G.AuctionHouseFrame
    if g and g:IsVisible() and (g:GetAlpha() or 1) > 0.1 and g:GetRight() then return g end
    if not EnumerateFrames then return nil end
    local ok, found = pcall(function()
        local f = EnumerateFrames()
        while f do
            if f:IsVisible() and type(f.money) == "table" and type(f.sub) == "table" and type(f.close) == "table"
                and (f:GetWidth() or 0) > 500 and f:GetRight() then
                return f
            end
            f = EnumerateFrames(f)
        end
    end)
    return ok and found or nil
end
P.Host = hostFrame   -- the window shows itself in front of it or behind it (UI.lua)

local function place()
    if not panel then return end
    panel:ClearAllPoints()
    local spot = ns.db.ahPanelSpot
    if spot then
        panel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", spot[1], spot[2])
        return
    end
    local host = hostFrame()
    if host and host:GetRight() and host:GetRight() + WIDTH + 12 < UIParent:GetWidth() then
        panel:SetPoint("TOPLEFT", host, "TOPRIGHT", 8, 0)
    elseif host then
        panel:SetPoint("TOPRIGHT", host, "TOPLEFT", -8, 0)
    else
        panel:SetPoint("RIGHT", UIParent, "RIGHT", -40, 80)
    end
end

local function line(parent, size, y)
    local fs = W.Text(parent, size or "body", "LEFT")
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", 14, y)
    fs:SetPoint("RIGHT", parent, "RIGHT", -14, 0)
    fs:SetWordWrap(true)
    return fs
end

local function build()
    local C = ns.Theme.C
    panel = CreateFrame("Frame", "CraftMasterAHPanel", UIParent)
    panel:SetSize(WIDTH, 184)   -- the house and the scan only
    panel:SetFrameStrata("HIGH")
    panel:SetClampedToScreen(true)
    panel:SetMovable(true)
    panel:EnableMouse(true)
    W.Skin(panel, "window")

    -- title: drag to move, right-click to put it back
    local head = CreateFrame("Button", nil, panel)
    head:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, 0)
    head:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -34, 0)
    head:SetHeight(36)
    head:RegisterForDrag("LeftButton")
    head:RegisterForClicks("RightButtonUp")
    head:SetScript("OnDragStart", function() panel:StartMoving() end)
    head:SetScript("OnDragStop", function()
        panel:StopMovingOrSizing()
        ns.db.ahPanelSpot = { math.floor(panel:GetLeft() + 0.5), math.floor(panel:GetTop() + 0.5) }
    end)
    head:SetScript("OnClick", function()
        ns.db.ahPanelSpot = nil
        place()
    end)
    local logo = panel:CreateTexture(nil, "ARTWORK")
    logo:SetSize(22, 22)
    logo:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -8)
    logo:SetTexture(ns.MEDIA .. "logo.png")
    local title = W.Text(panel, "head", "LEFT")
    title:SetPoint("LEFT", logo, "RIGHT", 8, 0)
    title:SetText("CraftMaster")
    title:SetTextColor(C.gold[1], C.gold[2], C.gold[3])
    W.Tip(head, "CraftMaster", { L.AHP_MOVE })
    local close = W.Close(panel, function() panel:Hide(); P.closed = true end)
    close:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -6, -6)

    -- the house
    panel.house = line(panel, "body", -40)

    -- the scan: words, a bar, a button
    panel.scan = line(panel, "body", -62)
    local bar = CreateFrame("Frame", nil, panel)
    bar:SetPoint("TOPLEFT", panel, "TOPLEFT", 14, -84)
    bar:SetPoint("RIGHT", panel, "RIGHT", -14, 0)
    bar:SetHeight(8)
    W.Fill(bar, "BACKGROUND", 1, 1, 1, 0.07)
    bar.fill = bar:CreateTexture(nil, "ARTWORK")
    bar.fill:SetPoint("TOPLEFT")
    bar.fill:SetPoint("BOTTOMLEFT")
    bar.fill:SetWidth(1)
    bar.fill:SetColorTexture(C.sky[1], C.sky[2], C.sky[3], 0.95)
    panel.bar = bar
    panel.fresh = line(panel, "small", -98)
    panel.fresh:SetTextColor(C.label[1], C.label[2], C.label[3])
    -- two buttons: a quick scan (any time) and a full scan (when Blizzard allows)
    local half = math.floor((WIDTH - 34) / 2)
    panel.scanBtn = W.Button(panel, L.SCANS_BTN_QUICK, half, function()
        if ns.Scan.Running() then ns.Scan.Stop() else ns.Scan.Start("quick") end
        P.Refresh()
    end)
    panel.scanBtn:SetPoint("TOPLEFT", panel, "TOPLEFT", 14, -144)
    panel.fullBtn = W.Button(panel, L.SCANS_BTN_FULL, half, function()
        local wait = ns.Scan.FullWait()
        if wait > 0 then ns.Print(L.SCANS_FULL_WAIT_MSG, ns.Duration(wait)) return end
        ns.Scan.Start("full")
        P.Refresh()
    end)
    panel.fullBtn:SetPoint("LEFT", panel.scanBtn, "RIGHT", 6, 0)
    panel.half = half

    panel:Hide()
end

function P.Refresh()
    if not panel or not panel:IsShown() then return end
    local C = ns.Theme.C
    local house = ns.Scan.OpenHouse()
    local hname = house == "neutral" and L.HOUSE_NEUTRAL or ns.FactionName()
    panel.house:SetText(string.format(L.AHP_HOUSE, "|cff62a8f5" .. hname .. "|r", ns.RulesetLabel()))

    local bar = panel.bar
    local full = bar:GetWidth() or (WIDTH - 28)
    if ns.Scan.Running() then
        local pct = ns.Scan.Progress()
        local n = ns.Scan.Count()
        local mode = ns.Scan.Mode()
        if mode == "full" and n == 0 then
            panel.scan:SetText(L.AHP_FULL_WAIT)
            pct = nil
        elseif pct then
            panel.scan:SetText(string.format(mode == "quick" and L.AHP_SCANNING_PCT or L.AHP_SCANNING_FULL, math.floor(pct * 100), n))
            bar.fill:SetWidth(math.max(1, full * pct))
        else
            panel.scan:SetText(string.format(L.AHP_SCANNING, n))
            -- no earlier picture: a moving stripe shows it is working
            local t = (ns.Scan.Elapsed() % 2) / 2
            bar.fill:SetWidth(math.max(1, full * t))
        end
        bar:Show()
        panel.scanBtn:SetWidth(WIDTH - 28)
        panel.scanBtn.SetLabel(L.AHP_STOP)
        panel.fullBtn:Hide()
    else
        local at = ns.Scan.LastAt(house)
        local book = ns.Scan.Book(house)
        local who = book.from == "blizzard" and "Blizzard" or (book.fromGuild and L.AHP_GUILD or "CraftMaster")
        if at then
            local age = time() - at
            local col = age < 3600 and "|cff73d982" or (age < 3 * 3600 and "|cffeda55f" or "|cffef5c42")
            panel.scan:SetText(string.format(L.AHP_LAST, col .. ns.Duration(age) .. "|r", who))
        else
            panel.scan:SetText("|cffef5c42" .. L.AHP_NEVER .. "|r")
        end
        bar:Hide()
        panel.scanBtn:SetWidth(panel.half)
        panel.scanBtn.SetLabel(L.SCANS_BTN_QUICK)
        panel.fullBtn:SetShown(ns.db.fullScan ~= false)
    end
    -- what the automatic scan will do, and when a full one is allowed
    local wait = ns.Scan.FullWait()
    local fullLine = ns.db.fullScan == false and "" or ("\n" .. (wait > 0 and string.format(L.AHP_FULL_IN, ns.Duration(wait)) or L.AHP_FULL_READY))
    if ns.Scan.Running() then
        panel.fresh:SetText(L.AHP_KEEP_OPEN)
    elseif not ns.db.autoScan then
        panel.fresh:SetText(L.AHP_AUTO_OFF .. fullLine)
    else
        local at = ns.Scan.LastAt(house)
        local wait2 = (ns.db.autoScanMin or 30) * 60
        if at and time() - at < wait2 then
            panel.fresh:SetText(string.format(L.AHP_AUTO_FRESH, ns.Duration(wait2 - (time() - at))) .. fullLine)
        else
            panel.fresh:SetText(L.AHP_AUTO_SOON .. fullLine)
        end
    end

end

local ticker
local function show()
    if ns.db.ahPanel == false or P.closed then return end
    if not panel then build() end
    panel:Show()
    place()
    P.Refresh()
    if not ticker and C_Timer.NewTicker then
        ticker = C_Timer.NewTicker(1, function() P.Refresh() end)
    end
end

ns.Register("AUCTION_HOUSE_SHOW", function()
    open = true
    P.closed = nil
    -- after the window (and Daylight UI's in its place) is up
    C_Timer.After(0.3, function() if open then show() end end)
    C_Timer.After(1.2, function() if open and panel and panel:IsShown() and not ns.db.ahPanelSpot then place() end end)
end)

ns.Register("AUCTION_HOUSE_CLOSED", function()
    open = false
    if panel then panel:Hide() end
    if ticker then ticker:Cancel(); ticker = nil end
end)

ns.On("ScanProgress", function() P.Refresh() end)
ns.On("ScanDone", function() C_Timer.After(0.5, function() P.Refresh() end) end)

-- for the settings: show it now when the Auction House is open
function P.Apply()
    if ns.db.ahPanel == false then
        if panel then panel:Hide() end
    elseif open then
        P.closed = nil
        show()
    end
end
