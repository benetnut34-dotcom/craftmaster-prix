local _, ns = ...
local L = ns.L

-- My operations: what I bought through CraftMaster to make gold, and what came
-- of it. An operation starts with a purchase (a good deal, a lot in volume, the
-- materials of a craft, an item for the other house, a plan at a merchant),
-- follows the posts at the Auction House, and is settled by the mail: each
-- sale received adds its gold, each listing back unsold is noted.
--   op = { id, at, kind ("deal" | "transfer" | "volume" | "craft" | "plan"),
--          item, name, house (where bought), sellHouse,
--          bought (units), cost (copper), bid (copper: a bid not won yet),
--          posted (units on sale), postUnit, sold (units), revenue (copper),
--          expired (units back unsold), aim (resale aimed per unit),
--          recipe, closed, link (the exact item bought, its random suffix with it),
--          log = { { time, what, units, copper, item } } }
-- Kept per character (its own mailbox), newest last.
local O = {}
ns.Ops = O

local MAX_OPS, MAX_LOG = 500, 80
local GROUP_TIME = 120          -- purchases of one item a couple of minutes apart: one operation
local CRAFT_TIME = 2 * 3600     -- the materials of one craft bought within two hours: one operation
local MAIL_DAYS = 30            -- an Auction House mail stays 30 days

local function ops()
    ns.char.ops = ns.char.ops or {}
    return ns.char.ops
end
function O.List() return ops() end

local function note(op, what, units, copper, item)
    op.log = op.log or {}
    op.log[#op.log + 1] = { time(), what, units, copper, item }
    while #op.log > MAX_LOG do table.remove(op.log, 1) end
end

-- The resale price per unit: the one it was posted at, else the one aimed at.
function O.SellUnit(op) return op.postUnit or op.aim end
-- The gain aimed at: every unit sold at that price, the cut taken, less the cost.
function O.AimedGain(op)
    local unit, n = O.SellUnit(op), math.max(1, op.bought or 0)
    if not unit or unit <= 0 then return nil end
    local keep = 1 - ns.CutPct(op.sellHouse or op.house) / 100
    return math.floor(unit * n * keep + 0.5) - (((op.cost or 0) > 0 and op.cost) or op.bid or 0)
end
-- what an operation earned so far: what came in, less what it cost
function O.Result(op) return (op.revenue or 0) - (op.cost or 0) end
-- units still to be sold (bought, not sold yet)
function O.Left(op) return math.max(0, (op.bought or 0) - (op.sold or 0)) end
-- Seconds until the first listing still on sale ends (posted through CraftMaster,
-- for 24 h): the posts in order, the units that left the sale (sold, back unsold)
-- taken from the oldest. nil when nothing is on sale.
function O.TimeLeft(op)
    if (op.posted or 0) <= 0 then return nil end
    local gone = (op.sold or 0) + (op.expired or 0)
    local hours = (ns.Sell and ns.Sell.HOURS) or 24
    for _, e in ipairs(op.log or {}) do
        if e[2] == "post" then
            local n = e[3] or 0
            if gone >= n then
                gone = gone - n
            else
                return e[1] + hours * 3600 - time()
            end
        end
    end
    return nil
end
-- "bid" (a bid not won yet), "open" (units still to sell), "won" or "lost" (settled)
function O.State(op)
    if (op.bid or 0) > 0 and (op.bought or 0) == 0 then return "bid" end
    if op.closed or ((op.bought or 0) > 0 and O.Left(op) == 0) then
        return O.Result(op) >= 0 and "won" or "lost"
    end
    return "open"
end

local function newOp(kind, item, ctx)
    local list = ops()
    local op = { id = (ns.char.opsNext or 0) + 1, at = time(), kind = kind, item = item, name = ns.ItemName(item),
                 house = ns.Scan.OpenHouse and ns.Scan.OpenHouse() or nil, sellHouse = ctx and ctx.sellHouse,
                 bought = 0, cost = 0, posted = 0, sold = 0, revenue = 0, expired = 0,
                 aim = ctx and ctx.aim, recipe = ctx and ctx.recipe, link = ctx and ctx.link, log = {} }
    ns.char.opsNext = op.id
    list[#list + 1] = op
    -- the oldest settled ones go first when there are too many
    while #list > MAX_OPS do
        local drop = 1
        for i, o in ipairs(list) do if O.State(o) == "won" or O.State(o) == "lost" then drop = i break end end
        table.remove(list, drop)
    end
    return op
end

-- the newest open operation of this item (and kind, when given), bought lately
local function recent(item, kind, within)
    local list = ops()
    for i = #list, 1, -1 do
        local o = list[i]
        if o.item == item and (not kind or o.kind == kind) and O.State(o) ~= "won" and O.State(o) ~= "lost"
            and time() - (o.last or o.at) <= within then return o end
    end
end
-- the oldest operation of an item with units to post, or on sale
local function oldest(item, test)
    for _, o in ipairs(ops()) do
        if o.item == item and not o.closed and test(o) then return o end
    end
end
-- Before 3.16.2 an item bought at the Auction House counted every auction of its
-- line (4 alike: 4 bought) though one only was bought, at the price of one.
-- An item that does not stack: one bought per purchase.
function O.Repair()
    for _, op in ipairs(ops()) do
        -- before 3.16.2 too: a sale mail read again once its gold was taken (a sale of 0)
        if not op.fixedMail then
            op.fixedMail = true
            local log = op.log or {}
            for k = #log, 1, -1 do
                local e = log[k]
                if e[2] == "sold" and (e[4] or 0) <= 0 then
                    op.sold = math.max(0, (op.sold or 0) - (e[3] or 0))
                    table.remove(log, k)
                end
            end
            if (op.bought or 0) > 0 and (op.sold or 0) > op.bought then op.sold = op.bought end
        end
        if (op.kind == "deal" or op.kind == "transfer") and not op.fixedQty then
            local stack = C_Item and C_Item.GetItemInfo and select(8, C_Item.GetItemInfo(op.item))
            if stack then
                op.fixedQty = true
                if stack <= 1 then
                    local n = 0
                    for _, e in ipairs(op.log or {}) do
                        if e[2] == "buy" and (e[3] or 0) > 1 then e[3] = 1 end
                        if e[2] == "buy" or e[2] == "won" then n = n + (e[3] or 0) end
                    end
                    if n > 0 and n < (op.bought or 0) then op.bought = n end
                end
            end
        end
    end
end
function O.Find(id) for _, o in ipairs(ops()) do if o.id == id then return o end end end

-- ------------------------------------------------------------ purchases
-- ctx (given by the tab that bought): { kind, aim, sellHouse, recipe, out, units }
function O.Bought(item, qty, total, ctx)
    if not (item and qty and qty > 0 and total) then return end
    ctx = ctx or { kind = "deal" }
    local op
    if ctx.kind == "craft" and ctx.recipe and ctx.out then
        -- the materials of one craft: one operation, on the item made
        for i = #ops(), 1, -1 do
            local o = ops()[i]
            if o.kind == "craft" and o.recipe == ctx.recipe and (o.sold or 0) == 0 and not o.closed
                and time() - (o.last or o.at) <= CRAFT_TIME then op = o break end
        end
        op = op or newOp("craft", ctx.out, ctx)
        op.bought = math.max(op.bought or 0, ctx.units or 1)   -- what the crafts will make
    else
        op = recent(item, ctx.kind, GROUP_TIME) or newOp(ctx.kind, item, ctx)
        op.bought = (op.bought or 0) + qty
        op.link = op.link or ctx.link
    end
    op.cost = (op.cost or 0) + total
    op.last = time()
    note(op, "buy", qty, total, item ~= op.item and item or nil)
    ns.Fire("OpsChanged")
    return op
end

-- a bid placed: an operation waiting for the auction to end
function O.Bid(item, total, ctx)
    if not (item and total) then return end
    local op = newOp((ctx and ctx.kind) or "deal", item, ctx)
    op.bid = total
    note(op, "bid", 1, total)
    ns.Fire("OpsChanged")
    return op
end

-- a plan bought at a merchant (any plan: the Plans tab shows where to sell it)
function O.MerchantBought(item, qty, total)
    local op = recent(item, "plan", GROUP_TIME) or newOp("plan", item, nil)
    op.bought = (op.bought or 0) + qty
    op.cost = (op.cost or 0) + total
    op.last = time()
    note(op, "buy", qty, total)
    ns.Fire("OpsChanged")
end

-- ------------------------------------------------------------ posts
function O.Posted(item, qty, unit)
    if not (item and qty and qty > 0) then return end
    local op = oldest(item, function(o) return (o.posted or 0) + (o.sold or 0) < (o.bought or 0) end)
    if not op then return end
    op.posted = (op.posted or 0) + qty
    op.postUnit = unit or op.postUnit
    note(op, "post", qty, unit and unit * qty or nil)
    ns.Fire("OpsChanged")
end

-- ------------------------------------------------------------ the mail
-- The Auction House mails, by their subject (the game's own words, any language).
local function subjectPattern(fmt)
    if type(fmt) ~= "string" or not fmt:find("%%s") then return nil end
    local p = fmt:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0")
    p = p:gsub("%%s", "(.+)")
    return "^" .. p .. "$"
end
-- "Linen Cloth (20)" -> "Linen Cloth", 20
local function splitCount(name)
    local n, c = name:match("^(.-) %((%d+)%)$")
    if n then return n, tonumber(c) end
    return name, nil
end
local function byName(name, test)
    for _, o in ipairs(ops()) do
        if (o.name == name or ns.ItemName(o.item) == name) and not o.closed and test(o) then return o end
    end
end

-- a sale received: its gold (the cut already taken), how many units
function O.MailSold(name, money, count)
    if not money or money <= 0 then return false end   -- its gold already taken: counted when it came
    local op = byName(name, function(o) return (o.sold or 0) < (o.bought or 0) end)
    if not op then return false end
    local units = count
    if not units then
        -- not in the subject: from the price it was posted at, after the cut
        local unit = op.postUnit or op.aim
        local cut = 1 - ns.CutPct(op.sellHouse or op.house) / 100
        units = (unit and unit > 0) and math.floor(money / (unit * cut) + 0.5) or 1
    end
    units = math.max(1, math.min(units, O.Left(op)))
    op.sold = (op.sold or 0) + units
    op.posted = math.max(0, (op.posted or 0) - units)
    op.revenue = (op.revenue or 0) + (money or 0)
    note(op, "sold", units, money)
    return true
end
-- a listing back unsold: the units come back to the bags (to post again)
function O.MailExpired(name, count)
    local op = byName(name, function(o) return (o.posted or 0) > 0 end)
    if not op then return false end
    count = math.max(1, math.min(count or 1, op.posted or 1))
    op.posted = math.max(0, (op.posted or 0) - count)
    op.expired = (op.expired or 0) + count
    note(op, "expired", count)
    return true
end
-- an auction won (a bid): the item is bought, at the bid
function O.MailWon(name)
    local op = byName(name, function(o) return (o.bid or 0) > 0 and (o.bought or 0) == 0 end)
    if not op then return false end
    op.bought, op.cost, op.last = 1, op.bid, time()
    note(op, "won", 1, op.bid)
    return true
end

-- The mails already counted: { subject, money, at (when received) }. A mail stays
-- in the box until taken: it is counted once, the first time it is seen.
local function seenList()
    ns.char.opsMail = ns.char.opsMail or {}
    return ns.char.opsMail
end
local patterns
local function mailPatterns()
    if not patterns then
        patterns = { sold = subjectPattern(AUCTION_SOLD_MAIL_SUBJECT), expired = subjectPattern(AUCTION_EXPIRED_MAIL_SUBJECT),
                     won = subjectPattern(AUCTION_WON_MAIL_SUBJECT), removed = subjectPattern(AUCTION_REMOVED_MAIL_SUBJECT) }
    end
    return patterns
end
function O.ReadMail()
    if not (GetInboxNumItems and GetInboxHeaderInfo) then return 0 end
    local p = mailPatterns()
    local seen, used, now, changed = seenList(), {}, time(), 0
    -- forget what left the box a while ago
    for i = #seen, 1, -1 do if now - (seen[i][3] or 0) > (MAIL_DAYS + 1) * 86400 then table.remove(seen, i) end end
    local n = GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, _, subject, money, _, daysLeft, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and type(subject) == "string" then
            local at = now - math.floor((MAIL_DAYS - (daysLeft or MAIL_DAYS)) * 86400)
            local known
            for k, e in ipairs(seen) do
                -- the same mail: same subject, received at the same time; its gold may have been
                -- taken since (then it shows 0)
                if not used[k] and e[1] == subject and (e[2] == (money or 0) or (money or 0) == 0)
                    and math.abs((e[3] or 0) - at) < 7200 then
                    used[k], known = true, true
                    break
                end
            end
            if not known then
                local done = false
                local name = p.sold and subject:match(p.sold)
                if name then
                    local nm, c = splitCount(name)
                    done = O.MailSold(nm, money or 0, c)
                end
                name = not done and p.expired and subject:match(p.expired)
                if name then
                    local nm, c = splitCount(name)
                    if not c and GetInboxItem then
                        local ok2, _, _, _, cnt = pcall(GetInboxItem, i, 1)
                        if ok2 and type(cnt) == "number" then c = cnt end
                    end
                    done = O.MailExpired(nm, c or itemCount)
                end
                name = not done and p.won and subject:match(p.won)
                if name then done = O.MailWon((splitCount(name))) end
                -- every Auction House mail is remembered, ours or not: never read twice
                seen[#seen + 1] = { subject, money or 0, at }
                used[#seen] = true
                if done then changed = changed + 1 end
            end
        end
    end
    if changed > 0 then ns.Fire("OpsChanged") end
    return changed
end

-- close by hand (the rest kept, used, or given away) or open again; delete
function O.SetClosed(op, on) op.closed = on or nil; note(op, on and "closed" or "reopened"); ns.Fire("OpsChanged") end
function O.Delete(op)
    for i, o in ipairs(ops()) do if o == op then table.remove(ops(), i) break end end
    ns.Fire("OpsChanged")
end

-- ------------------------------------------------------------ wiring
ns.On("Bought", function(item, qty, total, ctx) O.Bought(item, qty, total, ctx) end)
ns.On("BidPlaced", function(item, total, ctx) O.Bid(item, total, ctx) end)
ns.On("Posted", function(item, qty, unit) O.Posted(item, qty, unit) end)
ns.Register("MAIL_INBOX_UPDATE", function() O.ReadMail() end)
ns.Register("MAIL_SHOW", function() if CheckInbox then pcall(CheckInbox) end end)
-- a plan bought at a merchant
if hooksecurefunc then
    hooksecurefunc("BuyMerchantItem", function(index, qty)
        local link = GetMerchantItemLink and GetMerchantItemLink(index)
        local id = link and tonumber(link:match("item:(%d+)"))
        if not (id and ns.Gold and ns.Gold.IsPlan and ns.Gold.IsPlan(id)) then return end
        local price, stack = ns.MerchantInfo(index)
        if type(price) == "number" and price > 0 then
            local n = qty or 1
            O.MerchantBought(id, n, price / math.max(1, stack or 1) * n)
        end
    end)
end
