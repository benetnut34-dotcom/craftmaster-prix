local _, ns = ...
local L = ns.L

-- CraftMaster's own Auction House scan. Two ways:
--   full   the game's "replicate" list: every single listing (price, stack,
--          seller), which also tells what sold since the last full scan
--          (Tracker.lua). Blizzard allows one every 15 minutes. A full scan
--          asked by another addon (Daylight UI...) is read as well.
--   quick  a browse with an empty search: every item with its lowest price
--          and how many there are, any time; used between two full scans.
-- Nothing is bought or posted here.
local S = {}
ns.Scan = S

local running -- { mode = "full"|"passive"|"quick", started, items, n, expect, house }
local FULL_COOLDOWN = 15 * 60

function S.Running() return running ~= nil end
function S.Count() return running and running.n or 0 end
-- How far the scan is, 0-1, or nil when it can't tell (no earlier picture).
function S.Progress()
    if not running or not running.expect or running.expect < 50 then return nil end
    return math.min(0.99, running.n / running.expect)
end
function S.Elapsed() return running and (GetTime() - running.started) or 0 end
function S.Mode() return running and running.mode end
-- Seconds before Blizzard allows the next full scan (0 = now).
function S.FullWait()
    return math.max(0, FULL_COOLDOWN - (time() - ((ns.db and ns.db.fullAt) or 0)))
end

-- Which Auction House is open, without trusting the game's language:
--   1. the auctioneer I'm talking to: a Horde or Alliance one runs my
--      faction's house; a neutral one (the Steamwheedle goblins) the shared one;
--   2. else the map: Stranglethorn, Tanaris and Winterspring only have the
--      shared houses (Booty Bay, Gadgetzan, Everlook) — map numbers are the
--      same in every language;
--   3. else the town's name, in the game's languages.
local NEUTRAL_MAPS = { [1434] = true, [1446] = true, [1452] = true }
local NEUTRAL_TOWNS = {
    ["Booty Bay"] = true, ["Gadgetzan"] = true, ["Everlook"] = true,                   -- en
    ["Baie-du-Butin"] = true, ["Long-guet"] = true, ["Long-Guet"] = true,              -- fr
    ["Bahía del Botín"] = true, ["Vista Eterna"] = true,                               -- es
    ["Beutebucht"] = true, ["Ewige Warte"] = true,                                     -- de
    ["Baia del Bottino"] = true, ["Lungavista"] = true,                                -- it
    ["Angra do Butim"] = true, ["Visteterna"] = true,                                  -- pt
    ["Пиратская Бухта"] = true, ["Прибамбасск"] = true, ["Круговзор"] = true,           -- ru
}

local function onNeutralMap()
    if not (C_Map and C_Map.GetBestMapForUnit) then return false end
    local map = C_Map.GetBestMapForUnit("player")
    local guard = 0
    while map and guard < 6 do
        if NEUTRAL_MAPS[map] then return true end
        local info = C_Map.GetMapInfo and C_Map.GetMapInfo(map)
        map = info and info.parentMapID
        guard = guard + 1
    end
    return false
end

local current -- the house of the Auction House open now, found when it opened

function S.DetectHouse()
    if UnitExists and UnitExists("npc") then
        local f = UnitFactionGroup("npc")
        if f == "Horde" or f == "Alliance" then return "faction", "npc" end
        return "neutral", "npc"
    end
    if onNeutralMap() then return "neutral", "map" end
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local zone = GetZoneText and GetZoneText() or ""
    if NEUTRAL_TOWNS[sub] or NEUTRAL_TOWNS[zone] then return "neutral", "name" end
    return "faction", "default"
end

function S.OpenHouse() return current or (S.DetectHouse()) end

ns.Register("AUCTION_HOUSE_SHOW", function()
    current = (S.DetectHouse())
    ns.Fire("ScanProgress")
end)
ns.Register("AUCTION_HOUSE_CLOSED", function() current = nil end)

local function book(house)
    house = house or ns.House()
    local key = ns.HouseKey(house)
    ns.db.scans = ns.db.scans or {}
    ns.db.scans[key] = ns.db.scans[key] or { items = {} }
    return ns.db.scans[key]
end
S.Book = book

-- The price and quantity of the last scan of a house: price, age, quantity.
function S.Get(id, house)
    local b = book(house)
    local e = b.items[id]
    if not e then return nil end
    return e[1], b.at and (time() - b.at) or nil, e[2]
end

function S.LastAt(house) return book(house).at end

local function readNew()
    if not running then return end
    local ok, results = pcall(C_AuctionHouse.GetBrowseResults)
    if not ok or type(results) ~= "table" then return end
    for i = running.seen + 1, #results do
        local r = results[i]
        local key = r and r.itemKey
        local id = key and key.itemID
        local price = r and r.minPrice
        if id and type(price) == "number" and price > 0 then
            local cur = running.items[id]
            if not cur or price < cur[1] then
                running.items[id] = { price, (cur and cur[2] or 0) + (r.totalQuantity or 0) }
            elseif cur then
                cur[2] = cur[2] + (r.totalQuantity or 0)
            end
        end
    end
    running.seen = #results
    running.n = running.seen
    ns.Fire("ScanProgress")
end

local function finish(ok, partial)
    local r = running
    running = nil
    if not r then return end
    if ok then
        local b = book(r.house)
        if partial then
            for id, e in pairs(r.items) do b.items[id] = e end
        else
            b.items = r.items
        end
        b.at, b.fromGuild, b.from, b.house = time(), nil, nil, nil
        b.full = r.mode ~= "quick" or nil
        local n = 0
        for _ in pairs(r.items) do n = n + 1 end
        -- what the last scan of each kind did, for the Scans page (comparison)
        ns.db.scanStats = ns.db.scanStats or {}
        ns.db.scanStats[r.mode == "quick" and "quick" or "full"] = {
            at = time(), items = n, secs = math.floor(GetTime() - r.started + 0.5),
            listings = r.mode ~= "quick" and r.n or nil, key = ns.HouseKey(r.house), partial = partial or nil,
        }
        ns.FireSpread("ScanDone", r.house, r.items)
        ns.Print(r.mode == "quick" and L.SCAN_DONE or L.SCAN_DONE_FULL, n, math.floor(GetTime() - r.started + 0.5))
        if r.tracked then
            ns.Print(L.SALES_SEEN, math.floor((r.tracked.found or 0) + 0.5), r.tracked.expired or 0, math.floor((r.tracked.gap or 0) / 60))
        end
        ns.Print(L.SCAN_HOUSE, r.house == "neutral" and L.HOUSE_NEUTRAL or ns.FactionName())
        ns.Prices.Reset()
        ns.Fire("PricesChanged")
        if ns.History then ns.History.Snapshot() end
    end
    ns.Fire("ScanProgress")
end

local function more()
    if not running then return end
    if C_AuctionHouse.HasFullBrowseResults and C_AuctionHouse.HasFullBrowseResults() then
        finish(true)
        return
    end
    if C_AuctionHouse.IsThrottledMessageSystemReady and not C_AuctionHouse.IsThrottledMessageSystemReady() then
        running.waiting = true
        return
    end
    running.waiting = false
    pcall(C_AuctionHouse.RequestMoreBrowseResults)
end

-- ---------------------------------------------------------------------
-- Full scan: the replicate list, read a slice per frame
-- ---------------------------------------------------------------------

local worker = CreateFrame("Frame")
local hash = {}

-- The scale of the game's time left, from all the values of one scan: 0-3
-- (Retail) when a 0 is seen, 1-4 (Classic) when a 4 is; the amount to add
-- to get 1 short ... 4 very long, nil when it can't be told.
function ns.Scan.TimeLeftShift(minT, maxT)
    if not minT then return nil end
    if minT == 0 and maxT <= 3 then return 1 end
    if maxT == 4 and minT >= 1 then return 0 end
    return nil
end

local function readFull(total)
    local items, listings = {}, {}
    local r = running
    local timeLeft = C_AuctionHouse.GetReplicateItemTimeLeft
    local minT, maxT
    for i = 0, total - 1 do
        local _, _, count, _, _, _, _, _, _, buyout, _, _, _, owner, ownerFull, _, itemID =
            C_AuctionHouse.GetReplicateItemInfo(i)
        if itemID and type(buyout) == "number" and buyout > 0 and type(count) == "number" and count > 0 then
            local tl
            if timeLeft then
                local ok, v = pcall(timeLeft, i)
                if ok and type(v) == "number" then
                    tl = v
                    if not minT or v < minT then minT = v end
                    if not maxT or v > maxT then maxT = v end
                elseif not ok then
                    timeLeft = nil   -- the game refuses it: not asked again in this scan
                end
            end
            local unit = buyout / count
            local e = items[itemID]
            if not e then
                e = { math.floor(unit), 0 }
                items[itemID] = e
            elseif unit < e[1] then
                e[3], e[1] = e[1], math.floor(unit)
            elseif not e[3] or unit < e[3] then
                e[3] = math.floor(unit)
            end
            e[2] = e[2] + count
            local name = ownerFull or owner or ""
            local o = hash[name]
            if not o then o = ns.Tracker.Hash(name); hash[name] = o end
            local l = listings[itemID]
            if not l then l = {}; listings[itemID] = l end
            l[#l + 1] = { o = o, c = count, b = buyout, t = tl }
        end
        -- a slice of time per frame (5 ms), not a fixed number of listings: the
        -- game keeps its 60 images a second whatever the machine
        if i % 64 == 0 and ns.Work.Due() then
            r.n = i
            ns.Fire("ScanProgress")
            coroutine.yield()
        end
    end
    r.n = total
    r.reading = false          -- all read: the Auction House may close now
    r.items = items
    -- what sold since the last full scan of this house
    local shift = ns.Scan.TimeLeftShift(minT, maxT)
    ns.db.timeLeftScan = { at = time(), min = minT, max = maxT, shift = shift }
    local found, expired, gap = ns.Tracker.Process(r.house, listings, time(), shift)
    if found then r.tracked = { found = found, expired = expired, gap = gap } end
end

local function stopWorker()
    worker:SetScript("OnUpdate", nil)
    worker.co = nil
end

local function step()
    local r = running
    if not r or not worker.co then return stopWorker() end
    if r.reading and not ns.Buy.ahOpen then
        stopWorker()
        running = nil
        ns.Print(L.SCAN_CLOSED)
        ns.Fire("ScanProgress")
        return
    end
    ns.Work.Arm()
    local ok, err = coroutine.resume(worker.co)
    if not ok then
        stopWorker()
        running = nil
        ns.Print(L.BUY_FAIL, tostring(err))
        ns.Fire("ScanProgress")
    elseif coroutine.status(worker.co) == "dead" then
        stopWorker()
        finish(true)
    end
end

local function startReading(mode)
    local total = C_AuctionHouse.GetNumReplicateItems and C_AuctionHouse.GetNumReplicateItems() or 0
    if not total or total <= 0 then return false end
    if not running then
        running = { mode = mode, started = GetTime(), items = {}, n = 0, house = S.OpenHouse() }
    end
    running.mode, running.expect, running.reading = mode, total, true
    ns.db.fullAt = ns.db.fullAt and math.max(ns.db.fullAt, time() - 5) or time()
    worker.co = coroutine.create(function() readFull(total) end)
    worker:SetScript("OnUpdate", step)
    ns.Fire("ScanProgress")
    return true
end

-- The list is ready: mine, or one another addon asked for.
ns.Register("REPLICATE_ITEM_LIST_UPDATE", function()
    if worker.co then return end
    if running and running.mode == "full" then
        if not startReading("full") then running = nil; ns.Print(L.SCAN_EMPTY); ns.Fire("ScanProgress") end
    elseif not running and ns.Buy.ahOpen and ns.db.readOthers ~= false then
        startReading("passive")
    end
end)

local function startFull()
    if not (C_AuctionHouse and C_AuctionHouse.ReplicateItems) then return false end
    running = { mode = "full", started = GetTime(), items = {}, n = 0, house = S.OpenHouse() }
    local expect = 0
    for _ in pairs(book(running.house).items or {}) do expect = expect + 1 end
    running.expect = expect
    ns.db.fullAt = time()
    local ok = pcall(C_AuctionHouse.ReplicateItems)
    if not ok then running = nil; return false end
    local mine = running
    C_Timer.After(90, function()
        -- no answer: fall back to a quick scan
        if running == mine and not worker.co then
            running = nil
            ns.Print(L.SCAN_NO_ANSWER)
            S.Start("quick")
        end
    end)
    ns.Fire("ScanProgress")
    return true
end

-- What to scan, given the data the addon already holds. Blizzard's picture
-- (companion, every hour) has every house's lowest prices and quantities, and
-- the sales seen from one hour to the next; a scan only adds what happened
-- since. So:
--   picture 70 min old or less  -> "none"  (a scan would add almost nothing)
--   up to 3 hours               -> "quick" (what moved since the picture)
--   older, or no picture        -> "full"  (rebuilds prices and sales), else "quick"
-- Returns the kind, a reason key (Locales: SCAN_WHY_*) and the picture's age.
local FRESH_PICTURE, LATE_PICTURE = 70 * 60, 3 * 3600
function S.Recommend(house)
    local key = ns.HouseKey(house or ns.House())
    local ref = ns.Import and ns.Import.apiRef and ns.Import.apiRef[key]
    local at = ref and ref.at
    if not at then
        local b = book(house)
        if b.from == "blizzard" then at = b.at end
    end
    local age = at and (time() - at) or nil
    local fullOk = ns.db.fullScan ~= false and S.FullWait() == 0
    if not age then return fullOk and "full" or "quick", "NOPIC", nil end
    if age <= FRESH_PICTURE then return "none", "FRESH", age end
    if age <= LATE_PICTURE then return "quick", "LATE", age end
    return fullOk and "full" or "quick", "OLD", age
end

-- What the automatic scan does when the Auction House opens: nil = nothing,
-- else the argument of S.Start. ns.db.autoScan is the master switch;
-- ns.db.autoScanMode: "full" (a full scan when Blizzard allows, else quick: the
-- way it has always been), "quick", or "smart" (S.Recommend).
function S.AutoKind(house)
    if not ns.db.autoScan then return nil end
    local mode = ns.db.autoScanMode or "full"
    if mode == "quick" then return "quick" end
    if mode == "smart" then
        local kind = S.Recommend(house)
        if kind == "none" then return nil end
        return kind
    end
    return "any"          -- S.Start() : full when allowed, else quick
end

-- Inside a click: the game wants a person behind a search.
-- kind: "full", "quick", or nil = full when Blizzard allows it, else quick.
function S.Start(kind)
    if running then return false end
    if not (ns.Buy.ahOpen and C_AuctionHouse and C_AuctionHouse.SendBrowseQuery) then
        ns.Print(L.BUY_AH_CLOSED)
        return false
    end
    if kind ~= "quick" and ns.db.fullScan ~= false and (kind == "full" or S.FullWait() == 0) then
        if startFull() then return true end
    end
    running = { mode = "quick", started = GetTime(), items = {}, seen = 0, n = 0, house = S.OpenHouse() }
    -- how many to expect: the last full picture of this house (for a progress bar)
    local expect = 0
    for _ in pairs(book(running.house).items or {}) do expect = expect + 1 end
    running.expect = expect
    local query = { searchString = "", sorts = {}, filters = {}, itemClassFilters = {} }
    local ok, err = pcall(C_AuctionHouse.SendBrowseQuery, query)
    if not ok then
        running = nil
        ns.Print(L.BUY_FAIL, tostring(err))
        return false
    end
    ns.Fire("ScanProgress")
    return true
end

function S.Stop()
    if worker.co then stopWorker(); running = nil; ns.Fire("ScanProgress"); return end
    finish(false)
end

ns.Register("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", function()
    if not running or running.mode ~= "quick" then return end
    readNew()
    more()
end)
ns.Register("AUCTION_HOUSE_BROWSE_RESULTS_ADDED", function()
    if not running or running.mode ~= "quick" then return end
    readNew()
    more()
end)
ns.Register("AUCTION_HOUSE_THROTTLED_SYSTEM_READY", function()
    if running and running.waiting then more() end
end)
ns.Register("AUCTION_HOUSE_CLOSED", function()
    if running and running.mode ~= "quick" then
        if not worker.co then running = nil end   -- a full scan not answered yet
        return                                      -- one being read stops itself (step)
    end
    if running then
        -- keep what came in: a partial scan still beats none
        if running.n > 0 then finish(true, true) else finish(false) end
    end
end)

-- Saying (once) when a full scan is allowed again, away from the Auction House.
local reminded = false
local function tick()
    if not ns.db or ns.db.scanReminder == false or ns.db.fullScan == false then return end
    if S.FullWait() > 0 then reminded = false return end
    if reminded or ns.Buy.ahOpen or (InCombatLockdown and InCombatLockdown()) or (IsInInstance and IsInInstance()) then return end
    if not ns.db.fullAt then return end   -- never scanned: nothing to remind
    reminded = true
    ns.Print(L.SCAN_REMIND)
end
ns.On("Login", function()
    if C_Timer.NewTicker then C_Timer.NewTicker(30, tick) end
end)
