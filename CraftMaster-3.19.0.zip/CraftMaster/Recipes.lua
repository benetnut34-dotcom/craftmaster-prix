local _, ns = ...
local L = ns.L

-- Recipes: which ones this character knows, what they need, what they make,
-- and what they earn. The recipe list itself is ns.RECIPES (Data\Recipes.lua);
-- the materials come from the game (C_TradeSkillUI.GetRecipeSchematic,
-- remembered for every character), else from the bundled data, else from
-- what AuctionMaster read.
local R = {}
ns.Recipes = R

-- ---------------------------------------------------------------------
-- Known or not
-- ---------------------------------------------------------------------

function R.IsKnown(id)
    if ns.char.known[id] then return true end
    if IsPlayerSpell then
        local ok, yes = pcall(IsPlayerSpell, id)
        if ok and yes then return true end
    end
    if IsSpellKnown then
        local ok, yes = pcall(IsSpellKnown, id)
        if ok and yes then return true end
    end
    return false
end

-- ---------------------------------------------------------------------
-- Materials
-- ---------------------------------------------------------------------

local function readSchematic(id)
    if not (C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic) then return nil end
    local ok, s = pcall(C_TradeSkillUI.GetRecipeSchematic, id, false)
    if not ok or type(s) ~= "table" or type(s.reagentSlotSchematics) ~= "table" then return nil end
    local m = {}
    for _, slot in ipairs(s.reagentSlotSchematics) do
        local first = type(slot.reagents) == "table" and slot.reagents[1]
        local itemID = type(first) == "table" and tonumber(first.itemID)
        local basic = slot.reagentType == nil or slot.reagentType == 1
        if itemID and basic and slot.required ~= false and slot.hiddenInCraftingForm ~= true then
            m[#m + 1] = { itemID, tonumber(slot.quantityRequired) or 1 }
        end
    end
    if #m == 0 then return nil end
    local out = tonumber(s.outputItemID)
    if out == 0 then out = nil end
    local n = ((tonumber(s.quantityMin) or 1) + (tonumber(s.quantityMax) or tonumber(s.quantityMin) or 1)) / 2
    return { o = out, n = n, m = m }
end

-- Recipes AuctionMaster read from profession windows (keyed by crafted item).
local amImported = false
local function importAuctionMaster()
    if amImported then return end
    amImported = true
    if type(AuctionMasterDB) ~= "table" or type(AuctionMasterDB.factions) ~= "table" then return end
    for _, f in pairs(AuctionMasterDB.factions) do
        local data = type(f) == "table" and f.recipes and f.recipes.data
        if type(data) == "table" then
            for itemID, list in pairs(data) do
                if type(list) == "table" then
                    for _, e in ipairs(list) do
                        local id = type(e) == "table" and tonumber(e.id)
                        if id and ns.RECIPES[id] and not ns.db.schem[id] and type(e.reagents) == "table" then
                            local m = {}
                            for _, rg in ipairs(e.reagents) do
                                if rg.itemId and rg.quantity then m[#m + 1] = { rg.itemId, rg.quantity } end
                            end
                            if #m > 0 then
                                ns.db.schem[id] = { o = tonumber(itemID), n = tonumber(e.outputCount) or 1, m = m, src = "am" }
                            end
                        end
                    end
                end
            end
        end
    end
end

-- { { itemID, qty } }, crafted item ID (nil for an enchant), items made
-- per craft. Nil when the materials aren't known yet.
function R.Materials(id)
    local s = ns.db.schem[id]
    if not s then
        s = readSchematic(id)
        if s then ns.db.schem[id] = s end
    end
    local r = ns.RECIPES[id]
    if s then return s.m, s.o or (r and r.ci), s.n or 1 end
    if r and r.m then return r.m, r.ci, r.o or 1 end
    return nil, r and r.ci, 1
end

function R.Output(id)
    local _, out, n = R.Materials(id)
    return out, n or 1
end

-- Every recipe of my professions, read from the game a few at a time so
-- nothing stutters. `loud` prints how it went.
local reading = false
function R.ReadAllSchematics(loud)
    if reading then return end
    importAuctionMaster()
    local todo = {}
    for id, r in pairs(ns.RECIPES) do
        if (ns.profs[r.p] or loud) and not ns.db.schem[id] then todo[#todo + 1] = id end
    end
    reading = true
    local i = 0
    local function step()
        for _ = 1, 40 do
            i = i + 1
            local id = todo[i]
            if not id then
                reading = false
                local missing, got = 0, 0
                for rid, r in pairs(ns.RECIPES) do
                    if ns.profs[r.p] then
                        if R.Materials(rid) then got = got + 1 else missing = missing + 1 end
                    end
                end
                if loud then ns.Print(L.SCHEM_DONE, got, missing) end
                ns.Fire("RecipesChanged")
                return
            end
            local s = readSchematic(id)
            if s then ns.db.schem[id] = s end
        end
        C_Timer.After(0, step)
    end
    step()
end

-- The profession window: what's learned, for sure, and fresh materials.
local function scanWindow()
    if not (C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) then return end
    if C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked() then return end
    if C_TradeSkillUI.IsNPCCrafting and C_TradeSkillUI.IsNPCCrafting() then return end
    local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
    if not ok or type(ids) ~= "table" then return end
    for _, id in ipairs(ids) do
        local ok2, info = pcall(C_TradeSkillUI.GetRecipeInfo, id)
        if ok2 and type(info) == "table" and info.learned then ns.char.known[id] = true end
        if not ns.db.schem[id] and ns.RECIPES[id] then
            local s = readSchematic(id)
            if s then ns.db.schem[id] = s end
        end
    end
    ns.ReadProfessions()
    ns.Fire("RecipesChanged")
end

local pending = false
local function scanSoon()
    if pending then return end
    pending = true
    C_Timer.After(0.5, function() pending = false; scanWindow() end)
end
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "NEW_RECIPE_LEARNED" }) do
    ns.Register(e, scanSoon)
end

-- Daylight UI remembers the recipes each character knows: take them too.
local function importDaylightKnown()
    local db = DaylightRecipesDB
    local guid = UnitGUID and UnitGUID("player")
    local me = type(db) == "table" and type(db.chars) == "table" and guid and db.chars[guid]
    if type(me) ~= "table" or type(me.known) ~= "table" then return end
    for _, list in pairs(me.known) do
        if type(list) == "table" then
            for id, yes in pairs(list) do
                if yes and tonumber(id) then ns.char.known[tonumber(id)] = true end
            end
        end
    end
end

ns.On("Login", function()
    importDaylightKnown()
    C_Timer.After(8, function() R.ReadAllSchematics(false) end)
end)

-- ---------------------------------------------------------------------
-- Money
-- ---------------------------------------------------------------------

-- What one craft costs and earns: a table
-- { cost, costOk, value, valueAH, valueVendor, profit, margin, out, n, mats }
-- where mats = { { id, qty, unit, from, guess } }. Amounts are per craft.
-- Materials left out of a recipe's cost (owned anyway, farmed...): for one
-- recipe, or for every recipe.
function R.IsExcluded(recipeID, itemID)
    local d = ns.db
    if d.excludedGlobal and d.excludedGlobal[itemID] then return true end
    local e = d.excluded and d.excluded[recipeID]
    return e ~= nil and e[itemID] == true
end

function R.ToggleExcluded(recipeID, itemID)
    ns.db.excluded = ns.db.excluded or {}
    local ex = ns.db.excluded
    ex[recipeID] = ex[recipeID] or {}
    ex[recipeID][itemID] = not ex[recipeID][itemID] or nil
    if not next(ex[recipeID]) then ex[recipeID] = nil end
    ns.Fire("PricesChanged")
end

function R.SetExcludedGlobal(itemID, on)
    ns.db.excludedGlobal = ns.db.excludedGlobal or {}
    ns.db.excludedGlobal[itemID] = on and true or nil
    ns.Fire("PricesChanged")
end

-- A price set by hand for a material (a vendor one nobody scanned...), nil when none.
function R.CustomPrice(itemID) return ns.db.customPrices and ns.db.customPrices[itemID] end
function R.SetCustomPrice(itemID, copper)
    ns.db.customPrices = ns.db.customPrices or {}
    ns.db.customPrices[itemID] = (copper and copper > 0) and math.floor(copper) or nil
    ns.Fire("PricesChanged")
end

-- What one craft costs and earns: a table
-- { cost, costOk, value, valueAH, valueVendor, profit, margin, out, n, mats }
-- where mats = { { id, qty, unit, from, guess } }. Amounts are per craft.
function R.Price(id, sellAt)
    local mats, out, n = R.Materials(id)
    local res = { out = out, n = n or 1, mats = {} }
    if mats then
        local cost, ok = 0, true
        for _, m in ipairs(mats) do
            local unit, from, _, guess = ns.Prices.Cheapest(m[1])
            res.mats[#res.mats + 1] = { id = m[1], qty = m[2], unit = unit, from = from, guess = guess }
            if unit then cost = cost + unit * m[2] else ok = false end
        end
        res.cost, res.costOk = cost, ok
    end
    if out then
        local ah = ns.Prices.AH(out)
        local cut = 1 - ns.CutPct() / 100
        res.valueAH = ah and ah * res.n * cut or nil
        local vs = ns.Prices.VendorSell(out)
        res.valueVendor = (vs and vs > 0) and vs * res.n or nil
        sellAt = sellAt or ns.char.sellAt
        if sellAt == "vendor" then
            res.value = res.valueVendor
        elseif sellAt == "best" then
            res.value = math.max(res.valueAH or 0, res.valueVendor or 0)
            if res.value == 0 then res.value = nil end
        else
            res.value = res.valueAH
        end
    end
    if res.value and res.cost and res.costOk then
        res.profit = res.value - res.cost
        res.margin = res.cost > 0 and res.profit / res.cost or nil
    end
    return res
end

-- What a recipe needs besides materials (a specialization, a tool, a
-- forge...), from the game: { { text, unmet }, ... }.
local REQ_PREFIXES = { "Nécessite", "Requires", "Requiere", "Outils", "Tools", "Herramientas" }
local prereqCache = {}
function R.Prereqs(id)
    local c = prereqCache[id]
    if c and GetTime() - c.t < 5 then return c.list end
    local out, seen = {}, {}
    local function lines(data)
        if type(data) ~= "table" or type(data.lines) ~= "table" then return end
        for _, line in ipairs(data.lines) do
            local t = line.leftText
            if type(t) == "string" and t ~= "" then
                for _, prefix in ipairs(REQ_PREFIXES) do
                    if t:sub(1, #prefix) == prefix then
                        if not seen[t] then
                            seen[t] = true
                            local col = line.leftColor
                            out[#out + 1] = { text = t, unmet = col and col.r and col.r > 0.9 and col.g < 0.35 and col.b < 0.35 or false }
                        end
                        break
                    end
                end
            end
        end
    end
    if C_TradeSkillUI and C_TradeSkillUI.GetRecipeRequirements then
        local ok, reqs = pcall(C_TradeSkillUI.GetRecipeRequirements, id)
        if ok and type(reqs) == "table" then
            for _, req in ipairs(reqs) do
                if req.name and req.name ~= "" and not seen[req.name] then
                    seen[req.name] = true
                    out[#out + 1] = { text = req.name, unmet = req.met == false }
                end
            end
        end
    end
    if C_TooltipInfo and C_TooltipInfo.GetSpellByID then
        local ok, data = pcall(C_TooltipInfo.GetSpellByID, id)
        if ok then lines(data) end
    end
    local r = ns.RECIPES[id]
    if r and r.ri and C_TooltipInfo and C_TooltipInfo.GetItemByID then
        local ok, data = pcall(C_TooltipInfo.GetItemByID, r.ri)
        if ok then lines(data) end
    end
    prereqCache[id] = { t = GetTime(), list = out }
    return out
end

function R.Name(id)
    local n = ns.SpellName(id)
    if n then return n end
    local out = R.Output(id)
    if out then return ns.ItemName(out) end
    return "#" .. id
end

function R.Icon(id)
    local out = R.Output(id)
    if out then
        local i = ns.Item(out)
        if i and i.icon then return i.icon end
    end
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, t = pcall(C_Spell.GetSpellTexture, id)
        if ok and t then return t end
    end
    local r = ns.RECIPES[id]
    return r and ns.PROF_ICONS[r.p] or 134400
end

-- The list the Recipes page shows: rows { id, name, learn, known, price }.
function R.List(prof, filter, onlyProfit, query)
    local rows = {}
    query = query and query ~= "" and string.lower(query) or nil
    for id, r in pairs(ns.RECIPES) do
        if r.p == prof then
            local known = R.IsKnown(id)
            local learn = r.sk and r.sk[1] or 0
            local prof = ns.profs[r.p]
            local reach = not known and prof and learn <= prof.rank
            if filter == "all" or (filter == "known" and known) or (filter == "unknown" and not known)
                or (filter == "reach" and reach) then
                local name = R.Name(id)
                if not query or string.find(string.lower(name), query, 1, true) then
                    local price = R.Price(id)
                    if not onlyProfit or (price.profit and price.profit > 0) then
                        local trend
                        if price.out then
                            local series = ns.History.Series(price.out, ns.char.histDays or 30)
                            if #series > 1 then trend = ns.History.Stats(series).trend end
                        end
                        rows[#rows + 1] = { id = id, name = name, learn = learn, known = known, price = price, trend = trend }
                    end
                end
            end
        end
    end
    return rows
end

-- ---------------------------------------------------------------------
-- Reverse look-ups: what makes an item, what uses it, what a recipe item teaches
-- ---------------------------------------------------------------------

local index
function R.Index()
    if index then return index end
    index = { madeBy = {}, usedIn = {}, teaches = {}, all = {} }
    local function add(t, k, v)
        t[k] = t[k] or {}
        table.insert(t[k], v)
    end
    for id, r in pairs(ns.RECIPES) do
        local mats, out = R.Materials(id)
        if out then add(index.madeBy, out, id); index.all[out] = true end
        if mats then
            for _, m in ipairs(mats) do add(index.usedIn, m[1], id); index.all[m[1]] = true end
        end
        if r.ri then index.teaches[r.ri] = id; index.all[r.ri] = true end
    end
    return index
end
ns.On("RecipesChanged", function() index = nil end)

-- Whether one of my professions uses the item, and how many the cart needs.
function R.UsedByMe(id)
    for _, sid in ipairs(R.Index().usedIn[id] or {}) do
        if ns.profs[ns.RECIPES[sid].p] then return true end
    end
    return false
end

-- ---------------------------------------------------------------------
-- Narrow a list of recipe rows { id, ... } by the skill band they are learned in
-- ("1".."4": 1-75, 76-150, 151-225, 226-300) and by where they come from ("C"
-- learned with the profession, "T" trainer, "V" vendor, "D" drop, "Q" quest,
-- "R" reputation). nil or "all" keeps everything.
local ORIGIN_KINDS = { C = { C = true }, T = { T = true }, V = { V = true }, D = { M = true, W = true }, Q = { Q = true }, R = { R = true } }
function R.FilterBy(rows, rank, origin)
    if (not rank or rank == "all") and (not origin or origin == "all") then return rows end
    local lo, hi
    if rank and rank ~= "all" then
        local n = tonumber(rank)
        lo, hi = (n - 1) * 75 + (n > 1 and 1 or 0), n * 75
    end
    local kinds = origin and origin ~= "all" and ORIGIN_KINDS[origin]
    local out = {}
    for _, d in ipairs(rows) do
        local r = ns.RECIPES[d.id]
        local keep = true
        if lo then
            local learn = r and r.sk and r.sk[1] or 0
            keep = learn >= lo and learn <= hi
        end
        if keep and kinds then
            keep = false
            for _, s in ipairs(r and r.s or {}) do
                if kinds[s[1]] then keep = true break end
            end
        end
        if keep then out[#out + 1] = d end
    end
    return out
end

-- How to get a recipe
-- ---------------------------------------------------------------------

local function myFaction()
    local f = UnitFactionGroup and UnitFactionGroup("player")
    return f == "Horde" and "H" or f == "Alliance" and "A" or nil
end

local function npcLine(nid)
    local n = ns.NPCS[nid]
    if not n then return nil end
    local where = ns.Place(n.z or "")
    if n.x and n.x > 0 then where = string.format("%s %.0f, %.0f", where, n.x, n.y) end
    local pin = (n.x and n.x > 0 and n.z) and { zone = n.z, x = n.x, y = n.y, name = n.n } or nil
    return string.format("%s |cff999999(%s)|r", n.n or ("#" .. nid), where), n.f, pin
end
R.NpcLine = npcLine

-- A list of lines saying how to get the recipe, nearest first for the
-- player's faction (trainers and vendors of the other faction are left out).
function R.Sources(id)
    local r = ns.RECIPES[id]
    local lines = {}
    if not r or not r.s then return lines end
    local mine = myFaction()
    for _, s in ipairs(r.s) do
        local kind = s[1]
        local label = L.SRC[kind] or kind
        if kind == "T" or kind == "V" or kind == "M" then
            local names, pins = {}, {}
            for i = 2, #s do
                local text, f, pin = npcLine(s[i])
                if text and (kind == "M" or not mine or not f or f == "N" or f == mine) then
                    names[#names + 1] = text
                    if pin then pins[#pins + 1] = pin end
                end
            end
            if #names > 0 then
                local shown = {}
                for i = 1, math.min(3, #names) do shown[i] = names[i] end
                local line = table.concat(shown, ", ")
                if #names > 3 then line = line .. " " .. string.format(L.SRC_MORE, #names - 3) end
                lines[#lines + 1] = { label, line, pins = pins, kind = kind }
            end
        elseif kind == "W" then
            local zones = {}
            for i = 2, math.min(#s, 6) do zones[#zones + 1] = ns.Place(s[i]) end
            local line = table.concat(zones, ", ")
            if #s > 6 then line = line .. " " .. string.format(L.SRC_MORE, #s - 6) end
            lines[#lines + 1] = { label, line }
        elseif kind == "Q" then
            local names, qpins = {}, {}
            for i = 2, math.min(#s, 4) do
                local qid = s[i]
                local title = C_QuestLog and C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(qid)
                local q = ns.QUESTS[qid]
                names[#names + 1] = (title or ("#" .. qid)) .. (q and (" |cff999999(" .. ns.Place(q.z) .. ")|r") or "")
                if q and q.x and q.x > 0 then qpins[#qpins + 1] = { zone = q.z, x = q.x, y = q.y, name = title or ("#" .. qid), f = q.f } end
            end
            lines[#lines + 1] = { label, table.concat(names, ", "), pins = qpins, kind = kind }
        elseif kind == "R" then
            local who, pins = {}, {}
            for i = 4, #s do
                local text, _, pin = npcLine(s[i])
                if text then who[#who + 1] = text end
                if pin then pins[#pins + 1] = pin end
            end
            local rep = (L.REP[s[3]] or s[3])
            lines[#lines + 1] = { label, ns.Place(s[2]) .. " – " .. rep .. (#who > 0 and (" : " .. table.concat(who, ", ")) or ""),
                pins = pins, kind = kind }
        elseif kind == "F" then
            lines[#lines + 1] = { label, string.format(L.SRC_FAVOR, s[2]) }
        elseif kind == "C" then
            lines[#lines + 1] = { label, L.CUSTOM[s[2]] or s[2] }
        elseif kind == "E" then
            lines[#lines + 1] = { label, L.EVENT[s[2]] or s[2] }
        end
    end
    return lines
end
