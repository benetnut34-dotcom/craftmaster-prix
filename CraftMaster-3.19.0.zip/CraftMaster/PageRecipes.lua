local _, ns = ...
local L = ns.L
local W = ns.W

-- Recipes: every recipe of a profession, known or not, priced and sorted by
-- what it earns. Click one for its materials, how to get it, its price over
-- 30 days, and to put it in the cart.

local DETAIL_W = 310
local ROW_H = 24
local COLS = { -- key, label, width, justify
    { "learn", "COL_SKILL", 92, "CENTER" },
    { "cost", "COL_COST", 80, "RIGHT" },
    { "value", "COL_VALUE", 80, "RIGHT" },
    { "profit", "COL_PROFIT", 86, "RIGHT" },
    { "margin", "COL_MARGIN", 50, "RIGHT" },
    { "trend", "COL_TREND", 56, "RIGHT" },
}
local MULTS = { 1, 5, 10, 20 }

local function sortValue(row, key)
    local p = row.price
    if key == "name" then return row.name end
    if key == "learn" then return row.learn end
    if key == "cost" then return p.costOk and p.cost or nil end
    if key == "value" then return p.value end
    if key == "profit" then return p.profit end
    if key == "margin" then return p.margin end
    if key == "trend" then return row.trend end
end

ns.UI.AddPage("recipes", function(page)
    local body, color = page.body, page.color
    page.search = L.SEARCH
    local C = ns.Theme.C
    local selected
    local rows = {}

    -- ---------------------------------------------------------- toolbar
    local bar1 = CreateFrame("Frame", nil, body)
    bar1:SetHeight(24)
    bar1:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    bar1:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local profButtons = {}
    local others -- the "other professions" menu button
    local menu

    local function currentProf()
        local p = ns.char.prof
        if not p or not ns.L.PROF[p] then p = ns.MyProfs()[1] or "tailoring" end
        return p
    end

    local function buildProfButtons()
        for _, b in ipairs(profButtons) do b:Hide() end
        local x = 0
        local mine = ns.MyProfs()
        local cur = currentProf()
        local list = {}
        for _, k in ipairs(mine) do list[#list + 1] = k end
        local isOther = true
        for _, k in ipairs(mine) do if k == cur then isOther = false end end
        if isOther then list[#list + 1] = cur end
        for i, k in ipairs(list) do
            local b = profButtons[i]
            if not b then
                b = W.Button(bar1, "", 120)
                b.icon = b:CreateTexture(nil, "OVERLAY")
                b.icon:SetSize(16, 16)
                b.icon:SetPoint("LEFT", b, "LEFT", 6, 0)
                b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                profButtons[i] = b
            end
            local p = ns.profs[k]
            -- the icon says which profession; the rank beside it; the name in the tooltip
            b.SetLabel(p and string.format("|cff999999%d|r", p.rank) or "")
            b.text:ClearAllPoints()
            b.text:SetPoint("LEFT", b.icon, "RIGHT", 5, 0)
            b.icon:SetTexture(ns.PROF_ICONS[k])
            b.prof = k
            if not b.tipped then
                b.tipped = true
                W.Tip(b, function() return L.PROF[b.prof] end, function()
                    local pp = ns.profs[b.prof]
                    return pp and string.format(L.PROF_RANK_TIP, pp.rank) or nil
                end)
            end
            b:SetWidth(math.max(50, b.text:GetStringWidth() + 34))
            b:ClearAllPoints()
            b:SetPoint("LEFT", bar1, "LEFT", x, 0)
            b:SetScript("OnClick", function() ns.char.prof = k; selected = nil; page.Refresh() end)
            b.SetTint(k == cur and color or nil)
            b:Show()
            x = x + b:GetWidth() + 4
        end
        others:ClearAllPoints()
        others:SetPoint("LEFT", bar1, "LEFT", x, 0)
    end

    others = W.Button(bar1, "+ …", 40, function(self)
        if menu and menu:IsShown() then menu:Hide() return end
        if not menu then
            menu = CreateFrame("Frame", nil, self)
            menu:SetFrameStrata("FULLSCREEN_DIALOG")
            ns.Theme.Panel(menu, "menu")
            menu.items = {}
            for i, k in ipairs(ns.PROF_ORDER) do
                local it = W.Button(menu, L.PROF[k], 150, function()
                    ns.char.prof = k; selected = nil; menu:Hide(); page.Refresh()
                end)
                it:SetPoint("TOPLEFT", menu, "TOPLEFT", 6, -6 - (i - 1) * 26)
                menu.items[i] = it
            end
            menu:SetSize(162, 12 + #ns.PROF_ORDER * 26)
        end
        menu:ClearAllPoints()
        menu:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -4)
        menu:Show()
    end)
    W.Tip(others, L.PAGE.recipes, function()
        return L.OTHER_PROF
    end)

    local bar2 = CreateFrame("Frame", nil, body)
    bar2:SetHeight(24)
    bar2:SetPoint("TOPLEFT", bar1, "BOTTOMLEFT", 0, -8)
    bar2:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local filter = W.Pick(bar2, nil, { { "all", L.ALL }, { "known", L.KNOWN }, { "reach", L.REACH }, { "unknown", L.UNKNOWN } },
        function() return ns.char.filter end, function(v) ns.char.filter = v; page.Refresh() end)
    filter.color = color
    filter:SetPoint("LEFT", bar2, "LEFT", 0, 0)
    local sell = W.Pick(bar2, L.SELL_AT, { { "ah", L.FROM_AH }, { "vendor", L.SELL_VENDOR }, { "best", L.SELL_BEST } },
        function() return ns.char.sellAt end, function(v) ns.char.sellAt = v; page.Refresh() end)
    sell.color = color
    sell:SetPoint("LEFT", filter, "RIGHT", 10, 0)
    local multLabel = W.Text(bar2, "small", "LEFT")
    multLabel:SetPoint("LEFT", sell, "RIGHT", 18, 0)
    multLabel:SetText(L.MULT)
    multLabel:SetTextColor(C.label[1], C.label[2], C.label[3])
    local multItems = {}
    for _, m in ipairs(MULTS) do multItems[#multItems + 1] = { m, "×" .. m } end
    local mult = W.Segments(bar2, multItems, function() return ns.char.mult end,
        function(v) ns.char.mult = v; page.Refresh() end, 38)
    mult.color = color
    mult:SetPoint("LEFT", multLabel, "RIGHT", 8, 0)
    local multBox = W.Input(bar2, { numeric = true, width = 46, onEnter = function(t)
        local v = tonumber(t)
        if v and v >= 1 then ns.char.mult = math.floor(v); page.Refresh() end
    end })
    multBox:SetPoint("LEFT", mult, "RIGHT", 4, 0)
    W.Tip(multBox, L.MULT, L.MULT_TIP)
    for _, b in ipairs(mult.buttons) do W.Tip(b, L.MULT, L.MULT_TIP) end
    local bar3 = CreateFrame("Frame", nil, body)
    bar3:SetHeight(24)
    bar3:SetPoint("TOPLEFT", bar2, "BOTTOMLEFT", 0, -8)
    bar3:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    -- Quick sorts; the column headers sort too.
    local QUICK = { profit = { "profit", true }, margin = { "margin", true }, up = { "trend", true },
                    down = { "trend", false }, name = { "name", false } }
    local quick = W.Pick(bar3, L.SORT, { { "profit", L.COL_PROFIT }, { "margin", L.COL_MARGIN }, { "up", L.SORT_UP },
        { "down", L.SORT_DOWN }, { "name", L.SORT_NAME } }, function()
            for k, v in pairs(QUICK) do
                if ns.char.sort == v[1] and ns.char.sortDown == v[2] then return k end
            end
        end, function(v)
            ns.char.sort, ns.char.sortDown = QUICK[v][1], QUICK[v][2]
            page.Refresh()
        end)
    quick.color = color
    quick:SetPoint("LEFT", bar3, "LEFT", 0, 0)
    local periodLabel = W.Text(bar3, "small", "LEFT")
    periodLabel:SetPoint("LEFT", quick, "RIGHT", 18, 0)
    periodLabel:SetText(L.COL_TREND)
    periodLabel:SetTextColor(C.label[1], C.label[2], C.label[3])
    local period = W.Segments(bar3, { { 7, string.format(L.DAYS, 7) }, { 30, string.format(L.DAYS, 30) },
        { 90, string.format(L.DAYS, 90) } }, function() return ns.char.histDays end,
        function(v) ns.char.histDays = v; page.Refresh() end, 74)
    period.color = color
    period:SetPoint("LEFT", periodLabel, "RIGHT", 8, 0)
    W.Tip(periodLabel, L.COL_TREND, L.TREND_TIP)

    local profitSwitch = W.Switch(bar3, function() return ns.char.onlyProfit end,
        function(v) ns.char.onlyProfit = v; page.Refresh() end)
    profitSwitch:SetPoint("RIGHT", bar3, "RIGHT", -4, 0)
    local profitLabel = W.Text(bar3, "small", "RIGHT")
    profitLabel:SetPoint("RIGHT", profitSwitch, "LEFT", -8, 0)
    profitLabel:SetText(L.PROFITABLE)

    -- the rank of the profession (the skill band the recipe is learned in) and where it comes from
    local bar4 = CreateFrame("Frame", nil, body)
    bar4:SetHeight(24)
    bar4:SetPoint("TOPLEFT", bar3, "BOTTOMLEFT", 0, -8)
    bar4:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local rank = W.Pick(bar4, L.RANK, { { "all", L.ALL }, { "1", L.RANK_1 }, { "2", L.RANK_2 }, { "3", L.RANK_3 }, { "4", L.RANK_4 } },
        function() return ns.char.rank or "all" end, function(v) ns.char.rank = v; page.Refresh() end)
    rank.color = color
    rank:SetPoint("LEFT", bar4, "LEFT", 0, 0)
    local origin = W.Pick(bar4, L.ORIGIN, { { "all", L.ALL }, { "C", L.ORIGIN_C }, { "T", L.ORIGIN_T }, { "V", L.ORIGIN_V },
        { "D", L.ORIGIN_D }, { "Q", L.ORIGIN_Q }, { "R", L.ORIGIN_R } },
        function() return ns.char.origin or "all" end, function(v) ns.char.origin = v; page.Refresh() end)
    origin.color = color
    origin:SetPoint("LEFT", rank, "RIGHT", 10, 0)

    -- ---------------------------------------------------------- the figures of the list
    local tiles = W.Tiles(body, 2, 46)
    tiles:SetPoint("TOPLEFT", bar4, "BOTTOMLEFT", 0, -10)
    tiles:SetPoint("RIGHT", body, "RIGHT", -DETAIL_W - 12, 0)

    -- ---------------------------------------------------------- list
    local listCard = W.Card(body)
    listCard:SetPoint("TOPLEFT", tiles, "BOTTOMLEFT", 0, -10)
    listCard:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -DETAIL_W - 12, 0)

    local header = CreateFrame("Frame", nil, listCard)
    header:SetHeight(22)
    header:SetPoint("TOPLEFT", listCard, "TOPLEFT", 10, -8)
    header:SetPoint("RIGHT", listCard, "RIGHT", -10, 0)
    local headButtons = {}
    local function headButton(key, label, justify)
        local b = CreateFrame("Button", nil, header)
        b:SetHeight(22)
        b.text = W.Text(b, "small", justify)
        b.text:SetAllPoints()
        b.text:SetText(label)
        b.text:SetTextColor(C.label[1], C.label[2], C.label[3])
        b:SetScript("OnClick", function()
            if ns.char.sort == key then ns.char.sortDown = not ns.char.sortDown
            else ns.char.sort = key; ns.char.sortDown = key ~= "name" and key ~= "learn" end
            page.Refresh()
        end)
        b.arrow = b:CreateTexture(nil, "OVERLAY")
        b.arrow:SetSize(10, 10)
        b.arrow:SetTexture(ns.MEDIA .. "chevron.png")
        b.arrow:Hide()
        b.key, b.label, b.justify = key, label, justify
        headButtons[#headButtons + 1] = b
        return b
    end
    local nameHead = headButton("name", L.COL_RECIPE, "LEFT")
    nameHead:SetPoint("LEFT", header, "LEFT", 28, 0)
    local x = -30
    local colHeads = {}
    for i = #COLS, 1, -1 do
        local col = COLS[i]
        local b = headButton(col[1], L[col[2]], col[4])
        b:SetWidth(col[3])
        b:SetPoint("RIGHT", header, "RIGHT", x, 0)
        colHeads[i] = b
        x = x - col[3] - 8
    end
    nameHead:SetPoint("RIGHT", colHeads[1], "LEFT", -8, 0)
    local sep = header:CreateTexture(nil, "ARTWORK")
    sep:SetHeight(1)
    sep:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -2)
    sep:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, -2)
    sep:SetColorTexture(1, 1, 1, 0.08)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(18, 18)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        r.lock = r:CreateTexture(nil, "OVERLAY")
        r.lock:SetSize(10, 10)
        r.lock:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT", 3, -3)
        r.lock:SetTexture(ns.MEDIA .. "rond.png")
        r.cols = {}
        local xx = -30
        for i = #COLS, 1, -1 do
            local col = COLS[i]
            local fs = W.Text(r, "small", col[4])
            fs:SetWidth(col[3])
            fs:SetPoint("RIGHT", r, "RIGHT", xx, 0)
            r.cols[i] = fs
            xx = xx - col[3] - 8
        end
        -- the skill bar replaces the level number: orange, yellow, green, grey, and where I stand
        r.skill = W.SkillBar(r, 84, 10)
        r.skill:SetPoint("CENTER", r.cols[1], "CENTER", 0, 0)
        W.Tip(r.skill, function() return L.SKILLBAR_TITLE end, function()
            local sk = r.data and ns.RECIPES[r.data.id].sk
            if not sk then return nil end
            return string.format(L.SKILLBAR_TIP, sk[1], sk[2], sk[3], sk[4], sk[5])
        end)
        r.spark = ns.Chart.Spark(r, 50, 16)
        r.spark:SetPoint("RIGHT", r.cols[1], "LEFT", -8, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
        r.name:SetPoint("RIGHT", r.spark, "LEFT", -4, 0)
        r.name:SetWordWrap(false)
        r.add = W.Button(r, "+", 22, function(self)
            local d = self:GetParent().data
            if d then ns.Cart.Add(d.id, ns.char.mult) end
        end)
        r.add:SetHeight(20)
        r.add:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        W.Tip(r.add, L.ADD_CART, function() return string.format("x%d", ns.char.mult) end)
        r:SetScript("OnClick", function(self)
            selected = self.data and self.data.id
            page.RefreshDetail()
            page.list.Update()
        end)
        return r
    end

    local function fillRow(r, d)
        r.data = d
        local p, mult = d.price, ns.char.mult
        r.sel:SetShown(selected == d.id)
        r.icon:SetTexture(ns.Recipes.Icon(d.id))
        r.icon:SetDesaturated(not d.known)
        local q = p.out and ns.Item(p.out) and ns.Item(p.out).quality or 1
        local cr, cg, cb = ns.QualityColor(q)
        if not d.known then cr, cg, cb = cr * 0.7, cg * 0.7, cb * 0.7 end
        r.name:SetText(d.name)
        r.name:SetTextColor(cr, cg, cb)
        r.spark.Set(ns.Chart.PriceSeries(p.out))
        if d.known then
            r.lock:SetVertexColor(C.profit[1], C.profit[2], C.profit[3], 1)
        else
            r.lock:SetVertexColor(0.55, 0.55, 0.6, 1)
        end
        local prof = ns.profs[ns.RECIPES[d.id].p]
        r.cols[1]:SetText("")
        r.skill.Set(ns.RECIPES[d.id].sk, prof and prof.rank or nil)
        r.cols[2]:SetText(p.cost and ((p.costOk and "" or "> ") .. ns.Money(p.cost * mult, true)) or "-")
        r.cols[2]:SetTextColor(C.text[1], C.text[2], C.text[3])
        if p.value then
            r.cols[3]:SetText(ns.Money(p.value * mult, true))
            r.cols[3]:SetTextColor(C.text[1], C.text[2], C.text[3])
        else
            r.cols[3]:SetText(p.out and L.NO_PRICE or L.ENCHANT)
            r.cols[3]:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
        end
        W.ProfitText(r.cols[4], p.profit and p.profit * mult)
        if p.margin then
            r.cols[5]:SetText(string.format("%+d%%", math.floor(p.margin * 100 + 0.5)))
            local c = p.margin >= 0 and C.profit or C.loss
            r.cols[5]:SetTextColor(c[1], c[2], c[3])
        else
            r.cols[5]:SetText("-")
            r.cols[5]:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
        end
        if d.trend then
            local c = d.trend > 0 and C.profit or d.trend < 0 and C.loss or C.label
            r.cols[6]:SetText(string.format("%+d%%", math.floor(d.trend * 100 + 0.5)))
            r.cols[6]:SetTextColor(c[1], c[2], c[3])
        else
            r.cols[6]:SetText("-")
            r.cols[6]:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
        end
    end

    local list = W.List(listCard, ROW_H, makeRow, fillRow)
    list:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -6)
    list:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -6, 8)
    list.Color(color)
    page.list = list
    local empty = W.Text(listCard, "body", "CENTER")
    empty:SetPoint("TOPLEFT", list, "TOPLEFT", 20, -40)
    empty:SetPoint("TOPRIGHT", list, "TOPRIGHT", -20, -40)
    empty:SetWordWrap(true)
    empty:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- ---------------------------------------------------------- detail
    local det = W.Card(body)
    det:SetPoint("TOPRIGHT", bar3, "BOTTOMRIGHT", 0, -10)
    det:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    det:SetWidth(DETAIL_W)
    page.det = det
    local dIcon = W.ItemIcon(det, 36)
    dIcon:SetPoint("TOPLEFT", det, "TOPLEFT", 14, -14)
    local dName = W.Text(det, "head", "LEFT")
    dName:SetPoint("TOPLEFT", dIcon, "TOPRIGHT", 10, -2)
    dName:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    dName:SetWordWrap(true)
    local dStatus = W.Text(det, "small", "LEFT")
    dStatus:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -3)
    dStatus:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    dStatus:SetWordWrap(true)
    local dPick = W.Text(det, "body", "CENTER")
    dPick:SetPoint("CENTER", det, "CENTER")
    dPick:SetTextColor(C.label[1], C.label[2], C.label[3])
    dPick:SetText(L.PICK_RECIPE)

    -- The details flow down in a scrolling area between the title and the chart.
    local scroll = CreateFrame("ScrollFrame", nil, det)
    scroll:SetPoint("TOPLEFT", dIcon, "BOTTOMLEFT", 0, -10)
    scroll:SetPoint("BOTTOMRIGHT", det, "BOTTOMRIGHT", -12, 190)
    local content = W.Flow(scroll)
    content:SetWidth(DETAIL_W - 28)
    scroll:SetScrollChild(content)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, d)
        local max = math.max(0, content:GetHeight() - self:GetHeight())
        self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - d * 30)))
    end)

    local chart = ns.Chart.New(det)
    chart:SetHeight(120)
    chart:SetPoint("BOTTOMLEFT", det, "BOTTOMLEFT", 6, 46)
    chart:SetPoint("BOTTOMRIGHT", det, "BOTTOMRIGHT", -10, 46)
    local chartTitle = W.Text(det, "small", "LEFT")
    chartTitle:SetPoint("BOTTOMLEFT", chart, "TOPLEFT", 8, 4)
    chartTitle:SetText(L.PRICE_30D)
    chartTitle:SetTextColor(C.label[1], C.label[2], C.label[3])

    local qty = W.Input(det, { numeric = true, width = 50 })
    qty:SetPoint("BOTTOMLEFT", det, "BOTTOMLEFT", 14, 12)
    local qtyLabel = W.Text(det, "small", "LEFT")
    qtyLabel:SetPoint("BOTTOMLEFT", qty, "TOPLEFT", 0, 2)
    local add = W.Button(det, L.ADD_CART, 160, function()
        if selected then ns.Cart.Add(selected, tonumber(qty:GetText()) or ns.char.mult) end
    end)
    add:SetPoint("LEFT", qty, "RIGHT", 8, 0)
    add.SetTint(ns.Theme.SECTIONS.cart)
    local detailParts = { dIcon, dName, dStatus, scroll, chart, chartTitle, qty, add }

    function page.RefreshDetail()
        content.Clear()
        scroll:SetVerticalScroll(0)
        local id = selected
        local r = id and ns.RECIPES[id]
        for _, part in ipairs(detailParts) do part:SetShown(r ~= nil) end
        dPick:SetShown(r == nil)
        if not r then return end
        local mult = ns.char.mult
        local p = ns.Recipes.Price(id)
        local known = ns.Recipes.IsKnown(id)
        dIcon.Set(p.out, ns.Recipes.Icon(id))
        local q = p.out and ns.Item(p.out) and ns.Item(p.out).quality or 1
        dName:SetText(ns.Recipes.Name(id))
        dName:SetTextColor(ns.QualityColor(q))
        local prof = ns.profs[r.p]
        local learn = r.sk and r.sk[1] or 0
        local status = known and ("|cff73d982" .. L.KNOWN_YES .. "|r") or ("|cffb0b3ba" .. L.KNOWN_NO .. "|r")
        if not known and learn > 0 then
            local need = prof and string.format(L.SKILL_NEED, L.PROF[r.p], learn, prof.rank)
                or string.format(L.SKILL_NEED_NOPROF, L.PROF[r.p], learn)
            if prof and prof.rank < learn then need = "|cffef5c42" .. need .. "|r" end
            status = status .. " " .. need
        end
        if r.sk and r.sk[2] and r.sk[2] > 0 then
            -- when it still gives skill: orange (always), yellow, green, then grey (nothing more)
            status = status .. "\n" .. L.SKILLUP .. " |cffff8040" .. r.sk[2] .. "|r  |cffffff00" .. (r.sk[3] or "") .. "|r  |cff40c040"
                .. (r.sk[4] or "") .. "|r  |cff8c8c8c" .. (r.sk[5] or "") .. "|r"
        end
        dStatus:SetText(status)

        if not known then
            content.Head(L.HOW_TO_GET, color)
            local src = ns.Recipes.Sources(id)
            if #src == 0 then content.Line(L.SRC_UNKNOWN, { color = C.label }) end
            for i, s in ipairs(src) do
                if i > 6 then break end
                local pins = s.pins
                content.Line("|cffd9a441" .. s[1] .. "|r  " .. s[2], {
                    pin = (pins and #pins > 0) and function() ns.Map.GoNearest(pins) end or nil,
                })
            end
            if r.ri and r.bop then content.Line(L.RECIPE_ITEM_BOP, { color = C.sky }) end
        end

        if r.ri and not r.bop then
            -- the plan itself: bought from a merchant, resold at the Auction House,
            -- whether or not the recipe is known
            local ah, _, qty = ns.Prices.AH(r.ri)
            local vb = ns.Prices.VendorBuy(r.ri)
            local vend
            for _, s in ipairs(ns.Recipes.Sources(id)) do if s.kind == "V" then vend = s break end end
            local vlist = ns.Prices.VendorsOf(r.ri)
            if vend or #vlist > 0 or ah then
                content.Head(L.PLAN_HEAD, color)
                if vend then
                    content.Line(L.PLAN_VENDOR .. "  " .. vend[2], {
                        pin = (vend.pins and #vend.pins > 0) and function() ns.Map.GoNearest(vend.pins) end or nil })
                else
                    for n, v in ipairs(vlist) do
                        if n > 2 then break end
                        content.Line(L.PLAN_VENDOR .. "  " .. v.name .. " |cff999999(" .. ns.Place(v.zone) .. string.format(" %.0f, %.0f", v.x, v.y) .. ")|r",
                            { pin = function() ns.Map.Go(v.pin) end })
                    end
                end
                content.Line(L.PLAN_VENDOR_PRICE .. "  " .. (vb and ns.Money(vb) or ("|cff999999" .. L.PLAN_VENDOR_UNKNOWN .. "|r")), {})
                if ah then
                    local st = ns.SaleStats(r.ri, ns.House())
                    local more = {}
                    if qty then more[#more + 1] = string.format(L.PLAN_FOR_SALE, qty) end
                    if st and st.n and st.n >= 2 and st.p25 then more[#more + 1] = string.format(L.PLAN_SELLS_AT, ns.Money(st.p25)) end
                    if st and st.perDay and st.perDay > 0 then more[#more + 1] = string.format(L.PLAN_PER_DAY, st.perDay) end
                    content.Line(L.PLAN_AH .. "  " .. ns.Money(ah) .. (#more > 0 and ("  |cff999999(" .. table.concat(more, ", ") .. ")|r") or ""), { color = C.sky })
                    if vb then
                        local gain = ah * (1 - ns.CutPct() / 100) - vb
                        content.Line(L.PLAN_GAIN .. "  " .. ns.Money(math.abs(gain)) .. (gain < 0 and (" |cffef5c42" .. L.PLAN_LOSS .. "|r") or ""),
                            { color = gain >= 0 and C.profit or C.loss })
                    end
                end
            end
        end

        content.Head(L.REAGENTS .. (mult > 1 and ("  |cff999999x" .. mult .. "|r") or ""), color)
        if #p.mats == 0 then content.Line(L.REAGENTS_NONE, { color = C.label }) end
        for _, m in ipairs(p.mats) do
            local tag = m.from == "vendor" and ("|cffef9e3d" .. L.FROM_VENDOR .. "|r")
                or m.from == "ah" and ("|cff61a8f5" .. L.FROM_AH .. "|r") or "|cff999999?|r"
            local mid = m.id
            content.Line(string.format("%d× %s  %s", m.qty * mult, ns.ItemName(mid), tag), {
                icon = ns.Item(mid) and ns.Item(mid).icon or 134400,
                right = m.unit and ns.Money(m.unit * m.qty * mult, true) or "-",
                pin = ns.Map.HasSpots() and function()
                    local spots = ns.Map.Spots(mid)
                    if #spots == 0 then spots = ns.Map.Vendors(mid) end
                    if #spots == 0 then ns.Print(L.MAP_NO_SPOT, ns.ItemName(mid)) else ns.Map.GoNearest(spots) end
                end or nil,
                pinTip = L.MAP_SPOT,
            })
        end
        content.Gap(4)
        content.Money(L.TOTAL_COST, p.cost and p.cost * mult)
        if p.out then
            content.Money(string.format(L.SELL_AH_LINE, ns.CutPct()), p.valueAH and p.valueAH * mult)
            content.Money(L.SELL_VENDOR_LINE, p.valueVendor and p.valueVendor * mult)
        end
        content.Money(L.COL_PROFIT, p.profit and p.profit * mult, true)

        local series = {}
        if p.out then
            series[#series + 1] = { points = ns.History.Series(p.out, 30), color = C.sky, label = L.HIST_PRICE }
        end
        series[#series + 1] = { points = ns.History.CostSeries(id, 30), color = C.amber, label = L.HIST_COST }
        chart.Draw(series, 30, L.HIST_NONE)
        qty:SetText(tostring(mult))
        qtyLabel:SetText(L.QTY)
        qtyLabel:SetTextColor(C.label[1], C.label[2], C.label[3])
    end

    function page.Refresh()
        buildProfButtons()
        filter.Refresh(); sell.Refresh(); mult.Refresh(); quick.Refresh(); period.Refresh(); rank.Refresh(); origin.Refresh()
        profitSwitch.Refresh()
        local inPreset = false
        for _, m in ipairs(MULTS) do if m == ns.char.mult then inPreset = true end end
        multBox:SetText(inPreset and "" or tostring(ns.char.mult))
        for _, b in ipairs(headButtons) do
            local on = ns.char.sort == b.key
            b.text:SetText(b.label)
            b.arrow:SetShown(on)
            if on then
                b.text:SetTextColor(color[1], color[2], color[3])
                b.arrow:SetVertexColor(color[1], color[2], color[3])
                if ns.char.sortDown then b.arrow:SetTexCoord(0, 1, 0, 1) else b.arrow:SetTexCoord(0, 1, 1, 0) end
                b.arrow:ClearAllPoints()
                local w = b.text:GetStringWidth() or 30
                if b.justify == "RIGHT" then b.arrow:SetPoint("RIGHT", b, "RIGHT", -w - 3, 0)
                elseif b.justify == "CENTER" then b.arrow:SetPoint("LEFT", b, "CENTER", w / 2 + 2, 0)
                else b.arrow:SetPoint("LEFT", b, "LEFT", w + 4, 0) end
            else
                b.text:SetTextColor(C.label[1], C.label[2], C.label[3])
            end
        end
        local prof = currentProf()
        rows = ns.Recipes.List(prof, ns.char.filter, ns.char.onlyProfit, page.query)
        rows = ns.Recipes.FilterBy(rows, ns.char.rank, ns.char.origin)
        local key, down = ns.char.sort, ns.char.sortDown
        table.sort(rows, function(a, b)
            local va, vb = sortValue(a, key), sortValue(b, key)
            if va == nil and vb == nil then return a.name < b.name end
            if va == nil then return false end
            if vb == nil then return true end
            if va == vb then return a.name < b.name end
            if down then return va > vb end
            return va < vb
        end)
        list.SetData(rows, true)
        empty:SetShown(#rows == 0)
        empty:SetText(#ns.MyProfs() == 0 and L.NO_PROFESSION or L.NO_RECIPE)
        -- the figures: the best craft of the list, how many pay, the cart
        local bestRow, bestV, good = nil, nil, 0
        for _, r in ipairs(rows) do
            local v = sortValue(r, "profit")
            if v then
                if v > 0 then good = good + 1 end
                if not bestV or v > bestV then bestRow, bestV = r, v end
            end
        end
        if bestRow then
            tiles.Set(1, L.REC_T_BEST, bestRow.name .. "  " .. (bestV >= 0 and "+" or "-") .. ns.Money(math.abs(bestV)),
                bestV > 0 and C.profit or C.loss)
        else
            tiles.Set(1, L.REC_T_BEST, "-", C.label)
        end
        tiles.Set(2, L.REC_T_GOOD, string.format(L.REC_T_GOOD_N, good, #rows), good > 0 and C.profit or C.label)
        page.RefreshDetail()
    end

    function page.OnSearch() page.Refresh() end
end)
