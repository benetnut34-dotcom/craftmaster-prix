local _, ns = ...
local L = ns.L

-- Map markers: the game's own waypoint and its arrow, to a trainer, a vendor,
-- or a farming spot. A route is a list of stops: the next one is set as soon
-- as the player gets close to the current one (or with the Next button).
local M = {}
ns.Map = M

-- Zone names of the recipe data -> the game's map IDs (Classic maps, which
-- Forever uses). Zones Forever added are looked up by name at run time.
local ZONES = {
    ["Durotar"] = 1411, ["Mulgore"] = 1412, ["The Barrens"] = 1413, ["Kalimdor"] = 1414, ["Eastern Kingdoms"] = 1415,
    ["Alterac Mountains"] = 1416, ["Arathi Highlands"] = 1417, ["Badlands"] = 1418, ["Blasted Lands"] = 1419,
    ["Tirisfal Glades"] = 1420, ["Silverpine Forest"] = 1421, ["Western Plaguelands"] = 1422,
    ["Eastern Plaguelands"] = 1423, ["Hillsbrad Foothills"] = 1424, ["The Hinterlands"] = 1425, ["Dun Morogh"] = 1426,
    ["Searing Gorge"] = 1427, ["Burning Steppes"] = 1428, ["Elwynn Forest"] = 1429, ["Deadwind Pass"] = 1430,
    ["Duskwood"] = 1431, ["Loch Modan"] = 1432, ["Redridge Mountains"] = 1433, ["Stranglethorn Vale"] = 1434,
    ["Swamp of Sorrows"] = 1435, ["Westfall"] = 1436, ["Wetlands"] = 1437, ["Teldrassil"] = 1438, ["Darkshore"] = 1439,
    ["Ashenvale"] = 1440, ["Thousand Needles"] = 1441, ["Stonetalon Mountains"] = 1442, ["Desolace"] = 1443,
    ["Feralas"] = 1444, ["Dustwallow Marsh"] = 1445, ["Tanaris"] = 1446, ["Azshara"] = 1447, ["Felwood"] = 1448,
    ["Un'Goro Crater"] = 1449, ["Moonglade"] = 1450, ["Silithus"] = 1451, ["Winterspring"] = 1452,
    ["Stormwind City"] = 1453, ["Orgrimmar"] = 1454, ["Ironforge"] = 1455, ["Thunder Bluff"] = 1456,
    ["Darnassus"] = 1457, ["Undercity"] = 1458, ["Alterac Valley"] = 1459,
}

local byName -- localized map name -> map ID, built once when needed
local function lookup(name)
    if not (C_Map and C_Map.GetMapInfo) then return nil end
    if not byName then
        byName = {}
        for id = 1, 3000 do
            local info = C_Map.GetMapInfo(id)
            if info and info.name and not byName[info.name] and (info.mapType == 3 or info.mapType == 2 or info.mapType == 5) then
                byName[info.name] = id
            end
        end
    end
    return byName[name] or byName[ns.Place(name)]
end

function M.MapID(zone)
    if type(zone) == "number" then return zone end
    return ZONES[zone] or lookup(zone)
end

local function playerSpot()
    if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
    local map = C_Map.GetBestMapForUnit("player")
    local pos = map and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    if not pos then return map end
    local x, y = pos.x, pos.y
    if pos.GetXY then x, y = pos:GetXY() end
    return map, x, y
end

local function continentOf(map)
    local guard = 0
    while map and C_Map.GetMapInfo and guard < 6 do
        local info = C_Map.GetMapInfo(map)
        if not info then return nil end
        if info.mapType == 2 then return map end
        map = info.parentMapID
        guard = guard + 1
    end
end

-- The pin to go to first: in my zone, then on my continent, then any.
function M.Nearest(pins)
    if not pins or #pins == 0 then return nil end
    local here, px, py = playerSpot()
    local cont = here and continentOf(here)
    local best, bestScore
    for _, p in ipairs(pins) do
        local id = M.MapID(p.zone)
        if id then
            local score = 3
            if id == here then
                score = 0 + ((px and p.x) and math.sqrt((p.x / 100 - px) ^ 2 + (p.y / 100 - py) ^ 2) or 0.5)
            elseif cont and continentOf(id) == cont then
                score = 2
            end
            if not bestScore or score < bestScore then best, bestScore = p, score end
        end
    end
    return best or pins[1]
end

local route, routeAt -- the stops, and which one is set now

local function set(p)
    local id = M.MapID(p.zone)
    if not id or not (C_Map and C_Map.SetUserWaypoint and UiMapPoint) then
        ns.Print(L.MAP_NO_PIN, p.name or "", ns.Place(p.zoneName or p.zone or "?"), p.x or 0, p.y or 0)
        return false
    end
    if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(id) then
        ns.Print(L.MAP_NO_PIN, p.name or "", ns.Place(p.zoneName or p.zone or "?"), p.x or 0, p.y or 0)
        return false
    end
    local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(id, p.x / 100, p.y / 100))
    if ok and C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
    end
    ns.Print(L.MAP_PIN, p.name or "", ns.Place(p.zoneName or p.zone or "?"), p.x or 0, p.y or 0)
    return ok
end

-- One marker.
function M.Go(p)
    if not p then return end
    route, routeAt = nil, nil
    set(p)
    ns.Fire("RouteChanged")
end

-- One marker, and the world map opened on its zone (to see where it is).
function M.Show(p)
    if not p then return end
    M.Go(p)
    local id = M.MapID(p.zone)
    if not id then return end
    if WorldMapFrame and not WorldMapFrame:IsShown() then
        if ToggleWorldMap then pcall(ToggleWorldMap) elseif OpenWorldMap then pcall(OpenWorldMap, id) end
    end
    if WorldMapFrame and WorldMapFrame.SetMapID then pcall(WorldMapFrame.SetMapID, WorldMapFrame, id) end
end

-- The nearest of several places (all the trainers, all the spots).
function M.GoNearest(pins) M.Go(M.Nearest(pins)) end

-- Several stops in order.
function M.Route(stops)
    if not stops or #stops == 0 then return end
    route, routeAt = stops, 1
    M.WatchRoute(true)
    ns.Print(L.MAP_ROUTE, #stops)
    set(stops[1])
    ns.Fire("RouteChanged")
end

function M.Next()
    if not route then return end
    routeAt = routeAt + 1
    if routeAt > #route then
        M.Clear()
        ns.Print(L.MAP_ROUTE_DONE)
        return
    end
    set(route[routeAt])
    ns.Fire("RouteChanged")
end

function M.Clear()
    route, routeAt = nil, nil
    M.WatchRoute(false)
    if C_Map and C_Map.ClearUserWaypoint then pcall(C_Map.ClearUserWaypoint) end
    ns.Fire("RouteChanged")
end

function M.RouteState()
    if not route then return nil end
    return routeAt, #route, route[routeAt]
end

-- Arrived (close enough on the same map): on to the next stop.
-- The watcher only runs while a route is on (it used to run on every frame of
-- the whole session for nothing).
local ticker = 0
local watcher = CreateFrame("Frame")
local function watch(_, elapsed)
    ticker = ticker + elapsed
    if ticker < 2 or not route then return end
    ticker = 0
    local stop = route[routeAt]
    local here, px, py = playerSpot()
    if stop and here and px and M.MapID(stop.zone) == here then
        local d = math.sqrt((stop.x / 100 - px) ^ 2 + (stop.y / 100 - py) ^ 2)
        if d < 0.015 then M.Next() end
    end
end
function M.WatchRoute(on) watcher:SetScript("OnUpdate", on and watch or nil) end

-- ---------------------------------------------------------------------
-- Trainers of a profession (the "maître"), from the recipe data
-- ---------------------------------------------------------------------

local trainers = {}
function M.Trainers(prof)
    if trainers[prof] then return trainers[prof] end
    local f = UnitFactionGroup and UnitFactionGroup("player")
    local mine = f == "Horde" and "H" or f == "Alliance" and "A" or nil
    local seen, out = {}, {}
    for _, r in pairs(ns.RECIPES) do
        if r.p == prof and r.s then
            for _, s in ipairs(r.s) do
                if s[1] == "T" then
                    for i = 2, #s do
                        local nid = s[i]
                        local n = ns.NPCS[nid]
                        if n and not seen[nid] and n.x and n.x > 0 and (not mine or not n.f or n.f == "N" or n.f == mine) then
                            seen[nid] = true
                            out[#out + 1] = { zone = n.z, x = n.x, y = n.y, name = n.n }
                        end
                    end
                end
            end
        end
    end
    trainers[prof] = out
    return out
end

-- ---------------------------------------------------------------------
-- Farming spots of a material, from Questie's database (when installed):
-- the creatures that drop it and the nodes (herbs, veins, chests) that
-- hold it, with where they stand.
-- ---------------------------------------------------------------------

local function questie()
    local db = LibQuestieDB
    local zoneDB
    if QuestieLoader and QuestieLoader.ImportModule then
        local ok, z = pcall(QuestieLoader.ImportModule, QuestieLoader, "ZoneDB")
        if ok then zoneDB = z end
    end
    return db, zoneDB
end

function M.HasSpots() return LibQuestieDB ~= nil end

local function uiMap(zoneDB, area)
    if zoneDB and zoneDB.GetUiMapIdByAreaId then
        local ok, id = pcall(zoneDB.GetUiMapIdByAreaId, zoneDB, area)
        if ok and id then return id end
    end
    return area
end

local function addSpawns(out, zoneDB, name, spawns, kind)
    if type(spawns) ~= "table" then return end
    for area, list in pairs(spawns) do
        if type(list) == "table" and #list > 0 then
            -- the middle of the spawns in that zone, and how many there are
            local sx, sy, n = 0, 0, 0
            for _, c in ipairs(list) do
                if type(c) == "table" and c[1] and c[1] > 0 then sx, sy, n = sx + c[1], sy + c[2], n + 1 end
            end
            if n > 0 then
                local id = uiMap(zoneDB, area)
                local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(id)
                out[#out + 1] = { zone = id, zoneName = info and info.name or tostring(id), x = sx / n, y = sy / n,
                                  name = name, count = n, kind = kind }
            end
        end
    end
end

-- { { zone (map ID), zoneName, x, y, name, count, kind = "mob" | "node" } }, most spawns first.
function M.Spots(itemID)
    local db, zoneDB = questie()
    if not db or not db.Item then return {} end
    local out = {}
    local function get(t, id, field)
        local ok, v = pcall(t.Get, id, field)
        if ok then return v end
        ok, v = pcall(t.Get, t, id, field)
        if ok then return v end
    end
    local drops = get(db.Item, itemID, "npcDrops")
    if type(drops) == "table" and db.Npc then
        for i, nid in ipairs(drops) do
            if i > 25 then break end
            addSpawns(out, zoneDB, get(db.Npc, nid, "name") or ("#" .. nid), get(db.Npc, nid, "spawns"), "mob")
        end
    end
    local nodes = get(db.Item, itemID, "objectDrops")
    if type(nodes) == "table" and db.Object then
        for i, oid in ipairs(nodes) do
            if i > 25 then break end
            addSpawns(out, zoneDB, get(db.Object, oid, "name") or ("#" .. oid), get(db.Object, oid, "spawns"), "node")
        end
    end
    table.sort(out, function(a, b) return a.count > b.count end)
    return out
end

-- Vendors that sell the item, from Questie: { { zone, x, y, name } }.
function M.Vendors(itemID)
    local db, zoneDB = questie()
    if not db or not db.Item or not db.Npc then return {} end
    local ok, list = pcall(db.Item.Get, itemID, "vendors")
    if not ok then ok, list = pcall(db.Item.Get, db.Item, itemID, "vendors") end
    local out = {}
    if type(list) ~= "table" then return out end
    local f = UnitFactionGroup and UnitFactionGroup("player")
    local mine = f == "Horde" and "H" or f == "Alliance" and "A" or nil
    for _, nid in ipairs(list) do
        local _, name = pcall(db.Npc.Get, nid, "name")
        local _, spawns = pcall(db.Npc.Get, nid, "spawns")
        -- Questie says who a creature is friendly to: "A", "H" or "AH"
        local _, friendly = pcall(db.Npc.Get, nid, "friendlyToFaction")
        if mine and type(friendly) == "string" and friendly ~= "" and not friendly:find(mine, 1, true) then spawns = nil end
        addSpawns(out, zoneDB, type(name) == "string" and name or ("#" .. nid), spawns, "vendor")
    end
    return out
end
