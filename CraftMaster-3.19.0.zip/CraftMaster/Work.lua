local _, ns = ...

-- Work : repartit les gros travaux sur plusieurs images pour que le jeu ne
-- saccade jamais. A 60 images/s une image dure 16 ms : on ne prend qu'un petit
-- budget (5 ms) par image, le reste attend l'image suivante.
--   ns.Work.Add(nom, etape, fin)   etape() fait un morceau borne et renvoie true
--                                  quand tout est fini ; fin() est appele apres.
--   ns.Work.Due()                  vrai quand le budget de l'image est epuise
--                                  (a tester toutes les ~100 iterations d'une boucle).
-- ns.Work.Sync = true (tests, bench) : tout est fait tout de suite, sans images.
local Wk = {}
ns.Work = Wk

Wk.BUDGET = 5               -- ms de travail par image
Wk.Sync = false
local clock = debugprofilestop or function() return (GetTime and GetTime() or 0) * 1000 end
Wk.Clock = clock
Wk.deadline = 0

function Wk.Arm(ms) Wk.deadline = clock() + (ms or Wk.BUDGET) end
function Wk.Due() return clock() >= Wk.deadline end

local jobs = {}
local frame = CreateFrame("Frame")

local function runOne(j)
    local ok, done = pcall(j.step)
    if not ok then
        ns.Debug("travail %s : %s", tostring(j.name), tostring(done))
        return true
    end
    if done and j.finish then
        local ok2, err = pcall(j.finish)
        if not ok2 then ns.Debug("fin du travail %s : %s", tostring(j.name), tostring(err)) end
    end
    return done
end

local function pump()
    Wk.Arm()
    while jobs[1] do
        if runOne(jobs[1]) then table.remove(jobs, 1) end
        if Wk.Due() then break end
    end
    if not jobs[1] then frame:SetScript("OnUpdate", nil) end
end

function Wk.Add(name, step, finish)
    local j = { name = name, step = step, finish = finish }
    if Wk.Sync then
        Wk.deadline = math.huge
        local guard = 0
        while not runOne(j) and guard < 1000000 do guard = guard + 1 end
        return
    end
    jobs[#jobs + 1] = j
    frame:SetScript("OnUpdate", pump)
end

function Wk.Busy() return jobs[1] ~= nil end
