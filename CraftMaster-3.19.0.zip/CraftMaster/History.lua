local _, ns = ...

-- Price history: one number a day per item, the lowest Auction House price
-- seen that day, for the materials and crafts of my professions and of the
-- cart. Kept as a flat list { day, price, day, price, ... }, oldest first.
local H = {}
ns.History = H

local function store(house)
    ns.db.histBy = ns.db.histBy or {}
    local k = ns.HouseKey(house)
    ns.db.histBy[k] = ns.db.histBy[k] or {}
    return ns.db.histBy[k]
end
H.Store = store
-- The store of a house key ("PvP-Horde"...), for the imports.
function H.StoreOf(key)
    ns.db.histBy = ns.db.histBy or {}
    ns.db.histBy[key] = ns.db.histBy[key] or {}
    return ns.db.histBy[key]
end

local function note(id, day, price, house)
    if type(price) ~= "number" or price <= 0 then return end
    local db = store(house)
    local list = db[id]
    if not list then list = {}; db[id] = list end
    local n = #list
    if n >= 2 and list[n - 1] == day then
        if price < list[n] then list[n] = price end
        return
    end
    if n >= 2 and list[n - 1] > day then
        -- an older day (seeding): put it in its place
        local at = n - 1
        while at >= 1 and list[at] > day do at = at - 2 end
        if at >= 1 and list[at] == day then
            if price < list[at + 1] then list[at + 1] = price end
            return
        end
        table.insert(list, at + 2, day)
        table.insert(list, at + 3, price)
        return
    end
    list[n + 1] = day
    list[n + 2] = price
end

local function trim(list, keep)
    local first = ns.Today() - keep
    while #list >= 2 and list[1] < first do
        table.remove(list, 1)
        table.remove(list, 1)
    end
end

-- The items worth following.
function H.Tracked()
    local set = {}
    for id, r in pairs(ns.RECIPES) do
        if ns.profs[r.p] then
            local mats, out = ns.Recipes.Materials(id)
            if out then set[out] = true end
            if mats then for _, m in ipairs(mats) do set[m[1]] = true end end
        end
    end
    return set
end

-- Both houses: the faction one from every source, the shared one from
-- CraftMaster's own scan (when there is one).
function H.Snapshot()
    local day = ns.Today()
    local n = 0
    local neutral = ns.Scan.LastAt("neutral") ~= nil
    for id in pairs(H.Tracked()) do
        local price = ns.Prices.AH(id, "faction")
        if price then note(id, day, price, "faction"); n = n + 1 end
        if neutral then
            local pn = ns.Prices.AH(id, "neutral")
            if pn then note(id, day, pn, "neutral") end
        end
    end
    for _, db in ipairs({ store("faction"), store("neutral") }) do
        for _, list in pairs(db) do trim(list, ns.db.histDays or 90) end
    end
    ns.Fire("HistoryChanged")
    return n
end

-- { {day, price}, ... } for the last `days` days.
function H.Series(id, days, house)
    local out = {}
    local list = id and store(house)[id]
    if not list then return out end
    local first = ns.Today() - (days or 30)
    for i = 1, #list - 1, 2 do
        if list[i] >= first then out[#out + 1] = { list[i], list[i + 1] } end
    end
    return out
end

-- The price of an item on a day: that day's, else the closest earlier one.
local function priceOn(id, day, house)
    local list = store(house)[id]
    if not list then return nil end
    local best
    for i = 1, #list - 1, 2 do
        if list[i] <= day then best = list[i + 1] else break end
    end
    return best
end

-- What the materials of a recipe cost, day by day (cheapest of vendor and
-- Auction House, as on the Recipes page).
function H.CostSeries(spellID, days, house)
    local out = {}
    local mats = ns.Recipes.Materials(spellID)
    if not mats then return out end
    local today = ns.Today()
    for day = today - (days or 30), today do
        local total, ok = 0, true
        for _, m in ipairs(mats) do
            local unit = ns.Prices.VendorBuy(m[1])
            local ah = priceOn(m[1], day, house)
            if ah and (not unit or ah < unit) then unit = ah end
            if not unit then ok = false break end
            total = total + unit * m[2]
        end
        if ok then out[#out + 1] = { day, total } end
    end
    return out
end

function H.Stats(series)
    if #series == 0 then return nil end
    local lo, hi, sum = math.huge, 0, 0
    for _, p in ipairs(series) do
        lo = math.min(lo, p[2]); hi = math.max(hi, p[2]); sum = sum + p[2]
    end
    local first, last = series[1][2], series[#series][2]
    return { now = last, min = lo, max = hi, avg = sum / #series, trend = first > 0 and (last - first) / first or 0 }
end

-- When to take a picture of the prices.
local snapPending = false
local function snapSoon(delay)
    if snapPending then return end
    snapPending = true
    C_Timer.After(delay or 5, function()
        snapPending = false
        H.Snapshot()
    end)
end
ns.On("Login", function()
    C_Timer.After(15, function()
        H.Snapshot()
    end)
end)
ns.On("PricesChanged", function() snapSoon(5) end)
