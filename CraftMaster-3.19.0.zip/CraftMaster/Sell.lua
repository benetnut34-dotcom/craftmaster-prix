local _, ns = ...
local L = ns.L

-- Posting at the Auction House, one click at a time (the game only allows it
-- inside a click), for the volume plans: the units in the bags, at the unit
-- price of the plan, for the longest duration. When the game asks, a second
-- click confirms. The post is reported done only when the game says so
-- (AUCTION_HOUSE_AUCTION_CREATED): a post it refuses without a word is
-- reported too.
local S = {}
ns.Sell = S

S.DURATION = 3   -- the third duration of the game: 24 h on Forever (2, 8, 24 h)
S.HOURS = 24     -- how long that is
local state      -- { id, qty, unit, kind, loc, step = "confirm" | "sent" }

local function finish(ok, reason)
    local s = state
    state = nil
    if s and not ok and reason then ns.Print(L.SELL_FAIL, reason) end
    ns.Fire("SellChanged")
end

function S.State() return state end
function S.Busy() return state ~= nil end
function S.IsFor(id) return state ~= nil and state.id == id end

-- Units of an item in the bags (not the bank).
function S.InBags(id)
    if not id then return 0 end
    local n
    if C_Item and C_Item.GetItemCount then
        local ok, v = pcall(C_Item.GetItemCount, id, false, false, false)
        if ok then n = v end
    elseif GetItemCount then
        local ok, v = pcall(GetItemCount, id, false)
        if ok then n = v end
    end
    return tonumber(n) or 0
end

-- The first bag slot holding the item, as an ItemLocation (nil when none).
local function findLocation(id)
    local C = C_Container
    if not (C and C.GetContainerNumSlots and ItemLocation and ItemLocation.CreateFromBagAndSlot) then return nil end
    for bag = 0, 4 do
        for slot = 1, C.GetContainerNumSlots(bag) or 0 do
            local info = C.GetContainerItemInfo and C.GetContainerItemInfo(bag, slot)
            local itemID = type(info) == "table" and info.itemID or (C.GetContainerItemID and C.GetContainerItemID(bag, slot))
            if itemID == id then return ItemLocation:CreateFromBagAndSlot(bag, slot) end
        end
    end
    return nil
end
S.FindLocation = findLocation

local function isCommodity(id)
    if C_AuctionHouse and C_AuctionHouse.GetItemCommodityStatus then
        local ok, st = pcall(C_AuctionHouse.GetItemCommodityStatus, id)
        if ok and st == 2 then return true end
        if ok and st == 1 then return false end
    end
    local i = ns.Item(id)
    return (i and i.stack or 1) > 1
end

local function call(kind, confirm, s)
    local f
    if kind == "commodity" then
        f = C_AuctionHouse and (confirm and C_AuctionHouse.ConfirmPostCommodity or C_AuctionHouse.PostCommodity)
    else
        f = C_AuctionHouse and (confirm and C_AuctionHouse.ConfirmPostItem or C_AuctionHouse.PostItem)
    end
    if not f then return false, "unavailable" end
    if kind == "commodity" then return pcall(f, s.loc, S.DURATION, s.qty, s.unit) end
    -- an item: the unit price as buyout of each (the sale screen asks a unit price), no bid
    return pcall(f, s.loc, S.DURATION, s.qty, nil, s.unit)
end

local function waitCreated(s)
    s.step = "sent"
    C_Timer.After(15, function()
        if state == s and s.step == "sent" then finish(false, L.SELL_NOT_CONFIRMED) end
    end)
end

-- First click: post `qty` units (the ones in the bags at most) at `unit` copper each.
function S.Post(id, qty, unit)
    if not ns.Buy.ahOpen then ns.Print(L.BUY_AH_CLOSED) return false end
    if state or ns.Buy.Busy() or not id or not unit or unit <= 0 then return false end
    qty = math.min(qty or 0, S.InBags(id))
    if qty <= 0 then ns.Print(L.SELL_NONE_IN_BAGS, ns.ItemName(id)) return false end
    local loc = findLocation(id)
    if not loc then ns.Print(L.SELL_NONE_IN_BAGS, ns.ItemName(id)) return false end
    state = { id = id, qty = qty, unit = math.floor(unit), kind = isCommodity(id) and "commodity" or "item", loc = loc }
    local ok, needs = call(state.kind, false, state)
    if not ok then finish(false, tostring(needs)) return false end
    if needs then
        state.step = "confirm"
        local s = state
        C_Timer.After(90, function()
            if state == s and s.step == "confirm" then ns.Print(L.SELL_EXPIRED, ns.ItemName(s.id)); finish(false, nil) end
        end)
    else
        waitCreated(state)
    end
    ns.Fire("SellChanged")
    return true
end

-- Second click, when the game asked for one.
function S.Confirm()
    if not state or state.step ~= "confirm" then return false end
    local s = state
    local ok, err = call(s.kind, true, s)
    if not ok then finish(false, tostring(err)) return false end
    waitCreated(s)
    ns.Fire("SellChanged")
    return true
end

function S.Cancel()
    if state then finish(false, nil) end
end

ns.Register("AUCTION_HOUSE_AUCTION_CREATED", function()
    if not state or state.step ~= "sent" then return end
    local s = state
    ns.Print(L.SELL_DONE, s.qty, ns.ItemName(s.id), ns.Money(s.unit))
    ns.Fire("Posted", s.id, s.qty, s.unit)
    finish(true)
end)
ns.Register("AUCTION_HOUSE_CLOSED", function()
    if state then finish(false, L.SELL_CLOSED) end
end)
ns.Register("BAG_UPDATE_DELAYED", function() ns.Fire("SellChanged") end)
