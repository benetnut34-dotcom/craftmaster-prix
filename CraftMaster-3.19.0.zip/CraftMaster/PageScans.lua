local _, ns = ...
local L = ns.L
local W = ns.W

-- Page Scans : quand et comment scanner l'hotel des ventes. Le reglage de
-- l'ouverture de l'HV (rien / rapide / complet / automatique), deux boutons
-- (scan rapide, scan complet), ce que change chaque scan, et la
-- recommandation du moment d'apres les donnees que l'addon possede deja (la
-- photo Blizzard, les derniers scans).

local MUTED = "|cff8c8c99"
local GREEN = "|cff59d973"
local AMBER = "|cffffa733"
local RED = "|cffff6060"

local function ago(t)
    local G = ns.Gold
    if G and G.Ago then return G.Ago(t) end
    return t and date("%d/%m %H:%M", t) or L.GM_NEVER
end

local KINDS = { none = "SCANS_K_NONE", quick = "SCANS_K_QUICK", full = "SCANS_K_FULL" }

-- The reason text for a recommendation (kind, why, age).
local function reason(kind, why, age)
    if why == "FRESH" then return string.format(L.SCANS_WHY_FRESH, ns.Duration(age)) end
    if why == "LATE" then return string.format(L.SCANS_WHY_LATE, ns.Duration(age)) end
    if why == "OLD" then
        return string.format(kind == "full" and L.SCANS_WHY_OLD or L.SCANS_WHY_OLD_NOFULL, ns.Duration(age))
    end
    return L.SCANS_WHY_NOPIC
end

ns.UI.AddPage("scans", function(page)
    local body, color = page.body, page.color

    -- ------------------------------------------------------ left top: the rule, the advice, the buttons
    local rule = W.Card(body, L.SCANS_C_RULE, color)
    rule:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    rule:SetPoint("RIGHT", body, "CENTER", -6, 0)
    rule:SetHeight(250)

    local modeLabel = W.Text(rule, "small", "LEFT")
    modeLabel:SetPoint("TOPLEFT", rule, "TOPLEFT", 14, -40)
    modeLabel:SetText(MUTED .. L.SCANS_MODE .. "|r")
    local function modeItems()
        return {
            { "off", L.SCANS_MODE_OFF }, { "quick", L.SCANS_MODE_QUICK },
            { "full", L.SCANS_MODE_FULL }, { "smart", L.SCANS_MODE_SMART },
        }
    end
    local dropdown = W.Dropdown(rule, 300, modeItems, function()
        if not ns.db.autoScan then return "off" end
        return ns.db.autoScanMode or "full"
    end, function(v)
        if v == "off" then
            ns.db.autoScan = false
        else
            ns.db.autoScan = true
            ns.db.autoScanMode = v
        end
        ns.Fire("DealsChanged")
        page.Refresh()
    end)
    dropdown:SetPoint("TOPLEFT", modeLabel, "BOTTOMLEFT", 0, -4)
    dropdown:SetHeight(24)
    W.Tip(dropdown, L.SCANS_MODE, L.SCANS_MODE_TIP)

    local reco = W.Text(rule, "body", "LEFT")
    reco:SetPoint("TOPLEFT", dropdown, "BOTTOMLEFT", 0, -16)
    reco:SetPoint("RIGHT", rule, "RIGHT", -14, 0)
    reco:SetWordWrap(true)
    local why = W.Text(rule, "small", "LEFT")
    why:SetPoint("TOPLEFT", reco, "BOTTOMLEFT", 0, -6)
    why:SetPoint("RIGHT", rule, "RIGHT", -14, 0)
    why:SetWordWrap(true)
    why:SetJustifyV("TOP")

    local nowLabel = W.Text(rule, "small", "LEFT")
    nowLabel:SetPoint("BOTTOMLEFT", rule, "BOTTOMLEFT", 14, 44)
    nowLabel:SetText(MUTED .. L.SCANS_NOW .. "|r")
    local quick = W.Button(rule, L.SCANS_BTN_QUICK, 150, function()
        if not ns.Buy.ahOpen then ns.Print(L.SCANS_NEED_AH) return end
        ns.Scan.Start("quick")
        page.Refresh()
    end)
    quick:SetPoint("BOTTOMLEFT", rule, "BOTTOMLEFT", 14, 12)
    quick.SetTint(color)
    local full = W.Button(rule, L.SCANS_BTN_FULL, 150, function()
        if not ns.Buy.ahOpen then ns.Print(L.SCANS_NEED_AH) return end
        local wait = ns.Scan.FullWait()
        if wait > 0 then ns.Print(L.SCANS_FULL_WAIT_MSG, ns.Duration(wait)) return end
        ns.Scan.Start("full")
        page.Refresh()
    end)
    full:SetPoint("LEFT", quick, "RIGHT", 8, 0)
    full.SetTint(color)

    -- ------------------------------------------------------ left bottom: what I hold
    local have = W.Card(body, L.SCANS_C_HAVE, color)
    have:SetPoint("TOPLEFT", rule, "BOTTOMLEFT", 0, -10)
    have:SetPoint("BOTTOMRIGHT", body, "BOTTOM", -6, 0)
    local haveText = W.Text(have, "small", "LEFT")
    haveText:SetPoint("TOPLEFT", have, "TOPLEFT", 14, -36)
    haveText:SetPoint("BOTTOMRIGHT", have, "BOTTOMRIGHT", -14, 8)
    haveText:SetWordWrap(true)
    haveText:SetJustifyV("TOP")
    haveText:SetSpacing(3)

    -- ------------------------------------------------------ right: the comparison
    local cmp = W.Card(body, L.SCANS_C_COMPARE, color)
    cmp:SetPoint("TOPLEFT", body, "TOP", 6, 0)
    cmp:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    local cmpText = W.Text(cmp, "small", "LEFT")
    cmpText:SetPoint("TOPLEFT", cmp, "TOPLEFT", 14, -36)
    cmpText:SetPoint("BOTTOMRIGHT", cmp, "BOTTOMRIGHT", -14, 8)
    cmpText:SetWordWrap(true)
    cmpText:SetJustifyV("TOP")
    cmpText:SetSpacing(2)
    cmpText:SetText(L.SCANS_CMP)

    function page.Refresh()
        dropdown.Refresh()
        local house = ns.Scan.OpenHouse()
        local kind, why2, age = ns.Scan.Recommend(house)
        local col = kind == "none" and GREEN or (kind == "quick" and AMBER or RED)
        reco:SetText(col .. string.format(L.SCANS_RECO, L[KINDS[kind]]) .. "|r")
        why:SetText(MUTED .. reason(kind, why2, age) .. "|r")

        local lines = {}
        local key = ns.HouseKey(house)
        local ref = ns.Import and ns.Import.apiRef and ns.Import.apiRef[key]
        if ref then
            local n = 0
            for _ in pairs(ref.items) do n = n + 1 end
            lines[#lines + 1] = string.format(L.SCANS_HAVE_API, ago(ref.at), n)
        else
            lines[#lines + 1] = L.SCANS_HAVE_API_NONE
        end
        local b = ns.Scan.Book(house)
        if b.at then
            local n = 0
            for _ in pairs(b.items or {}) do n = n + 1 end
            local who = b.from == "blizzard" and L.DATA_PROV_BLIZZ
                or (b.fromGuild and string.format(L.DATA_PROV_GUILD, b.fromWho or "?") or L.DATA_PROV_ME)
            lines[#lines + 1] = string.format(L.SCANS_HAVE_BOOK, who, ago(b.at), n)
        else
            lines[#lines + 1] = L.SCANS_HAVE_BOOK_NONE
        end
        lines[#lines + 1] = ""
        local st = ns.db.scanStats or {}
        if st.quick then
            lines[#lines + 1] = string.format(L.SCANS_HAVE_QUICK, st.quick.items or 0, st.quick.secs or 0, ago(st.quick.at))
        else
            lines[#lines + 1] = L.SCANS_HAVE_QUICK_NONE
        end
        if st.full then
            lines[#lines + 1] = string.format(L.SCANS_HAVE_FULL, st.full.items or 0, st.full.listings or 0, st.full.secs or 0, ago(st.full.at))
        else
            lines[#lines + 1] = L.SCANS_HAVE_FULL_NONE
        end
        local wait = ns.Scan.FullWait()
        if ns.db.fullScan ~= false and wait > 0 then
            lines[#lines + 1] = AMBER .. string.format(L.AHP_FULL_IN, ns.Duration(wait)) .. "|r"
        end
        if ns.Scan.Running() then
            local m = ns.Scan.Mode()
            lines[#lines + 1] = ""
            lines[#lines + 1] = GREEN .. string.format(L.SCANS_RUNNING, m == "quick" and L.SCANS_KIND_QUICK or L.SCANS_KIND_FULL, ns.Scan.Count()) .. "|r"
        end
        haveText:SetText(table.concat(lines, "\n"))
    end
end)
