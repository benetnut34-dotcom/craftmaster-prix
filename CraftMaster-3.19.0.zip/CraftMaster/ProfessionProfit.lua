local _, ns = ...
local L = ns.L

-- What a craft earns, shown in the game's own profession window: to the right of each recipe of
-- the list, the money made between the price of the reagents (a merchant first, else the Auction
-- House) and the best way to sell the result: the Auction House (after its cut) or a merchant.
-- Green for a gain, red for a loss, with the source of the best price next to it; the tooltip
-- gives the whole reckoning.
--
-- Two windows are served: Daylight UI's own profession window when it is in use (through its
-- plugin API: its recipe rows hand us the recipe, we draw on the holder it gives us), and the
-- game's (ProfessionsFrame, Forever client) otherwise. For the game's window, nothing is added to its frames:
-- the figures live on frames of our own, anchored to its rows and refreshed while it is open
-- (a few times a second, only while the window is shown), so the game's secure code is never
-- touched.
local PP = {}
ns.ProfessionProfit = PP

-- ---------------------------------------------------------------------
-- The reckoning (memoized; thrown away when prices change)
-- ---------------------------------------------------------------------

local memo = {}
local function flush() memo = {} end
for _, e in ipairs({ "PricesChanged", "GoldChanged", "ScanDone", "HouseChanged", "RecipesChanged" }) do ns.On(e, flush) end

-- { cost, parts = { {id, n, unit, src} }, ah (net of the cut, whole batch), vendor (whole batch),
--   best = "ah" | "vendor", gain (best - cost), estimate (AH price is only a guess), missing }
-- or nil when the recipe is not known to the addon (no reagent list).
function PP.Reckon(recipeID)
    local m = memo[recipeID]
    if m ~= nil then return m or nil end
    local G = ns.Gold
    local r = G and G.Recipes()[recipeID]
    if not r then memo[recipeID] = false return nil end
    local d = G.EvaluateRecipe(recipeID, r)
    local out = { parts = {}, missing = false }
    local cost = 0
    for _, rg in ipairs(r.reagents) do
        if not G.IsExcluded(recipeID, rg.id) then
            local unit, src = G.ReagentPrice(rg.id)
            out.parts[#out.parts + 1] = { id = rg.id, n = rg.n, unit = unit, src = src }
            if unit then cost = cost + unit * rg.n else out.missing = true end
        end
    end
    out.cost = cost
    out.qty = r.qty or 1
    out.ah = d.sell                                   -- net of the Auction House cut, for the whole batch
    out.estimate = d.estimate
    local vs = ns.Prices.VendorSell(r.out)
    out.vendor = (vs and vs > 0) and vs * out.qty or nil
    if out.ah and (not out.vendor or out.ah >= out.vendor) then out.best = "ah"
    elseif out.vendor then out.best = "vendor" end
    if out.best and not out.missing then
        out.gain = (out.best == "ah" and out.ah or out.vendor) - cost - (d.cdPrice or 0)
    end
    memo[recipeID] = out
    return out
end

local function sign(v) return v >= 0 and "+" or "-" end

-- The short text of a row: "+1g 20s" and the source, coloured.
function PP.RowText(rk)
    local C = ns.Theme.C
    if not rk then return nil end
    if rk.missing or not rk.best then return "|cff8c8c8c" .. L.PROFIT_NONE .. "|r" end
    local col = rk.gain >= 0 and C.profit or C.loss
    local hex = string.format("|cff%02x%02x%02x", col[1] * 255, col[2] * 255, col[3] * 255)
    local src = rk.best == "ah" and L.FROM_AH or L.PROFIT_VENDOR_SHORT
    return hex .. sign(rk.gain) .. ns.Money(math.abs(rk.gain), true) .. "|r |cff8c8c8c" .. src .. (rk.estimate and "~" or "") .. "|r"
end

-- The tooltip: reagents with where each comes from, the two ways to sell, the best.
function PP.Tooltip(tip, recipeID)
    local rk = PP.Reckon(recipeID)
    if not rk then return false end
    tip:AddLine(L.PROFIT_TITLE, 1, 0.82, 0)
    for _, p in ipairs(rk.parts) do
        local src = p.src == "vendor" and L.FROM_VENDOR or p.src == "ah" and L.FROM_AH or p.src == "manual" and L.GM_MANUAL or "?"
        tip:AddDoubleLine(string.format("%d x %s  |cff8c8c8c%s|r", p.n, ns.ItemName(p.id), src),
            p.unit and ns.Money(p.unit * p.n, true) or L.PROFIT_NO_PRICE, 1, 1, 1, 1, 1, 1)
    end
    tip:AddDoubleLine(L.PROFIT_COST, rk.missing and (L.PROFIT_INCOMPLETE) or ns.Money(rk.cost, true), 0.8, 0.8, 0.85, 1, 1, 1)
    tip:AddLine(" ")
    local function way(label, v, best)
        tip:AddDoubleLine(label .. (best and ("  |cff73d982" .. L.PROFIT_BEST .. "|r") or ""),
            v and ns.Money(v, true) or L.PROFIT_NO_PRICE, 1, 1, 1, 1, 1, 1)
    end
    way(L.PROFIT_SELL_AH .. (rk.estimate and " (~)" or ""), rk.ah, rk.best == "ah")
    way(L.PROFIT_SELL_VENDOR, rk.vendor, rk.best == "vendor")
    if rk.gain then
        local C = ns.Theme.C
        local col = rk.gain >= 0 and C.profit or C.loss
        tip:AddLine(" ")
        tip:AddDoubleLine(L.PROFIT_GAIN, sign(rk.gain) .. ns.Money(math.abs(rk.gain), true), 1, 1, 1, col[1], col[2], col[3])
    end
    return true
end

-- ---------------------------------------------------------------------
-- On the game's window
-- ---------------------------------------------------------------------

local labels = {}          -- pool of { frame, text }
local ticker

local function label(i)
    local l = labels[i]
    if not l then
        local f = CreateFrame("Frame", nil, UIParent)
        f:SetSize(96, 16)
        f:SetFrameStrata("HIGH")
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        f.text:SetPoint("RIGHT", f, "RIGHT", 0, 0)
        f.text:SetJustifyH("RIGHT")
        f:EnableMouse(true)
        f:SetScript("OnEnter", function(self)
            if not self.recipeID then return end
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            if not PP.Tooltip(GameTooltip, self.recipeID) then GameTooltip:Hide() return end
            GameTooltip:Show()
        end)
        f:SetScript("OnLeave", function() GameTooltip:Hide() end)
        labels[i] = f
        l = f
    end
    return l
end

local function hideAll()
    for _, f in ipairs(labels) do f:Hide(); f.recipeID = nil end
end

-- The recipe list of the profession window, when it is open: its scroll box.
local function listBox()
    local pf = _G.ProfessionsFrame
    if not (pf and pf.IsShown and pf:IsShown()) then return nil end
    local page = pf.CraftingPage
    if not page or (page.IsShown and not page:IsShown()) then return nil end
    local list = page.RecipeList
    return list and list.ScrollBox or nil
end

local function recipeOf(row)
    local ok, ed = pcall(row.GetElementData, row)
    if not ok or type(ed) ~= "table" then return nil end
    local data = ed.data or (ed.GetData and ed:GetData())
    local info = type(data) == "table" and data.recipeInfo
    if type(info) ~= "table" or not info.recipeID then return nil end
    if info.learned == false then return nil end        -- only what I can craft
    return info.recipeID
end

local function refresh()
    local box = listBox()
    if not box or ns.db.profitInWindow == false then hideAll() return end
    local n = 0
    local function each(row)
        if not (row and row.IsShown and row:IsShown()) then return end
        local id = recipeOf(row)
        local rk = id and PP.Reckon(id)
        local text = rk and PP.RowText(rk)
        if not text then return end
        n = n + 1
        local f = label(n)
        f:ClearAllPoints()
        f:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        f:SetFrameLevel((row:GetFrameLevel() or 1) + 5)
        f.recipeID = id
        f.text:SetText(text)
        f:Show()
    end
    if box.ForEachFrame then pcall(box.ForEachFrame, box, each) end
    for i = n + 1, #labels do labels[i]:Hide(); labels[i].recipeID = nil end
end

function PP.Refresh() if ticker then pcall(refresh) else hideAll() end end
PP.RefreshNow = refresh     -- tests
PP.labels = labels

local function tick()
    if not listBox() then
        hideAll()
        if ticker then ticker:Cancel(); ticker = nil end
        return
    end
    refresh()
end

-- ---------------------------------------------------------------------
-- Daylight UI's profession window (it replaces the game's): its API tells us each recipe line
-- (kind "craftrow", unit = the recipe's id) when it is made, reused for another recipe or
-- repainted; API.Attach gives a holder laid over the line, above its art.
-- ---------------------------------------------------------------------

local dui                       -- the API, once hooked
local function paintDaylight(kind, row, recipeID)
    if kind ~= "craftrow" or not row or not recipeID then return end
    local holder = dui.Attach(row)
    if not holder then return end
    local b = holder.cmProfit
    if not b then
        b = CreateFrame("Frame", nil, holder)
        b:SetSize(100, 16)
        b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        b.text:SetPoint("RIGHT", b, "RIGHT", 0, 0)
        b.text:SetJustifyH("RIGHT")
        b:EnableMouse(true)
        b:SetScript("OnEnter", function(self)
            if not self.recipeID then return end
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            if not PP.Tooltip(GameTooltip, self.recipeID) then GameTooltip:Hide() return end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        holder.cmProfit = b
    end
    local rk = ns.db.profitInWindow ~= false and PP.Reckon(recipeID)
    local text = rk and PP.RowText(rk)
    b.recipeID = recipeID
    if not text then b:Hide() return end
    -- on the name's line, to the left of the count the line already shows on its right
    local gap = 0
    local v = row.value
    if v and v.GetStringWidth and v.IsShown and v:IsShown() then gap = (v:GetStringWidth() or 0) + 10 end
    b:ClearAllPoints()
    b:SetPoint("TOPRIGHT", holder, "TOPRIGHT", -(8 + gap), -7)
    b.text:SetText(text)
    b:Show()
end

local function repaintDaylight()
    if not dui or not dui.Frames then return end
    for row, id in dui.Frames("craftrow") do pcall(paintDaylight, "craftrow", row, id) end
end

local function hookDaylight()
    local api = _G.DaylightUI and _G.DaylightUI.API
    if dui or type(api) ~= "table" or api.major ~= 1 or not api.On or not api.Attach then return end
    dui = api
    for _, ev in ipairs({ "FrameMade", "FrameUnitChanged", "FrameStyled" }) do
        api.On(ev, function(kind, row, unit) paintDaylight(kind, row, unit) end, "CraftMaster")
    end
end
PP.HookDaylight, PP.PaintDaylight, PP.RepaintDaylight = hookDaylight, paintDaylight, repaintDaylight
ns.On("Login", hookDaylight)
-- new prices: the lines of Daylight UI's window follow
for _, e in ipairs({ "PricesChanged", "GoldChanged", "ScanDone", "RecipesChanged" }) do
    ns.On(e, function() if dui and C_Timer then C_Timer.After(0.2, repaintDaylight) end end)
end

-- While the profession window is open: look at its rows a few times a second.
local function start()
    if ticker or not (C_Timer and C_Timer.NewTicker) then return end
    ticker = C_Timer.NewTicker(0.3, function() pcall(tick) end)
    pcall(tick)
end
ns.Register("TRADE_SKILL_SHOW", function() C_Timer.After(0.2, start) end)
ns.Register("TRADE_SKILL_CLOSE", function() hideAll() end)
