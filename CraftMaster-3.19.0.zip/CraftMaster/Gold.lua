local _, ns = ...
local L = ns.L

-- The reckoning of the market pages (Good deals, Crafts, Buying in volume,
-- Sharing), on CraftMaster's data: the last scan of the Auction House shown (lowest
-- price, quantity, second price), its daily lows (the usual price), the
-- sales seen (Tracker.lua), the cooldowns (Cooldown.lua), the prices set by
-- hand and the materials left out.
local G = {}
ns.Gold = G

-- One model for the four tabs that make gold (an offer, a craft, a lot bought
-- in volume, an item bought in one house and sold in the other):
--   itemID   what is sold;  units: how many of it (1, what the recipe makes, the lot)
--   buy      what it costs in all (one listing, the materials, the whole lot)
--   market   the resale price of ONE unit, before the cut of the Auction House
--   sell     the resale of the whole thing, before the cut: market x units
--   profit   sell less the cut, less buy (and less a cooldown's value); margin = profit / buy
--   stats    the sales seen (perDay: units sold per day); conf: 0..100, the stars
--   source   where the resale price comes from: "sales", "listings", "estimate", "vendor"
--   house    where it is sold (its resale price, cut, stars and sales): the house
--            shown, or the other one for a transfer (from: where it is bought)
-- A vendor offer (kind "PNJ") pays no cut. Materials are priced by hand first,
-- then at a merchant, then at the Auction House (ReagentPrice). The long lists
-- (every item of a scan) are worked out a few per frame by G.Spread.

-- Gathering and fishing make nothing to sell: left out of the crafts.
-- Enchanting and first aid are left out of the crafts too (asked by the players).
local SKIP_PROFS = { mining = true, herbalism = true, skinning = true, fishing = true, enchanting = true, firstaid = true }
local SKILL_OF = {}
for line, key in pairs(ns.SKILLLINES or {}) do SKILL_OF[key] = line end
G.SKILL_OF = SKILL_OF

local function house() return ns.House() end
local function cut(h) return ns.CutPct(h or house()) / 100 end
G.Cut = cut

-- The last scan of the house shown: { p = lowest, q = quantity, p2 = second price }
function G.Current(id, h)
    local b = ns.Scan.Book(h or house())
    local e = b.items and b.items[id]
    if not e then return nil end
    return { p = e[1], q = e[2] or 0, p2 = e[3] }
end

-- The usual price: the median of the daily lows of the last 14 days (at
-- least minDays of them, 3 unless /gg jours says otherwise).
local HISTORY_DAYS = 14
function G.MarketPrice(id, h)
    local today, vals = ns.Today(), {}
    for _, low in ipairs(ns.Deals.Lows(id, h or house())) do
        if today - low[1] < HISTORY_DAYS then vals[#vals + 1] = low[2] end
    end
    if #vals < (ns.db.minDays or 3) then return nil, #vals end
    table.sort(vals)
    local n = #vals
    if n % 2 == 1 then return vals[(n + 1) / 2], n end
    return (vals[n / 2] + vals[n / 2 + 1]) / 2, n
end

function G.Stats(id, h) return ns.Tracker.Stats(id, h or house()) end
function G.Stars(score) return ns.Tracker.Stars(score) end
function G.StarString(score, size) return ns.Tracker.StarString(score, size) end

-- Resale price: what it really sells at (low quartile of the sales seen, to
-- be careful), else the usual listing price, else the second listing.
local function resalePrice(id, fallback, h)
    local st = G.Stats(id, h)
    if st and st.n >= 2 and st.p25 then return st.p25, false, st, "sales" end
    local market, days = G.MarketPrice(id, h)
    if market then return market, false, st, "listings", days end
    return fallback, fallback ~= nil, st, "estimate"
end

-- Confidence of an offer: the item's score lowered by the competition under
-- the resale price (Tracker.OfferScore). Second answer: the competition.
local lastComp, lastEv
local function offerConf(id, price, h, skipCheapest)
    local sc, c, ev = ns.Tracker.OfferScore(id, price, h or house(), skipCheapest)
    lastComp, lastEv = c, ev
    return sc
end

function G.EvaluateItem(id, h)
    local cur = G.Current(id, h)
    local sell, estimate, st, source, days = resalePrice(id, cur and cur.p2, h)
    -- the same rules as a craft (EvaluateRecipe): the confidence of the resale price,
    -- the cheapest listing left out of the competition (it is the one I buy)
    local d = { itemID = id, days = days, estimate = estimate, kind = "HV", sell = sell, market = sell, units = 1,
                stats = st, conf = offerConf(id, sell, h, true), source = source }
    d.comp, d.ev = lastComp, lastEv
    if cur then d.buy, d.qty = cur.p, cur.q end
    if d.buy and d.sell then
        d.profit = d.sell * (1 - cut(h)) - d.buy
        d.margin = d.buy > 0 and d.profit / d.buy or 0
    end
    return d
end

-- ---------------------------------------------------------------------
-- Prices set by hand, materials left out
-- ---------------------------------------------------------------------

function G.CustomPrice(id) return ns.db.customPrices and ns.db.customPrices[id] end

-- What one unit of a reagent costs and where it comes from: a price set by
-- hand first, then a merchant (always there, fixed price), then the Auction
-- House. Second answer: the source, "manual" | "vendor" | "ah" | "none".
function G.ReagentPrice(id, h)
    local manual = G.CustomPrice(id)
    if manual then return manual, "manual" end
    local v, guess = ns.Prices.VendorBuy(id)
    local cur = G.Current(id, h)
    if v and (not guess or not cur or v <= cur.p) then return v, "vendor", cur end
    if cur then return cur.p, "ah", cur end
    return nil, "none"
end
function G.SetCustomPrice(id, copper)
    ns.db.customPrices = ns.db.customPrices or {}
    ns.db.customPrices[id] = (copper and copper > 0) and math.floor(copper) or nil
    ns.Fire("GoldChanged")
end

function G.IsExcludedGlobal(id) return ns.db.excludedGlobal and ns.db.excludedGlobal[id] == true end
function G.IsExcluded(recipeID, id)
    if G.IsExcludedGlobal(id) then return true end
    local e = ns.db.excluded and ns.db.excluded[recipeID]
    return e ~= nil and e[id] == true
end
function G.SetExcludedGlobal(id, on)
    ns.db.excludedGlobal = ns.db.excludedGlobal or {}
    ns.db.excludedGlobal[id] = on and true or nil
end
function G.ToggleExcluded(recipeID, id)
    ns.db.excluded = ns.db.excluded or {}
    local ex = ns.db.excluded
    ex[recipeID] = ex[recipeID] or {}
    ex[recipeID][id] = not ex[recipeID][id] or nil
    if not next(ex[recipeID]) then ex[recipeID] = nil end
    ns.Fire("GoldChanged")
end

-- Materials from the gathering professions (by the item's subclass).
local TRADEGOODS = (Enum and Enum.ItemClass and Enum.ItemClass.Tradegoods) or 7
local SUB = (Enum and Enum.ItemTradeGoodsSubclass) or {}
G.REAGENT_CATEGORIES = {
    { key = "mining", sub = SUB.MetalStone or 7 },
    { key = "herb", sub = SUB.Herb or 9 },
    { key = "skin", sub = SUB.Leather or 6 },
    { key = "fish", sub = SUB.Cooking or 8 },
}
local function instant(id)
    if C_Item and C_Item.GetItemInfoInstant then return C_Item.GetItemInfoInstant(id) end
    if GetItemInfoInstant then return GetItemInfoInstant(id) end
end
function G.ReagentCategory(id)
    local _, _, _, _, _, classID, subID = instant(id)
    if classID == TRADEGOODS then
        for _, c in ipairs(G.REAGENT_CATEGORIES) do
            if subID == c.sub then return c.key, L.GM_CAT[c.key] end
        end
    end
    return "other", L.GM_CAT.other
end

-- ---------------------------------------------------------------------
-- Recipes: CraftMaster's (with materials) and the ones shared by others
-- ---------------------------------------------------------------------

local recipes
function G.Recipes()
    if recipes then return recipes end
    recipes = {}
    for id, r in pairs(ns.RECIPES) do
        if not SKIP_PROFS[r.p] then
            local mats, out, n = ns.Recipes.Materials(id)
            if mats and out and #mats > 0 then
                local reagents = {}
                for _, m in ipairs(mats) do reagents[#reagents + 1] = { id = m[1], n = m[2] } end
                recipes[id] = { out = out, qty = n or 1, reagents = reagents, prof = r.p }
            end
        end
    end
    for id, r in pairs(ns.db.gmRecipes or {}) do
        if not recipes[id] and type(r) == "table" and r.out and type(r.reagents) == "table" and #r.reagents > 0 then
            -- a profession by number: only the crafting ones we know (not herbalism, fishing...)
            local key = r.prof
            if type(key) == "number" then key = ns.SKILLLINES[key] end
            if type(key) == "string" and not SKIP_PROFS[key] then
                recipes[id] = { out = r.out, qty = r.qty or 1, reagents = r.reagents, prof = key, name = r.name }
            end
        end
    end
    return recipes
end
function G.RecipeCount()
    local n = 0
    for _ in pairs(G.Recipes()) do n = n + 1 end
    return n
end
for _, e in ipairs({ "RecipesChanged", "Login" }) do ns.On(e, function() recipes = nil end) end

-- Recipes another player sent (Sync.lua), kept for this account.
function G.AddRecipe(id, name, out, qty, reagents, prof)
    if type(id) ~= "number" or type(out) ~= "number" or type(reagents) ~= "table" then return false end
    ns.db.gmRecipes = ns.db.gmRecipes or {}
    if ns.db.gmRecipes[id] or (ns.db.schem and ns.db.schem[id]) then return false end
    if ns.RECIPES[id] and ns.Recipes.Materials(id) then return false end
    ns.db.gmRecipes[id] = { name = name, out = out, qty = qty or 1, reagents = reagents, prof = prof }
    recipes = nil
    return true
end

function G.RecipeName(id, r)
    local n = ns.SpellName(id)
    if n then return n end
    r = r or G.Recipes()[id]
    if r and r.name then return r.name end
    return r and ns.ItemName(r.out) or ("#" .. id)
end
function G.ProfName(key) return (L.PROF and L.PROF[key]) or key end

function G.EvaluateRecipe(id, r, h)
    r = r or G.Recipes()[id]
    local cost, nExcluded = 0, 0
    for _, rg in ipairs(r.reagents) do
        if G.IsExcluded(id, rg.id) then
            nExcluded = nExcluded + 1
        else
            local price = G.ReagentPrice(rg.id, h)
            if not price then cost = nil; break end
            cost = cost + price * rg.n
        end
    end
    local outCur = G.Current(r.out, h)
    local market, estimate, st, source, days = resalePrice(r.out, outCur and outCur.p, h)
    local d = {
        itemID = r.out, label = G.RecipeName(id, r), recipe = r, recipeID = id, kind = "Craft", excludedCount = nExcluded,
        buy = cost, days = days, estimate = estimate, stats = st, conf = offerConf(r.out, market, h, false), source = source,
        learned = ns.Recipes.IsKnown(id), market = market, units = r.qty,
    }
    d.comp, d.ev = lastComp, lastEv
    if market then d.sell = market * r.qty end
    -- a cooldown craft: what other players pay for the cooldown comes off,
    -- and the profit is ranked per day of cooldown
    local cd = ns.Cooldown.Get(id)
    if cd > 0 then
        d.cd = cd
        d.cdPrice, d.cdSource, d.cdCount = ns.Cooldown.Price(id)
    end
    if cost and d.sell then
        d.profitRaw = d.sell * (1 - cut(h)) - cost
        d.profit = d.profitRaw - (d.cdPrice or 0)
        d.margin = cost > 0 and d.profit / cost or 0
        if cd > 0 then d.perDay = d.profit / math.max(1, cd / 86400) end
    end
    d.rank = d.perDay or d.profit
    return d
end

-- ---------------------------------------------------------------------
-- 1) Good deals
-- ---------------------------------------------------------------------

-- The deal on one item of the last scan (e: its entry { price, quantity }), or nil:
-- listed well under what it sells for, or under what a vendor pays.
local function dealOf(id, e, h)
    local db = ns.db
    local threshold, minProfit = db.dealThreshold or 0.70, db.minProfit or 0
    local best
    local d = G.EvaluateItem(id, h)
    if d.sell and d.buy and d.buy <= d.sell * threshold and d.profit >= minProfit then best = d end
    -- sold to a vendor: no risk
    local vendor = ns.Prices.VendorSell(id)
    local buy = e[1]
    if vendor and vendor > buy and (vendor - buy) >= minProfit and (not best or vendor - buy > best.profit) then
        best = { itemID = id, buy = buy, sell = vendor, market = vendor, units = 1, profit = vendor - buy,
                 margin = buy > 0 and (vendor - buy) / buy or 0,
                 days = d.days, qty = e[2], kind = "PNJ", conf = 100, source = "vendor" }
    end
    return best
end

function G.FindDeals(h)
    h = h or house()
    local res = {}
    for id, e in pairs(ns.Scan.Book(h).items or {}) do
        local d = dealOf(id, e, h)
        if d then res[#res + 1] = d end
    end
    return res
end

-- The long lists: every item of a scan looked at one by one, a few per frame
-- (ns.Work), kept until their stamp changes (a new scan, a setting): the same
-- machinery for the lots in volume, the good deals and the two houses.
--   G.Spread(name, key, stamp, ids, each, done) -> the list (the last one while
--   a new one is worked out, nil the first time), busy
--   ids(): the items to look at; each(id): a line or nil; done(list): when ready
local spread = {}   -- [name] = { cache = { [key] = { stamp, list } }, running = { [key] = stamp } }
local function spreadOf(name)
    local s = spread[name]
    if not s then s = { cache = {}, running = {} }; spread[name] = s end
    return s
end
function G.Spread(name, key, stamp, ids, each, done)
    local s = spreadOf(name)
    local c = s.cache[key]
    if c and c.stamp == stamp then return c.list, false end
    if s.running[key] ~= stamp then
        s.running[key] = stamp
        local order, list, i = ids(), {}, 0
        ns.Work.Add(name, function()
            while i < #order do
                i = i + 1
                local d = each(order[i])
                if d then list[#list + 1] = d end
                if ns.Work.Due() then return false end
            end
            return true
        end, function()
            if s.running[key] ~= stamp then return end   -- a newer one started
            s.running[key] = nil
            s.cache[key] = { stamp = stamp, list = list }
            if done then done(list) end
            if ns.UI and ns.UI.RefreshSoon then ns.UI.RefreshSoon() end
        end)
    end
    c = s.cache[key]
    return c and c.list or nil, true
end
-- the list ready now for that stamp, without starting anything
function G.SpreadPeek(name, key, stamp)
    local c = spreadOf(name).cache[key]
    return (c and c.stamp == stamp) and c.list or nil
end
function G.SpreadBusy(name, key) return spreadOf(name).running[key] ~= nil end
-- new prices: worked out again, whatever the stamp says
function G.SpreadForget(name, key)
    local s = spreadOf(name)
    s.cache[key], s.running[key] = nil, nil
end
ns.On("Login", function() spread = {} end)
local function keysOf(...)
    local order, seen = {}, {}
    for k = 1, select("#", ...) do
        for id in pairs(select(k, ...) or {}) do
            if not seen[id] then seen[id] = true; order[#order + 1] = id end
        end
    end
    return order
end

-- The good deals of the last scan of a house, in short, for the Auction House
-- bubble, the Home page, the menu and the line after a scan:
-- { n (deals), top (Top offers), best (the best Top offer, else the best deal) }.
-- Worked out a few items per frame (ns.Work) after each scan and kept until
-- the prices or the settings change; nil while it is being worked out.
local summaries, dealsTell = {}, {}   -- [key] = { stamp, n, top, best }; [key] = true: tell it when ready
local function dealsStamp(h)
    return table.concat({ ns.HouseKey(h), tostring(ns.Scan.Book(h).at), tostring(ns.db.dealThreshold or 0.7),
                          tostring(ns.db.minProfit or 0), tostring(ns.CutPct(h)), tostring(G.TopMinStars()) }, "|")
end
-- what is known now, without starting anything
function G.DealsPeek(h)
    h = h or house()
    local c = summaries[ns.HouseKey(h)]
    return (c and c.stamp == dealsStamp(h)) and c or nil
end
-- the line after a scan: a notice on screen for an exceptional deal (45 % under
-- its resale price or more), else a line in the chat
local function tellDeals(c)
    if not c or c.n == 0 then return end
    local b = c.best
    local pct = (b and b.sell and b.sell > 0 and b.buy) and (1 - b.buy / b.sell) or 0
    if pct >= 0.45 and ns.db.toast ~= false and ns.Toast and not (InCombatLockdown and InCombatLockdown()) then
        ns.Toast.Show(L.TOAST_DEAL_TITLE, string.format(L.TOAST_DEAL, ns.ItemName(b.itemID), ns.Money(b.profit),
            math.floor(pct * 100 + 0.5)), function() ns.UI.Open("gmdeals") end)
    else
        ns.Print(L.DEALS_FOUND, c.n, c.top, b and ns.ItemName(b.itemID) or "?", b and ns.Money(b.profit) or "-")
    end
end
G.TellDeals = tellDeals
function G.DealsSummary(h)
    h = h or house()
    local key, stamp = ns.HouseKey(h), dealsStamp(h)
    local c = summaries[key]
    if c and c.stamp == stamp then return c end
    local items = ns.Scan.Book(h).items or {}
    G.Spread("deals", key, stamp, function() return keysOf(items) end,
        function(id) return dealOf(id, items[id], h) end,
        function(list)
            local top, best = 0, nil
            for _, d in ipairs(list) do if G.IsTopDeal(d) then top = top + 1 end end
            best = G.TopDeals(list)[1]
            if not best then for _, d in ipairs(list) do if not best or d.profit > best.profit then best = d end end end
            local done = { stamp = stamp, n = #list, top = top, best = best }
            summaries[key] = done
            if dealsTell[key] then dealsTell[key] = nil; tellDeals(done) end
            ns.Fire("DealsChanged")
        end)
    return nil
end
-- after a scan, the deals of that house are worked out, then told
ns.On("ScanDone", function(h)
    local key = ns.HouseKey(h)
    summaries[key] = nil
    G.SpreadForget("deals", key)
    dealsTell[key] = true
    G.DealsSummary(h)
end)
ns.On("Login", function() summaries, dealsTell = {}, {} end)

-- ---------------------------------------------------------------------
-- 2) Crafts that pay
-- ---------------------------------------------------------------------

-- filter = { prof = profession key or nil, all = true for every recipe (losing
-- ones and unknown profits too), else only the ones paying the minimum profit }
function G.FindCrafts(filter, h)
    filter = filter or {}
    local res, minProfit = {}, ns.db.minProfit or 0
    for id, r in pairs(G.Recipes()) do
        if not filter.prof or r.prof == filter.prof then
            local d = G.EvaluateRecipe(id, r, h)
            if filter.all or (d.profit and d.profit >= minProfit) then res[#res + 1] = d end
        end
    end
    return res
end

-- A profession shown in the crafts (not gathering, enchanting or first aid).
function G.IsCraftProf(key)
    return type(key) == "string" and ns.PROF_ICONS[key] ~= nil and not SKIP_PROFS[key]
end

-- The professions of the crafts bar: { key, name, icon, count, known }
function G.Professions()
    local counts = {}
    for _, r in pairs(G.Recipes()) do counts[r.prof] = (counts[r.prof] or 0) + 1 end
    local list = {}
    for _, key in ipairs(ns.PROF_ORDER) do
        if not SKIP_PROFS[key] then
            list[#list + 1] = { id = key, name = G.ProfName(key), icon = ns.PROF_ICONS[key], count = counts[key] or 0,
                                known = ns.profs[key] ~= nil }
        end
    end
    return list
end

-- ---------------------------------------------------------------------
-- Filters, top offers
-- ---------------------------------------------------------------------

-- Which filter hides this line: "maxBuy", "stars", "search", or nil (shown).
function G.FilterMiss(d, f)
    if f.maxBuy and f.maxBuy > 0 and (d.buy or 0) > f.maxBuy then return "maxBuy" end
    if f.minStars and d.kind ~= "PNJ" and G.Stars(d.conf) < f.minStars then return "stars" end
    if f.search and f.search ~= "" then
        local needle = f.search:lower()
        local name = ns.Item(d.itemID).name
        local hit = (name and name:lower():find(needle, 1, true)) or (d.label and d.label:lower():find(needle, 1, true))
        if not hit then return "search" end
    end
    return nil
end
function G.PassesFilters(d, f) return G.FilterMiss(d, f) == nil end

-- The stars a Top offer or a Top craft needs: 4 at least (an imported setting can ask more, not less).
function G.TopMinStars() return math.max(4, ns.db.topMinStars or 4) end

-- The same Top for the three tabs: a resale price read on real sales, the stars
-- of the Top and a pace of sales; ranked by profit (per day of cooldown for a
-- craft) times confidence, the 5 best.
local function isTop(d)
    return d.profit ~= nil and d.source == "sales" and G.Stars(d.conf) >= G.TopMinStars()
        and d.stats ~= nil and (d.stats.perDay or 0) >= (ns.db.topMinPerDay or 1)
end
local function topOf(list, keep)
    local top = {}
    for _, d in ipairs(list) do if keep(d) then top[#top + 1] = d end end
    table.sort(top, function(a, b) return (a.rank or a.profit) * a.conf > (b.rank or b.profit) * b.conf end)
    for i = #top, 6, -1 do top[i] = nil end
    return top
end

function G.IsTopDeal(d) return d.kind == "HV" and isTop(d) end
function G.TopDeals(list) return topOf(list, G.IsTopDeal) end
function G.IsTopCraft(d) return d.recipe ~= nil and isTop(d) end
function G.TopCrafts(list) return topOf(list, G.IsTopCraft) end
-- ---------------------------------------------------------------------
-- 3) Buying in volume: the cheapest units of a basic material, sold back a
--    little dearer. The profit comes from the number, not from each unit.
-- ---------------------------------------------------------------------

G.VOLUME_DAYS = 3        -- buy no more than about 3 days of sales: what the market takes back
G.VOLUME_RISK_DAYS = 7   -- the risky plan (raising the market): up to 7 days of sales
-- The least a lot must earn on what it costs (5 % unless changed in the tab): 700 gold
-- risked for 2 is not worth it, 30 for 2 is. A smaller lot that earns enough is chosen.
-- How big a stake is: "small" under 50 po, "mid" under 250 po, "big" above.
G.BUDGET_MID, G.BUDGET_BIG = 50 * 10000, 250 * 10000
function G.Budget(cost)
    if not cost then return nil end
    if cost >= G.BUDGET_BIG then return "big" end
    if cost >= G.BUDGET_MID then return "mid" end
    return "small"
end
-- Bag slots that n units of an item take (one per stack), and the free ones
-- in the bags (general bags only: a herb or mining bag does not take anything).
function G.SlotsFor(id, n)
    if not (id and n and n > 0) then return 0 end
    local st = (ns.Item(id) or {}).stack or 1
    return math.ceil(n / math.max(1, st))
end
function G.FreeSlots()
    local C = C_Container
    local f = C and C.GetContainerNumFreeSlots
    if not f then return nil end
    local free = 0
    for bag = 0, 4 do
        local ok, n, family = pcall(f, bag)
        if ok and n and (family or 0) == 0 then free = free + n end
    end
    return free
end
function G.VolMinReturn() return (ns.db.volMinReturn or 5) / 100 end
-- The categories of the tab (trade goods by their subclass), in the order of the bar.
G.VOLUME_CATS = {
    { key = "herb", sub = SUB.Herb or 9, icon = 136246 },
    { key = "mining", sub = SUB.MetalStone or 7, icon = 136248 },
    { key = "skin", sub = SUB.Leather or 6, icon = 133611 },
    { key = "cloth", sub = SUB.Cloth or 5, icon = 136249 },
    { key = "meat", sub = SUB.Cooking or 8, icon = 133971 },
    { key = "ench", sub = SUB.Enchanting or 12, icon = 136244 },   -- dusts, essences, shards
    { key = "other", icon = "Interface\\Icons\\INV_Misc_Bag_10" },
}
-- The category of an item, nil when it is not a trade good.
function G.VolumeCategory(id)
    local _, _, _, _, _, classID, subID = instant(id)
    if classID ~= TRADEGOODS then return nil end
    for _, c in ipairs(G.VOLUME_CATS) do
        if c.sub and c.sub == subID then return c.key end
    end
    return "other"
end

-- Selling just under the next listing: 1 copper under, as everyone does (a
-- price with copper posts fine on Forever, confirmed in game).
G.PRICE_STEP = 1
local function silverDown(p) return math.floor(p / G.PRICE_STEP) * G.PRICE_STEP end
local function silverUnder(p) return math.ceil(p / G.PRICE_STEP) * G.PRICE_STEP - G.PRICE_STEP end   -- the last step strictly under p
G.SilverUnder = silverUnder

-- The plan for one material: buy the n cheapest units (no more than the market
-- takes back in VOLUME_DAYS days of sales), sell them again in whole silver
-- just under what is left, never above the price it really sells at (the same
-- resale price, stars and verdict as an offer or a craft). The lot that pays
-- the most wins. nil when it is not a trade good or nothing is for sale.
function G.EvaluateVolume(id, h)
    h = h or house()
    local cat = G.VolumeCategory(id)
    if not cat then return nil end
    -- the sales first (cheap, kept): without a pace of sales, no advice and no need to read the listings
    local ref, estimate, st, source, days = resalePrice(id, nil, h)
    local d = { itemID = id, kind = "Volume", volume = true, cat = cat, stats = st, source = source,
                days = days, estimate = estimate }
    if not ref or not st or (st.perDay or 0) <= 0 then return d end
    local lv, _, lfrom = ns.Tracker.Ladder(id, h)
    if not lv or #lv == 0 then return d end
    d.ladder, d.ladderFrom = lv, lfrom
    local keep = 1 - cut(h)
    local absorb = math.max(1, math.floor(st.perDay * G.VOLUME_DAYS + 0.5))
    local cap = silverDown(ref)
    local best, n, cost, cands = nil, 0, 0, {}
    local minRet = G.VolMinReturn()
    for i, l in ipairs(lv) do
        local unit, c = l[1], l[2]
        local take = math.min(c, absorb - n)   -- a material is a commodity: any number can be bought
        if take <= 0 then break end
        n, cost = n + take, cost + take * unit
        local nextUnit = take < c and unit or (lv[i + 1] and lv[i + 1][1])
        local resale = nextUnit and math.min(cap, silverUnder(nextUnit)) or cap
        if resale > 0 then
            local profit = n * resale * keep - cost
            local cand = { n = n, cost = cost, resale = resale, profit = profit, unit = unit, level = i, nextUnit = nextUnit }
            -- every lot that pays enough on what it costs: the plans to choose from
            local enough = profit > 0 and cost > 0 and profit / cost >= minRet
            if enough then cands[#cands + 1] = cand end
            if enough and (not best or profit > best.profit) then best = cand end
        end
        if take < c then break end
    end
    if not best then return d end
    -- the risky plan: buy what is for sale up to 7 days of sales so that the cheapest
    -- left is dearer, and sell just under it, never above the high quartile of the
    -- sales seen. Shown only when it pays more than the most profit above.
    local high = (source == "sales" and st.p75 and st.p75 > ref) and silverDown(st.p75) or cap
    local absorbRisk = math.max(absorb, math.floor(st.perDay * G.VOLUME_RISK_DAYS + 0.5))
    local risky
    n, cost = 0, 0
    for i, l in ipairs(lv) do
        local unit, c = l[1], l[2]
        local take = math.min(c, absorbRisk - n)
        if take <= 0 then break end
        n, cost = n + take, cost + take * unit
        local nextUnit = take < c and unit or (lv[i + 1] and lv[i + 1][1])
        local resale = nextUnit and math.min(high, silverUnder(nextUnit)) or high
        local profit = n * resale * keep - cost
        if resale > 0 and n > best.n and profit > best.profit and profit / cost >= minRet and (not risky or profit > risky.profit) then
            risky = { n = n, cost = cost, resale = resale, profit = profit, unit = unit, level = i, nextUnit = nextUnit }
        end
        if take < c then break end
    end
    d.risky = risky
    d.n, d.units, d.buy, d.market, d.sell, d.profit = best.n, best.n, best.cost, best.resale, best.resale * best.n, best.profit
    d.unitMax, d.unitAvg, d.nextUnit, d.level, d.absorb = best.unit, best.cost / best.n, best.nextUnit, best.level, absorb
    d.margin = best.cost > 0 and best.profit / best.cost or 0
    d.cands = cands
    d.suffix = "  x" .. best.n   -- after the name, read when shown (it may still be loading now)
    d.conf = offerConf(id, best.resale, h, best.n)
    d.comp, d.ev = lastComp, lastEv
    return d
end

-- Two or three plans for one material, smallest lot first: { key, n, cost, unit
-- (the dearest bought), resale, profit, margin, days, conf }.
--   "max": the most profit (the plan of the list);
--   "safe": a clearly smaller lot (80 % of it at most) with a better return on what is
--           spent than the max, still a fifth of its profit at least;
--   "mid": a lot half-way between the two, 10 % of the max's size away from each;
--   "risk": raising the market (more days of sales, a dearer resale), when it pays more.
function G.VolumePlans(d, h)
    h = h or house()
    local cands = d.cands or {}
    if not d.n or #cands == 0 then return {} end
    local max
    for _, c in ipairs(cands) do if not max or c.profit > max.profit then max = c end end
    local function ret(c) return c.cost > 0 and c.profit / c.cost or 0 end
    local safe
    for _, c in ipairs(cands) do
        if c.n <= max.n * 0.8 and ret(c) > ret(max) and c.profit >= max.profit * 0.2
            and (not safe or ret(c) > ret(safe)) then safe = c end
    end
    local mid
    if safe then
        local target, gap = (safe.n + max.n) / 2, max.n * 0.1
        for _, c in ipairs(cands) do
            if c.n - safe.n >= gap and max.n - c.n >= gap and c.profit > safe.profit
                and (not mid or math.abs(c.n - target) < math.abs(mid.n - target)) then mid = c end
        end
    end
    local plans = {}
    for _, pick in ipairs({ { "safe", safe }, { "mid", mid }, { "max", max }, { "risk", d.risky } }) do
        local c = pick[2]
        if c then
            local sc, comp = ns.Tracker.OfferScore(d.itemID, c.resale, h, c.n)
            local perDay = d.stats and d.stats.perDay or 0
            plans[#plans + 1] = { key = pick[1], n = c.n, cost = c.cost, unit = c.unit, resale = c.resale, profit = c.profit,
                                  margin = c.cost > 0 and c.profit / c.cost or 0, conf = sc,
                                  days = perDay > 0 and ((comp and comp.units or 0) + c.n) / perDay or nil }
        end
    end
    return plans
end

-- Every material worth buying in volume (at least the minimum profit), for the
-- house shown; filter = { cat = category key or nil }. Kept until the prices change.
-- true while the list of the house shown is being worked out
function G.VolumeBusy(h) return G.SpreadBusy("volume", ns.HouseKey(h or house())) end
function G.FindVolume(filter, h)
    filter, h = filter or {}, h or house()
    local book = ns.Scan.Book(h)
    local key = ns.HouseKey(h)
    local snap = ns.db.snapFull and ns.db.snapFull[key]
    local data = type(CraftMasterData) == "table" and type(CraftMasterData.houses) == "table" and CraftMasterData.houses[key]
    local stamp = table.concat({ key, tostring(book.at), tostring(snap and snap.time), tostring(data and data.at),
                                 tostring(ns.CutPct(h)), tostring(G.TopMinStars()), tostring(G.VolMinReturn()) }, "|")
    -- every item priced, or listed in the last full scan
    local list = G.Spread("volume", key, stamp, function() return keysOf(book.items, snap and snap.items) end,
        function(id)
            local d = G.EvaluateVolume(id, h)
            return (d and d.profit and d.profit > 0) and d or nil
        end)
    local res, minProfit = {}, ns.db.minProfit or 0
    for _, d in ipairs(list or {}) do
        if d.profit >= minProfit and (not filter.cat or d.cat == filter.cat) then res[#res + 1] = d end
    end
    return res
end

-- The listings of an item read again at the house: its lot in the list is worked
-- out again on them (or leaves the list), so that a card and its detail agree.
ns.On("LiveLadder", function(id)
    local h = house()
    local c = spreadOf("volume").cache[ns.HouseKey(h)]
    if not (c and c.list) then return end
    for i, d in ipairs(c.list) do
        if d.itemID == id then
            local nd = G.EvaluateVolume(id, h)
            if nd and nd.profit and nd.profit > 0 then c.list[i] = nd else table.remove(c.list, i) end
            if ns.UI and ns.UI.RefreshSoon then ns.UI.RefreshSoon() end
            return
        end
    end
end)
-- The lots shown, the Auction House open: their listings read again one after the
-- other (the game takes 100 searches a minute at most), each card then tells the truth.
local liveQueue, liveTicking = {}, false
local function liveTick()
    if not ns.Buy.ahOpen or #liveQueue == 0 then liveTicking = false; liveQueue = {} return end
    if ns.Buy.Busy() or ns.Sell.Busy() or ns.Scan.Running() then C_Timer.After(2, liveTick) return end   -- a purchase first
    local id = table.remove(liveQueue, 1)
    local age = ns.Tracker.LiveAge(id)
    if not age or age > 300 then ns.Tracker.ReadLive(id) end
    C_Timer.After(0.8, liveTick)
end
function G.VolumeCheckLive(list)
    if not (ns.Buy.ahOpen and C_Timer and C_Timer.After) or ns.Scan.Running() then return end
    local queued = {}
    for _, id in ipairs(liveQueue) do queued[id] = true end
    local n = 0
    for _, d in ipairs(list or {}) do
        if n >= 40 then break end
        local age = ns.Tracker.LiveAge(d.itemID)
        if not queued[d.itemID] and (not age or age > 300) then
            liveQueue[#liveQueue + 1] = d.itemID
            queued[d.itemID] = true
            n = n + 1
        end
    end
    if not liveTicking and #liveQueue > 0 then liveTicking = true; C_Timer.After(0.2, liveTick) end
end

function G.IsTopVolume(d) return d.volume == true and isTop(d) and d.profit > 0 end
function G.TopVolume(list) return topOf(list, G.IsTopVolume) end

-- ---------------------------------------------------------------------
-- 4) From one house to the other (the comparison of the houses): bought at the
--    cheapest listing of one house, sold again at the other. The reckoning of
--    an offer, on the house where it is sold: its resale price, its cut, its
--    stars (sales seen there, what is for sale there under my price).
-- ---------------------------------------------------------------------

G.HOUSES_MAX_GAP = 48 * 3600   -- two scans further apart do not compare: one photo is too old
G.OTHER_HOUSE = { faction = "neutral", neutral = "faction" }
-- Both houses scanned, and not too far apart? Second and third answers: when.
function G.HousesComparable()
    local a, b = ns.Scan.LastAt("faction"), ns.Scan.LastAt("neutral")
    return (a and b and math.abs(a - b) <= G.HOUSES_MAX_GAP) and true or false, a, b
end

-- Bought at the house `from`, sold at the other; nil when not for sale at `from`.
function G.EvaluateTransfer(id, from)
    local to = G.OTHER_HOUSE[from]
    local cur, there = G.Current(id, from), G.Current(id, to)
    if not (to and cur) then return nil end
    -- no sale seen nor usual price over there: the cheapest listing there, a guess
    local sell, estimate, st, source, days = resalePrice(id, there and there.p, to)
    local d = { itemID = id, kind = "HV", transfer = true, from = from, to = to, house = to, units = 1,
                buy = cur.p, qty = cur.q, sell = sell, market = sell, estimate = estimate, stats = st,
                source = source, days = days, conf = offerConf(id, sell, to, false) }
    d.comp, d.ev = lastComp, lastEv
    if sell then
        d.profit = sell * (1 - cut(to)) - d.buy
        d.margin = d.buy > 0 and d.profit / d.buy or 0
    end
    return d
end

-- The better way for one item, when it is a deal: the same rule as an offer
-- (bought at the deal threshold of its resale price or under, the minimum profit).
local function transferOf(id)
    local threshold, minProfit = ns.db.dealThreshold or 0.70, ns.db.minProfit or 0
    local best
    for _, from in ipairs({ "faction", "neutral" }) do
        local d = G.EvaluateTransfer(id, from)
        if d and d.profit and d.buy <= d.sell * threshold and d.profit >= minProfit
            and (not best or d.profit > best.profit) then best = d end
    end
    return best
end

local function transferStamp()
    local a, b = ns.Scan.Book("faction"), ns.Scan.Book("neutral")
    return table.concat({ tostring(a.at), tostring(b.at), tostring(ns.db.dealThreshold or 0.7), tostring(ns.db.minProfit or 0),
                          tostring(ns.CutPct("faction")), tostring(ns.CutPct("neutral")), tostring(G.TopMinStars()) }, "|")
end
function G.TransferBusy() return G.SpreadBusy("houses", "both") end
-- Every item worth moving from one house to the other (both scans recent enough).
function G.FindTransfers()
    if not G.HousesComparable() then return {} end
    local fa, ne = ns.Scan.Book("faction").items, ns.Scan.Book("neutral").items
    -- listed in both: an item listed on one side only has no price to aim at over there
    local list = G.Spread("houses", "both", transferStamp(), function()
        local order = {}
        for id in pairs(fa or {}) do if ne and ne[id] then order[#order + 1] = id end end
        return order
    end, transferOf)
    return list or {}
end
function G.IsTopTransfer(d) return d.transfer == true and isTop(d) end
function G.TopTransfers(list) return topOf(list, G.IsTopTransfer) end

-- ---------------------------------------------------------------------
-- 5) Plans from a merchant, sold at the Auction House (the faction one or the
--    shared one, the better): bought at the merchant's price, the reckoning
--    of an offer on the house where it is sold.
-- ---------------------------------------------------------------------

-- [recipe item] = spell it teaches, the ones that can be sold (not bound when picked up)
local planList
local function planItems()
    if not planList then
        planList = {}
        for sid, r in pairs(ns.RECIPES or {}) do
            if r.ri and not r.bop then planList[r.ri] = sid end
        end
    end
    return planList
end
-- What a merchant asks for a plan: a merchant of my side sells it (the table of
-- merchants), or one was seen in game (that price wins). nil when none sells it.
local function planVendorPrice(ri)
    local seen = ns.db.vendorBuy and ns.db.vendorBuy[ri]
    if seen then return seen end
    if ns.VENDOR_PRICE and ns.VENDOR_PRICE[ri] and #ns.Prices.VendorsOf(ri) > 0 then return ns.VENDOR_PRICE[ri] end
end
G.PlanVendorPrice = planVendorPrice
function G.IsPlan(ri) return planItems()[ri] ~= nil end

-- the reputations of one side only (the other side has its own merchant)
local REP_SIDE = { ["Durotar Supply and Logistics"] = "Horde", ["Azeroth Commerce Authority"] = "Alliance" }
-- What makes a plan hard to get at its merchant, in words: a limited stock (seen
-- at a visit: it comes back slowly once bought), a reputation to reach, an event
-- of the year (the merchant sells it then only).
function G.PlanLimits(ri)
    local out, seen = {}, {}
    if ns.db.vendorLimited and ns.db.vendorLimited[ri] then out[#out + 1] = L.GM_PL_LIMITED end
    local sid = planItems()[ri]
    local r = sid and ns.RECIPES[sid]
    for _, s in ipairs(r and r.s or {}) do
        local words
        local side = s[1] == "R" and REP_SIDE[s[2]]
        if side and UnitFactionGroup and UnitFactionGroup("player") ~= side then
            words = nil
        elseif s[1] == "R" then
            words = string.format(L.GM_PL_REP, L.REP_STANDING[s[3]] or L.REP_STANDING["?"], L.REP_FACTION[s[2]] or s[2])
        elseif s[1] == "E" then
            words = string.format(L.GM_PL_EVENT, L.WORLD_EVENT[s[2]] or s[2])
        end
        if words and not seen[words] then seen[words] = true; out[#out + 1] = words end
    end
    return out
end

-- A plan bought at a merchant and sold at the house h; nil when no merchant sells it.
function G.EvaluatePlan(ri, h)
    local v = planVendorPrice(ri)
    if not v then return nil end
    local cur = G.Current(ri, h)
    -- no sale seen nor usual price: the cheapest listing there, a guess
    local sell, estimate, st, source, days = resalePrice(ri, cur and cur.p, h)
    local sid = planItems()[ri]
    local r = sid and ns.RECIPES[sid]
    local d = { itemID = ri, kind = "HV", plan = true, house = h, to = h, units = 1, buy = v,
                sell = sell, market = sell, estimate = estimate, stats = st, source = source, days = days,
                qty = cur and cur.q, prof = r and r.p, spellID = sid, conf = offerConf(ri, sell, h, false),
                limits = G.PlanLimits(ri) }
    d.comp, d.ev = lastComp, lastEv
    if sell then
        d.profit = sell * (1 - cut(h)) - v
        d.margin = v > 0 and d.profit / v or 0
    end
    return d
end

-- The better house for one plan, when it is a deal (the rule of an offer).
local function planOf(ri)
    local threshold, minProfit = ns.db.dealThreshold or 0.70, ns.db.minProfit or 0
    local best
    for _, h in ipairs({ "faction", "neutral" }) do
        local d = G.EvaluatePlan(ri, h)
        if d and d.profit and d.buy <= d.sell * threshold and d.profit >= minProfit
            and (not best or d.profit > best.profit) then best = d end
    end
    return best
end
local function planStamp()
    local a, b = ns.Scan.Book("faction"), ns.Scan.Book("neutral")
    local seen = 0
    for _ in pairs(ns.db.vendorBuy or {}) do seen = seen + 1 end
    return table.concat({ tostring(a.at), tostring(b.at), tostring(ns.db.dealThreshold or 0.7), tostring(ns.db.minProfit or 0),
                          tostring(ns.CutPct("faction")), tostring(ns.CutPct("neutral")), tostring(G.TopMinStars()), seen }, "|")
end
function G.PlanBusy() return G.SpreadBusy("plans", "both") end
-- Every plan worth buying at a merchant and selling at the Auction House.
function G.FindPlans()
    local list = G.Spread("plans", "both", planStamp(), function()
        local order = {}
        for ri in pairs(planItems()) do order[#order + 1] = ri end
        return order
    end, planOf)
    return list or {}
end
function G.IsTopPlan(d) return d.plan == true and isTop(d) end
function G.TopPlans(list) return topOf(list, G.IsTopPlan) end
ns.On("RecipesChanged", function() planList = nil end)

-- Days before mine sells, for an offer, a craft or a lot alike: what is for sale
-- under my resale price (the competition its stars were given with) plus mine
-- (one, what the recipe makes, the whole lot), at the pace it sells. nil when unknown.
function G.DaysToSell(d)
    local c, st = d.comp, d.stats
    if not c or not st or not st.perDay or st.perDay <= 0 then return nil end
    return (c.units + (d.units or d.n or 1)) / st.perDay
end

-- The resale aimed at, as shown: the price per unit it lists at, times what is
-- sold (one, the recipe's batch, the lot), before the cut.
function G.ResaleShown(d)
    if d.recipe then return d.market and d.market * (d.recipe.qty or 1) or nil end
    return d.sell
end

-- Are sales known for the house shown (seen by the scans, or published by Blizzard)?
function G.SalesKnown(h)
    if G.TotalSales() > 0 then return true end
    local d = CraftMasterData
    local hd = type(d) == "table" and type(d.houses) == "table" and d.houses[ns.HouseKey(h or house())]
    return type(hd) == "table" and type(hd.sales) == "string" and hd.sales ~= ""
end

-- Sales seen (sure or probable) and the items they were of, for the house shown.
function G.TotalSales()
    local n, items = 0, 0
    for _, list in pairs(ns.Tracker.Store(ns.HouseKey(house()))) do
        local any = false
        for _, e in ipairs(list) do if (e[4] or 0) > 0 then n = n + 1; any = true end end
        if any then items = items + 1 end
    end
    return n, items
end

-- The last sales of an item: { {time, price, qty, weight, seller, shared}, ... } newest first
function G.Sales(id, h)
    local out = {}
    for _, e in ipairs(ns.Tracker.Store(ns.HouseKey(h or house()))[id] or {}) do out[#out + 1] = e end
    table.sort(out, function(a, b) return a[1] > b[1] end)
    return out
end

-- The sales seen, grouped: one line per scan and kind instead of one per
-- listing. { { t, kind = "expired"|"sold"|"maybe", n (units), lo, hi, shared, mine = "buy"|"sell"|nil } }, newest first.
function G.SalesGroups(events, max)
    local out = {}
    for _, e in ipairs(events) do
        local kind = e[4] < 0 and "expired" or (e[4] >= 0.5 and "sold" or "maybe")
        local g = out[#out]
        if not (g and g.t == e[1] and g.kind == kind and g.mine == e[9]) then
            if max and #out >= max then break end
            g = { t = e[1], kind = kind, n = 0, lo = e[2], hi = e[2], mine = e[9] }
            out[#out + 1] = g
        end
        g.n = g.n + (e[3] or 1)
        if e[2] < g.lo then g.lo = e[2] end
        if e[2] > g.hi then g.hi = e[2] end
        if e[6] then g.shared = true end
    end
    return out
end

-- How long the sales were watched: "20 h", "3 j" (one day at least).
function G.SpanText(s) return ns.Duration(math.floor(((s and s.span) or 1) * 86400 + 0.5)) end

-- The one-line verdict of an offer: level ("good", "warn", "bad", "info") and
-- the main reason of its stars, in the order a player cares about.
function G.Verdict(d)
    if d.kind == "PNJ" then return "good", string.format(L.GM_V_VENDOR, ns.Money(d.sell)) end
    local s, ev, c = d.stats, d.ev, d.comp
    if not s or (s.n or 0) <= 0 then return "info", L.GM_V_NO_SALE end
    local price = ns.Money(d.market or d.sell)
    local alarm = ns.Tracker.EvidenceAlarm(ev)
    if alarm == "none" then return "bad", string.format(L.GM_V_EXPIRED_NO_SALE, ev.expired24, price) end
    if alarm == "hard" and ev.expired24 > ev.sold24 then return "bad", string.format(L.GM_V_EXPIRED, ev.expired24, price) end
    if alarm == "hard" then return "bad", string.format(L.GM_V_LOW_THROUGH, math.floor(ev.through * 100 + 0.5)) end
    if c and c.listings > 10 and (c.days or 0) > 1 then return "warn", string.format(L.GM_V_CROWDED, c.listings) end
    if c and c.days and c.days > 2 then return "warn", string.format(L.GM_V_SLOW, c.days) end
    if ev and ev.through < ns.Tracker.OK_THROUGH then return "warn", string.format(L.GM_V_LOW_THROUGH, math.floor(ev.through * 100 + 0.5)) end
    local n = math.floor(s.n + 0.5)
    if G.Stars(d.conf or 0) >= 4 then return "good", string.format(L.GM_V_SELLS, n, G.SpanText(s), s.perDay or 0) end
    return "info", string.format(L.GM_V_LIKELY, n, G.SpanText(s))
end

-- ---------------------------------------------------------------------
-- Recipe details
-- ---------------------------------------------------------------------

function G.ReagentDetails(r, count, recipeID)
    local list = {}
    for _, rg in ipairs(r.reagents) do
        local unit, source, cur = G.ReagentPrice(rg.id)
        local need = rg.n * count
        list[#list + 1] = {
            id = rg.id, need = need, unit = unit, total = unit and unit * need,
            available = cur and cur.q or 0, market = (G.MarketPrice(rg.id)),
            source = source,
            excluded = recipeID and G.IsExcluded(recipeID, rg.id) or false,
            excludedGlobal = G.IsExcludedGlobal(rg.id),
        }
    end
    return list
end

-- Every material of the recipes: { {id, uses, cat, catLabel}, ... }
function G.AllReagents()
    local map = {}
    for _, r in pairs(G.Recipes()) do
        for _, rg in ipairs(r.reagents) do
            local e = map[rg.id]
            if not e then
                local key, label = G.ReagentCategory(rg.id)
                e = { id = rg.id, uses = 0, cat = key, catLabel = label }
                map[rg.id] = e
            end
            e.uses = e.uses + 1
        end
    end
    local list = {}
    for _, e in pairs(map) do list[#list + 1] = e end
    return list
end

-- Opens the item at the Auction House (it must be open).
function G.SearchAH(id)
    if not (AuctionHouseFrame and AuctionHouseFrame:IsShown()) then
        return ns.Print(L.GM_OPEN_AH)
    end
    local name = ns.Item(id).name
    local bar = AuctionHouseFrame.SearchBar
    if name and bar and bar.SearchBox then bar.SearchBox:SetText(name) end
    local ok = AuctionHouseFrame.SelectBrowseResult and C_AuctionHouse.MakeItemKey
        and pcall(AuctionHouseFrame.SelectBrowseResult, AuctionHouseFrame, { itemKey = C_AuctionHouse.MakeItemKey(id) })
    if not ok and bar and bar.StartSearch then
        if not pcall(bar.StartSearch, bar) then ns.Print(L.GM_NAME_COPIED) end
    end
end

-- ---------------------------------------------------------------------
-- Scans
-- ---------------------------------------------------------------------

-- Seconds before a full scan is allowed again (0: now).
function G.ScanWait() return ns.Scan.FullWait() end
function G.LastScan() return ns.Scan.LastAt(house()) end

ns.On("ScanDone", function()
    ns.db.scanCount = (ns.db.scanCount or 0) + 1
end)

-- Prices, sales and cooldowns move: the pages redraw.
for _, e in ipairs({ "PricesChanged", "SalesChanged", "HouseChanged" }) do
    ns.On(e, function() ns.Fire("GoldChanged") end)
end
