local _, ns = ...
local L = ns.L
local W = ns.W

-- Codex: everything about one item. Its prices (Auction House, vendor,
-- disenchanting), how it moved, the recipes that make it and use it, the
-- recipe it teaches, where to get it — with map markers to the vendors and
-- farming spots.

local LIST_W = 320

ns.UI.AddPage("codex", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    page.search = L.SEARCH_ITEM

    local left = W.Card(body)
    left:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0)
    left:SetWidth(LIST_W)
    local hint = W.Text(left, "tiny", "LEFT")
    hint:SetPoint("TOPLEFT", left, "TOPLEFT", 12, -8)
    hint:SetPoint("RIGHT", left, "RIGHT", -12, 0)
    hint:SetTextColor(C.label[1], C.label[2], C.label[3])

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(18, 18)
        r.icon:SetPoint("LEFT", r, "LEFT", 4, 0)
        r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        r.price = W.Text(r, "small", "RIGHT")
        r.price:SetWidth(80)
        r.price:SetPoint("RIGHT", r, "RIGHT", -4, 0)
        r.spark = ns.Chart.Spark(r, 56, 16)
        r.spark:SetPoint("RIGHT", r.price, "LEFT", -6, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
        r.name:SetPoint("RIGHT", r.spark, "LEFT", -4, 0)
        r.name:SetWordWrap(false)
        r:SetScript("OnClick", function(self)
            ns.char.codexItem = self.data
            page.Refresh()
        end)
        return r
    end
    local function fillRow(r, id)
        r.data = id
        r.sel:SetShown(ns.char.codexItem == id)
        local i = ns.Item(id)
        r.icon:SetTexture(i and i.icon or 134400)
        r.name:SetText(ns.ItemName(id))
        r.name:SetTextColor(ns.QualityColor(i and i.quality or 1))
        local p = ns.Prices.AH(id)
        r.spark.Set(ns.Chart.PriceSeries(id))
        r.price:SetText(p and ns.Money(p, true) or "")
        r.price:SetTextColor(C.text[1], C.text[2], C.text[3])
    end
    local list = W.List(left, 24, makeRow, fillRow)
    list:SetPoint("TOPLEFT", left, "TOPLEFT", 8, -24)
    list:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -6, 10)
    list.Color(color)

    -- ---------------------------------------------------------- the item
    local right = W.Card(body)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 12, 0)
    right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    local icon = W.ItemIcon(right, 40)
    icon:SetPoint("TOPLEFT", right, "TOPLEFT", 14, -14)
    local title = W.Text(right, "title", "LEFT")
    title:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, -2)
    title:SetPoint("RIGHT", right, "RIGHT", -14, 0)
    title:SetWordWrap(false)
    local sub = W.Text(right, "small", "LEFT")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    sub:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- two columns: facts on the left, recipes on the right
    local colL = CreateFrame("ScrollFrame", nil, right)
    colL:SetPoint("TOPLEFT", icon, "BOTTOMLEFT", 0, -14)
    colL:SetPoint("BOTTOM", right, "BOTTOM", 0, 150)
    colL:SetPoint("RIGHT", right, "CENTER", -8, 0)
    local flowL = W.Flow(colL)
    colL:SetScrollChild(flowL)
    local colR = CreateFrame("ScrollFrame", nil, right)
    colR:SetPoint("TOPLEFT", right, "TOP", 8, -68)
    colR:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -14, 150)
    local flowR = W.Flow(colR)
    colR:SetScrollChild(flowR)
    for _, sf in ipairs({ { colL, flowL }, { colR, flowR } }) do
        local frame, flow = sf[1], sf[2]
        frame:EnableMouseWheel(true)
        frame:SetScript("OnMouseWheel", function(self, d)
            local max = math.max(0, flow:GetHeight() - self:GetHeight())
            self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - d * 30)))
        end)
    end
    local chart = ns.Chart.New(right)
    chart:SetHeight(120)
    chart:SetPoint("BOTTOMLEFT", right, "BOTTOMLEFT", 6, 12)
    chart:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -14, 12)
    local empty = W.Text(right, "body", "CENTER")
    empty:SetPoint("CENTER")
    empty:SetText(L.CODEX_PICK)
    empty:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- What the list holds: with a search, every item CraftMaster knows of;
    -- without, my bags, the cart and the crafts of my professions.
    local function buildList()
        local q = page.query and page.query ~= "" and string.lower(page.query) or nil
        local out, seen = {}, {}
        local function add(id)
            if id and not seen[id] then
                seen[id] = true
                if not q or string.find(string.lower(ns.ItemName(id)), q, 1, true) then out[#out + 1] = id end
            end
        end
        if q then
            for id in pairs(ns.Recipes.Index().all) do add(id) end
            local book = ns.Scan.Book()
            for id in pairs(book.items or {}) do add(id) end
        else
            if C_Container and C_Container.GetContainerNumSlots then
                for bag = 0, 4 do
                    for slot = 1, C_Container.GetContainerNumSlots(bag) or 0 do
                        local info = C_Container.GetContainerItemInfo(bag, slot)
                        if info and info.itemID then add(info.itemID) end
                    end
                end
            end
        end
        table.sort(out, function(a, b) return ns.ItemName(a) < ns.ItemName(b) end)
        while #out > 400 do table.remove(out) end
        return out
    end

    local function recipeLine(flow, sid)
        local r = ns.RECIPES[sid]
        local known = ns.Recipes.IsKnown(sid)
        local mark = known and "|cff73d982•|r " or ""
        flow.Line(mark .. ns.Recipes.Name(sid) .. string.format("  |cff999999%s %d|r", L.PROF[r.p], r.sk and r.sk[1] or 0), {
            icon = ns.Recipes.Icon(sid),
            pin = nil,
        })
    end

    function page.Refresh()
        local items = buildList()
        list.SetData(items, true)
        hint:SetText(page.query and page.query ~= "" and string.format(L.HIST_COUNT, #items) or L.CODEX_HINT)
        local id = ns.char.codexItem
        flowL.Clear(); flowR.Clear()
        colL:SetVerticalScroll(0); colR:SetVerticalScroll(0)
        local shown = id ~= nil
        for _, part in ipairs({ icon, title, sub, colL, colR, chart }) do part:SetShown(shown) end
        empty:SetShown(not shown)
        if not shown then return end
        flowL:SetWidth(math.max(120, colL:GetWidth()))
        flowR:SetWidth(math.max(120, colR:GetWidth()))
        local i = ns.Item(id) or {}
        icon.Set(id)
        title:SetText(ns.ItemName(id))
        title:SetTextColor(ns.QualityColor(i.quality or 1))
        local have = ns.Count(id)
        sub:SetText(string.format(L.CODEX_HAVE, have) .. ((i.ilvl or 0) > 0 and ("  ·  " .. string.format(L.CODEX_ILVL, i.ilvl)) or ""))

        -- prices
        flowL.Head(L.CARD_PRICES, color)
        local ah, age, qty, src = ns.Prices.AH(id)
        flowL.Line(L.FROM_AH .. (src and ("  |cff999999" .. src .. (age and (" · " .. string.format(L.AGO, ns.Duration(age))) or "") .. "|r") or ""),
            { color = C.label, right = ah and ns.Money(ah, true) or "-" })
        if qty then flowL.Line(L.CODEX_LISTED, { color = C.label, right = tostring(qty) }) end
        local vb, guess = ns.Prices.VendorBuy(id)
        if vb then flowL.Line(L.CODEX_VENDOR_BUY .. (guess and " ~" or ""), { color = C.label, right = ns.Money(vb, true) }) end
        flowL.Line(L.CODEX_VENDOR_SELL, { color = C.label, right = (i.sell and i.sell > 0) and ns.Money(i.sell, true) or "-" })
        local de, res = ns.Disenchant.Value(id)
        if res then
            flowL.Line(L.CODEX_DE, { color = C.label, right = de and ns.Money(de, true) or "-" })
            for _, x in ipairs(res) do
                flowL.Line(string.format("%d%%  %.1f× %s", math.floor(x[2] * 100 + 0.5), x[3], ns.ItemName(x[1])),
                    { color = C.muted, indent = 12, icon = ns.Item(x[1]) and ns.Item(x[1]).icon })
            end
        end
        local s30 = ns.History.Stats(ns.History.Series(id, 30))
        if s30 and #ns.History.Series(id, 30) > 1 then
            local c = s30.trend >= 0 and C.profit or C.loss
            flowL.Line(L.HIST_TREND .. " (30)", { color = C.label, right = string.format("%+d%%", math.floor(s30.trend * 100 + 0.5)), rightColor = c })
        end

        -- where to get it
        flowL.Head(L.CODEX_WHERE, color)
        local any = false
        local vendors = ns.Map.Vendors(id)
        if #vendors > 0 then
            any = true
            flowL.Line(string.format(L.CODEX_VENDORS, #vendors), { pin = function() ns.Map.GoNearest(vendors) end, pinTip = L.MAP_GO })
        end
        local spots = ns.Map.Spots(id)
        for n, sp in ipairs(spots) do
            if n > 6 then break end
            any = true
            local kind = sp.kind == "node" and L.CODEX_NODE or L.CODEX_MOB
            flowL.Line(string.format("%s |cff999999(%s, %s)|r", sp.name, kind, sp.zoneName), {
                pin = function() ns.Map.Go(sp) end, pinTip = L.MAP_SPOT,
            })
        end
        local teaches = ns.Recipes.Index().teaches[id]
        if teaches then
            any = true
            for _, s in ipairs(ns.Recipes.Sources(teaches)) do
                local pins = s.pins
                flowL.Line("|cffd9a441" .. s[1] .. "|r  " .. s[2], {
                    pin = (pins and #pins > 0) and function() ns.Map.GoNearest(pins) end or nil,
                })
            end
        end
        if not any then flowL.Line(ns.Map.HasSpots() and L.SRC_UNKNOWN or L.CODEX_NO_QUESTIE, { color = C.muted }) end

        -- recipes
        local idx = ns.Recipes.Index()
        if teaches then
            flowR.Head(L.CODEX_TEACHES, color)
            recipeLine(flowR, teaches)
            local p = ns.Recipes.Price(teaches)
            flowR.Money(L.COL_PROFIT, p.profit, true)
        end
        if idx.madeBy[id] then
            flowR.Head(L.CODEX_MADE_BY, color)
            for _, sid in ipairs(idx.madeBy[id]) do recipeLine(flowR, sid) end
            local p = ns.Recipes.Price(idx.madeBy[id][1])
            if p.cost then flowR.Money(L.TOTAL_COST, p.cost) end
        end
        if idx.usedIn[id] then
            flowR.Head(string.format(L.CODEX_USED_IN, #idx.usedIn[id]), color)
            local listU = {}
            for _, sid in ipairs(idx.usedIn[id]) do listU[#listU + 1] = sid end
            table.sort(listU, function(a, b)
                local ma, mb = ns.profs[ns.RECIPES[a].p] and 0 or 1, ns.profs[ns.RECIPES[b].p] and 0 or 1
                if ma ~= mb then return ma < mb end
                return (ns.RECIPES[a].sk and ns.RECIPES[a].sk[1] or 0) < (ns.RECIPES[b].sk and ns.RECIPES[b].sk[1] or 0)
            end)
            for n, sid in ipairs(listU) do
                if n > 25 then flowR.Line(string.format(L.SRC_MORE, #listU - 25), { color = C.muted }) break end
                recipeLine(flowR, sid)
            end
        end
        if not teaches and not idx.madeBy[id] and not idx.usedIn[id] then
            flowR.Head(L.CODEX_RECIPES, color)
            flowR.Line(L.CODEX_NO_RECIPE, { color = C.muted })
        end

        local series = { { points = ns.History.Series(id, 30), color = C.sky, label = L.HIST_PRICE } }
        chart.Draw(series, 30, L.HIST_NONE)
    end
    function page.OnSearch() page.Refresh() end
    function page.OnResize() if page.frame:IsShown() then page.Refresh() end end
end)

-- Other pages can open an item here.
function ns.UI.ShowItem(id)
    ns.char.codexItem = id
    ns.UI.Open("codex")
end
