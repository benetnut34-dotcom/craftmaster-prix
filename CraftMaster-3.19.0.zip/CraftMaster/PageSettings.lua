local _, ns = ...
local L = ns.L
local W = ns.W

-- Settings: a few cards of rows, a label (and what it does) on the left,
-- the control on the right.

ns.UI.AddPage("settings", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local refreshers = {}

    local scroll = CreateFrame("ScrollFrame", nil, body)
    scroll:SetAllPoints()
    local inner = CreateFrame("Frame", nil, scroll)
    inner:SetSize(600, 1000)
    scroll:SetScrollChild(inner)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, d)
        local max = math.max(0, inner:GetHeight() - self:GetHeight())
        self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - d * 40)))
    end)

    local y = 0
    local card, cardY
    local function startCard(title)
        card = W.Card(inner, title, color)
        card:SetPoint("TOPLEFT", inner, "TOPLEFT", 0, -y)
        card:SetPoint("RIGHT", inner, "RIGHT", 0, 0)
        cardY = card.top
    end
    local function endCard()
        card:SetHeight(cardY + 8)
        y = y + cardY + 8 + 12
    end
    local function row(label, desc, control, width)
        local l = W.Text(card, "body", "LEFT")
        l:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -cardY - 2)
        l:SetText(label)
        local d = W.Text(card, "small", "LEFT")
        d:SetPoint("TOPLEFT", l, "BOTTOMLEFT", 0, -3)
        d:SetPoint("RIGHT", card, "RIGHT", -(width or 200) - 30, 0)
        d:SetWordWrap(true)
        d:SetText(desc or "")
        d:SetTextColor(C.label[1], C.label[2], C.label[3])
        if control then
            control:SetParent(card)
            control:ClearAllPoints()
            control:SetPoint("TOPRIGHT", card, "TOPRIGHT", -16, -cardY)
        end
        cardY = cardY + 44
    end

    startCard(L.CARD_PRICES)
    local srcItems = { { "auto", L.SRC_AUTO }, { "own", "CraftMaster" },
        { "am", "AuctionMaster" }, { "daylight", "Daylight" }, { "auctionator", "Auctionator" } }
    local src = W.Segments(card, srcItems, function() return ns.db.source end,
        function(v) ns.db.source = v; ns.Prices.Reset(); ns.Fire("PricesChanged") end)
    src.color = color
    row(L.SET_SOURCE, L.SET_SOURCE_DESC, src, src:GetWidth())
    refreshers[#refreshers + 1] = src.Refresh
    local cut = W.Input(card, { numeric = true, width = 50, onEnter = function(t)
        local v = tonumber(t)
        if v and v >= 0 and v <= 50 then ns.db.cut = v; ns.Fire("PricesChanged") end
    end })
    row(L.SET_CUT, L.SET_CUT_DESC, cut, 60)
    refreshers[#refreshers + 1] = function() if not cut:HasFocus() then cut:SetText(tostring(ns.db.cut)) end end
    local cutN = W.Input(card, { numeric = true, width = 50, onEnter = function(t)
        local v = tonumber(t)
        if v and v >= 0 and v <= 50 then ns.db.cutN = v; ns.Fire("PricesChanged") end
    end })
    row(L.SET_CUT_N, L.SET_CUT_N_DESC, cutN, 60)
    refreshers[#refreshers + 1] = function() if not cutN:HasFocus() then cutN:SetText(tostring(ns.db.cutN or 15)) end end
    local sources = W.Text(card, "small", "LEFT")
    sources:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -cardY - 2)
    sources:SetPoint("RIGHT", card, "RIGHT", -16, 0)
    sources:SetWordWrap(true)
    cardY = cardY + 22
    refreshers[#refreshers + 1] = function()
        local names = {}
        for _, s in ipairs(ns.Prices.Sources()) do names[#names + 1] = s.name end
        sources:SetText(L.SET_SOURCES .. " : " .. (#names > 0 and ("|cff73d982" .. table.concat(names, ", ") .. "|r") or ("|cffef5c42" .. L.SOURCES_NONE .. "|r")))
    end
    endCard()

    startCard(L.CARD_CART)
    local warn = W.Input(card, { numeric = true, width = 60, onEnter = function(t)
        local v = tonumber(t)
        if v and v >= 100 then ns.db.warn = v end
    end })
    row(L.SET_WARN, L.SET_WARN_DESC, warn, 70)
    refreshers[#refreshers + 1] = function() if not warn:HasFocus() then warn:SetText(tostring(ns.db.warn)) end end
    endCard()

    startCard(L.CARD_DATA)
    local autoSw = W.Switch(card, function() return ns.db.autoScan end, function(v) ns.db.autoScan = v end)
    row(L.DEAL_AUTO, L.DEAL_AUTO_TIP, autoSw, 40)
    refreshers[#refreshers + 1] = autoSw.Refresh
    local remindSw = W.Switch(card, function() return ns.db.scanReminder ~= false end, function(v) ns.db.scanReminder = v end)
    row(L.GM_REMINDER, L.GM_REMINDER_TIP, remindSw, 40)
    refreshers[#refreshers + 1] = remindSw.Refresh
    local toastSw = W.Switch(card, function() return ns.db.toast ~= false end, function(v) ns.db.toast = v end)
    row(L.SET_TOAST, L.SET_TOAST_DESC, toastSw, 40)
    refreshers[#refreshers + 1] = toastSw.Refresh
    local profSw = W.Switch(card, function() return ns.db.profitInWindow ~= false end, function(v) ns.db.profitInWindow = v; ns.ProfessionProfit.Refresh() end)
    row(L.SET_PROFIT_WINDOW, L.SET_PROFIT_WINDOW_DESC, profSw, 40)
    refreshers[#refreshers + 1] = profSw.Refresh
    local hist = W.Segments(card, { { 30, "30" }, { 60, "60" }, { 90, "90" }, { 180, "180" } },
        function() return ns.db.histDays end, function(v) ns.db.histDays = v end, 44)
    hist.color = color
    row(L.SET_HIST, L.SET_HIST_DESC, hist, hist:GetWidth())
    refreshers[#refreshers + 1] = hist.Refresh
    local read = W.Button(card, L.SCAN_SCHEM, 160, function() ns.Recipes.ReadAllSchematics(true) end)
    row(L.SCAN_SCHEM, L.SCAN_SCHEM_DESC, read, 160)
    local diag = W.Button(card, L.DIAG, 160, function() ns.Diag() end)
    row(L.DIAG, "/craftmaster diag", diag, 160)
    endCard()

    startCard(L.CARD_IMPORT)
    local rsText = W.Text(card, "body", "RIGHT")
    rsText:SetWidth(260)
    row(L.SET_RULESET, L.SET_RULESET_DESC, rsText, 260)
    refreshers[#refreshers + 1] = function()
        local rs, sure = ns.Ruleset()
        local label = ns.RulesetLabel(rs)
        rsText:SetText("|cffd9a441" .. (sure and label or string.format(L.RULESET_GUESS, label)) .. "|r")
    end
    local imp = W.Button(card, L.IMPORT_NOW, 160, function()
        ns.Import.Run(true)
        page.Refresh()
    end)
    row(L.IMPORT_NOW, L.IMPORT_DESC, imp, 160)
    cardY = cardY + 8
    local found = W.Text(card, "small", "LEFT")
    found:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -cardY - 2)
    found:SetPoint("RIGHT", card, "RIGHT", -16, 0)
    found:SetWordWrap(true)
    cardY = cardY + 34
    refreshers[#refreshers + 1] = function()
        local parts = {}
        for _, r in ipairs(ns.Import.Found()) do
            local st = ns.Import.stats[r.key]
            parts[#parts + 1] = st and string.format(L.IMPORT_STAT, r.name, st.items, st.days) or r.name
        end
        found:SetText(L.IMPORT_READ .. "\n" .. string.format(L.IMPORT_FOUND,
            #parts > 0 and ("|cff73d982" .. table.concat(parts, ", ") .. "|r") or ("|cffef5c42" .. L.IMPORT_NONE .. "|r")))
    end
    endCard()

    startCard(L.CARD_GUILD)
    local share = W.Switch(card, function() return ns.db.share ~= false end, function(v) ns.db.share = v; ns.Fire("SyncChanged") end)
    row(L.SET_SHARE, L.SET_SHARE_DESC, share, 40)
    refreshers[#refreshers + 1] = share.Refresh
    local syncInfo = W.Text(card, "small", "LEFT")
    syncInfo:SetPoint("TOPLEFT", card, "TOPLEFT", 16, -cardY - 2)
    syncInfo:SetPoint("RIGHT", card, "RIGHT", -16, 0)
    cardY = cardY + 22
    refreshers[#refreshers + 1] = function()
        local st = ns.Sync.Status()
        syncInfo:SetText(string.format(L.SYNC_STATUS, st.peers, st.sent, st.got, st.queued))
    end
    endCard()

    startCard(L.CARD_LOOK)
    local skin = W.Switch(card, function() return ns.db.skin ~= "own" end,
        function(v) ns.db.skin = v and "daylight" or "own" end)
    row(L.SET_SKIN, L.SET_SKIN_DESC, skin, 40)
    refreshers[#refreshers + 1] = skin.Refresh
    local reload = W.Button(card, L.RELOAD, 120, function() ReloadUI() end)
    row("", "", reload, 120)
    cardY = cardY - 14
    local tt = W.Switch(card, function() return ns.db.tooltip ~= false end, function(v) ns.db.tooltip = v end)
    row(L.SET_TOOLTIP, L.SET_TOOLTIP_DESC, tt, 40)
    refreshers[#refreshers + 1] = tt.Refresh
    local ahp = W.Switch(card, function() return ns.db.ahPanel ~= false end,
        function(v) ns.db.ahPanel = v; ns.AHPanel.Apply() end)
    row(L.SET_AHPANEL, L.SET_AHPANEL_DESC, ahp, 40)
    refreshers[#refreshers + 1] = ahp.Refresh
    local mm = W.Switch(card, function() return not ns.db.minimap.hide end,
        function(v) ns.db.minimap.hide = not v; ns.Minimap.Refresh() end)
    row(L.SET_MINIMAP, L.SET_MINIMAP_DESC, mm, 40)
    refreshers[#refreshers + 1] = mm.Refresh
    endCard()

    inner:SetHeight(y)
    function page.OnResize() inner:SetWidth(math.max(400, body:GetWidth() - 10)) end
    function page.Refresh()
        page.OnResize()
        for _, fn in ipairs(refreshers) do fn() end
    end
end)
