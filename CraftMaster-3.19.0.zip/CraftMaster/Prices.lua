local _, ns = ...
local L = ns.L

-- Where prices come from. CraftMaster scans nothing itself: it reads the
-- Auction House scans of the addons the player already uses, through their
-- public functions (AuctionMaster.API, DaylightUI.AuctionPrices,
-- Auctionator.API.v1), and the vendor prices they and CraftMaster saw at
-- merchants.
local P = {}
ns.Prices = P

local CALLER = "CraftMaster"
local FRESH = 12 * 3600

-- Prices a few vendors are known to ask, for reagents nobody has seen at a
-- merchant yet: a rough guide only, replaced as soon as a merchant is seen.
local VENDOR_GUESS = {
    [2320] = 10, [2321] = 100, [4291] = 500, [8343] = 2000, [14341] = 5000, [2324] = 25, [2325] = 1000,
    [2604] = 50, [2605] = 100, [6260] = 50, [4340] = 350, [4341] = 500, [4342] = 2500, [10290] = 2500,
    [3371] = 4, [3372] = 40, [8925] = 500, [18256] = 20000, [2880] = 100, [3466] = 2000,
    [4399] = 200, [4400] = 2000, [2678] = 10, [2692] = 40, [3713] = 160, [159] = 25, [30817] = 25,
    [2596] = 120, [4289] = 50, [6217] = 124, [4470] = 38, [2665] = 20, [3857] = 500,
    [17020] = 1000, [17194] = 10, [17196] = 50, [1179] = 125, [2894] = 50,
}

-- ---------------------------------------------------------------------
-- Auction House sources
-- ---------------------------------------------------------------------

local SOURCES = {
    {
        key = "own", name = "CraftMaster",
        label = function() return ns.Scan.Book("faction").from == "blizzard" and "Blizzard" or "CraftMaster" end,
        ok = function() return ns.Scan and ns.Scan.LastAt("faction") ~= nil end,
        get = function(id) return ns.Scan.Get(id, "faction") end,
    },
    {
        key = "am", name = "AuctionMaster",
        ok = function() return AuctionMaster and AuctionMaster.API and AuctionMaster.API.GetMarketPrice end,
        get = function(id)
            local api = AuctionMaster.API
            local low = api.GetLowestPrice(id)
            local age = api.GetDataAge and api.GetDataAge(id)
            local qty = api.GetAvailableQuantity and api.GetAvailableQuantity(id)
            local market = api.GetMarketPrice(id)
            if low and age and age < FRESH then return low, age, qty, market end
            if market then return market, age, qty, market end
            if low then return low, age, qty, market end
        end,
    },
    {
        key = "daylight", name = "Daylight UI",
        ok = function() return DaylightUI and DaylightUI.AuctionPrices and DaylightUI.AuctionPrices.Item end,
        get = function(id)
            local b = DaylightUI.AuctionPrices
            local price, at, qty
            if b.Offer then price, at, qty = b.Offer(id) else price, at = b.Item(id) end
            if not price then return nil end
            return price, at and (time() - at) or nil, qty, nil
        end,
    },
    {
        key = "auctionator", name = "Auctionator",
        ok = function() return Auctionator and Auctionator.API and Auctionator.API.v1 and Auctionator.API.v1.GetAuctionPriceByItemID end,
        get = function(id)
            local v1 = Auctionator.API.v1
            local ok, price = pcall(v1.GetAuctionPriceByItemID, CALLER, id)
            if not ok or not price then return nil end
            local age
            if v1.GetAuctionAgeByItemID then
                local ok2, days = pcall(v1.GetAuctionAgeByItemID, CALLER, id)
                if ok2 and type(days) == "number" then age = days * 86400 end
            end
            return price, age, nil, nil
        end,
    },
}

function P.Sources()
    local out = {}
    for _, s in ipairs(SOURCES) do
        local ok, yes = pcall(s.ok)
        if ok and yes then out[#out + 1] = s end
    end
    return out
end

local cache, cacheAt = { faction = {}, neutral = {} }, 0
function P.Reset() cache = { faction = {}, neutral = {} } end

-- Which source gave the prices on screen: counted on every look-up, read
-- (and started again) by the window on each refresh.
local usage = {}
function P.ResetUsage() usage = {} end
function P.MainSource()
    local best, n = nil, 0
    for name, c in pairs(usage) do if c > n then best, n = name, c end end
    return best
end

-- The Auction House price of one unit: price, age in seconds (or nil),
-- quantity for sale (or nil), the name of the source. Nil when unknown.
-- house: "faction" (default: the one picked in the window) or "neutral",
-- which only CraftMaster's own scan knows apart.
function P.AH(id, house)
    if not id then return nil end
    house = house or ns.House()
    if GetTime() - cacheAt > 5 then P.Reset(); cacheAt = GetTime() end
    local c = cache[house][id]
    if c == nil then
        local best
        if house == "neutral" then
            local price, age, qty = ns.Scan.Get(id, "neutral")
            if price then best = { price, age, qty, ns.Scan.Book("neutral").from == "blizzard" and "Blizzard" or "CraftMaster" } end
        else
            local want = ns.db.source
            -- A recent picture of exactly this house (Blizzard's, my own scan
            -- or a guild mate's) comes first: the other addons may mix the
            -- three houses (Daylight UI) or be older.
            local book = ns.Scan.Book(house)
            if want == "auto" and book.at and time() - book.at < 3 * 3600 then
                local price, age, qty = ns.Scan.Get(id, house)
                if price then best = { price, age, qty, book.from == "blizzard" and "Blizzard" or "CraftMaster", a = age or 0 } end
            end
            for _, s in ipairs(best and {} or P.Sources()) do
                if want == "auto" or want == s.key then
                    local ok, price, age, qty = pcall(s.get, id)
                    if ok and type(price) == "number" and price > 0 then
                        -- the freshest wins; a source that can't tell its age loses to one that can
                        local a = age or (365 * 86400)
                        if not best or a < best.a then best = { price, age, qty, s.label and s.label() or s.name, a = a } end
                    end
                end
            end
        end
        c = best or false
        cache[house][id] = c
    end
    if c == false then return nil end
    usage[c[4]] = (usage[c[4]] or 0) + 1
    return c[1], c[2], c[3], c[4]
end

-- When the newest scan was, of any source: for the "scanned 2 h ago" line.
function P.LastScan(house)
    if (house or ns.House()) == "neutral" then return ns.Scan.LastAt("neutral") end
    local at = ns.Scan and ns.Scan.LastAt("faction")
    if DaylightUI and DaylightUI.AuctionPrices and DaylightUI.AuctionPrices.ScannedAt then
        local ok, t = pcall(DaylightUI.AuctionPrices.ScannedAt)
        if ok and type(t) == "number" and (not at or t > at) then at = t end
    end
    if AuctionMasterDB and type(AuctionMasterDB.global) == "table" then
        local scan = AuctionMasterDB.global.scan
        local t = scan and scan.data and scan.data.lastScan
        if type(t) == "number" and (not at or t > at) then at = t end
    end
    return at
end

-- ---------------------------------------------------------------------
-- Vendors
-- ---------------------------------------------------------------------

-- What a merchant asks for one unit: copper, and whether it's only a guess.
function P.VendorBuy(id)
    if not id then return nil end
    local own = ns.db.vendorBuy[id]
    if own then return own end
    -- the table of unlimited-stock vendor prices (Data/Vendors.lua)
    local seed = ns.VENDOR_PRICE and ns.VENDOR_PRICE[id]
    if seed then return seed end
    if DaylightUI and DaylightUI.AuctionPrices and DaylightUI.AuctionPrices.Vendor then
        local ok, v = pcall(DaylightUI.AuctionPrices.Vendor, id)
        if ok and type(v) == "number" and v > 0 then return v end
    end
    if type(AUCTIONATOR_VENDOR_PRICE_CACHE) == "table" then
        local v = AUCTIONATOR_VENDOR_PRICE_CACHE[tostring(id)] or AUCTIONATOR_VENDOR_PRICE_CACHE[id]
        if type(v) == "number" and v > 0 then return v end
    end
    if type(AuctionMasterDB) == "table" and type(AuctionMasterDB.factions) == "table" then
        for _, f in pairs(AuctionMasterDB.factions) do
            local vp = type(f) == "table" and f.vendorPrices and f.vendorPrices.data
            local v = type(vp) == "table" and vp[id]
            if type(v) == "number" and v > 0 then return v end
        end
    end
    local g = VENDOR_GUESS[id]
    if g then return g, true end
    return nil
end

-- What a vendor pays for one.
function P.VendorSell(id)
    local i = ns.Item(id)
    return i and i.sell or 0
end

-- The cheapest way to get one unit: copper, "vendor" | "ah", age.
-- A merchant who sells it is the first source: its stock does not run out and
-- its price does not move; the Auction House is only the fallback (or, for a
-- vendor price that is just a guess, a rival when it is cheaper).
function P.Cheapest(id, house)
    local v, guess = P.VendorBuy(id)
    if v and not guess then return v, "vendor", nil, false end
    local a, age = P.AH(id, house)
    if v and (not a or v <= a) then return v, "vendor", nil, guess end
    if a then return a, "ah", age end
    return nil, nil
end

-- Who sells it, where: remembered at each visit for what the merchant sells
-- without limit (the reagents), so a craft can say where to buy.
-- ns.db.vendorWho[itemID] = { name, zone, x, y }
function P.NoteVendor(id)
    local name = UnitName and UnitName("npc")
    if not name then return end
    ns.db.vendorWho = ns.db.vendorWho or {}
    local x, y
    if C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition then
        local m = C_Map.GetBestMapForUnit("player")
        local pos = m and C_Map.GetPlayerMapPosition(m, "player")
        if pos and pos.GetXY then x, y = pos:GetXY() end
    end
    ns.db.vendorWho[id] = { name, GetRealZoneText and GetRealZoneText() or "", x and math.floor(x * 1000) / 10 or 0, y and math.floor(y * 1000) / 10 or 0 }
end

-- The merchant that sells an item: name, zone, x, y (nil if never seen).
function P.VendorWho(id)
    local w = ns.db.vendorWho and ns.db.vendorWho[id]
    if w then return w[1], w[2], w[3], w[4] end
end

-- The merchants that sell an item (Data/Vendors.lua), the nearest to the
-- player's faction first: { { id, name, zone, x, y, pin }, ... }
function P.VendorsOf(id)
    local ids = ns.VENDOR_OF and ns.VENDOR_OF[id]
    local out = {}
    if not ids then return out end
    local f = UnitFactionGroup and UnitFactionGroup("player")
    local mine = f == "Horde" and "H" or f == "Alliance" and "A" or nil
    for _, nid in ipairs(ids) do
        local v = ns.VENDORS and ns.VENDORS[nid]
        if v and (not mine or v.f == "N" or v.f == mine) then
            out[#out + 1] = { id = nid, name = v.n, zone = v.z, x = v.x, y = v.y,
                              pin = { zone = v.z, x = v.x, y = v.y, name = v.n } }
        end
    end
    -- nothing in my table: Questie (adapted to Forever) knows who sells it and where
    if #out == 0 and ns.Map and ns.Map.Vendors then
        local ok, spots = pcall(ns.Map.Vendors, id)
        if ok and type(spots) == "table" then
            for _, sp in ipairs(spots) do
                out[#out + 1] = { name = sp.name, zone = sp.zoneName, x = sp.x, y = sp.y, pin = sp }
            end
        end
    end
    return out
end

-- Merchants: what they sell and for how much, noted on every visit.
ns.Register("MERCHANT_SHOW", function()
    if not GetMerchantNumItems then return end
    local same, diff = 0, 0
    for i = 1, GetMerchantNumItems() do
        local link = GetMerchantItemLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local price, stack, avail, extended = ns.MerchantInfo(i)
        -- a limited stock (the game gives what is left, -1 when it never runs out): noted
        if id and type(avail) == "number" then
            ns.db.vendorLimited = ns.db.vendorLimited or {}
            ns.db.vendorLimited[id] = avail >= 0 or nil
        end
        if id and type(price) == "number" and price > 0 and not extended and (avail == -1 or avail == nil or avail > 0) then
            local unit = price / math.max(1, stack or 1)
            local seed = ns.VENDOR_PRICE and ns.VENDOR_PRICE[id]
            if seed then
                if math.abs(seed - unit) < 0.5 then same = same + 1 else diff = diff + 1 end
            end
            ns.db.vendorBuy[id] = unit
            if avail == -1 or avail == nil then P.NoteVendor(id) end
        end
    end
    -- how far the Classic-based table is from what this merchant really asks on Forever
    if diff > 0 then ns.Print(L.VENDOR_DIFF, diff, same + diff) end
    ns.Fire("MerchantChanged", true)
end)
ns.Register("MERCHANT_CLOSED", function() ns.Fire("MerchantChanged", false) end)

-- A scan finished somewhere: drop what we remembered and say so.
ns.On("Login", function()
    if AuctionMaster and AuctionMaster.API and AuctionMaster.API.AddDataChangeListener then
        AuctionMaster.API.AddDataChangeListener(function()
            P.Reset()
            ns.Fire("PricesChanged")
        end)
    end
end)
ns.Register("AUCTION_HOUSE_CLOSED", function()
    P.Reset()
    ns.Fire("PricesChanged")
end)
