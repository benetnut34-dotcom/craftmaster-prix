local _, ns = ...
local L = ns.L

-- The addon's own version, against the latest published one. The companion
-- (Windows, CraftMaster_Data\Companion) downloads and installs new versions by
-- itself; an addon cannot download or write files, so this file only reads what the
-- companion wrote in the header of Data.lua (ver = installed on disk, latest =
-- the latest published, upd = ok | available | installed | error) and asks it, from
-- the Data page, to update right now.
local U = {}
ns.Update = U

local function parts(v)
    local out = {}
    for n in tostring(v or ""):gmatch("%d+") do out[#out + 1] = tonumber(n) end
    return out
end

-- 1 if a is newer than b, -1 if older, 0 if equal (or unreadable)
function U.Compare(a, b)
    local pa, pb = parts(a), parts(b)
    if #pa == 0 or #pb == 0 then return 0 end
    for i = 1, math.max(#pa, #pb) do
        local x, y = pa[i] or 0, pb[i] or 0
        if x ~= y then return x > y and 1 or -1 end
    end
    return 0
end

-- state: "unknown" (the companion does not say), "current", "available" (a newer
-- version exists), "asked" (I asked the companion: wait, then reload), "ready"
-- (the newer version is on disk: reload), "error".
-- Then: the loaded version, the latest one, the one on disk.
function U.State()
    local loaded = ns.version
    local d = CraftMasterData
    if type(d) ~= "table" or type(d.latest) ~= "string" or d.latest == "" then return "unknown", loaded end
    local latest, disk = d.latest, (type(d.ver) == "string" and d.ver ~= "") and d.ver or nil
    if d.upd == "error" and U.Compare(latest, loaded) > 0 then return "error", loaded, latest, disk end
    if U.Compare(latest, loaded) <= 0 then return "current", loaded, latest, disk end
    if disk and U.Compare(disk, latest) >= 0 then return "ready", loaded, latest, disk end
    local ask = ns.db and ns.db.updateAsk
    if ask and ask > 0 and (not d.synced or ask >= d.synced - 3600) and time() - ask < 6 * 3600 then
        return "asked", loaded, latest, disk
    end
    return "available", loaded, latest, disk
end

-- Short text and button for the menu: what to say about the version, and what the main button does
-- ("update", "reload" or nil), whatever the state.
function U.Menu()
    local st, loaded, latest = U.State()
    -- a forced update asked a moment ago: wait for the companion, then reload
    local ask = ns.db and ns.db.updateAsk
    if st ~= "asked" and st ~= "ready" and ask and ns.db.updateForce == ask and time() - ask < 600 then st = "asked" end
    local text = ({
        current = L.UPD_MENU_CURRENT, unknown = L.UPD_MENU_UNKNOWN, available = L.UPD_MENU_AVAILABLE,
        asked = L.UPD_MENU_ASKED, ready = L.UPD_MENU_READY, error = L.UPD_MENU_ERROR,
    })[st]
    local action = (st == "available" or st == "error") and "update" or (st == "asked" or st == "ready") and "reload" or nil
    return st, string.format(text, loaded or "?", latest or "?"), action
end

-- Ask the companion to install the update. The request travels in the saved
-- variables (written when the interface reloads), which the companion's icon
-- watches: so the interface reloads once now, then again when it says it is done.
function U.Ask()
    ns.db.updateAsk = time()
    ns.Print(L.UPD_ASKED)
    if ReloadUI then ReloadUI() end
end

-- The same, even when the addon is already the latest: the companion installs it again. The interface
-- reloads once now to hand the request over (the saved variables are written then).
function U.Force()
    ns.db.updateAsk = time()
    ns.db.updateForce = ns.db.updateAsk
    ns.Print(L.UPD_FORCED)
    if ReloadUI then ReloadUI() end
end

function U.Reload()
    if ReloadUI then ReloadUI() end
end
