local _, ns = ...
local L = ns.L
local W = ns.W

-- Guide: a leveling route for a profession, worked out from the Auction
-- House prices of now, three ways (most profitable, fastest, cheapest).
-- Each step can go in the cart; the route to the trainer and the vendors
-- goes on the map.

local DETAIL_W = 320
local ROW_H = 30

ns.UI.AddPage("guide", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local plan, selected
    local dirty = true

    local function myProf()
        local p = ns.char.guideProf
        if not p or not ns.profs[p] then p = ns.MyProfs()[1] end
        return p
    end

    -- ---------------------------------------------------------- toolbar
    local bar1 = CreateFrame("Frame", nil, body)
    bar1:SetHeight(24)
    bar1:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    bar1:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local profButtons = {}
    local function buildProfButtons()
        for _, b in ipairs(profButtons) do b:Hide() end
        local x = 0
        for i, k in ipairs(ns.MyProfs()) do
            local b = profButtons[i]
            if not b then
                b = W.Button(bar1, "", 120)
                b.icon = b:CreateTexture(nil, "OVERLAY")
                b.icon:SetSize(16, 16)
                b.icon:SetPoint("LEFT", b, "LEFT", 6, 0)
                b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                profButtons[i] = b
            end
            local p = ns.profs[k]
            -- the icon says which profession; the rank beside it; the name in the tooltip
            b.SetLabel(string.format("|cff999999%d|r", p.rank))
            b.text:ClearAllPoints()
            b.text:SetPoint("LEFT", b.icon, "RIGHT", 5, 0)
            b.icon:SetTexture(ns.PROF_ICONS[k])
            b.prof = k
            if not b.tipped then
                b.tipped = true
                W.Tip(b, function() return L.PROF[b.prof] end, function()
                    local pp = ns.profs[b.prof]
                    return pp and string.format(L.PROF_RANK_TIP, pp.rank) or nil
                end)
            end
            b:SetWidth(math.max(50, b.text:GetStringWidth() + 34))
            b:ClearAllPoints()
            b:SetPoint("LEFT", bar1, "LEFT", x, 0)
            b:SetScript("OnClick", function()
                ns.char.guideProf = k; ns.char.guideFrom = nil; selected = nil; dirty = true; page.Refresh()
            end)
            b.SetTint(k == myProf() and color or nil)
            b:Show()
            x = x + b:GetWidth() + 4
        end
    end

    local bar2 = CreateFrame("Frame", nil, body)
    bar2:SetHeight(24)
    bar2:SetPoint("TOPLEFT", bar1, "BOTTOMLEFT", 0, -8)
    bar2:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    local way = W.Segments(bar2, { { "profit", L.WAY_PROFIT }, { "fast", L.WAY_FAST }, { "cheap", L.WAY_CHEAP } },
        function() return ns.char.guideWay or "profit" end,
        function(v) ns.char.guideWay = v; selected = nil; dirty = true; page.Refresh() end)
    way.color = color
    way:SetPoint("LEFT", bar2, "LEFT", 0, 0)
    local tips = { profit = L.WAY_PROFIT_TIP, fast = L.WAY_FAST_TIP, cheap = L.WAY_CHEAP_TIP }
    for _, b in ipairs(way.buttons) do W.Tip(b, function() return b.text:GetText() end, tips[b.key]) end

    local fromLabel = W.Text(bar2, "small", "LEFT")
    fromLabel:SetPoint("LEFT", way, "RIGHT", 18, 0)
    fromLabel:SetText(L.GUIDE_FROM)
    fromLabel:SetTextColor(C.label[1], C.label[2], C.label[3])
    local fromBox = W.Input(bar2, { numeric = true, width = 46, onEnter = function(t)
        local v = tonumber(t)
        if v and v >= 1 and v < 300 then ns.char.guideFrom = v; selected = nil; dirty = true; page.Refresh() end
    end })
    fromBox:SetPoint("LEFT", fromLabel, "RIGHT", 6, 0)
    local toLabel = W.Text(bar2, "small", "LEFT")
    toLabel:SetPoint("LEFT", fromBox, "RIGHT", 10, 0)
    toLabel:SetText(L.GUIDE_TO)
    toLabel:SetTextColor(C.label[1], C.label[2], C.label[3])
    local toBox = W.Input(bar2, { numeric = true, width = 46, onEnter = function(t)
        local v = tonumber(t)
        if v and v > 1 and v <= 300 then ns.char.guideTo = v; selected = nil; dirty = true; page.Refresh() end
    end })
    toBox:SetPoint("LEFT", toLabel, "RIGHT", 6, 0)

    local addAll = W.Button(bar2, L.GUIDE_ADD_ALL, 170, function()
        if not plan then return end
        for _, st in ipairs(plan.steps) do
            if st.id and st.crafts > 0 then ns.Cart.Add(st.id, st.crafts) end
        end
        ns.UI.Open("cart")
    end)
    addAll:SetPoint("RIGHT", bar2, "RIGHT", 0, 0)
    addAll.SetTint(ns.Theme.SECTIONS.cart)
    local routeBtn = W.Button(bar2, L.GUIDE_ROUTE, 150, function()
        if not plan then return end
        local stops = ns.Leveling.Route(plan)
        if #stops == 0 then ns.Print(L.MAP_NOTHING) else ns.Map.Route(stops) end
    end)
    routeBtn:SetPoint("RIGHT", addAll, "LEFT", -6, 0)
    routeBtn.SetTint({ 1, 0.45, 0.6 })
    W.Tip(routeBtn, L.GUIDE_ROUTE, L.GUIDE_ROUTE_TIP)

    -- ---------------------------------------------------------- summary
    local sum = W.Card(body)
    sum:SetPoint("TOPLEFT", bar2, "BOTTOMLEFT", 0, -10)
    sum:SetPoint("RIGHT", body, "RIGHT", -DETAIL_W - 12, 0)
    sum:SetHeight(50)
    local sumBoxes = {}
    for i, k in ipairs({ "GUIDE_CRAFTS", "GUIDE_SPENT", "GUIDE_BACK", "GUIDE_NET" }) do
        local l = W.Text(sum, "tiny", "LEFT")
        l:SetPoint("TOPLEFT", sum, "TOPLEFT", 14 + (i - 1) * 150, -9)
        l:SetText(L[k])
        l:SetTextColor(C.label[1], C.label[2], C.label[3])
        local v = W.Text(sum, "head", "LEFT")
        v:SetPoint("TOPLEFT", l, "BOTTOMLEFT", 0, -3)
        sumBoxes[i] = v
    end

    -- what the prices rest on: age of the scan, recipes left out, prices replaced
    local sumCheck = W.Text(sum, "tiny", "RIGHT")
    sumCheck:SetPoint("TOPRIGHT", sum, "TOPRIGHT", -14, -10)
    sumCheck:SetPoint("LEFT", sum, "LEFT", 14 + 4 * 150, 0)
    sumCheck:SetWordWrap(true)
    sumCheck:SetJustifyV("TOP")

    -- ---------------------------------------------------------- steps
    local listCard = W.Card(body)
    listCard:SetPoint("TOPLEFT", sum, "BOTTOMLEFT", 0, -10)
    listCard:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -DETAIL_W - 12, 0)

    local function makeRow(parent)
        local r = CreateFrame("Button", nil, parent)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(color[1], color[2], color[3], 0.16)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.05)
        r.range = W.Text(r, "body", "CENTER")
        r.range:SetWidth(70)
        r.range:SetPoint("LEFT", r, "LEFT", 0, 0)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(22, 22)
        r.icon:SetPoint("LEFT", r.range, "RIGHT", 4, 0)
        r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        r.add = W.Button(r, "+", 22, function(self)
            local d = self:GetParent().data
            if d and d.id then ns.Cart.Add(d.id, d.crafts) end
        end)
        r.add:SetHeight(20)
        r.add:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        r.pin = W.Button(r, "", 26)
        r.pin:SetSize(26, 20)
        r.pin.text:Hide()
        local g = r.pin:CreateTexture(nil, "OVERLAY")
        g:SetSize(12, 12); g:SetPoint("CENTER"); g:SetTexture(ns.MEDIA .. "pin.png"); g:SetVertexColor(1, 0.45, 0.6)
        r.pin:SetPoint("RIGHT", r, "RIGHT", -2, 0)
        r.cost = W.Text(r, "small", "RIGHT")
        r.cost:SetWidth(84)
        r.cost:SetPoint("RIGHT", r.add, "LEFT", -8, 0)
        r.count = W.Text(r, "body", "RIGHT")
        r.count:SetWidth(46)
        r.count:SetPoint("RIGHT", r.cost, "LEFT", -6, 0)
        r.name = W.Text(r, "body", "LEFT")
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 2)
        r.name:SetPoint("RIGHT", r.count, "LEFT", -6, 0)
        r.name:SetWordWrap(false)
        r.sub = W.Text(r, "tiny", "LEFT")
        r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -1)
        r.sub:SetPoint("RIGHT", r.count, "LEFT", -6, 0)
        r.sub:SetWordWrap(false)
        r:SetScript("OnClick", function(self)
            selected = self.index
            page.RefreshDetail()
            page.list.Update()
        end)
        return r
    end
    local function fillRow(r, d, index)
        r.data, r.index = d, index
        r.sel:SetShown(selected == index)
        if d.rank then
            r.range:SetText(tostring(d.rank))
            r.range:SetTextColor(color[1], color[2], color[3])
            r.icon:SetTexture(ns.PROF_ICONS[plan.prof])
            r.name:SetText(string.format(L.GUIDE_RANK, d.rank))
            r.name:SetTextColor(color[1], color[2], color[3])
            r.sub:SetText(L.GUIDE_RANK_SUB)
            r.count:SetText(""); r.cost:SetText("")
            r.add:Hide(); r.pin:Show()
            r.pin:SetScript("OnClick", function() ns.Map.GoNearest(ns.Map.Trainers(plan.prof)) end)
            return
        end
        r.add:Show(); r.pin:Hide()
        local c = W.SKILL_COLORS[d.color] or W.SKILL_COLORS[2]
        r.range:SetText(d.from .. " - " .. d.to)
        r.range:SetTextColor(c[1], c[2], c[3])
        r.icon:SetTexture(ns.Recipes.Icon(d.id))
        r.name:SetText(ns.Recipes.Name(d.id))
        local out = ns.Recipes.Output(d.id)
        local q = out and ns.Item(out) and ns.Item(out).quality or 1
        r.name:SetTextColor(ns.QualityColor(q))
        local sub = {}
        if d.how == "T" then sub[#sub + 1] = "|cffd9a441" .. L.GUIDE_LEARN_T .. "|r"
        elseif d.how == "V" then sub[#sub + 1] = "|cffef9e3d" .. L.GUIDE_LEARN_V .. "|r"
        elseif d.how == "AH" then sub[#sub + 1] = "|cff61a8f5" .. string.format(L.GUIDE_LEARN_AH, ns.Money(d.learnCost, true)) .. "|r" end
        local mats = ns.Recipes.Materials(d.id)
        if mats then
            local parts = {}
            for i, m in ipairs(mats) do
                if i > 3 then parts[#parts + 1] = "…" break end
                parts[#parts + 1] = (m[2] * d.crafts) .. " " .. ns.ItemName(m[1])
            end
            sub[#sub + 1] = table.concat(parts, ", ")
        end
        if d.low then sub[#sub + 1] = "|cffef5c42" .. L.GUIDE_LOW_SUB .. "|r" end
        r.sub:SetText(table.concat(sub, "  ·  "))
        r.count:SetText("x" .. d.crafts)
        r.cost:SetText(ns.Money(d.cost, true))
    end
    local list = W.List(listCard, ROW_H, makeRow, fillRow)
    list:SetPoint("TOPLEFT", listCard, "TOPLEFT", 8, -8)
    list:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -6, 8)
    list.Color(color)
    page.list = list
    local empty = W.Text(listCard, "body", "CENTER")
    empty:SetPoint("TOPLEFT", list, "TOPLEFT", 20, -40)
    empty:SetPoint("TOPRIGHT", list, "TOPRIGHT", -20, -40)
    empty:SetWordWrap(true)
    empty:SetTextColor(C.label[1], C.label[2], C.label[3])

    -- ---------------------------------------------------------- detail
    local det = W.Card(body)
    det:SetPoint("TOPRIGHT", bar2, "BOTTOMRIGHT", 0, -10)
    det:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    det:SetWidth(DETAIL_W)
    local dIcon = W.ItemIcon(det, 36)
    dIcon:SetPoint("TOPLEFT", det, "TOPLEFT", 14, -14)
    local dName = W.Text(det, "head", "LEFT")
    dName:SetPoint("TOPLEFT", dIcon, "TOPRIGHT", 10, -2)
    dName:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    local dSub = W.Text(det, "small", "LEFT")
    dSub:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -3)
    dSub:SetPoint("RIGHT", det, "RIGHT", -14, 0)
    dSub:SetWordWrap(true)
    local scroll = CreateFrame("ScrollFrame", nil, det)
    scroll:SetPoint("TOPLEFT", dIcon, "BOTTOMLEFT", 0, -12)
    scroll:SetPoint("BOTTOMRIGHT", det, "BOTTOMRIGHT", -12, 46)
    local flow = W.Flow(scroll)
    flow:SetWidth(DETAIL_W - 28)
    scroll:SetScrollChild(flow)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, d)
        local max = math.max(0, flow:GetHeight() - self:GetHeight())
        self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - d * 30)))
    end)
    local addStep = W.Button(det, L.ADD_CART, 150, function()
        local st = plan and selected and plan.steps[selected]
        if st and st.id then ns.Cart.Add(st.id, st.crafts) end
    end)
    addStep:SetPoint("BOTTOMLEFT", det, "BOTTOMLEFT", 14, 12)
    addStep.SetTint(ns.Theme.SECTIONS.cart)
    local trainerBtn = W.Button(det, L.MAP_TRAINER, 130, function()
        if plan then ns.Map.GoNearest(ns.Map.Trainers(plan.prof)) end
    end)
    trainerBtn:SetPoint("LEFT", addStep, "RIGHT", 6, 0)
    trainerBtn.SetTint({ 1, 0.45, 0.6 })

    function page.RefreshDetail()
        flow.Clear()
        scroll:SetVerticalScroll(0)
        local st = plan and selected and plan.steps[selected]
        if not st or not st.id then
            dIcon:Hide()
            dName:SetText(plan and L.GUIDE_PICK or "")
            dName:SetTextColor(C.label[1], C.label[2], C.label[3])
            dSub:SetText(plan and plan.gap and string.format(L.GUIDE_GAP, plan.gap) or "")
            addStep:Hide()
            if plan then
                flow.Head(L.GUIDE_HOW, color)
                flow.Line(({ profit = L.WAY_PROFIT_TIP, fast = L.WAY_FAST_TIP, cheap = L.WAY_CHEAP_TIP })[plan.way], { color = C.label })
                flow.Money(L.GUIDE_PEAK, plan.peak or 0)
                flow.Line(L.GUIDE_NOTE, { color = C.muted })
            end
            return
        end
        addStep:Show(); dIcon:Show()
        local out = ns.Recipes.Output(st.id)
        dIcon.Set(out, ns.Recipes.Icon(st.id))
        dName:SetText(ns.Recipes.Name(st.id))
        local q = out and ns.Item(out) and ns.Item(out).quality or 1
        dName:SetTextColor(ns.QualityColor(q))
        local c = W.SKILL_COLORS[st.color]
        dSub:SetText(string.format(L.GUIDE_STEP, st.from, st.to, st.crafts))
        dSub:SetTextColor(c[1], c[2], c[3])
        local sk = st.sk
        flow.Line(string.format("|cffff8040%d|r  |cffffff00%d|r  |cff40c040%d|r  |cff808080%d|r", sk[2], sk[3], sk[4], sk[5]), { color = C.label })
        local p1, p2 = ns.Leveling.Chance(sk, st.from), ns.Leveling.Chance(sk, st.to - 1)
        flow.Line(string.format(L.GUIDE_CHANCE, math.floor(p1 * 100 + 0.5), st.from, math.floor(p2 * 100 + 0.5), st.to - 1),
            { color = (st.low or p2 < ns.Leveling.MIN_CHANCE and plan.way == "fast") and C.loss or C.label })
        if st.how then
            flow.Head(L.HOW_TO_GET, color)
            for i, s in ipairs(ns.Recipes.Sources(st.id)) do
                if i > 5 then break end
                local pins = s.pins
                flow.Line("|cffd9a441" .. s[1] .. "|r  " .. s[2], {
                    pin = (pins and #pins > 0) and function() ns.Map.GoNearest(pins) end or nil,
                })
            end
        end
        flow.Head(L.REAGENTS .. string.format("  |cff999999x%d|r", st.crafts), color)
        local mats = ns.Recipes.Materials(st.id) or {}
        for _, m in ipairs(mats) do
            local mid = m[1]
            local unit, from = ns.Prices.Cheapest(mid)
            local tag = from == "vendor" and ("|cffef9e3d" .. L.FROM_VENDOR .. "|r") or ("|cff61a8f5" .. L.FROM_AH .. "|r")
            local need = m[2] * st.crafts
            flow.Line(string.format("%d× %s  %s", need, ns.ItemName(mid), tag), {
                icon = ns.Item(mid) and ns.Item(mid).icon or 134400,
                right = unit and ns.Money(unit * need, true) or "-",
                pin = ns.Map.HasSpots() and function()
                    local spots = ns.Map.Spots(mid)
                    if #spots == 0 then spots = ns.Map.Vendors(mid) end
                    if #spots == 0 then ns.Print(L.MAP_NO_SPOT, ns.ItemName(mid)) else ns.Map.GoNearest(spots) end
                end or nil,
                pinTip = L.MAP_SPOT,
            })
        end
        flow.Gap(4)
        flow.Money(L.GUIDE_SPENT, st.cost + (st.learnCost or 0))
        flow.Money(L.GUIDE_BACK, st.sold)
        flow.Money(L.GUIDE_NET, st.sold - st.cost - (st.learnCost or 0), true)
    end

    function page.Refresh()
        buildProfButtons()
        way.Refresh()
        local prof = myProf()
        if not prof then
            plan = nil
            list.SetData({})
            empty:SetShown(true)
            empty:SetText(L.NO_PROFESSION)
            for _, v in ipairs(sumBoxes) do v:SetText("-") end
            page.RefreshDetail()
            return
        end
        local rank = ns.profs[prof].rank
        local from = ns.char.guideFrom or math.max(1, rank)
        local to = ns.char.guideTo or 300
        if to <= from then to = math.min(300, from + 25) end
        if not fromBox:HasFocus() then fromBox:SetText(tostring(from)) end
        if not toBox:HasFocus() then toBox:SetText(tostring(to)) end
        local key = prof .. from .. to .. (ns.char.guideWay or "profit") .. ns.House()
        if dirty or not plan or plan.key ~= key then
            plan = ns.Leveling.Plan(prof, from, to, ns.char.guideWay or "profit")
            plan.key = key
            dirty = false
        end
        list.SetData(plan.steps, true)
        local any = false
        for _, st in ipairs(plan.steps) do if st.id then any = true break end end
        empty:SetShown(not any)
        empty:SetText(L.GUIDE_EMPTY)
        sumBoxes[1]:SetText(tostring(plan.crafts))
        sumBoxes[2]:SetText(ns.Money(plan.cost, true))
        sumBoxes[3]:SetText(ns.Money(plan.back, true))
        W.ProfitText(sumBoxes[4], plan.back - plan.cost)
        local ck = plan.check or {}
        local parts, bad = {}, false
        if not ck.age then
            parts[1] = L.GUIDE_CHECK_NONE; bad = true
        elseif ck.stale then
            parts[1] = string.format(L.GUIDE_CHECK_OLD, ns.Duration(ck.age)); bad = true
        else
            parts[1] = string.format(L.GUIDE_CHECK, ns.Duration(ck.age))
        end
        if (ck.skipped or 0) > 0 then parts[#parts + 1] = string.format(L.GUIDE_CHECK_SKIPPED, ck.skipped) end
        if (ck.spikes or 0) + (ck.usual or 0) > 0 then parts[#parts + 1] = string.format(L.GUIDE_CHECK_FIXED, (ck.spikes or 0) + (ck.usual or 0)) end
        local cc = bad and C.loss or C.label
        sumCheck:SetTextColor(cc[1], cc[2], cc[3])
        sumCheck:SetText(table.concat(parts, "\n"))
        page.RefreshDetail()
    end

    -- New prices or recipes: the plan is worked out again next time.
    for _, e in ipairs({ "PricesChanged", "RecipesChanged", "ProfessionsChanged", "HouseChanged" }) do
        ns.On(e, function() dirty = true end)
    end
end)
