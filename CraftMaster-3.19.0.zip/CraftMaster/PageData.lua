local _, ns = ...
local L = ns.L
local W = ns.W

-- Data page: do we have the price history, how fresh it is, and where it
-- comes from. Four things are shown:
--   1. the Blizzard file (CraftMasterData, written by the companion from the
--      craftmaster-prix GitHub repository): when it was generated, when this
--      PC copied it, the three houses, how much history, how much memory;
--   2. the coverage: how many API pictures were received each day (gaps);
--   3. where the current prices of each house come from (Blizzard, my scan,
--      a guildmate) and what my own history holds;
--   4. guild sharing (last sync, players seen, messages).

local MUTED = "|cff8c8c99"
local GREEN = "|cff59d973"
local AMBER = "|cffffa733"
local RED = "|cffff6060"
local DAY = 86400
local SIDES = { "Alliance", "Horde", "Neutral" }

local function ago(t)
    local G = ns.Gold
    if G and G.Ago then return G.Ago(t) end
    return t and date("%d/%m %H:%M", t) or L.GM_NEVER
end

local function dayText(d) return date("%d/%m", d * DAY) end

-- ---------------------------------------------------------------- analysis
-- Read once per loaded file: the file does not change until the next /reload.
local cache

local function analyse()
    local d = CraftMasterData
    if type(d) ~= "table" or type(d.houses) ~= "table" then return nil end
    if cache and cache.src == d then return cache end
    local s = { src = d, at = d.at, synced = d.synced, got = d.got, keep = tonumber(d.keep) or 14,
                origin = d.src, gen = d.gen, ruleset = d.ruleset or "PvP", houses = {},
                kb = { items = 0, lows = 0, sales = 0 }, anyCov = false, maxItems = 0 }
    for _, side in ipairs(SIDES) do
        local key = s.ruleset .. "-" .. side
        local h = d.houses[key]
        if type(h) == "table" then
            local e = { key = key, side = side, id = h.id, at = h.at, items = 0, perDay = {}, cov = {}, nDays = 0, salesItems = 0 }
            if type(h.items) == "string" then
                for _ in h.items:gmatch("%d+:%d+:%d+") do e.items = e.items + 1 end
                s.kb.items = s.kb.items + #h.items
            end
            if type(h.lows) == "string" then
                s.kb.lows = s.kb.lows + #h.lows
                for _, list in h.lows:gmatch("(%d+)=([^;]+)") do
                    for dd in list:gmatch("(%d+):%d+") do
                        dd = tonumber(dd)
                        e.perDay[dd] = (e.perDay[dd] or 0) + 1
                    end
                end
            end
            for dd in pairs(e.perDay) do
                e.nDays = e.nDays + 1
                if not e.first or dd < e.first then e.first = dd end
                if not e.last or dd > e.last then e.last = dd end
            end
            if type(h.cov) == "string" then
                for dd, n in h.cov:gmatch("(%d+):(%d+)") do e.cov[tonumber(dd)] = tonumber(n); s.anyCov = true end
            end
            if type(h.sales) == "string" then
                s.kb.sales = s.kb.sales + #h.sales
                local _, n = h.sales:gsub(";", ";")
                e.salesItems = n
            end
            if e.items > s.maxItems then s.maxItems = e.items end
            s.houses[#s.houses + 1] = e
        end
    end
    cache = s
    return s
end

-- What my own history holds (the days kept in this character's data).
local function myHistory()
    local key = ns.HouseKey("faction")
    local store = ns.db.histBy and ns.db.histBy[key]
    if not store then return nil end
    local items, first, last, days = 0, nil, nil, {}
    for _, list in pairs(store) do
        items = items + 1
        for i = 1, #list - 1, 2 do
            local dd = list[i]
            days[dd] = true
            if not first or dd < first then first = dd end
            if not last or dd > last then last = dd end
        end
    end
    local n = 0
    for _ in pairs(days) do n = n + 1 end
    return { key = key, items = items, first = first, last = last, days = n }
end

local function origin(b)
    if b.from == "blizzard" then return L.DATA_PROV_BLIZZ end
    if b.fromGuild then return string.format(L.DATA_PROV_GUILD, b.fromWho or "?") end
    return L.DATA_PROV_ME
end

local function verdict(s)
    if not s then return RED, L.DATA_NONE end
    local now, worst = time(), 0
    for _, e in ipairs(s.houses) do
        if e.at then worst = math.max(worst, now - e.at) end
    end
    if #s.houses == 0 then return RED, L.DATA_NONE end
    if worst > 12 * 3600 then return RED, L.DATA_V_OLD end
    if worst > 3 * 3600 then return AMBER, L.DATA_V_LATE end
    return GREEN, L.DATA_V_OK
end

-- State of the companion's scheduled task, from the header of Data.lua:
-- "none" (no file), "unknown" (old companion, no version), "old" (task older
-- than ns.COMPANION_TASK: Installer.cmd must be run again), "ok".
local function companionState()
    local d = CraftMasterData
    if type(d) ~= "table" or type(d.houses) ~= "table" then return "none" end
    local task = tonumber(d.task)
    if not task then return "unknown" end
    if task < (ns.COMPANION_TASK or 0) then return "old", task end
    return "ok", task
end

-- Shared with the Home page.
ns.DataInfo = { Analyse = analyse, Verdict = verdict, MyHistory = myHistory, CompanionState = companionState }

-- ---------------------------------------------------------------- page
ns.UI.AddPage("data", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C

    -- --------------------------------------------------------- verdict banner
    local banner = W.Card(body)
    banner:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    banner:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    banner:SetHeight(54)
    local verdictText = W.Text(banner, "body", "LEFT")
    verdictText:SetPoint("LEFT", banner, "LEFT", 14, 0)
    verdictText:SetPoint("RIGHT", banner, "RIGHT", -230, 0)
    verdictText:SetWordWrap(true)
    local reload = W.Button(banner, L.DATA_RELOAD, 200, function() ReloadUI() end)
    reload:SetPoint("RIGHT", banner, "RIGHT", -14, 0)
    reload.SetTint(color)
    W.Tip(reload, L.DATA_RELOAD, L.DATA_RELOAD_TIP)

    -- --------------------------------------------------------- the addon's own version
    local ucard = W.Card(body)
    ucard:SetPoint("TOPLEFT", banner, "BOTTOMLEFT", 0, -10)
    ucard:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    ucard:SetHeight(46)
    local uText = W.Text(ucard, "body", "LEFT")
    uText:SetPoint("LEFT", ucard, "LEFT", 14, 0)
    uText:SetPoint("RIGHT", ucard, "RIGHT", -180, 0)
    uText:SetWordWrap(true)
    local uBtn = W.Button(ucard, L.UPD_BUTTON, 150, function() ns.Update.Ask() end)
    uBtn:SetPoint("RIGHT", ucard, "RIGHT", -14, 0)
    uBtn.SetTint(color)
    W.Tip(uBtn, L.UPD_BUTTON, L.UPD_BUTTON_TIP)
    local uReload = W.Button(ucard, L.UPD_RELOAD, 150, function() ns.Update.Reload() end)
    uReload:SetPoint("RIGHT", ucard, "RIGHT", -14, 0)
    uReload.SetTint(color)
    W.Tip(uReload, L.UPD_RELOAD, L.UPD_RELOAD_TIP)

    -- --------------------------------------------------------- left: Blizzard file
    local left = W.Card(body, L.DATA_C_BLIZZ, color)
    left:SetPoint("TOPLEFT", ucard, "BOTTOMLEFT", 0, -10)
    left:SetPoint("BOTTOMRIGHT", body, "BOTTOM", -6, 0)
    local leftText = W.Text(left, "small", "LEFT")
    leftText:SetPoint("TOPLEFT", left, "TOPLEFT", 14, -36)
    leftText:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -14, 10)
    leftText:SetWordWrap(true)
    leftText:SetJustifyV("TOP")
    leftText:SetSpacing(3)

    -- --------------------------------------------------------- right top: coverage per day (columns: a count to compare)
    local cov = W.Card(body, L.DATA_C_COVER, color)
    cov:SetPoint("TOPLEFT", ucard, "BOTTOM", 6, -10)
    cov:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    cov:SetHeight(190)
    local chart = ns.Chart.Line(cov, true, true)
    chart:SetPoint("TOPLEFT", cov, "TOPLEFT", 8, -52)
    chart:SetPoint("BOTTOMRIGHT", cov, "BOTTOMRIGHT", -8, 40)
    local covNote = W.Text(cov, "tiny", "LEFT")
    covNote:SetPoint("BOTTOMLEFT", cov, "BOTTOMLEFT", 14, 10)
    covNote:SetPoint("RIGHT", cov, "RIGHT", -14, 0)
    covNote:SetWordWrap(true)
    covNote:SetJustifyV("BOTTOM")
    local covSub = W.Text(cov, "tiny", "LEFT")
    covSub:SetPoint("TOPLEFT", cov, "TOPLEFT", 14, -34)
    covSub:SetPoint("RIGHT", cov, "RIGHT", -14, 0)

    -- --------------------------------------------------------- right bottom: provenance + guild
    local prov = W.Card(body, L.DATA_C_PROV, color)
    prov:SetPoint("TOPLEFT", cov, "BOTTOMLEFT", 0, -10)
    prov:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    local provText = W.Text(prov, "small", "LEFT")
    provText:SetPoint("TOPLEFT", prov, "TOPLEFT", 14, -36)
    provText:SetPoint("BOTTOMRIGHT", prov, "BOTTOMRIGHT", -14, 10)
    provText:SetWordWrap(true)
    provText:SetJustifyV("TOP")
    provText:SetSpacing(3)

    -- one point a day: the pictures received (or, for an old file, the share of
    -- items priced), green when the day is full, amber when it is thin, red when
    -- it is nearly empty, grey when nothing came
    local function drawLine(s)
        local n = math.min(s and s.keep or 14, 30)
        local today = ns.Today()
        local items = {}
        for i = 1, n do
            local d = today - (n - i)
            local count, full = 0, 24
            if s then
                if s.anyCov then
                    for _, e in ipairs(s.houses) do count = math.max(count, e.cov[d] or 0) end
                else
                    -- old file: no picture counter, use the items that have a price that day
                    local m = 0
                    for _, e in ipairs(s.houses) do m = math.max(m, e.perDay[d] or 0) end
                    full = math.max(1, s.maxItems)
                    count = m
                end
            end
            local ratio = math.min(1, count / full)
            local col
            if count == 0 then col = { 0.5, 0.5, 0.55 }
            elseif ratio >= 0.8 then col = C.profit
            elseif ratio >= 0.35 then col = { 1, 0.65, 0.2 }
            else col = C.loss end
            local tip = (s and s.anyCov) and string.format(L.DATA_TIP_COV, count) or string.format(L.DATA_TIP_ITEMS, math.floor(ratio * 100 + 0.5))
            items[i] = { ratio * 24, dayText(d), tip, date("%d", d * DAY), col }
        end
        chart.Draw(s and items or {}, nil, L.DATA_NO_FILE_SHORT)
    end

    function page.Refresh()
        local s = analyse()
        local col, text = verdict(s)
        verdictText:SetText(col .. text .. "|r")

        -- the addon's version: current, a newer one exists, asked, ready to reload
        local ust, loaded, latest = ns.Update.State()
        local shown = ({
            current = L.UPD_CURRENT, unknown = L.UPD_UNKNOWN, available = L.UPD_AVAILABLE,
            asked = L.UPD_ASKED_STATE, ready = L.UPD_READY, error = L.UPD_ERROR,
        })[ust]
        uText:SetText(((ust == "current" or ust == "unknown") and "" or AMBER) .. string.format(shown, loaded or "?", latest or "?") .. "|r")
        uBtn:SetShown(ust == "available" or ust == "error")
        uReload:SetShown(ust == "asked" or ust == "ready")

        -- left: the Blizzard file
        local lines = {}
        if not s then
            lines[#lines + 1] = MUTED .. L.DATA_NONE .. "|r"
        else
            if s.origin then
                lines[#lines + 1] = string.format(L.DATA_SRC, s.origin .. (s.gen and (" #" .. s.gen) or ""))
            else
                lines[#lines + 1] = MUTED .. L.DATA_SRC_OLD .. "|r"
            end
            lines[#lines + 1] = string.format(L.DATA_FILE_AT, s.at and date("%d/%m %H:%M", s.at) or "?", ago(s.at))
            if s.synced then
                lines[#lines + 1] = string.format(L.DATA_SYNCED, ago(s.synced))
                if s.got then lines[#lines + 1] = string.format(L.DATA_GOT, ago(s.got)) end
            else
                lines[#lines + 1] = AMBER .. L.DATA_SYNC_UNKNOWN .. "|r"
            end
            lines[#lines + 1] = string.format(L.DATA_KEEP, s.keep)
            local state, task = companionState()
            if state == "ok" then
                lines[#lines + 1] = string.format(L.DATA_COMP_TASK, tostring(task))
            elseif state == "old" then
                lines[#lines + 1] = RED .. string.format(L.DATA_COMP_TASK_OLD, tostring(task), ns.COMPANION_TASK) .. "|r"
            else
                lines[#lines + 1] = RED .. L.DATA_COMP_TASK_UNKNOWN .. "|r"
            end
            lines[#lines + 1] = ""
            for _, e in ipairs(s.houses) do
                if e.nDays > 0 then
                    lines[#lines + 1] = string.format(L.DATA_HOUSE, e.id or "?", e.side, e.items, ago(e.at), e.nDays,
                        dayText(e.first), dayText(e.last))
                else
                    lines[#lines + 1] = string.format(L.DATA_HOUSE_NOHIST, e.id or "?", e.side, e.items, ago(e.at))
                end
            end
            lines[#lines + 1] = ""
            lines[#lines + 1] = MUTED .. string.format(L.DATA_VOLUME, math.floor(s.kb.items / 1024),
                math.floor(s.kb.lows / 1024), math.floor(s.kb.sales / 1024)) .. "|r"
        end
        leftText:SetText(table.concat(lines, "\n"))

        -- right top: coverage
        drawLine(s)
        if s then
            local present = 0
            local today = ns.Today()
            for d = today - s.keep + 1, today do
                local has = false
                for _, e in ipairs(s.houses) do
                    if (e.cov[d] or 0) > 0 or (e.perDay[d] or 0) > 0 then has = true break end
                end
                if has then present = present + 1 end
            end
            covSub:SetText(MUTED .. string.format(L.DATA_DAYS_WITH, present, s.keep) .. "|r")
            covNote:SetText(MUTED .. (s.anyCov and L.DATA_COVER_NOTE or L.DATA_COVER_OLDFMT) .. "|r")
        else
            covSub:SetText("")
            covNote:SetText("")
        end

        -- right bottom: provenance of the current prices, my history, the guild
        local out = {}
        local books = ns.db.scans or {}
        local rs = (s and s.ruleset) or (ns.Ruleset and (ns.Ruleset())) or "PvP"
        local shown = 0
        for _, side in ipairs(SIDES) do
            local key = tostring(rs) .. "-" .. side
            local b = books[key]
            if b and b.at then
                local n = 0
                for _ in pairs(b.items or {}) do n = n + 1 end
                out[#out + 1] = string.format(L.DATA_PROV_LINE, key, origin(b), ago(b.at), n)
                shown = shown + 1
            end
        end
        if shown == 0 then out[#out + 1] = MUTED .. L.DATA_NO_SCANS .. "|r" end
        out[#out + 1] = ""
        local mh = myHistory()
        if mh and mh.items > 0 and mh.first then
            out[#out + 1] = string.format(L.DATA_MYHIST, mh.items, mh.days, dayText(mh.first), dayText(mh.last))
        else
            out[#out + 1] = MUTED .. L.DATA_MYHIST_NONE .. "|r"
        end
        out[#out + 1] = ""
        if ns.db.share == false then
            out[#out + 1] = AMBER .. L.DATA_GUILD_OFF .. "|r"
        else
            local st = ns.Sync.Status()
            out[#out + 1] = string.format(L.DATA_GUILD, ago(ns.Sync.LastSync()), st.peers or 0, st.got or 0, st.sent or 0)
            local log = ns.Sync.Log()
            for i = 1, math.min(3, #log) do
                local e = log[i]
                if e.dir ~= "req" then
                    out[#out + 1] = MUTED .. date("%d/%m %H:%M", e.t) .. " " .. (e.dir == "in" and "<-" or "->") .. " "
                        .. (e.who or "?") .. " - " .. (e.text or "") .. "|r"
                end
            end
        end
        provText:SetText(table.concat(out, "\n"))
    end
end)
