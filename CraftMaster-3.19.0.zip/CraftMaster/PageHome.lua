local _, ns = ...
local L = ns.L
local W = ns.W

-- Page Accueil : les nouveautes de CraftMaster (journal des modifications,
-- CHANGELOG.md -> Data\Changelog.lua), avec un menu deroulant pour lire les
-- versions precedentes ; ce qui demande de l'attention (compagnon a
-- reinstaller, prix en retard) ; un resume de l'etat des donnees ; des
-- raccourcis. A chaque mise a jour, la fenetre s'ouvre dessus (UI.Open).

local MUTED = "|cff8c8c99"
local GREEN = "|cff59d973"
local AMBER = "|cffffa733"
local RED = "|cffff6060"
local GOLD = "|cfff2b53a"

local function ago(t)
    local G = ns.Gold
    if G and G.Ago then return G.Ago(t) end
    return t and date("%d/%m %H:%M", t) or L.GM_NEVER
end

local function frDate(iso)
    local y, m, d = tostring(iso or ""):match("^(%d+)-(%d+)-(%d+)$")
    if not y then return tostring(iso or "") end
    return d .. "/" .. m .. "/" .. y
end

-- ---------------------------------------------------------------- text wrapping
-- The rows of the list are one line each: long entries are cut by words,
-- keeping the color of a |c...|r span that runs over the cut.
local function charCount(s)
    local t = s:gsub("|c%x%x%x%x%x%x%x%x", "")
    t = t:gsub("|r", "")
    local _, n = t:gsub("[^\128-\191]", "")
    return n
end

local function wrap(text, width)
    local lines, cur, curLen, color = {}, "", 0, nil
    for word in tostring(text or ""):gmatch("%S+") do
        local wl = charCount(word)
        if curLen > 0 and curLen + 1 + wl > width then
            lines[#lines + 1] = cur .. (color and "|r" or "")
            cur, curLen = (color or ""), 0
        end
        if curLen > 0 then cur = cur .. " "; curLen = curLen + 1 end
        cur = cur .. word
        curLen = curLen + wl
        local pos = 1
        while true do
            local s = word:find("|[cr]", pos)
            if not s then break end
            if word:sub(s, s + 1) == "|c" then color = word:sub(s, s + 9); pos = s + 10
            else color = nil; pos = s + 2 end
        end
    end
    if cur ~= "" then lines[#lines + 1] = cur end
    return lines
end

-- The lines shown for one version: summary, then each section with its bullets.
local function versionLines(e, chars)
    local rows = {}
    for _, l in ipairs(wrap(e.summary, chars)) do rows[#rows + 1] = "|cffe6e6ec" .. l .. "|r" end
    for _, sec in ipairs(e.sections or {}) do
        if sec.items and #sec.items > 0 then
            rows[#rows + 1] = ""
            local c = sec.title == "Important" and AMBER or GOLD
            rows[#rows + 1] = c .. sec.title .. "|r"
            for _, it in ipairs(sec.items) do
                for i, l in ipairs(wrap(it, chars - 3)) do
                    rows[#rows + 1] = (i == 1 and "• " or "   ") .. l
                end
            end
        end
    end
    return rows
end

-- ---------------------------------------------------------------- page
ns.UI.AddPage("home", function(page)
    local body, color = page.body, page.color
    local C = ns.Theme.C
    local selected
    local changelog = ns.CHANGELOG or {}

    -- ----------------------------------------------------- the figures that matter
    local tiles = W.Tiles(body, 3, 50)
    tiles:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
    tiles:SetPoint("RIGHT", body, "RIGHT", 0, 0)

    -- ----------------------------------------------------- left: the news
    local left = W.Card(body, L.HOME_C_NEWS, color)
    left:SetPoint("TOPLEFT", tiles, "BOTTOMLEFT", 0, -10)
    left:SetPoint("BOTTOMRIGHT", body, "BOTTOM", 80, 0)

    local function versionItems()
        local out = {}
        for i, e in ipairs(changelog) do
            out[#out + 1] = { e.v, "v" .. e.v .. " · " .. frDate(e.date) .. (i == 1 and (" (" .. L.HOME_LATEST .. ")") or "") }
        end
        return out
    end
    local dropdown
    if #changelog > 0 then
        selected = changelog[1].v
        dropdown = W.Dropdown(left, 230, versionItems, function() return selected end, function(v)
            selected = v
            page.Refresh()
        end)
        dropdown:SetPoint("TOPRIGHT", left, "TOPRIGHT", -14, -6)
        dropdown:SetHeight(24)
    end

    local function makeRow(parent)
        local r = CreateFrame("Frame", nil, parent)
        r.text = W.Text(r, "small", "LEFT")
        r.text:SetAllPoints()
        r.text:SetWordWrap(false)
        return r
    end
    local news = W.List(left, 17, makeRow, function(r, line) r.text:SetText(line) end)
    news:SetPoint("TOPLEFT", left, "TOPLEFT", 14, -42)
    news:SetPoint("BOTTOMRIGHT", left, "BOTTOMRIGHT", -10, 10)
    news.Color(color)
    local empty = W.Text(left, "small", "LEFT")
    empty:SetPoint("TOPLEFT", left, "TOPLEFT", 14, -44)
    empty:SetText(MUTED .. L.HOME_NO_CHANGELOG .. "|r")
    empty:SetShown(#changelog == 0)

    -- ----------------------------------------------------- right: notices and first steps, summary, shortcuts
    local notice = W.Card(body, L.HOME_C_NOTICE, color)
    notice:SetPoint("TOPLEFT", tiles, "BOTTOM", 86, -10)
    notice:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    notice:SetHeight(190)
    local noticeText = W.Text(notice, "small", "LEFT")
    noticeText:SetPoint("TOPLEFT", notice, "TOPLEFT", 14, -36)
    noticeText:SetPoint("BOTTOMRIGHT", notice, "BOTTOMRIGHT", -14, 36)
    noticeText:SetWordWrap(true)
    noticeText:SetJustifyV("TOP")
    noticeText:SetSpacing(3)
    local hideSteps = W.Button(notice, L.HOME_STEPS_HIDE, 150, function()
        ns.db.onboarded = true
        page.Refresh()
    end)
    hideSteps:SetPoint("BOTTOMRIGHT", notice, "BOTTOMRIGHT", -12, 8)
    hideSteps:SetHeight(22)
    W.Tip(hideSteps, L.HOME_STEPS_HIDE, L.HOME_STEPS_HIDE_TIP)

    local go = W.Card(body, L.HOME_C_GO, color)
    go:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    go:SetPoint("LEFT", notice, "LEFT", 0, 0)
    go:SetHeight(84)
    local targets = { { "recipes", L.HOME_GO_RECIPES }, { "gmdeals", L.HOME_GO_DEALS }, { "scans", L.HOME_GO_SCANS }, { "settings", L.HOME_GO_SETTINGS } }
    local prev
    for _, t in ipairs(targets) do
        local b = W.Button(go, t[2], 100, function() ns.UI.Open(t[1]) end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 6, 0) else b:SetPoint("TOPLEFT", go, "TOPLEFT", 14, -40) end
        b.SetTint(ns.UI.Color(t[1]))
        prev = b
    end

    local summary = W.Card(body, L.HOME_C_SUMMARY, color)
    summary:SetPoint("TOPLEFT", notice, "BOTTOMLEFT", 0, -10)
    summary:SetPoint("BOTTOMRIGHT", go, "TOPRIGHT", 0, 10)
    local summaryText = W.Text(summary, "small", "LEFT")
    summaryText:SetPoint("TOPLEFT", summary, "TOPLEFT", 14, -36)
    summaryText:SetPoint("BOTTOMRIGHT", summary, "BOTTOMRIGHT", -14, 8)
    summaryText:SetWordWrap(true)
    summaryText:SetJustifyV("TOP")
    summaryText:SetSpacing(3)

    -- the good deals of the last scan of the house in front of me (Good deals):
    -- worked out a few per frame after the scan, the page redraws when ready
    local function deals()
        local house = ns.Scan.OpenHouse()
        if not ns.Scan.LastAt(house) then return nil, false end
        local ok, ds = pcall(ns.Gold.DealsSummary, house)
        return ok and ds or nil, true
    end

    local function safe(fn, ...)
        local ok, a, b = pcall(fn, ...)
        if ok then return a, b end
    end

    -- The first steps: make money in 3 moves. nil once they are done or hidden.
    local function firstSteps(DI)
        if ns.db.onboarded then return nil end
        local s = DI and safe(DI.Analyse)
        local st = ns.db.scanStats or {}
        local seen = ns.db.visited or {}
        local list = {
            { s ~= nil and #s.houses > 0, L.HOME_STEP_1 },
            { st.quick ~= nil or st.full ~= nil, L.HOME_STEP_2 },
            { seen.gmdeals == true, L.HOME_STEP_3 },
        }
        local lines, doneN = { GOLD .. L.HOME_STEPS_TITLE .. "|r" }, 0
        for _, st2 in ipairs(list) do
            if st2[1] then doneN = doneN + 1 end
            lines[#lines + 1] = (st2[1] and (GREEN .. L.HOME_STEP_DONE) or (AMBER .. L.HOME_STEP_TODO)) .. "|r " .. st2[2]
        end
        if doneN == #list then
            lines[#lines + 1] = GREEN .. L.HOME_STEPS_BRAVO .. "|r"
            ns.db.onboarded = true          -- shown this once, then it makes room
        end
        return lines
    end

    function page.Refresh()
        local DI = ns.DataInfo
        -- the news of the chosen version
        local entry
        for _, e in ipairs(changelog) do if e.v == selected then entry = e break end end
        if entry then
            local w = news:GetWidth()
            if not w or w < 100 then w = 520 end
            news.SetData(versionLines(entry, math.max(40, math.floor((w - 24) / 6.2))), true)
        else
            news.SetData({})
        end
        if dropdown then dropdown.Refresh() end

        -- what needs attention, then the first steps
        local lines = {}
        local state, task = "none", nil
        if DI then
            state, task = DI.CompanionState()
            if state == "old" then lines[#lines + 1] = RED .. string.format(L.HOME_ALERT_OLD, tostring(task), ns.COMPANION_TASK) .. "|r"
            elseif state == "unknown" then lines[#lines + 1] = RED .. L.HOME_ALERT_UNKNOWN .. "|r"
            elseif state == "none" then lines[#lines + 1] = AMBER .. L.HOME_ALERT_NONE .. "|r" end
            local ust = ns.Update.State()
            if ust == "available" or ust == "asked" then lines[#lines + 1] = AMBER .. L.HOME_ALERT_UPDATE .. "|r"
            elseif ust == "ready" then lines[#lines + 1] = AMBER .. L.HOME_ALERT_RELOAD .. "|r" end
            local col, text = DI.Verdict(DI.Analyse())
            if col ~= GREEN and state ~= "none" then lines[#lines + 1] = col .. text .. "|r" end
        end
        local steps = firstSteps(DI)
        if steps then
            if #lines > 0 then lines[#lines + 1] = "" end
            for _, l in ipairs(steps) do lines[#lines + 1] = l end
        end
        if #lines == 0 then lines[1] = GREEN .. L.HOME_ALL_GOOD .. "|r" end
        noticeText:SetText(table.concat(lines, "\n"))
        hideSteps:SetShown(steps ~= nil and not ns.db.onboarded)

        -- the figures
        local s = DI and safe(DI.Analyse)
        local ds, scanned = deals()
        if ds and ds.best then
            tiles.Set(1, L.HOME_T_DEAL, ns.ItemName(ds.best.itemID) .. "  +" .. ns.Money(ds.best.profit), C.profit)
        else
            tiles.Set(1, L.HOME_T_DEAL, not scanned and L.HOME_T_DEAL_NOSCAN or (ds and L.HOME_T_DEAL_NONE or L.HOME_T_WORKING), C.label)
        end
        local top = ds and ds.top or 0
        tiles.Set(2, L.HOME_T_COUNT, ds and tostring(top) or "-", top > 0 and C.profit or C.label)
        if s and s.houses and #s.houses > 0 then
            local newest = 0
            for _, e in ipairs(s.houses) do if (e.at or 0) > newest then newest = e.at end end
            local age = time() - newest
            tiles.Set(3, L.HOME_T_PRICES, ago(newest), age <= 3600 and C.profit or (age <= 3 * 3600 and C.amber or C.loss))
        else
            tiles.Set(3, L.HOME_T_PRICES, L.HOME_S_PRICES_NONE_SHORT, C.loss)
        end

        -- the rest, in words
        local out = {}
        out[#out + 1] = string.format(L.HOME_S_ADDON, ns.version, task and tostring(task) or "?")
        local profs = safe(ns.MyProfs)
        if type(profs) == "table" and #profs > 0 then out[#out + 1] = string.format(L.HOME_S_PROFS, table.concat(profs, ", "))
        else out[#out + 1] = L.HOME_S_PROFS_NONE end
        local mh = DI and safe(DI.MyHistory)
        if mh and mh.items and mh.items > 0 then out[#out + 1] = string.format(L.HOME_S_HIST, mh.items, mh.days or 0) end
        if ns.db.share == false then
            out[#out + 1] = L.HOME_S_GUILD_OFF
        else
            local st = safe(ns.Sync.Status) or {}
            out[#out + 1] = string.format(L.HOME_S_GUILD, st.peers or 0, ago(safe(ns.Sync.LastSync)))
        end
        summaryText:SetText(table.concat(out, "\n"))

        -- the news have been shown: the window stops opening here by itself
        ns.db.seenVersion = ns.version
    end
end)

-- At login: the companion to reinstall (red), the news of a new version.
ns.On("Login", function()
    C_Timer.After(12, function()
        local DI = ns.DataInfo
        local state = DI and DI.CompanionState and DI.CompanionState()
        if state == "old" or state == "unknown" then ns.Print("|cffff6060" .. L.HOME_ALERT_CHAT .. "|r") end
        if ns.db.seenVersion ~= ns.version then ns.Print(L.HOME_NEWS, ns.version) end
    end)
end)
