local _, ns = ...

-- Leveling guides worked out from the Auction House prices of now. Three
-- ways to pick the recipe at each skill point:
--   profit — the most gold back (or the least lost) once the crafts are sold
--            at the best of the Auction House and the vendor;
--   fast   — one skill point per craft, as near as it gets: only recipes that
--            give a point at least MIN_CHANCE (70 %) of the time, the surest
--            first (orange, then the surest yellow), the cheaper on a tie;
--            when no recipe reaches 70 % at a point, the surest one is used and
--            the step says so;
--   cheap  — for when there is no money for the reagents: what costs the
--            least once the crafts are sold to a vendor (the money comes back
--            at once), the smaller outlay on a tie.
-- The prices are checked: a resale price far above the usual one (a thin
-- market, a lone listing) is replaced by the usual price; an item with no
-- listing but a usual price is priced at it; recipes with a missing price are
-- left out and counted; the age of the scan is reported with the plan.
-- A recipe counts when it is known, or can be learned from a trainer, a
-- vendor, or bought at the Auction House (that price is paid once).
-- Skill-up chance: 100 % while orange, then (grey - skill) / (grey - yellow).
local G = {}
ns.Leveling = G

G.RANKS = { 75, 150, 225 }
G.MIN_CHANCE = 0.70      -- the fast way: at least this chance of a skill point per craft
G.SPIKE = 1.6            -- an Auction House price above this times the usual one is a spike
G.STALE = 24 * 3600      -- a scan older than this is reported as old

local function chance(sk, s)
    local yellow, grey = sk[3], sk[5]
    if s < yellow then return 1 end
    if s >= grey then return 0 end
    return (grey - s) / math.max(1, grey - yellow)
end
G.Chance = chance

-- The color of a recipe at a skill: 1 orange, 2 yellow, 3 green, 4 grey.
function G.Color(sk, s)
    if s < sk[3] then return 1 elseif s < sk[4] then return 2 elseif s < sk[5] then return 3 end
    return 4
end

local function learnable(id, r)
    if ns.Recipes.IsKnown(id) then return true, 0, nil end
    local how
    for _, s in ipairs(r.s or {}) do
        if s[1] == "T" then return true, 0, "T" end
        if s[1] == "V" then how = "V" end
        if s[1] == "C" and s[2] == "DEFAULT_RECIPE" then return true, 0, nil end
    end
    if how then return true, 0, how end
    if r.ri and not r.bop then
        local p = ns.Prices.AH(r.ri)
        if p then return true, p, "AH" end
    end
    return false
end

-- The price of a made item at the Auction House, checked against its usual price.
-- Returns price (or nil), and why it is not the plain listing: "usual" (no listing, the usual
-- price is used) or "spike" (the listing is far above the usual price: the usual one is used).
local function checkedAH(id)
    if not id then return nil end
    local p = ns.Prices.AH(id)
    local usual = ns.Deals and ns.Deals.Usual and ns.Deals.Usual(id, ns.House())
    if p and usual and usual > 0 and p > usual * G.SPIKE then return usual, "spike" end
    if p then return p end
    if usual then return usual, "usual" end
    return nil
end

-- A reagent: a merchant first, else the Auction House; with no listing but a usual price, that.
local function reagentPrice(id)
    local unit = ns.Prices.Cheapest(id)
    if unit then return unit end
    local usual = ns.Deals and ns.Deals.Usual and ns.Deals.Usual(id, ns.House())
    if usual then return usual, "usual" end
    return nil
end

-- Everything the guide needs to know about each usable recipe, once, and what was checked.
local function candidates(prof)
    local list = {}
    local check = { skipped = 0, usual = 0, spikes = 0 }
    local cut = 1 - ns.CutPct() / 100
    for id, r in pairs(ns.RECIPES) do
        if r.p == prof and r.sk and r.sk[5] and r.sk[5] > 0 and not r.spec then
            local ok, learnCost, how = learnable(id, r)
            local mats, out, n = ns.Recipes.Materials(id)
            if ok and mats then
                local cost, priced, guessed = 0, true, false
                for _, m in ipairs(mats) do
                    local unit, why = reagentPrice(m[1])
                    if not unit then priced = false break end
                    if why then guessed = true end
                    cost = cost + unit * m[2]
                end
                if priced then
                    local vendor = out and (ns.Prices.VendorSell(out) or 0) * (n or 1) or 0
                    local ah, why = checkedAH(out)
                    if why == "spike" then check.spikes = check.spikes + 1 elseif why == "usual" then check.usual = check.usual + 1 end
                    ah = ah and ah * (n or 1) * cut or 0
                    list[#list + 1] = { id = id, sk = r.sk, cost = cost, vendor = vendor, ah = ah, best = math.max(vendor, ah),
                                        learnCost = learnCost, how = how, known = ns.Recipes.IsKnown(id), guessed = guessed }
                else
                    check.skipped = check.skipped + 1
                end
            end
        end
    end
    return list, check
end

-- steps = { { from, to, id, crafts, cost, back, learnCost, how, color, rank, low } }
-- with rank set on the rows that are a trainer visit instead of a craft, low set when the
-- fast way found no recipe at 70 % there.
function G.Plan(prof, from, to, way)
    local list, check = candidates(prof)
    local picked = {}      -- recipes already paid for
    local steps = {}
    local cur
    local totalCost, totalBack, totalCrafts, gap, lowAt = 0, 0, 0, nil, 0
    for s = from, to - 1 do
        for _, rank in ipairs(G.RANKS) do
            if s == rank and from < rank then
                steps[#steps + 1] = { rank = rank }
                cur = nil
            end
        end
        local best, bestScore, bestN, bestLow
        -- the fast way: recipes that give a point 70 % of the time or better; none: the surest
        local sure = false
        if way == "fast" then
            for _, c in ipairs(list) do
                if c.sk[1] <= s and s < c.sk[5] and chance(c.sk, s) >= G.MIN_CHANCE then sure = true break end
            end
        end
        for _, c in ipairs(list) do
            if c.sk[1] <= s and s < c.sk[5] then
                local p = chance(c.sk, s)
                if p > 0 and (way ~= "fast" or not sure or p >= G.MIN_CHANCE) then
                    local n = 1 / p
                    local extra = picked[c.id] and 0 or c.learnCost
                    local score
                    if way == "fast" then
                        -- the fewest crafts per point first; on a tie the smaller net cost, learning included
                        score = n * 1e7 + n * (c.cost - c.vendor) + extra
                    elseif way == "cheap" then
                        -- the least money lost once sold to a vendor; the smaller outlay on a tie
                        score = n * (c.cost - c.vendor) + extra + c.cost * 1e-6
                    else
                        score = n * (c.cost - c.best) + extra
                    end
                    if not bestScore or score < bestScore then best, bestScore, bestN, bestLow = c, score, n, (way == "fast" and not sure) end
                end
            end
        end
        if not best then
            gap = gap or s
            cur = nil
        else
            if bestLow then lowAt = lowAt + 1 end
            if not picked[best.id] then
                picked[best.id] = true
                totalCost = totalCost + best.learnCost
            end
            if cur and cur.id == best.id then
                cur.to = s + 1
                cur.exact = cur.exact + bestN
                cur.low = cur.low or bestLow
            else
                cur = { from = s, to = s + 1, id = best.id, exact = bestN, unit = best.cost,
                        back = (way == "cheap" or way == "fast") and best.vendor or best.best, bestBack = best.best,
                        learnCost = (best.known or best.learnCost == 0) and 0 or best.learnCost, how = (not best.known) and best.how or nil,
                        color = G.Color(best.sk, s), sk = best.sk, low = bestLow, guessed = best.guessed }
                steps[#steps + 1] = cur
            end
        end
    end
    local peak = 0
    for _, st in ipairs(steps) do
        if st.id then
            st.crafts = math.ceil(st.exact - 1e-9)
            st.cost = st.crafts * st.unit
            st.sold = st.crafts * st.back
            totalCost = totalCost + st.cost
            totalBack = totalBack + st.sold
            totalCrafts = totalCrafts + st.crafts
            peak = math.max(peak, st.cost + (st.learnCost or 0))     -- the most to have in hand for one step
        end
    end
    -- the Auction House data the plan rests on
    local at = ns.Prices.LastScan and ns.Prices.LastScan()
    check.age = at and (time() - at) or nil
    check.stale = (not check.age) or check.age > G.STALE
    return { steps = steps, cost = totalCost, back = totalBack, crafts = totalCrafts, gap = gap, way = way,
             prof = prof, from = from, to = to, peak = peak, lowAt = lowAt, check = check }
end

-- The stops of a route for the plan: the trainer (for recipes and ranks)
-- and the vendors of the recipes to buy.
function G.Route(plan)
    local stops = {}
    local needTrainer = false
    for _, st in ipairs(plan.steps) do
        if st.rank or st.how == "T" then needTrainer = true end
    end
    if needTrainer then
        local t = ns.Map.Nearest(ns.Map.Trainers(plan.prof))
        if t then stops[#stops + 1] = t end
    end
    for _, st in ipairs(plan.steps) do
        if st.how == "V" then
            local pins = {}
            for _, line in ipairs(ns.Recipes.Sources(st.id)) do
                if line.kind == "V" and line.pins then for _, p in ipairs(line.pins) do pins[#pins + 1] = p end end
            end
            local p = ns.Map.Nearest(pins)
            if p then stops[#stops + 1] = p end
        end
    end
    return stops
end
