local _, ns = ...
local L = ns.L

-- Buying at the Auction House, one click at a time (the game only allows a
-- purchase inside a click). A material sold by the unit (a commodity) takes
-- two clicks: the first asks the game for the real price, the second buys at
-- that price. Anything else is searched, then the cheapest buyout is bought
-- on the second click. A purchase that was sent is never sent again.
-- An item (not a commodity) can also take a bid: the auction with the lowest
-- next bid is chosen on the first click, the bid is placed on the second; the
-- item comes by mail if nobody bids more before the end.
local B = {}
ns.Buy = B

B.ahOpen = false
local state -- { id, qty, step = "quote" | "confirm" | "sent", unit, total, kind, auctionID, expected, bid }

local function finish(ok, reason)
    local s = state
    state = nil
    if s and not ok and reason then ns.Print(L.BUY_FAIL, L.BUY_WHY[reason] or reason) end
    ns.Fire("BuyChanged")
end

-- a price shown and never confirmed: dropped after 90 s, so that it does not block
-- every other purchase (the buttons stay greyed while one waits)
local function lapse(s)
    s.asked = (s.asked or 0) + 1
    local mine = s.asked
    C_Timer.After(90, function()
        if state == s and s.step == "confirm" and s.asked == mine then
            if s.kind == "commodity" and C_AuctionHouse.CancelCommoditiesPurchase then pcall(C_AuctionHouse.CancelCommoditiesPurchase) end
            ns.Print(L.BUY_EXPIRED, ns.ItemName(s.id))
            finish(false, nil)
        end
    end)
end

function B.State() return state end
function B.Busy() return state ~= nil end
function B.IsFor(id) return state and state.id == id end

local function isCommodity(id)
    if C_AuctionHouse and C_AuctionHouse.GetItemCommodityStatus then
        local ok, st = pcall(C_AuctionHouse.GetItemCommodityStatus, id)
        if ok and st == 2 then return true end
        if ok and st == 1 then return false end
    end
    local i = ns.Item(id)
    return (i and i.stack or 1) > 1
end
B.IsCommodity = isCommodity

local SORTS = { { sortOrder = 0, reverseSort = false } }   -- cheapest first
local SEARCH_TRIES = 4

-- The last purchase, step by step, for /craftmaster diag (what the game answered).
local trace = {}
local function note(fmt, ...)
    trace[#trace + 1] = string.format(fmt, ...)
    if #trace > 14 then table.remove(trace, 1) end
end
function B.Trace() return trace end
local function keyText(k)
    if type(k) ~= "table" then return tostring(k) end
    return string.format("%s/%s/%s", tostring(k.itemID), tostring(k.itemLevel), tostring(k.itemSuffix))
end

-- The listings of an item, found the way the Auction House's own window finds
-- them: a search by name lists the item with its exact key (a weapon or an
-- armour carries its item level in it), then that key is searched.
local function searchKey(s)
    if state ~= s or s.step ~= "quote" then return end
    s.tries = (s.tries or 0) + 1
    s.sub = "search"
    note("search %s (try %d)", keyText(s.key), s.tries)
    local ok, err = pcall(C_AuctionHouse.SendSearchQuery, s.key, SORTS, true)
    if not ok then note("search error %s", tostring(err)); finish(false, tostring(err)) end
end
local function searchItem(s)
    if state ~= s or s.step ~= "quote" then return end
    local name = ns.Item(s.id).name
    if name and C_AuctionHouse.SendBrowseQuery then
        s.sub = "browse"
        note("browse \"%s\"", name)
        local ok, err = pcall(C_AuctionHouse.SendBrowseQuery, { searchString = name, sorts = {}, filters = {}, itemClassFilters = {} })
        if ok then return end
        note("browse error %s", tostring(err))
    end
    s.key = C_AuctionHouse.MakeItemKey(s.id)
    searchKey(s)
end
local function onBrowse()
    local s = state
    if not (s and s.kind == "item" and s.step == "quote" and s.sub == "browse") then return end
    local ok, results = pcall(C_AuctionHouse.GetBrowseResults)
    if not ok or type(results) ~= "table" then results = {} end
    local best
    for _, r in ipairs(results) do
        local k = r and r.itemKey
        if k and k.itemID == s.id and (not best or (r.minPrice or 0) < (best.minPrice or 0)) then best = r end
    end
    note("browse: %d results, mine %s", #results, best and keyText(best.itemKey) or "none")
    if best then s.key = best.itemKey; searchKey(s) return end
    if C_AuctionHouse.HasFullBrowseResults and not C_AuctionHouse.HasFullBrowseResults() then
        pcall(C_AuctionHouse.RequestMoreBrowseResults)
        return
    end
    s.key = C_AuctionHouse.MakeItemKey(s.id)   -- not found by its name: the item alone
    searchKey(s)
end
ns.Register("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", onBrowse)
ns.Register("AUCTION_HOUSE_BROWSE_RESULTS_ADDED", onBrowse)

-- First click. bid: a bid on the item instead of its buyout (not for a commodity).
-- ctx: where it comes from (the tab, what it aims at), handed on to "Bought" for My operations.
function B.Start(id, qty, maxUnit, bid, ctx)
    if not B.ahOpen then ns.Print(L.BUY_AH_CLOSED) return false end
    if state or not id or not qty or qty <= 0 then return false end
    -- a scan browses the house: an item searched now would mix with it (a commodity does not)
    if ns.Scan.Running() and (bid or not isCommodity(id)) then ns.Print(L.BUY_SCANNING) return false end
    local expected = ns.Prices.AH(id)
    if bid and isCommodity(id) then ns.Print(L.BUY_NO_BID_COMMODITY) return false end
    if not bid and isCommodity(id) then
        state = { id = id, qty = qty, step = "quote", kind = "commodity", expected = expected, max = maxUnit, ctx = ctx }
        local ok, err = pcall(C_AuctionHouse.StartCommoditiesPurchase, id, qty)
        if not ok then finish(false, tostring(err)) return false end
    else
        state = { id = id, qty = 1, step = "quote", kind = "item", expected = expected, max = maxUnit, bid = bid and true or nil, ctx = ctx }
        trace = {}
        note("start %d, %s", id, bid and "bid" or "buyout")
        searchItem(state)
        if not state then return false end
    end
    local mine = state
    C_Timer.After(12, function()
        if state == mine and state.step == "quote" then finish(false, "timeout") end
    end)
    ns.Fire("BuyChanged")
    return true
end

-- Second click: buy at the price shown.
function B.Confirm()
    if not state or state.step ~= "confirm" then return false end
    local s = state
    local ok, err
    if s.kind == "commodity" then
        ok, err = pcall(C_AuctionHouse.ConfirmCommoditiesPurchase, s.id, s.qty)
    else
        ok, err = pcall(C_AuctionHouse.PlaceBid, s.auctionID, s.total)
    end
    if not ok then finish(false, tostring(err)) return false end
    s.step = "sent"
    C_Timer.After(15, function()
        if state ~= s or s.step ~= "sent" then return end
        -- a bid the game did not confirm out loud: say it was sent, not that it failed
        if s.bid then ns.Print(L.BUY_BID_SENT, ns.Money(s.total), ns.ItemName(s.id)); ns.Fire("BidPlaced", s.id, s.total, s.ctx); finish(true)
        else finish(false, "timeout") end
    end)
    ns.Fire("BuyChanged")
    return true
end

function B.Cancel()
    if not state then return end
    if state.kind == "commodity" and state.step == "confirm" and C_AuctionHouse.CancelCommoditiesPurchase then
        pcall(C_AuctionHouse.CancelCommoditiesPurchase)
    end
    finish(false, nil)
end

-- How much more than usual, in % (nil when there's nothing to compare to).
function B.Overprice()
    if not state or not state.unit or not state.expected or state.expected <= 0 then return nil end
    return math.floor(state.unit / state.expected * 100 + 0.5)
end

ns.Register("COMMODITY_PRICE_UPDATED", function(unit, total)
    if not state or state.kind ~= "commodity" then return end
    if state.step == "quote" or state.step == "confirm" then
        if state.step == "quote" then lapse(state) end
        state.unit, state.total, state.step = unit, total, "confirm"
        local pct = B.Overprice()
        if pct and pct >= (ns.db.warn or 150) then ns.Print(L.BUY_EXPENSIVE, ns.ItemName(state.id), pct) end
        state.tooHigh = state.max and unit and unit > state.max or nil
        if state.tooHigh then ns.Print(L.BUY_OVER_MAX, ns.Money(unit), ns.Money(state.max)) end
        ns.Fire("BuyChanged")
    end
end)
ns.Register("COMMODITY_PRICE_UNAVAILABLE", function()
    if state and state.kind == "commodity" then finish(false, "unavailable") end
end)
ns.Register("COMMODITY_PURCHASE_SUCCEEDED", function()
    if not state or state.kind ~= "commodity" then return end
    local s = state
    ns.Print(L.BUY_DONE, s.qty, ns.ItemName(s.id), ns.Money(s.total))
    ns.Fire("Bought", s.id, s.qty, s.total, s.ctx)
    finish(true)
end)
ns.Register("COMMODITY_PURCHASE_FAILED", function()
    if state and state.kind == "commodity" then finish(false, "failed") end
end)

ns.Register("ITEM_SEARCH_RESULTS_UPDATED", function(itemKey)
    if not state or state.kind ~= "item" or state.step ~= "quote" or state.sub ~= "search" then return end
    if type(itemKey) == "table" and itemKey.itemID and itemKey.itemID ~= state.id then return end
    -- the game sometimes answers "nothing" while the listings are there: ask again
    local AH = C_AuctionHouse
    local n = AH.GetNumItemSearchResults and AH.GetNumItemSearchResults(itemKey) or 0
    if AH.HasSearchResults and AH.HasFullItemSearchResults and AH.GetItemSearchResultsQuantity then
        local has, full = AH.HasSearchResults(itemKey), AH.HasFullItemSearchResults(itemKey)
        local qty = AH.GetItemSearchResultsQuantity(itemKey) or 0
        note("results %s: has %s, full %s, quantity %d, listings %d", keyText(itemKey), tostring(has), tostring(full), qty, n)
        if (not has or (not full and qty == 0)) and (state.tries or 0) < SEARCH_TRIES then
            local s = state
            C_Timer.After(0.3, function() searchKey(s) end)
            return
        end
    else
        note("results %s: listings %d", keyText(itemKey), n)
    end
    local best
    for i = 1, n do
        local r = C_AuctionHouse.GetItemSearchResultInfo(itemKey, i)
        -- a bid: what the next bid must be (minBid); a buyout: the buyout price
        local price = r and (state.bid and r.minBid or r.buyoutAmount)
        -- the price shown by the Auction House is already the price of one: the
        -- cheapest the way it sorts them, and at the same price the smallest lot
        -- (dividing by the quantity took a lot of 7 at 19 for cheaper than one at 15)
        if price and price > 0 and not r.containsOwnerItem then
            local q = r.quantity or 1
            if not best or price < best.each or (price == best.each and q < (best.r.quantity or 1)) then
                best = { r = r, each = price, price = price }
            end
        end
    end
    if not best then
        local r1 = n > 0 and C_AuctionHouse.GetItemSearchResultInfo(itemKey, 1)
        if r1 then note("first listing: buyout %s, bid %s, minBid %s, mine %s", tostring(r1.buyoutAmount), tostring(r1.bidAmount),
            tostring(r1.minBid), tostring(r1.containsOwnerItem)) end
        finish(false, state.bid and L.BUY_NO_BID or "unavailable")
        return
    end
    note("chosen auction %s at %s", tostring(best.r.auctionID), tostring(best.price))
    state.auctionID = best.r.auctionID
    -- the exact item of the auction (an item "of the eagle" has its stats in its link only)
    if type(best.r.itemLink) == "string" then
        state.ctx = state.ctx or {}
        state.ctx.link = best.r.itemLink
    end
    state.total = best.price
    state.timeLeft = best.r.timeLeft
    -- Forever shows the same auctions on one line (quantity 4: four auctions);
    -- PlaceBid buys one of them, at the price shown: one item when it does not stack
    local stack = (ns.Item(state.id) or {}).stack or 1
    state.qty = stack > 1 and (best.r.quantity or 1) or 1
    state.unit = best.each
    state.tooHigh = state.max and best.each > state.max or nil
    state.step = "confirm"
    lapse(state)
    ns.Fire("BuyChanged")
end)
-- a bid placed: the item is not mine yet (it comes by mail if nobody bids more)
local function bidPlaced()
    if not (state and state.bid and state.step == "sent") then return end
    ns.Print(L.BUY_BID_DONE, ns.Money(state.total), ns.ItemName(state.id))
    ns.Fire("BidPlaced", state.id, state.total, state.ctx)
    finish(true)
end
ns.Register("BID_ADDED", bidPlaced)
ns.Register("BIDS_UPDATED", bidPlaced)

ns.Register("AUCTION_HOUSE_PURCHASE_COMPLETED", function(auctionID)
    if not state or state.kind ~= "item" or state.bid or state.auctionID ~= auctionID then return end
    local s = state
    ns.Print(L.BUY_DONE, s.qty, ns.ItemName(s.id), ns.Money(s.total))
    ns.Fire("Bought", s.id, s.qty, s.total, s.ctx)
    finish(true)
end)
ns.Register("AUCTION_HOUSE_SHOW_ERROR", function()
    if state and state.step == "sent" and state.kind == "item" then finish(false, "failed") end
end)

ns.Register("AUCTION_HOUSE_SHOW", function()
    B.ahOpen = true
    ns.Fire("BuyChanged")
end)
ns.Register("AUCTION_HOUSE_CLOSED", function()
    B.ahOpen = false
    if state then finish(false, "closed") else ns.Fire("BuyChanged") end
end)
